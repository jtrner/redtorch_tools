import os
import sys
import shutil
import json
import rig_factory
import rig_factory.objects as obs
import time

framework_directory = os.path.dirname(os.path.dirname(rig_factory.__file__.replace('\\', '/')))
parts_directory = '%s/part_library' % framework_directory
part_versions_directory = '%s/versions' % parts_directory
part_versions_json_path = '%s/versions.json' % part_versions_directory


def get_subclasses(base_class):
    sub_classes = list(base_class.__subclasses__())
    for sub_class in sub_classes:
        sub_classes.extend(get_subclasses(sub_class))
    return sub_classes


def contains_source_code(directory):
    for x in os.listdir(directory):
        if x.endswith('.py'):
            return True
    return False


def generate_versions_data(root_directory, data=None):
    if data is None:
        data = dict()
    for item in os.listdir(root_directory):
        item_path = '%s/%s' % (root_directory, item)
        if item.endswith('.py'):
            sys.path.insert(0, root_directory)
            part_name = root_directory.split('/')[-2]
            module_name = item.replace('.py', '')
            module = __import__(module_name, fromlist=['.'])
            if hasattr(module, '__version__'):
                version_data = dict(
                    path=item_path.replace(part_versions_directory, ''),
                )
                for p in ['developer', 'email', 'notes']:
                    version_data[p] = getattr(module, '__%s__' % p)
                version_data['created'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(item_path)))
                data.setdefault(part_name, dict())[module.__version__] = version_data
            sys.modules.pop(module_name)
            sys.path.pop(0)
        elif os.path.isdir(item_path):
            generate_versions_data(
                item_path,
                data
            )
    return data


def deploy_part_versions():
    if not os.path.exists(part_versions_directory):
        os.makedirs(part_versions_directory)
    for module_name in list(set([x.__module__ for x in get_subclasses(obs.BasePart)])):
        pyc_path = '%s/%s.pyc' % (framework_directory, '/'.join(module_name.split('.')))
        if os.path.exists(pyc_path):
            os.remove(pyc_path)
        module = __import__(module_name, fromlist=['.'])
        if hasattr(module, '__version__'):
            local_folder = '/'.join(module.__name__.split('.')[2:])

            version_directory = '%s/%s/%s_%s' % (
                part_versions_directory,
                local_folder,
                module_name.split('.')[-1],
                module.__version__
            )
            if not os.path.exists(version_directory):
                os.makedirs(version_directory)
            module_short_name = os.path.basename(module.__file__).split('.')[0]
            source_file = module.__file__.replace('.pyc', '.py')
            if os.path.exists(source_file):
                file_name = '%s.py' % module_short_name
                file_path = '%s/%s' % (version_directory, file_name)
                if not os.path.exists(file_path):
                    print file_path
                    shutil.copy(source_file, file_path)

    with open(part_versions_json_path, mode='w') as f:
        json.dump(
            generate_versions_data(part_versions_directory),
            f,
            sort_keys=True,
            indent=4,
            separators=(',', ': ')
        )


if __name__ == '__main__':
    deploy_part_versions()