import os
import glob
import rig_factory


def get_standard_build_script_path():
    return '%s/build/build.py' % os.path.dirname(rig_factory.__file__.replace('\\', '/'))


def get_base_directory():
    return '%s%s' % (
        os.environ['SERVER_BASE'].replace('\\', '/'),
        os.environ['TT_PROJCODE'],
    )


def get_all_users_work_scenes():
    """
    Get all users work files (.ma)
    """
    work_scenes = []
    for work_dir in get_all_users_work_directories():
        user_scenes = [x.replace('\\', '/') for x in glob.glob(
            '%s/%s_rig_v*.ma' % (
                work_dir,
                os.environ['TT_ENTNAME']
            )
        )]
        if user_scenes:
            work_scenes.extend(user_scenes)
    return sorted(work_scenes, key=lambda x: os.path.basename(x))


def get_next_versions(major_version_up=False):
    """
    get the next major and minor version strings based on ALL user work files
    """
    major_version, minor_version = get_current_work_versions()
    product_version = get_latest_product_version()
    if int(product_version) > int(major_version):
        major_version = str(int(product_version) + 1).zfill(4)
        minor_version = '0001'

    if major_version_up:
        major_version = str(int(major_version) + 1).zfill(4)
        minor_version = '0001'
    else:
        minor_version = str(int(minor_version) + 1).zfill(4)

    return [major_version, minor_version]


def get_current_work_versions():
    """
    get the current major and minor version strings based on ALL user work files
    """
    work_scenes = get_all_users_work_scenes()
    if not work_scenes:
        return ['0001', '0001']
    latest_work_scene = work_scenes[-1]
    major_verson = os.path.basename(latest_work_scene).split('rig_v')[-1].split('.')[0]
    minor_version = os.path.basename(latest_work_scene).split('rig_v')[-1].split('.')[1]
    return [major_verson, minor_version]


def get_latest_product_version():
    list_of_files = glob.glob(
        '%s/%s_rig_v*.ma' % (
            '%s/%s/%s' % (
                os.environ['SERVER_BASE'],
                os.environ['TT_PROJCODE'],
                ''
            ),
            os.environ['TT_ENTNAME']
        )
    )
    if not list_of_files:
        return '0000'
    latest_file = sorted(list_of_files, key=lambda x: os.path.basename(x))[-1]
    return os.path.basename(latest_file).split('rig_v')[-1].split('.')[0]


def get_pipeline_directory():
    return '%s/assets/type/%s/%s/pipeline' % (
        get_base_directory(),
        os.environ['TT_ASSTYPE'],
        os.environ['TT_ENTNAME']
    )


def get_logs_directory():
    return '%s/logs' % get_pipeline_directory()


def get_work_directory():
    return '%s/assets/type/%s/%s/work' % (
        get_base_directory(),
        os.environ['TT_ASSTYPE'],
        os.environ['TT_ENTNAME']
    )


def get_all_users_work_directories():
    work_rig_directory = '%s/rig/Maya' % get_work_directory()
    user_work_dirs = []
    for user in os.listdir(work_rig_directory):
        item_path = '%s/%s' % (work_rig_directory, user)
        if os.path.isdir(item_path):
            user_work_dirs.append(item_path)
    return user_work_dirs


def get_user_work_directory():
    return '%s/rig/Maya/%s' % (
        get_work_directory(),
        os.environ['USERNAME']
    )


def get_user_build_directory():
    return '%s/build' % (
        get_user_work_directory()
    )


def get_products_directory():
    return '%s/assets/type/%s/%s/products' % (
        get_base_directory(),
        os.environ['TT_ASSTYPE'],
        os.environ['TT_ENTNAME']
    )


def get_scene_cache_directory():
    return '%s/scene_cache' % get_elems_directory()


def get_elems_directory():
    return '%s/elems' % (
        get_work_directory()
    )


def get_gen_elems_directory():
    return '%s/assets/gen_elems' % (
        get_base_directory()
    )


def get_abc_directory():
    return '%s/abc' % get_products_directory()


def get_latest_abc():
    abc_directory = get_abc_directory()
    if os.path.exists(abc_directory):
        list_of_files = glob.glob('%s/*.abc' % abc_directory)
        if list_of_files:
            latest_file = max(list_of_files, key=os.path.getctime)
            return latest_file.replace('\\', '/')


def get_latest_product_directory():
    rig_build_directory = '%s/rig_build' % get_products_directory()
    list_of_directories = [x.replace('\\', '/') for x in glob.glob(
        '%s/rig_build_v*' % (
            rig_build_directory
        )
    )]
    if list_of_directories:
        return sorted(list_of_directories, key=lambda x: os.path.basename(x))[-1]


def get_project_config_path():
    return 'G:/Rigging/Shows/%s/show_config.json' % os.environ.get('TT_PROJCODE')
