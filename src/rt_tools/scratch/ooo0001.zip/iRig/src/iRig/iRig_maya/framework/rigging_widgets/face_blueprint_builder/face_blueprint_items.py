
class DataItem(object):

    def __init__(self, name, data=None, parent=None):
        super(DataItem, self).__init__()
        if parent is not None and not isinstance(parent, DataItem):
            raise StandardError('Invalud parent type "%s"' % type(parent))
        self.data = data
        self.name = name
        self.parent = parent
        self.children = []
        if parent:
            parent.children.append(self)

    def __repr__(self):
        return '%s(name="%s")' % (self.__class__.__name__, self.name)

    def insert_child(self, index, child):
        self.children.insert(index, child)
        child.parent = self

    def add_child(self, child):
        self.children.append(child)
        child.parent = self

class FaceNetworkItem(DataItem):

    def __init__(self, *args, **kwargs):
        super(FaceNetworkItem, self).__init__(*args, **kwargs)


class FaceGroupItem(DataItem):

    def __init__(self, *args, **kwargs):
        super(FaceGroupItem, self).__init__(*args, **kwargs)


class FaceTargetItem(DataItem):

    def __init__(self, *args, **kwargs):
        super(FaceTargetItem, self).__init__(*args, **kwargs)


def build_items(data, parent=None, index=None):
    groups_data = data.get('groups', None)
    targets_data = data.get('targets', None)
    if groups_data is not None:
        new_item = FaceNetworkItem(
            data.get('name', data['root_name']),
            data=data,
            parent=parent
        )
        for group_data in groups_data:
            build_items(
                group_data,
                parent=new_item
            )
    elif targets_data is not None:
        new_item = FaceGroupItem(
            data.get('name', data['root_name']),
            data=data
        )
        if parent:
            if index:
                parent.insert_child(index, new_item)
            else:
                parent.add_child(new_item)
        if targets_data:
            for target_data in targets_data:
                build_items(
                    target_data,
                    parent=new_item
                )
    else:
        FaceTargetItem(
            data.get('driver_value', 'unknown driver value ??'),
            data=data,
            parent=parent
        )


