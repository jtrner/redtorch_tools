import copy
from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
from qtpy.QtWidgets import *
from database_tree_model import DatabaseTreeModel
from database_data_model import DatabaseDataModel
from database_tree_view import DatabaseTreeView
from database_data_view import DatabaseDataView
import rigging_widgets.blueprint_builder.environment as env
import rigging_database.session as ses
import rigging_database.table_objects as tob
session = ses.initialize_session('G:/Rigging/.rigging/project_data.db')


class DatabaseWidget(QFrame):

    data_signal = Signal(list)

    def __init__(self, *args, **kwargs):
        super(DatabaseWidget, self).__init__(*args, **kwargs)
        self.root_layout = QVBoxLayout(self)
        self.stacked_layout = QStackedLayout()
        self.menu_layout = QHBoxLayout()
        self.blueprint_view = DatabaseTreeView(self)
        self.blueprint_data_view = DatabaseDataView(self)
        self.splitter_widget = QSplitter(self)
        # self.project_combo_box = QComboBox(self)
        self.project_label = QLabel(self)
        self.splitter_widget.addWidget(self.blueprint_view)
        self.splitter_widget.addWidget(self.blueprint_data_view)
        self.menu_bar = QMenuBar(self)
        self.root_layout.addLayout(self.menu_layout)
        self.root_layout.addLayout(self.stacked_layout)
        self.stacked_layout.addWidget(self.splitter_widget)
        # self.menu_layout.addWidget(self.project_combo_box)
        self.menu_layout.addWidget(self.project_label)
        edit_menu = self.menu_bar.addMenu(QIcon('%s/hamburger.png' % env.images_directory), '&Edit')
        reload_action = QAction("&Reload", self)
        reload_action.toggled.connect(self.load_projects)
        edit_menu.addAction(reload_action)
        self.menu_layout.addStretch()
        self.menu_layout.addWidget(self.menu_bar)
        self.load_projects()
        # self.project_combo_box.setMinimumSize(QSize(65, 22))
        #  Styling
        font = QFont('', 15, True)
        self.project_label.setFont(font)

        #  Signals
        self.blueprint_view.items_selected_signal.connect(self.blueprint_data_view.load_items)
        # self.project_combo_box.currentIndexChanged.connect(self.update_project)

    def load_projects(self):
        root = tob.ProjectRoot()
        root.projects = list(session.query(tob.Project))
        for project in root.projects:
            project.project_root = root
        model = DatabaseTreeModel(root)
        self.blueprint_view.setModel(model)

    def update_project(self, *args):
        combo_text = self.project_combo_box.currentText()
        if combo_text:
            project = session.query(tob.Project).filter(tob.Project.sg_code == combo_text).first()
            if project:
                self.project_label.setText(project.name)

    def set_god_mode(self, value):
        self.blueprint_data_view.set_god_mode(value)

    def emit_data(self):
        model = self.blueprint_view.model()
        if not model:
            raise StandardError('No Model Found')
        if not model.root:
            raise StandardError('No Root')
        if not model.root.children:
            raise StandardError('No Rig')
        self.data_signal.emit(copy.deepcopy(model.root.children[0].data))
