from qtpy.QtWidgets import *

class SideDelegate(QStyledItemDelegate):
    pass