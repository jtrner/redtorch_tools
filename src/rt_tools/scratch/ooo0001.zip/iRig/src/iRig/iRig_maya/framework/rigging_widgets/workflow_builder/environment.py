import os

root_package_directory = os.path.dirname(__file__.replace('\\', '/'))

images_directory = '%s/static/icons' % root_package_directory
