import sys
import os
batch_tasks_directory = 'D:/pipeline/paxtong/dev/git_repo/irig/src/iRig/iRig_maya/framework/batch_tasks'
if not os.path.exists(batch_tasks_directory):
    batch_tasks_directory = 'G:/Rigging/.rigging/iRig/iRig_1.84.0/src/iRig/iRig_maya/framework/batch_tasks'
if batch_tasks_directory not in sys.path:
    sys.path.insert(0, batch_tasks_directory)

import batch_build as bbd

def auto_build_rig(project, entity, dev_mode=False, publish=False, comment=None, build_work=False):
    bbd.build_rig(
        project,
        entity,
        dev_mode=dev_mode,
        publish=publish,
        comment=comment,
        build_work=build_work
    )
