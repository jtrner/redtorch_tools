import os
from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.node_objects.transform import Transform


def import_geometry(controller, path, parent=None):
    root_nodes = controller.scene.import_geometry(path)
    if root_nodes:
        new_geometry = dict()
        for geometry_root in [controller.initialize_node(x, parent=parent) for x in root_nodes]:
            shapes = get_shape_descendants(controller, geometry_root)
            new_geometry.update(dict((x.name, x) for x in shapes if isinstance(x, Mesh)))
            controller.scene.select(cl=True)
        return new_geometry
    else:
        print 'Warning ! No geometry roots found in %s' % path


def get_shape_descendants(controller, node):
    mesh_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='mesh',
        f=True
    )
    nurbs_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='nurbsSurface',
        f=True
    )
    descendants = []
    if mesh_relatives:
        descendants = [controller.initialize_node(x, parent=node) for x in mesh_relatives]
    if nurbs_relatives:
        descendants = [controller.initialize_node(x, parent=node) for x in nurbs_relatives]
    transform_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='transform',
        f=True
    )
    if transform_relatives:
        transforms = [controller.initialize_node(x, parent=node) for x in transform_relatives]
        for transform in transforms:
            descendants.extend(controller.get_shape_descendants(transform))
    return descendants


def create_origin_geometry(container, origin_geometry_names):
    controller = container.controller
    error_messages = []
    for origin_geometry_name in origin_geometry_names:
        if origin_geometry_name in controller.named_objects:
            origin_geometry_faces = origin_geometry_names[origin_geometry_name]
            geometry_transform = controller.named_objects[origin_geometry_name]
            mesh_objects = [x for x in geometry_transform.children if isinstance(x, Mesh)]
            if len(mesh_objects) < 1:
                error_messages.append('No mesh children found under "%s"' % geometry_transform)
            elif len(mesh_objects) > 1:
                error_messages.append('more than one mesh children found under "%s"' % geometry_transform)
            else:
                origin_geometry_transform = controller.create_object(
                    Transform,
                    name='%s_Origin' % origin_geometry_name,
                    parent=container.origin_geometry_group
                )
                origin_mesh = controller.copy_mesh(
                    mesh_objects[0].name,
                    origin_geometry_transform,
                    name='%s_OriginShape' % origin_geometry_name,
                )
                origin_mesh.assign_shading_group(
                    container.shaders['origin'].shading_group
                )
                container.geometry[origin_mesh.name] = origin_mesh
                if origin_geometry_faces:
                    index_strings = origin_geometry_faces.split('[')[-1].split(']')[0].split(':')
                    start_index, end_index = map(int, index_strings)
                    controller.scene.select('%s.f[%s:%s]' % (origin_mesh, start_index, end_index))
                    controller.scene.select('%s.f[*]' % origin_mesh, tgl=True)
                    controller.scene.delete()
                    controller.scene.delete(origin_mesh, ch=True)

                difference_blendshape = controller.create_blendshape(
                    mesh_objects[0],
                    parent=mesh_objects[0],
                    root_name=mesh_objects[0].name
                )
                blendshsape_group = difference_blendshape.create_group(
                    origin_mesh,
                    root_name=origin_mesh.name
                )
                blendshsape_group.get_weight_plug().set_value(1.0)

        else:
            #self.origin_geometry_names.pop(origin_geometry_name)
            pass


def import_geometry_paths(container, geometry_paths):
    controller = container.controller
    controller.progress_signal.emit(
        message='Importing Geometry...',
        maximum=len(geometry_paths) + 1,
        value=0
    )
    for i, path in enumerate(geometry_paths):
        controller.progress_signal.emit(
            message='Importing Geometry: %s' % path.split('/')[-1],
            value=i+1
        )
        if os.path.exists(path):
            new_geometry = import_geometry(
                controller,
                path,
                parent=container.geometry_group
            )
            container.geometry.update(new_geometry)
        else:
            print 'The geometry path does not exist: %s' % path
    controller.progress_signal.emit(done=True)