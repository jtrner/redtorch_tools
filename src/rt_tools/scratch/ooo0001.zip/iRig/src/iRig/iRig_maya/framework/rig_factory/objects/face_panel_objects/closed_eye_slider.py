
from rig_factory.objects.face_panel_objects.base_slider import BaseSlider, BaseSliderGuide
from rig_math.matrix import Matrix
import utilities as utl
from rig_factory.objects.base_objects.properties import ObjectProperty, ObjectListProperty
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint
import copy


class ClosedEyeSliderGuide(BaseSliderGuide):

    default_settings = dict(
        root_name='closed_eye',
        side='left',
        size=2.0
    )

    def __init__(self, **kwargs):
        super(ClosedEyeSliderGuide, self).__init__(**kwargs)
        self.toggle_class = ClosedEyeSlider.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(BaseSliderGuide, cls).create(controller, **kwargs)
        root_name = this.root_name
        joints = []
        for handle_name in ('lid', 'blink'):
            handle = this.create_handle(
                root_name=root_name + '_' + handle_name
            )
            handle.mesh.assign_shading_group(this.get_root().shaders[this.side].shading_group)
            joint = handle.create_child(
                Joint
            )
            controller.create_parent_constraint(handle, joint)
            joint.plugs['drawStyle'].set_value(2)
            joints.append(joint)
        this.joints = joints
        return this


class ClosedEyeSlider(BaseSlider):

    up_handle = ObjectProperty(
        name='up_handle'
    )

    down_handle = ObjectProperty(
        name='up_handle'
    )

    blink_handle = ObjectProperty(
        name='blink_handle'
    )

    def __init__(self, **kwargs):
        super(ClosedEyeSlider, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(ClosedEyeSlider, cls).create(controller, **kwargs)
        root_name = this.root_name
        side = this.side
        size = this.size
        if len(this.matrices) == 1:
            eye_matrix, blink_matrix = [
                this.matrices[0],
                copy.copy(this.matrices[0])
            ]
        else:
            eye_matrix, blink_matrix = this.matrices

        #  Nodes

        up_handle = this.create_handle(
            root_name='up_' + root_name,
            shape='circle_half_smooth',
            size=size * 0.5,
            matrix=eye_matrix * Matrix(0.0, size, 0.0)
        )
        utl.set_attr_limit(up_handle, 'TransY', size * -2.25, size * 0.25)
        utl.set_attr_limit(up_handle, 'TransX', size * -1.0, size)
        utl.set_attr_limit(up_handle, 'TransZ', 0.0, 0.0)
        if side == 'right':
            up_handle.groups[-1].plugs['rotateY'].set_value(180.0)

        down_handle = this.create_handle(
            root_name='down_' + root_name,
            shape='circle_half_smooth',
            size=size * 0.5,
            matrix=eye_matrix * Matrix(0.0, -1.0 * size, 0.0)
        )
        utl.set_attr_limit(down_handle, 'TransY', size * -0.25, size * 2.25)
        utl.set_attr_limit(down_handle, 'TransX', size * -1.0, size)
        utl.set_attr_limit(down_handle, 'TransZ', 0.0, 0.0)
        down_handle.multiply_shape_matrix(Matrix(scale=[1.0, -1.0, 1.0]))
        if side == 'right':
            down_handle.groups[-1].plugs['rotateY'].set_value(180.0)

        position_transform = this.create_child(
            Transform,
            matrix=blink_matrix,
            root_name=root_name + '_blink_position',
        )

        outline_curve = position_transform.create_child(
            NurbsCurve,
            root_name=root_name + '_outline',
            degree=1,
            positions=[
                [0.0, size, 0.0],
                [size, size, 0.0],
                [size, size * -1.0, 0.0],
                [0.0, size * -1.0, 0.0],
                [0.0, size, 0.0]
            ]
        )

        outline_curve_wide = position_transform.create_child(
            NurbsCurve,
            root_name=root_name + '_outline_wide',
            degree=1,
            positions=[
                [0.0, size, 0.0],
                [size * -0.25, size, 0.0],
                [size * -0.25, size * -1.0, 0.0],
                [0.0, size * -1.0, 0.0],
                [0.0, size, 0.0]
            ]
        )

        center_curve = position_transform.create_child(
            NurbsCurve,
            root_name=root_name + '_center',
            degree=1,
            positions=[
                [size * -0.25, 0.0, 0.0],
                [size, 0.0, 0.0]
            ]
        )

        outline_curve.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )
        center_curve.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )
        outline_curve_wide.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )

        blink_handle = this.create_handle(
            root_name=root_name + '_blink',
            shape='star_four',
            axis='z',
            size=size,
            side=side,
            matrix=blink_matrix,
            parent=position_transform
        )
        utl.set_attr_limit(blink_handle, 'TransY', size * -1.0, size)
        utl.set_attr_limit(blink_handle, 'TransX', size * -0.25, size)
        utl.set_attr_limit(blink_handle, 'TransZ', 0.0, 0.0)
        blink_handle.plugs['tx'].set_value(size)

        horizontal_multiplier = this.create_child(
            DependNode,
            node_type='multiplyDivide',
            root_name=root_name + '_horizontal'
        )
        horizontal_multiplier.plugs.set_values(
            operation=2,
            input2X=size,
            input2Y=size
        )
        up_handle.plugs['tx'].connect_to(
            horizontal_multiplier.plugs['input1X']
        )
        down_handle.plugs['tx'].connect_to(
            horizontal_multiplier.plugs['input1Y']
        )

        # Center blink nodes

        blink_up_center_right = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_blink_up_center_right'
        )
        blink_up_center_right.plugs.set_values(
            inputMin=0,
            inputMax=size,
            outputMin=1,
            outputMax=0
        )
        blink_handle.plugs['translateX'].connect_to(
            blink_up_center_right.plugs['inputValue']
        )

        blink_down_center_right = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_blink_down_center_right'
        )
        blink_down_center_right.plugs.set_values(
            inputMin=0,
            inputMax=size,
            outputMin=-1,
            outputMax=0
        )
        blink_handle.plugs['translateX'].connect_to(
            blink_down_center_right.plugs['inputValue']
        )

        blink_up_wide_center_left = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_blink_up_wide_center_left'
        )
        blink_up_wide_center_left.plugs.set_values(
            inputMin=-0.25 * size,
            inputMax=0,
            outputMin=0.25,
            outputMax=0
        )
        blink_handle.plugs['translateX'].connect_to(
            blink_up_wide_center_left.plugs['inputValue']
        )

        blink_down_wide_center_left = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_blink_down_wide_center_left'
        )
        blink_down_wide_center_left.plugs.set_values(
            inputMin=-0.25 * size,
            inputMax=0,
            outputMin=-0.25,
            outputMax=0
        )
        blink_handle.plugs['translateX'].connect_to(
            blink_down_wide_center_left.plugs['inputValue']
        )

        blink_up_wide_center_add = this.create_child(
            DependNode,
            node_type='addDoubleLinear',
            root_name=this.root_name + '_blink_up_wide_center_add'
        )
        blink_up_center_right.plugs['outValue'].connect_to(
            blink_up_wide_center_add.plugs['input1']
        )
        blink_up_wide_center_left.plugs['outValue'].connect_to(
            blink_up_wide_center_add.plugs['input2']
        )

        blink_down_wide_center_add = this.create_child(
            DependNode,
            node_type='addDoubleLinear',
            root_name=this.root_name + '_blink_down_wide_center_add'
        )
        blink_down_center_right.plugs['outValue'].connect_to(
            blink_down_wide_center_add.plugs['input1']
        )
        blink_down_wide_center_left.plugs['outValue'].connect_to(
            blink_down_wide_center_add.plugs['input2']
        )

        # Top Nodes

        blink_up_top_left = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_blink_up_top_left'
        )
        blink_up_top_left.plugs.set_values(
            inputMin=-0.25 * size,
            inputMax=0,
            outputMin=2,
            outputMax=1
        )
        blink_handle.plugs['translateX'].connect_to(
            blink_up_top_left.plugs['inputValue']
        )

        # Blender A

        blink_blender_A_rmp = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_blink_blender_A_rmp'
        )
        blink_blender_A_rmp.plugs.set_values(
            inputMin=0,
            inputMax=size,
            outputMin=1,
            outputMax=0
        )
        blink_handle.plugs['translateY'].connect_to(
            blink_blender_A_rmp.plugs['inputValue']
        )

        blink_blender_A = this.create_child(
            DependNode,
            node_type='blendColors',
            root_name=this.root_name + '_blink_blender_A'
        )
        blink_blender_A.plugs['color2G'].set_value(1)
        blink_blender_A_rmp.plugs['outValue'].connect_to(
            blink_blender_A.plugs['blender']
        )
        blink_up_wide_center_add.plugs['output'].connect_to(
            blink_blender_A.plugs['color1R']
        )
        blink_down_wide_center_add.plugs['output'].connect_to(
            blink_blender_A.plugs['color1G']
        )
        blink_up_top_left.plugs['outValue'].connect_to(
            blink_blender_A.plugs['color2R']
        )

        # Bottom Nodes

        blink_down_bottom_left = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_blink_down_bottom_left'
        )
        blink_down_bottom_left.plugs.set_values(
            inputMin=-0.25 * size,
            inputMax=0,
            outputMin=-2,
            outputMax=-1
        )
        blink_handle.plugs['translateX'].connect_to(
            blink_down_bottom_left.plugs['inputValue']
        )

        # Blender B

        blink_blender_B_rmp = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_blink_blender_B_rmp'
        )
        blink_blender_B_rmp.plugs.set_values(
            inputMin=-1 * size,
            inputMax=0,
            outputMin=0,
            outputMax=1
        )
        blink_handle.plugs['translateY'].connect_to(
            blink_blender_B_rmp.plugs['inputValue']
        )

        blink_blender_B = this.create_child(
            DependNode,
            node_type='blendColors',
            root_name=this.root_name + '_blink_blender_B'
        )
        blink_blender_B.plugs['color2R'].set_value(-1)
        blink_blender_A.plugs['output'].connect_to(
            blink_blender_B.plugs['color1']
        )
        blink_blender_B_rmp.plugs['outValue'].connect_to(
            blink_blender_B.plugs['blender']
        )
        blink_down_bottom_left.plugs['outValue'].connect_to(
            blink_blender_B.plugs['color2G']
        )

        # Eyes up

        eyes_up_middle = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_eyes_up_middle'
        )
        eyes_up_middle.plugs.set_values(
            inputMin=-2.25 * size,
            inputMax=0,
            outputMin=-1,
            outputMax=1
        )
        up_handle.plugs['translateY'].connect_to(
            eyes_up_middle.plugs['inputValue']
        )

        eyes_up_wide = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_eyes_up_wide'
        )
        eyes_up_wide.plugs.set_values(
            inputMin=0,
            inputMax=0.25 * size,
            outputMin=0,
            outputMax=0.25
        )
        up_handle.plugs['translateY'].connect_to(
            eyes_up_wide.plugs['inputValue']
        )

        eyes_up_add = this.create_child(
            DependNode,
            node_type='addDoubleLinear',
            root_name=this.root_name + '_eyes_up_add'
        )
        eyes_up_middle.plugs['outValue'].connect_to(
            eyes_up_add.plugs['input1']
        )
        eyes_up_wide.plugs['outValue'].connect_to(
            eyes_up_add.plugs['input2']
        )

        # Eyes down

        eyes_down_middle = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_eyes_down_middle'
        )
        eyes_down_middle.plugs.set_values(
            inputMin=0,
            inputMax=2.25 * size,
            outputMin=-1,
            outputMax=1
        )
        down_handle.plugs['translateY'].connect_to(
            eyes_down_middle.plugs['inputValue']
        )

        eyes_down_wide = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_eyes_down_wide'
        )
        eyes_down_wide.plugs.set_values(
            inputMin=-0.25 * size,
            inputMax=0,
            outputMin=-0.25,
            outputMax=0
        )
        down_handle.plugs['translateY'].connect_to(
            eyes_down_wide.plugs['inputValue']
        )

        eyes_down_add = this.create_child(
            DependNode,
            node_type='addDoubleLinear',
            root_name=this.root_name + '_eyes_down_add'
        )
        eyes_down_middle.plugs['outValue'].connect_to(
            eyes_down_add.plugs['input1']
        )
        eyes_down_wide.plugs['outValue'].connect_to(
            eyes_down_add.plugs['input2']
        )

        # wide override

        wide_override_blender_rmp = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_wide_override_blender_rmp'
        )
        wide_override_blender_rmp.plugs.set_values(
            inputMin=-0.25 * size,
            inputMax=0,
            outputMin=0,
            outputMax=1
        )
        blink_handle.plugs['translateX'].connect_to(
            wide_override_blender_rmp.plugs['inputValue']
        )

        wide_override_blender = this.create_child(
            DependNode,
            node_type='blendColors',
            root_name=this.root_name + '_wide_override_blender'
        )
        wide_override_blender.plugs.set_values(
            color2R=1.25,
            color2G=-1.25
        )
        eyes_up_add.plugs['output'].connect_to(
            wide_override_blender.plugs['color1R']
        )
        eyes_down_add.plugs['output'].connect_to(
            wide_override_blender.plugs['color1G']
        )
        wide_override_blender_rmp.plugs['outValue'].connect_to(
            wide_override_blender.plugs['blender']
        )

        # Blink limiters

        eyes_up_blink_limiter = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_eyes_up_blink_limiter'
        )
        eyes_up_blink_limiter.plugs.set_values(
            inputMin=-1,
            outputMin=-1
        )
        blink_blender_B.plugs['outputR'].connect_to(
            eyes_up_blink_limiter.plugs['inputMax']
        )
        blink_blender_B.plugs['outputR'].connect_to(
            eyes_up_blink_limiter.plugs['outputMax']
        )
        wide_override_blender.plugs['outputR'].connect_to(
            eyes_up_blink_limiter.plugs['inputValue']
        )

        eyes_down_blink_limiter = this.create_child(
            DependNode,
            node_type='remapValue',
            root_name=this.root_name + '_eyes_down_blink_limiter'
        )
        eyes_down_blink_limiter.plugs.set_values(
            inputMax=1,
            outputMax=1
        )
        blink_blender_B.plugs['outputG'].connect_to(
            eyes_down_blink_limiter.plugs['inputMin']
        )
        blink_blender_B.plugs['outputG'].connect_to(
            eyes_down_blink_limiter.plugs['outputMin']
        )
        wide_override_blender.plugs['outputG'].connect_to(
            eyes_down_blink_limiter.plugs['inputValue']
        )

        # Blend weighted nodes

        eyes_down_blink_weighted = this.create_child(
            DependNode,
            node_type='blendWeighted',
            root_name=this.root_name + '_eyes_down_blink_weighted'
        )
        eyes_down_blink_limiter.plugs['outValue'].connect_to(
            eyes_down_blink_weighted.plugs['input'].element(0)
        )

        eyes_up_blink_weighted = this.create_child(
            DependNode,
            node_type='blendWeighted',
            root_name=this.root_name + '_eyes_up_blink_weighted'
        )
        eyes_up_blink_limiter.plugs['outValue'].connect_to(
            eyes_up_blink_weighted.plugs['input'].element(0)
        )

        horizontal_mlt_X_weighted = this.create_child(
            DependNode,
            node_type='blendWeighted',
            root_name=this.root_name + '_horizontal_mlt_X_weighted'
        )
        horizontal_multiplier.plugs['outputX'].connect_to(
            horizontal_mlt_X_weighted.plugs['input'].element(0)
        )

        horizontal_mlt_Y_weighted = this.create_child(
            DependNode,
            node_type='blendWeighted',
            root_name=this.root_name + '_horizontal_mlt_Y_weighted'
        )
        horizontal_multiplier.plugs['outputY'].connect_to(
            horizontal_mlt_Y_weighted.plugs['input'].element(0)
        )

        # plugs

        up_lid_blink_driver_plug = this.create_plug(
            'up_lid_blink_driver',
            k=True,
            at='double'
        )
        eyes_up_blink_weighted.plugs['output'].connect_to(
            up_lid_blink_driver_plug
        )

        down_lid_blink_driver_plug = this.create_plug(
            'down_lid_blink_driver',
            k=True,
            at='double'
        )
        eyes_down_blink_weighted.plugs['output'].connect_to(
            down_lid_blink_driver_plug
        )

        up_horizontal_driver = this.create_plug(
            'up_horizontal_driver',
            k=True,
            at='double',
            min=-1.0,
            max=1.0
        )
        horizontal_mlt_X_weighted.plugs['output'].connect_to(
            up_horizontal_driver
        )

        down_horizontal_driver = this.create_plug(
            'down_horizontal_driver',
            k=True,
            at='double',
            min=-1.0,
            max=1.0
        )
        horizontal_mlt_Y_weighted.plugs['output'].connect_to(
            down_horizontal_driver
        )

        joint = this.create_child(
            Joint,
            parent=this.joint_group,
            index=1
        )


        root = this.get_root()
        root.add_plugs(
            blink_handle.plugs['tx'],
            blink_handle.plugs['ty'],
            blink_handle.plugs['rz'],
            up_handle.plugs['tx'],
            up_handle.plugs['ty'],
            up_handle.plugs['rz'],
            down_handle.plugs['tx'],
            down_handle.plugs['ty'],
            down_handle.plugs['rz'],
        )

        #  Properties

        this.joints.append(joint)
        this.up_handle = up_handle
        this.down_handle = down_handle
        this.blink_handle = blink_handle

        return this

    def finalize(self):
        self.blink_handle.plugs['tx'].set_value(0.0)
