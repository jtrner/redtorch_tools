import uuid
import os
import sys
import tempfile
import subprocess


def launch_build(project, entity, dev_mode=False, publish=False, comment=None, build_work=False, maya_version=None):

    current_location = os.path.dirname(__file__.replace('\\', '/'))
    if current_location:
        script_path = '%s/scripts/build_rig_script.py' % current_location
    else:
        script_path = '%s/scripts/build_rig_script.py' % os.getcwd().replace('\\', '/')

    with open(script_path, mode='r') as f:
        script = f.read()
    temp_build_directry = '%s/auto_rig_build_%s' % (tempfile.gettempdir().replace('\\', '/'), uuid.uuid4())
    os.makedirs(temp_build_directry)
    python_path = '%s/auto_build.py' % temp_build_directry
    with open(python_path, mode='w') as f:
        f.write(script)
    mel_path = '%s/auto_build.mel' % temp_build_directry
    with open(mel_path, mode='w') as f:
        f.write(
            'python("import sys;sys.path.append(\'%s\');import auto_build;auto_build.auto_build_rig(\'%s\', \'%s\', dev_mode=%s, publish=%s, comment=%s, build_work=%s)");' % (
                temp_build_directry,
                project,
                entity,
                dev_mode,
                publish,
                '\'%s\'' % comment if comment else None,
                build_work
            )
        )
    if maya_version is None:
        maya_version = '2019'
    program = 'C:/Program Files/Autodesk/Maya%s/bin/mayabatch.exe' % maya_version
    subprocess.Popen(
        '\"%s\" -command \"source \\"%s\\"\"' % (program, mel_path),
        shell=False
    )
    # stdout, stderr = process.communicate()
    # print stdout

