import launch_build as lb


if __name__ == '__main__':
    project = str(raw_input('Enter the project code...   '))
    assets_input = raw_input('Enter the asset names separated by commas...   ')
    assets = [x.strip() for x in assets_input.split(',')]
    comment = str(raw_input('Enter a comment...'))
    work_string = str(raw_input('Would you like to build from your work directory?  type "y" or "n" ...  '))
    publish_string = str(raw_input('Would you like to publish the result  type "y" or "n" ...  '))

    if len(assets) > 10:
        raise StandardError('The maximum number of batch builds is 5')
    for asset in assets:
        lb.launch_build(
            project,
            asset,
            publish=publish_string == 'y',
            comment=comment,
            build_work=work_string == 'y'
        )
