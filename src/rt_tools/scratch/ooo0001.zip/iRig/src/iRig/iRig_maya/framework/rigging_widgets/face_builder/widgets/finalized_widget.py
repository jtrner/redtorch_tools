from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
import rigging_widgets.rig_builder.environment as env


class FinalizedWidget(QWidget):


    def __init__(self, *args, **kwargs):
        super(FinalizedWidget, self).__init__(*args, **kwargs)

        self.horizontal_layout = QHBoxLayout(self)
        self.vertical_layout = QVBoxLayout()
        self.title_layout = QHBoxLayout()

        self.text_label = QLabel('The face has been finalized', self)
        self.label = QLabel( self)
        self.label.setPixmap('%s/lock.png' % env.images_directory)
        self.label.setAlignment(Qt.AlignHCenter)
        message_font = QFont('', 13, True)
        message_font.setWeight(50)
        self.text_label.setAlignment(Qt.AlignHCenter)
        self.text_label.setFont(message_font)
        self.text_label.setWordWrap(True)
        self.horizontal_layout.addStretch()
        self.horizontal_layout.addLayout(self.vertical_layout)
        self.vertical_layout.addLayout(self.title_layout)

        self.horizontal_layout.addStretch()
        self.vertical_layout.addStretch()
        self.title_layout.addStretch()
        self.title_layout.addStretch()

        self.vertical_layout.addWidget(self.text_label)
        self.vertical_layout.addWidget(self.label)
        self.vertical_layout.addStretch()
        self.vertical_layout.addStretch()
        self.controller = None

    def set_controller(self, controller):
        self.controller = controller
        self.update_widgets()

