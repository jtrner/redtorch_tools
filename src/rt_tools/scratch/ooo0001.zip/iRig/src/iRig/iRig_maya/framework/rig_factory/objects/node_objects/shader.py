from typing import *
from depend_node import DependNode
from shading_group import ShadingGroup
from rig_factory.objects.base_objects.properties import (
    ObjectProperty, ObjectListProperty
)


class Shader(DependNode):

    shading_group = ObjectProperty(
        name='shading_group'
    )

    geometries = ObjectListProperty(
        name='geometries'
    )

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(Shader, cls).create(controller, **kwargs)
        shading_group = controller.create_object(
            ShadingGroup,
            root_name=this.root_name,
            index=this.index,
            side=this.side,
            parent=this
        )
        this.plugs['outColor'].connect_to(shading_group.plugs['surfaceShader'])
        this.shading_group = shading_group
        shading_group.shaders.append(this)
        return this

    def create_in_scene(self):
        self.m_object = self.controller.scene.create_shader(
            self.node_type,
            self.name
        )

    def teardown(self):
        if len(self.shading_group.shaders) < 2:
            self.controller.schedule_objects_for_deletion(self.shading_group)
        super(Shader, self).teardown()

    def add_geometries(self, geometries):
        # type: (List) -> None
        """
        Assigns self to the given list of geometries.
        :param geometries:
            Objects to assign self too.
        """
        unique_geometries = [x for x in geometries if x not in self.geometries]
        self.controller.scene.sets(
            *(x.get_selection_string() for x in unique_geometries),
            forceElement=self.shading_group.get_selection_string()
        )
        self.geometries.extend(unique_geometries)

    def remove_geometries(self, geometries):
        # type: (List) -> None
        """
        Un-assigns self from given list of geometries.
        :param geometries:
            Objects to un-assign self too.
        """
        valid_geometries = [x for x in geometries if x in self.geometries]
        self.controller.scene.sets(
            *(x.get_selection_string() for x in valid_geometries),
            remove=self.shading_group.get_selection_string()
        )
        for x in valid_geometries:
            self.geometries.remove(x)
