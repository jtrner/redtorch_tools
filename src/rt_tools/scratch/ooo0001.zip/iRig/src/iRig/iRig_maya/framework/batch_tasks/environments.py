import os
import sys
import glob
import maya.cmds as mc
import shotgun
sg = shotgun.connect()


def load_system_paths(dev_mode=True):
    mc.loadPlugin('C:/pipeline_modules/maya/assetInfo/1.1/20XX/plug-ins/assetInfo.py')
    user = os.environ['USERNAME']
    if dev_mode:
        framework_location = 'D:/pipeline/%s/dev/git_repo/irig/src/iRig/iRig_maya/framework' % user
    else:

        irig_location = 'G:/Rigging/.rigging/iRig'
        irig_version_locations = [x.replace('\\', '/') for x in glob.glob('%s/iRig_*.*.*' % irig_location) if os.path.isdir(x)]
        latest_irig_location = sorted(irig_version_locations, key=os.path.getmtime)[-1]
        framework_location = '%s/src/iRig/iRig_maya/framework' % latest_irig_location  # for framework

    mc.loadPlugin('%s/maya_tools/shard_matrix.py' % framework_location)

    if not os.path.exists(framework_location):
        raise StandardError('framework path not found: %s' % framework_location)
    if framework_location in sys.path:
        sys.path.remove(framework_location)
    sys.path.insert(0, framework_location)
    if dev_mode:
        git_location = 'D:/pipeline/%s/dev/git_repo' % os.environ['USERNAME']
        pipe_base = '%s/pipeline_monolith' % git_location
        os.environ['PIPE_BASE'] = pipe_base
        system_paths = [
            '%s/py_utilities' % pipe_base,  # for file_tools
            '%s/python/control_tower/v0002' % pipe_base, # for fileTools
            '%s/maya/scripts' % pipe_base  # for maya scripts
        ]

    else:
        pipe_base = 'G:/Pipeline/pipeline'
        os.environ['PIPE_BASE'] = pipe_base
        system_paths = [
            '%s/py_utilities' % pipe_base,  # for file_tools
            '%s/python/control_tower/v0002' % pipe_base,  # for fileTools
            '%s/maya/scripts' % pipe_base  # for maya scripts
        ]

    sys.path.insert(0, 'G:/Pipeline/pipeline_external/Python27/site-packages')
    for system_path in system_paths:
        if not os.path.exists(system_path):
            raise StandardError('A local copy of a system path not found: %s' % system_path)
        if system_path not in sys.path:
            sys.path.insert(0, system_path)


def load_rigging_environment(project, entity):
    project_data = sg.find(
        "Project",
        [["sg_code", "is", project]],
        ["sg_code"]
    )

    if not project_data:
        raise StandardError('No Project called : "%s"' % project)

    asset_data = sg.find(
        "Asset",
        [["code", "is", entity], ["project.Project.sg_code", "is", project]],
        ["code", "sg_asset_type"]
    )

    if not asset_data:
        raise StandardError('The asset "%s" was not found in the project "%s"' % (entity, project))

    os.environ['SERVER_BASE'] = 'Y:\\'
    os.environ['TT_PROJCODE'] = project_data[0]['sg_code']
    os.environ['TT_ENTNAME'] = asset_data[0]['code']
    os.environ['TT_ASSTYPE'] = asset_data[0]['sg_asset_type']
    os.environ['TT_STEPCODE'] = 'rig'
    os.environ['TT_PACKAGE'] = 'Maya'
    os.environ['TT_ENTTYPE'] = 'Asset'
    os.environ['TT_ENTID'] = str(asset_data[0]['id'])
    os.environ['TT_USER'] = os.environ['USERNAME']
    os.environ['MAYA_PLUG_IN_PATH'] = '' \
                                      'Z:/pipeline/pixar/RenderManStudio-19.0-maya2015/plug-ins;' \
                                      'Z:/pipeline/config/EAV/custom/plugins;' \
                                      'C:/Users/paxtong/Documents/maya/2019/plug-ins;' \
                                      'C:/Users/paxtong/Documents/maya/plug-ins;' \
                                      'C:/Program Files/Autodesk/Maya2019/bin/plug-ins;' \
                                      'C:/Program Files/Autodesk/Maya2019/plug-ins/ATF/plug-ins;' \
                                      'C:/Program Files/Autodesk/Bifrost/Maya2019/bifrost/plug-ins;' \
                                      'C:/Program Files/Autodesk/Maya2019/plug-ins/MASH/plug-ins;' \
                                      'C:/Program Files/Autodesk/Maya2019/plug-ins/fbx/plug-ins;' \
                                      'C:/Program Files/Autodesk/Maya2019/plug-ins/camd/plug-ins;' \
                                      'C:/solidangle/mtoadeploy/2019/plug-ins;' \
                                      'C:/Allegorithmic/SubstanceMaya/2019/plug-ins;' \
                                      'C:/Program Files/Autodesk/Bifrost/Maya2019/vnn/plug-ins;' \
                                      'C:/Program Files/Autodesk/Maya2019/plug-ins/xgen/plug-ins' \
                                      ''

