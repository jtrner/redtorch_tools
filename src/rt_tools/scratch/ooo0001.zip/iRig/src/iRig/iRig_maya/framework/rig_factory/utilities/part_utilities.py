import rig_factory.utilities.selection_utilities as sut
from rig_factory.objects.part_objects.base_container import BaseContainer
from rig_factory.objects.part_objects.base_part import BasePart
from rig_factory.objects.face_objects.face_handle_array import FaceHandleArrayGuide


def assign_nurbs_surface(controller):
    selected_parts = sut.get_selected_parts(controller, types=FaceHandleArrayGuide)
    if not selected_parts:
        controller.raise_warning(
            'There doesn\'t seem to be any face handle arrays selected.'
        )
        return
    selection_list = controller.scene.ls(sl=True)
    if not selection_list:
        controller.raise_warning('Nothing is selected')
        return
    last_selected_item = selection_list[-1]

    if last_selected_item in controller.named_objects:
        last_selected_node = controller.named_objects[last_selected_item]
        if isinstance(last_selected_node, (BaseContainer, BasePart)):
            controller.raise_warning(
                'Last item in selection "%s" is a Part. it should be a surface' % last_selected_item
            )
            return
    surface_objects = controller.scene.get_nurbs_surface_objects(last_selected_item)
    surface_object_names = [controller.scene.get_selection_string(x) for x in surface_objects]
    if len(surface_objects) > 1:
        controller.raise_warning(
            'Last item in selection list contained more than one surface object: %s' % '\n'.join(surface_object_names)
        )
        return
    elif len(surface_objects) < 1:
        controller.raise_warning(
            'No surface objects were found in the last selected item : %s' % last_selected_item
        )
        return
    surface_name = surface_object_names[-1]
    data = controller.scene.get_surface_data(surface_name)

    for part in selected_parts:
        part.surface_data = data

    controller.raise_warning('Success!: Set Surface data for : %s' % selected_parts)


def assign_closest_vertices_to_selected_parts(controller):
    selected_parts = sut.get_selected_parts(controller)
    selection_list = controller.scene.ls(sl=True)
    if not selection_list:
        controller.raise_warning('Nothing is selected')
        return
    last_selected_item = selection_list[-1]
    if last_selected_item not in controller.named_objects:
        controller.raise_warning(
            'Last item in selection "%s" is not registered with the controller' % last_selected_item
        )
        return
    last_selected_node = controller.named_objects[last_selected_item]
    if isinstance(last_selected_node, (BaseContainer, BasePart)):
        controller.raise_warning(
            'Last item in selection "%s" is a Part. it should be a mesh' % last_selected_item
        )
        return
    mesh_objects = controller.scene.get_mesh_objects(last_selected_item)
    mesh_object_names = [controller.scene.get_selection_string(x) for x in mesh_objects]
    if len(mesh_objects) > 1:
        controller.raise_warning(
            'Last item in selection list contained more than one mesh object: %s' % '\n'.join(mesh_object_names)
        )
        return
    elif len(mesh_objects) < 1:
        controller.raise_warning(
            'No mesh objects were found in the last selected item : %s' % last_selected_item
        )
        return
    if not mesh_object_names[0] in controller.named_objects:
        controller.raise_warning(
            'Selected mesh "%s" is not registered with the controller' % mesh_object_names[0]
        )
        return
    mesh_object = controller.named_objects[mesh_object_names[0]]
    for part in selected_parts:
        controller.assign_closest_vertices(part, mesh_object)


def snap_selected_parts_to_selected_mesh(controller):
    """
    This is a user facing selection based function and so must have a lot of checks
    """
    selection_list = controller.scene.ls(sl=True)
    if not selection_list:
        controller.raise_warning('Nothing is selected')
        return
    last_selected_item = selection_list[-1]

    if last_selected_item in controller.named_objects:
        if isinstance(controller.named_objects[last_selected_item], (BaseContainer, BasePart)):
            controller.raise_warning(
                'Last item in selection "%s" is a Part. it should be a mesh' % last_selected_item
            )
            return

    mesh_m_objects = controller.scene.get_mesh_objects(last_selected_item)
    mesh_object_names = [controller.scene.get_selection_string(x) for x in mesh_m_objects]
    if len(mesh_m_objects) > 1:
        controller.raise_warning(
            'Last item in selection list contained more than one mesh object: %s' % '\n'.join(
                mesh_object_names
            )
        )
        return

    elif len(mesh_m_objects) < 1:
        controller.raise_warning(
            'No mesh objects were found in the last selected item : %s' % mesh_m_objects
        )
        return

    mesh_name = mesh_object_names[0]

    similar_mesh = controller.find_similar_mesh(mesh_name)
    if not similar_mesh:
        controller.raise_warning(
            'Invalid mesh: %s' % mesh_name
        )
        return

    handles = sut.get_selected_part_handles(
        controller,
        include_selected_handles=True
    )

    if not handles:
        controller.raise_warning(
            'No handles found in selection'
        )
        return

    vertexless_handles = []
    for handle in handles:
        if handle.vertices:
            vertex_strings = []
            for x in handle.vertices:
                # if x.mesh == similar_mesh:
                vertex_strings.append('%s.vtx[%s]' % (mesh_name, x.index))
            if vertex_strings:
                position = controller.scene.get_bounding_box_center(*vertex_strings)
                controller.xform(handle, t=position, ws=True)
        else:
            vertexless_handles.append(handle)
    vertexless_handles = list(set(vertexless_handles))
    vertexless_handle_names = [vertexless_handles[x].name for x in range(len(vertexless_handles)) if x < 10]
    if vertexless_handles:
        controller.raise_warning(
            'Warning: some handles did not have vertex assignments and could not be snapped.\n%s' % '\n'.join(
                vertexless_handle_names
            )
        )


def snap_part_to_mesh(part, mesh_name):
    controller = part.controller
    similar_mesh = controller.find_similar_mesh(mesh_name)
    if not similar_mesh:
        raise StandardError('Invalid mesh: %s' % mesh_name)
    for handle in part.get_handles(part):
        if handle.vertices:
            vertex_strings = []
            for x in handle.vertices:
                if x.mesh == similar_mesh:
                    vertex_strings.append('%s.vtx[%s]' % (mesh_name, x.index))
            if vertex_strings:
                position = controller.scene.get_bounding_box_center(*vertex_strings)
                controller.xform(handle, t=position, ws=True)
        else:
            print 'Handle "%s" had no vertices ' % handle


def snap_part_to_selected_mesh(part):
    controller = part.controller
    mesh_names = controller.get_selected_mesh_names()
    for mesh_name in mesh_names:
        snap_part_to_mesh(part, mesh_name)
