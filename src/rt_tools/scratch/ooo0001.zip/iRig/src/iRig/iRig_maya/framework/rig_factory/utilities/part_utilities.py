import rig_factory.utilities.selection_utilities as sut
from rig_factory.objects.part_objects.base_container import BaseContainer
from rig_factory.objects.part_objects.base_part import BasePart


def snap_selected_parts_to_selected_mesh(controller):
    """
    This is a user facing selection based function and so must have a lot of checks
    """
    selection_list = controller.scene.ls(sl=True)
    if not selection_list:
        controller.raise_warning('Nothing is selected')
        return
    last_selected_item = selection_list[-1]

    if last_selected_item in controller.named_objects:
        if isinstance(controller.named_objects[last_selected_item], (BaseContainer, BasePart)):
            controller.raise_warning(
                'Last item in selection "%s" is a Part. it should be a mesh' % last_selected_item
            )
            return

    mesh_m_objects = controller.scene.get_mesh_objects(last_selected_item)
    mesh_object_names = [controller.scene.get_selection_string(x) for x in mesh_m_objects]
    if len(mesh_m_objects) > 1:
        controller.raise_warning(
            'Last item in selection list contained more than one mesh object: %s' % '\n'.join(
                mesh_object_names
            )
        )
        return

    elif len(mesh_m_objects) < 1:
        controller.raise_warning(
            'No mesh objects were found in the last selected item : %s' % mesh_m_objects
        )
        return

    mesh_name = mesh_object_names[0]

    similar_mesh = controller.find_similar_mesh(mesh_name)
    if not similar_mesh:
        controller.raise_warning(
            'Invalid mesh: %s' % mesh_name
        )
        return

    handles = sut.get_selected_part_handles(
        controller,
        include_selected_handles=True
    )

    if not handles:
        controller.raise_warning(
            'No handles found in selection'
        )
        return

    vertexless_handles = []
    for handle in handles:
        if handle.vertices:
            vertex_strings = []
            for x in handle.vertices:
                # if x.mesh == similar_mesh:
                vertex_strings.append('%s.vtx[%s]' % (mesh_name, x.index))
            if vertex_strings:
                position = controller.scene.get_bounding_box_center(*vertex_strings)
                controller.xform(handle, t=position, ws=True)
        else:
            vertexless_handles.append(handle)
    vertexless_handles = list(set(vertexless_handles))
    vertexless_handle_names = [vertexless_handles[x].name for x in range(len(vertexless_handles)) if x < 10]
    if vertexless_handles:
        controller.raise_warning(
            'Warning: some handles did not have vertex assignments and could not be snapped.\n%s' % '\n'.join(
                vertexless_handle_names
            )
        )


def snap_part_to_mesh(part, mesh_name):
    controller = part.controller
    similar_mesh = controller.find_similar_mesh(mesh_name)
    if not similar_mesh:
        raise StandardError('Invalid mesh: %s' % mesh_name)
    for handle in part.get_handles(part):
        if handle.vertices:
            vertex_strings = []
            for x in handle.vertices:
                if x.mesh == similar_mesh:
                    vertex_strings.append('%s.vtx[%s]' % (mesh_name, x.index))
            if vertex_strings:
                position = controller.scene.get_bounding_box_center(*vertex_strings)
                controller.xform(handle, t=position, ws=True)
        else:
            print 'Handle "%s" had no vertices ' % handle


def snap_part_to_selected_mesh(part):
    controller = part.controller
    mesh_names = controller.get_selected_mesh_names()
    for mesh_name in mesh_names:
        snap_part_to_mesh(part, mesh_name)
