from sqlalchemy.orm import scoped_session, sessionmaker
from rigging_database.table_objects import *


def initialize_session(database_path=None):
    # if database_path:
    #     engine = sqlalchemy.create_engine("sqlite:///%s" % database_path)
    # else:
    engine = sqlalchemy.create_engine(
        'postgresql://rigging_team:A&Yu%:WtE^HAfux@iconprvm20/rigging_codes'
    )
    Base.metadata.bind = engine
    Base.metadata.create_all()
    session = scoped_session(sessionmaker())
    # session.configure(bind=engine)
    return session


def initialize_user(session, user_name):
    existing_user = session.query(User).filter(User.name == user_name).first()

    if existing_user:
        return existing_user
    new_user = User(name=user_name)
    session.add(new_user)
    session.commit()
    return new_user


def initialize_project(session, project_name):
    existing_project = session.query(Project)\
        .filter(Project.name == project_name).first()

    if existing_project:
        return existing_project
    new_project = Project(name=project_name)
    session.add(new_project)
    session.commit()
    return new_project


def initialize_entity(session, project, entity_name):
    existing_entity = session.query(Entity)\
        .filter(Entity.name == entity_name)\
        .join(Entity.project)\
        .filter(Project.id == project.id).first()

    if existing_entity:
        return existing_entity
    new_project = Entity(
        name=entity_name,
        project=project
    )
    session.add(new_project)
    session.commit()
    return new_project

if __name__ == '__main__':
    initialize_session()