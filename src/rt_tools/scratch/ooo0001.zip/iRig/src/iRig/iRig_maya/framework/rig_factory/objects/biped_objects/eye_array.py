
from rig_factory.objects.part_objects.part_array import PartArrayGuide, PartArray
from rig_factory.objects.biped_objects.eye import EyeGuide, Eye
from rig_factory.objects.base_objects.properties import ObjectProperty
from rig_math.matrix import Matrix
from rig_math.vector import Vector

import rig_factory.positions as pos


class EyeArrayGuide(PartArrayGuide):

    default_settings = dict(
        root_name='eyes',
        size=1.0,
        side='center'
    )

    left_eye = ObjectProperty(
        name='left_eye'
    )
    right_eye = ObjectProperty(
        name='right_eye'
    )

    def __init__(self, **kwargs):
        super(EyeArrayGuide, self).__init__(**kwargs)
        self.toggle_class = EyeArray.__name__

    def create_members(self):
        super(EyeArrayGuide, self).create_members()
        left_eye = self.create_part(
            'EyeGuide',
            parent=self,
            root_name='eye',
            side='left'
        )
        right_eye = self.create_part(
            'EyeGuide',
            parent=self,
            root_name='eye',
            side='right'
        )
        self.left_eye = left_eye
        self.right_eye = right_eye
        self.set_handle_positions(pos.BIPED_POSITIONS)


class EyeArray(PartArray):

    def post_create(self, **kwargs):
        eye_positions = []
        eye_parts = []
        if self.parts:
            for part in self.parts:
                if isinstance(part, Eye):
                    eye_parts.append(part)
                    aim_handle = part.handles[1]
                    matrix = aim_handle.get_matrix()
                    translation = matrix.get_translation()
                    eye_positions.append(translation)

        total_eye_vector = Vector([0, 0, 0])
        for eye_position in eye_positions:
            total_eye_vector = total_eye_vector + eye_position

        average_translation = total_eye_vector * (1.0/len(eye_positions))
        if len(eye_parts) == 2:
            distance = (eye_parts[0].handles[1].get_translation() - eye_parts[0].handles[1].get_translation()).mag()
        else:
            distance = self.size * 10
        matrix = Matrix(*average_translation.data)
        shape_matrix = Matrix()
        shape_matrix.set_scale([(distance + (self.size * 2)), self.size * 2, self.size * 2])
        eye_handle = self.create_handle(
            shape='square',
            size=self.size,
            matrix=matrix,
            root_name='%s_aim' % self.root_name,
            axis='z'
        )
        cross_eye_plug = eye_handle.create_plug(
            'cross_eye',
            at='double',
            k=False,
            dv=0.0
        )
        eye_handle.plugs['shape_matrix'].set_value(list(shape_matrix))

        for eye in eye_parts:
            eye.handles[1].groups[0].set_parent(eye_handle)
        root = self.get_root()
        root.add_plugs([
            eye_handle.plugs['tx'],
            eye_handle.plugs['ty'],
            eye_handle.plugs['tz'],
            eye_handle.plugs['rz'],
            cross_eye_plug
        ])