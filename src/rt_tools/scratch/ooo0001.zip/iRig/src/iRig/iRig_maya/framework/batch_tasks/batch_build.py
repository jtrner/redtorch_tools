import environments as env


def build_rig(project, entity, dev_mode=False, publish=False, comment=None, build_work=False):
    env.load_system_paths(dev_mode=dev_mode)
    env.load_rigging_environment(project, entity)
    import rig_factory.build.utilities.publish_utilities as put
    import rig_factory.build.utilities.controller_utilities as cut
    import rig_factory.build.utilities.blueprint_utilities as but
    controller = cut.initialize_rig_controller()
    if not build_work:
        controller.build_directory = put.get_latest_product_directory()
    but.execute_blueprints(controller)

    if publish:
        if comment is None:
            comment = 'Auto Publish'
        import maya.cmds as mc
        mc.loadPlugin('C:/pipeline_modules/maya/assetInfo/1.1/20XX/plug-ins/assetInfo.py')
        put.publish_rig(
            controller,
            comment=comment
            )
    else:
        if comment is None:
            comment = 'Auto Build'
        put.save_work_scene(
            controller,
            comment=comment
        )



