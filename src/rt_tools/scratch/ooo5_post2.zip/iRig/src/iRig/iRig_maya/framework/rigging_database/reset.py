import sqlalchemy
import table_objects as tob
engine = sqlalchemy.create_engine(
    'postgresql://rigging_team:A&Yu%:WtE^HAfux@iconprvm20/rigging_codes'
)

tob.Project.__table__.drop(engine)
tob.User.__table__.drop(engine)


