import rig_factory.build.frank_utilities.frank_controller_utilities as fcu
import rigging_widgets.widget_launchers.launch_widgets as lw
fcu.initialize_rig_controller()
lw.launch()




