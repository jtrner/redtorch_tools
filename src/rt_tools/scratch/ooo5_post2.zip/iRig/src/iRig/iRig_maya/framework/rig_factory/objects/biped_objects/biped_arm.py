import copy
import rig_factory
import rig_factory.environment as env
from rig_factory.objects.base_objects.properties import ObjectProperty, ObjectListProperty, DataProperty
from rig_factory.objects.biped_objects.biped_arm_fk import BipedArmFk
from rig_factory.objects.biped_objects.biped_arm_ik import BipedArmIk
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.part_objects.chain_guide import ChainGuide
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.rig_objects.curve_handle import CurveHandle
from rig_factory.objects.rig_objects.grouped_handle import LocalHandle
from rig_math.matrix import Matrix
from rig_math.vector import Vector
import rig_factory.positions as pos


class BipedArmGuide(ChainGuide):
    segment_names = DataProperty(
        name='segment_names',
        default_value=['Clavicle', 'Shoulder', 'Elbow', 'Hand', 'HandEnd']
    )

    default_settings = dict(
        root_name='arm',
        size=5.0,
        side='left'
    )

    def __init__(self, **kwargs):
        super(BipedArmGuide, self).__init__(**kwargs)
        self.toggle_class = BipedArm.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['count'] = 5
        kwargs['up_vector_indices'] = [0, 1, 3]
        kwargs.setdefault('root_name', 'Arm')
        this = super(BipedArmGuide, cls).create(controller, **kwargs)
        this.set_handle_positions(pos.BIPED_POSITIONS)
        return this

    def align_elbow(self):
        root_position = Vector(self.base_handles[1].get_translation())
        elbow_position = Vector(self.base_handles[2].get_translation())
        up_vector_position = Vector(self.up_handles[1].get_translation())
        wrist_position = Vector(self.base_handles[3].get_translation())
        mag_1 = (elbow_position - root_position).mag()
        mag_2 = (wrist_position - elbow_position).mag()
        total_mag = mag_1 + mag_2
        if total_mag == 0.0:
            self.controller.raise_warning('Warning: the second joint had no angle. unable to calculate pole position')
            return up_vector_position
        fraction_1 = mag_1 / total_mag
        center_position = root_position + (wrist_position - root_position) * fraction_1
        angle_vector = (up_vector_position - center_position)
        angle_mag = angle_vector.mag()
        if angle_mag == 0.0:
            self.controller.raise_warning('Warning: the second joint had no angle. unable to calculate pole position')
            return up_vector_position
        distance = (elbow_position - center_position).mag()
        elbow_offset = angle_vector.normalize() * distance
        elbow_position = center_position + elbow_offset
        return self.base_handles[2].plugs['translate'].set_value(elbow_position.data)


class BipedArm(Part):
    segment_names = DataProperty(
        name='segment_names',
        default_value=['Clavicle', 'Shoulder', 'Elbow', 'Hand', 'HandEnd']
    )

    settings_handle = ObjectProperty(
        name='settings_handle'
    )

    clavicle_handle = ObjectProperty(
        name='clavicle_handle'
    )
    base_joints = ObjectListProperty(
        name='base_joints'
    )
    wrist_handle = ObjectProperty(
        name='wrist_handle'
    )
    wrist_handle_gimbal = ObjectProperty(
        name='wrist_handle_gimbal'
    )
    elbow_handle = ObjectProperty(
        name='elbow_handle'
    )
    ik_group = ObjectProperty(
        name='ik_group'
    )
    ik_joints = ObjectListProperty(
        name='ik_joints'
    )
    fk_joints = ObjectListProperty(
        name='fk_joints'
    )
    ik_handles = ObjectListProperty(
        name='ik_handles'
    )
    fk_handles = ObjectListProperty(
        name='fk_handles'
    )
    stretchable_plugs = ObjectListProperty(
        name='stretchable_plugs'
    )
    elbow_line = ObjectProperty(
        name='elbow_line'
    )
    isolate_group = ObjectProperty(
        name='isolate_group'
    )

    def __init__(self, **kwargs):
        super(BipedArm, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['count'] = 5
        this = super(BipedArm, cls).create(controller, **kwargs)
        cls.build_rig(this)
        return this

    @staticmethod
    def build_rig(this):
        controller = this.controller
        root = this.get_root()
        size = this.size
        side = this.side
        matrices = this.matrices
        joint_parent = this.joint_group
        segment_names = this.segment_names

        joints = []
        for i in range(len(matrices)):
            joint = this.create_child(
                Joint,
                parent=joint_parent,
                matrix=matrices[i],
                segment_name=segment_names[i]
            )
            joint.zero_rotation()
            joint_parent = joint
            joint.plugs['overrideEnabled'].set_value(True)
            joint.plugs['overrideDisplayType'].set_value(2)
            joints.append(joint)

        clavicle_handle = this.create_handle(
            handle_type=LocalHandle,
            segment_name=segment_names[0],
            size=size * 1.5,
            side=side,
            matrix=matrices[0],
            shape='c_curve',
            rotation_order='yzx'
        )
        handles = [clavicle_handle]
        root.add_plugs([
            clavicle_handle.plugs[m + a]
            for m in 'trs'
            for a in 'xyz'
        ])
        clavicle_handle.stretch_shape(matrices[1])
        shape_scale = [
            1.5 if side == 'right' else -1.5,
            1,
            1
        ]
        clavicle_handle.multiply_shape_matrix(Matrix(scale=shape_scale))

        controller.create_parent_constraint(
            clavicle_handle.gimbal_handle,
            joints[0],
            mo=True,
        )

        this.handles = []
        this.differentiation_name = 'Fk'
        fk_group = this.create_child(
            Transform,
            segment_name='SubPart',
            parent=clavicle_handle.gimbal_handle,
            matrix=Matrix()
        )
        this.top_group = fk_group
        this.segment_names = segment_names[1:]
        this.matrices = matrices[1:]
        # Fk Arm
        BipedArmFk.build_rig(this)
        fk_joints = list(this.joints)
        fk_handles = list(this.handles)
        this.handles = []
        this.joints = []

        this.differentiation_name = 'Ik'
        ik_group = this.create_child(
            Transform,
            segment_name='SubPart',
            parent=clavicle_handle.gimbal_handle,
            matrix=Matrix()
        )
        this.top_group = ik_group
        this.matrices = matrices[1:]
        # Ik Arm
        BipedArmIk.build_rig(this)
        ik_joints = list(this.joints)
        kinematic_joints = list(this.ik_joints)
        ik_handles = list(this.handles)
        handles.extend(fk_handles)  # reorder handles
        handles.extend(ik_handles)  # reorder handles
        this.handles = handles
        this.differentiation_name = None
        this.matrices = matrices
        this.top_group = this
        this.ik_handles = ik_handles
        this.ik_joints = ik_joints
        this.fk_handles = fk_handles
        this.ik_handles = ik_handles

        fk_joints[0].set_parent(joints[0])
        ik_joints[0].set_parent(joints[0])
        kinematic_joints[0].set_parent(joints[0])
        this.segment_names = segment_names

        part_ik_plug = this.create_plug(
            'ikSwitch',
            at='double',
            k=True,
            dv=0.0,
            min=0.0,
            max=1.0
        )

        for i in range(3):
            index_character = rig_factory.index_dictionary[i].title()
            pair_blend = this.create_child(
                DependNode,
                node_type='pairBlend',
                segment_name='Blend%s' % index_character
            )
            blend_colors = this.create_child(
                DependNode,
                node_type='blendColors',
                segment_name='Blend%s' % index_character
            )
            ik_joints[i].plugs['translate'].connect_to(pair_blend.plugs['inTranslate2'])
            fk_joints[i].plugs['translate'].connect_to(pair_blend.plugs['inTranslate1'])
            ik_joints[i].plugs['rotate'].connect_to(pair_blend.plugs['inRotate2'])
            fk_joints[i].plugs['rotate'].connect_to(pair_blend.plugs['inRotate1'])
            pair_blend.plugs['outTranslate'].connect_to(joints[i + 1].plugs['translate'])
            pair_blend.plugs['outRotate'].connect_to(joints[i + 1].plugs['rotate'])
            blend_colors.plugs['output'].connect_to(joints[i + 1].plugs['scale'])
            ik_joints[i].plugs['scale'].connect_to(blend_colors.plugs['color1'])
            fk_joints[i].plugs['scale'].connect_to(blend_colors.plugs['color2'])
            pair_blend.plugs['rotInterpolation'].set_value(1)
            part_ik_plug.connect_to(pair_blend.plugs['weight'])
            part_ik_plug.connect_to(blend_colors.plugs['blender'])
            joints[i + 1].plugs['rotateOrder'].connect_to(fk_joints[i].plugs['rotateOrder'])
            joints[i + 1].plugs['rotateOrder'].connect_to(ik_joints[i].plugs['rotateOrder'])
        settings_handle = this.create_handle(
            handle_type=CurveHandle,
            segment_name='Settings',
            shape='gear_simple',
            axis='z',
            matrix=matrices[-2],
            parent=joints[-1],
            size=size * 0.5
        )
        settings_handle.plugs.set_values(
            overrideEnabled=True,
            overrideRGBColors=True,
            overrideColorRGB=env.colors['highlight'],
            tx=size * 2.0 if side == 'right' else size * -2.0
        )

        ik_plug = settings_handle.create_plug(
            'ikSwitch',
            at='double',
            k=True,
            dv=0.0,
            min=0.0,
            max=1.0
        )

        ik_plug.connect_to(part_ik_plug)

        for ik_handle in ik_handles:
            part_ik_plug.connect_to(ik_handle.groups[0].plugs['visibility'])
        part_ik_plug.connect_to(this.elbow_line.plugs['visibility'])

        reverse_node = this.create_child(
            DependNode,
            node_type='reverse'
        )
        part_ik_plug.connect_to(reverse_node.plugs['inputX'])
        for fk_handle in fk_handles:
            reverse_node.plugs['outputX'].connect_to(fk_handle.groups[0].plugs['visibility'])
        ik_joints[0].plugs['visibility'].set_value(False)
        fk_joints[0].plugs['visibility'].set_value(False)
        root = this.get_root()
        joints[0].plugs['type'].set_value(9)
        joints[1].plugs['type'].set_value(10)
        joints[2].plugs['type'].set_value(11)
        joints[3].plugs['type'].set_value(12)
        root.add_plugs(
            ik_plug,
            keyable=True
        )
        this.fk_joints = fk_joints
        this.ik_joints = ik_joints
        this.fk_handles = fk_handles
        this.ik_handles = ik_handles
        this.joints = joints
        this.settings_handle = settings_handle
        this.clavicle_handle = clavicle_handle

        return this

    def toggle_ik(self):
        value = self.settings_handle.plugs['ikSwitch'].get_value()
        if value > 0.5:
            self.match_to_fk()
        else:
            self.match_to_ik()

    def match_to_fk(self):
        self.settings_handle.plugs['ikSwitch'].set_value(0.0)
        positions = [x.get_matrix() for x in self.ik_arm.joints]
        for i in range(len(positions[0:3])):
            self.fk_arm.handles[i].set_matrix(Matrix(positions[i]))

    def match_to_ik(self):
        self.settings_handle.plugs['ikSwitch'].set_value(1.0)
        positions = [x.get_matrix() for x in self.fk_arm.joints]
        self.ik_arm.wrist_handle.set_matrix(positions[2])
        vector_multiplier = self.size * 10
        if self.side == 'left':
            vector_multiplier = vector_multiplier * -1
        z_vector_1 = Vector(positions[0].data[2][0:3]).normalize()
        z_vector_2 = Vector(positions[1].data[2][0:3]).normalize()
        z_vector = (z_vector_1 + z_vector_2) * 0.5
        pole_position = positions[1].get_translation() + (z_vector * vector_multiplier)
        self.ik_arm.elbow_handle.set_matrix(Matrix(pole_position))
