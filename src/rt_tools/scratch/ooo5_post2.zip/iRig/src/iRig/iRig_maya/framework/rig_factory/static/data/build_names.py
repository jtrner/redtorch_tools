import os
import json
here = os.path.dirname(__file__.replace('\\', '/'))

with open('%s/old_guide_node_names.json' % here, mode='r') as f:
    old_guide_names =json.load(f)
with open('%s/new_guide_node_names.json' % here, mode='r') as f:
    new_guide_names =json.load(f)

guide_pairs = []

assert len(old_guide_names) == len(new_guide_names)

for x in range(len(old_guide_names)):
    guide_pairs.append([old_guide_names[x], new_guide_names[x]])

with open('%s/guide_pairs.json' % here, mode='w') as f:
    new_guide_names = json.dump(
        guide_pairs,
        f,
        sort_keys=True,
        indent=4,
        separators=(',', ': ')
    )
