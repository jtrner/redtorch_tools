from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
from rigging_widgets.rig_builder.models.dag_model import DagModel
from rigging_widgets.rig_builder.views.dag_view import DagView
import rigging_widgets.rig_builder.environment as env


class DagWidget(QWidget):

    finished_signal = Signal()

    def __init__(self, *args, **kwargs):
        super(DagWidget, self).__init__(*args, **kwargs)
        self.vertical_layout = QVBoxLayout(self)
        self.button_layout = QHBoxLayout()
        self.stacked_layout = QStackedLayout()
        self.mesh_widget = DagViewWidget(self)
        self.button_layout.addStretch()
        self.vertical_layout.addLayout(self.button_layout)
        self.vertical_layout.addLayout(self.stacked_layout)
        self.stacked_layout.addWidget(self.mesh_widget)
        self.vertical_layout.setSpacing(4)
        self.stacked_layout.setContentsMargins(4, 0, 0, 0)
        self.stacked_layout.setContentsMargins(0, 0, 0, 0)
        self.controller = None
        self.mesh_widget.finished_signal.connect(self.finished_signal.emit)
        self.mesh_widget.geometry_view.items_selected.connect(self.select_items)

    def load_model(self):
        geometry_model = DagModel()
        geometry_model.set_controller(self.controller)
        self.mesh_widget.geometry_view.setModel(geometry_model)

    def finish(self):
        self.mesh_widget.setModel(None)

    def set_controller(self, controller):
        self.controller = controller
        self.mesh_widget.set_controller(self.controller)

    def select_items(self, items):
        if self.controller:
            self.controller.select(*items)

    def raise_error(self, exception):
        print exception.message
        message_box = QMessageBox(self)
        message_box.setWindowTitle('Invalid Face Selection')
        message_box.setText(exception.message)
        message_box.exec_()
        raise exception


class DagViewWidget(QWidget):

    finished_signal = Signal()

    def __init__(self, *args, **kwargs):
        super(DagViewWidget, self).__init__(*args, **kwargs)
        self.controller = None

        self.vertical_layout = QVBoxLayout(self)
        self.button_layout = QHBoxLayout()
        self.geometry_view = DagView(self)
        self.back_button = QPushButton('Rig', self)
        self.back_button.setIcon(QIcon('%s/back_arrow.png' % env.images_directory))
        self.button_layout.addWidget(self.back_button)
        self.button_layout.addStretch()
        self.vertical_layout.addLayout(self.button_layout)
        self.vertical_layout.addWidget(self.geometry_view)
        self.vertical_layout.setSpacing(4)
        self.geometry_view.items_selected.connect(self.select_items)
        self.back_button.pressed.connect(self.finished_signal.emit)
        self.back_button.pressed.connect(self.finish)

    def finish(self):
        self.geometry_view.setModel(None)

    def set_controller(self, controller):
        self.controller = controller
        self.geometry_view.set_controller(self.controller)

    def select_items(self, items):
        if self.controller:
            self.controller.select(*items)
