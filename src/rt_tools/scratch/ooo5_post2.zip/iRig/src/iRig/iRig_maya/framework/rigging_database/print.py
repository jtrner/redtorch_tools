import sqlalchemy
from sqlalchemy import inspect

engine = sqlalchemy.create_engine(
    'postgresql://rigging_team:A&Yu%:WtE^HAfux@iconprvm20/rigging_codes'
)

inspector = inspect(engine)

for table_name in inspector.get_table_names():
    print table_name
    for column in inspector.get_columns(table_name):
        print("        Column: %s" % column['name'])
