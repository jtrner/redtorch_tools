import copy
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.nurbs_surface import NurbsSurface
from rig_factory.objects.face_objects.face_handle import FaceHandle
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_math.matrix import Matrix
import rig_factory.environment as env
import rig_factory

class ArrayMixin(object):

    def __init__(self, **kwargs):
        super(ArrayMixin, self).__init__(**kwargs)

    def get_control_points(self):
        return self.controller.get_control_points(self)

    def snap_to_mesh(self, mesh):
        self.controller.snap_to_mesh(self, mesh)

    def create_points(self, *vertices, **kwargs):
        return self.controller.create_points(self, *vertices, **kwargs)

    def create_point(self, **kwargs):
        return self.controller.create_point(self, **kwargs)


class SurfaceSplineGuide(PartGuide, ArrayMixin):

    surface_data = DataProperty(
        name='surface_data'
    )
    locators = ObjectListProperty(
        name='locators'
    )
    count = DataProperty(
        name='count'
    )
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )
    joint_count = DataProperty(
        name='joint_count',
        default_value=19
    )
    fit_curve = DataProperty(
        name='fit_curve',
        default_value=False
    )
    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    threshold = DataProperty(
        name='threshold',
        default_value=0.01
    )

    default_settings = dict(
        root_name='Handle',
        count=5,
        lower_count=None,
        size=3.0,
        mirror=False,
        side=None,
        threshold=0.01,
        create_gimbal=False,
        fit_curve=False,
        joint_count=9
    )

    def __init__(self, **kwargs):
        super(SurfaceSplineGuide, self).__init__(**kwargs)
        self.toggle_class = SurfaceSpline.__name__

    @classmethod
    def create(cls, controller, **kwargs):

        # handle_data = kwargs.pop('handle_data', None)
        this = super(SurfaceSplineGuide, cls).create(controller, **kwargs)
        count = this.count
        side = this.side
        size = this.size

        # if handle_data:
        #     create_guide_handles_from_data(
        #         this,
        #         handle_data
        #     )
        #
        # elif count:
        create_guide_handles_from_data(
            this,
            create_handle_data(
                count,
                side,
                this.root_name,
                size,

            )
        )

        base_curve_transform = this.create_child(
            Transform,
            segment_name='BaseSpline',
        )
        base_curve = base_curve_transform.create_child(
            NurbsCurve,
            positions=[x.get_translation() for x in this.handles],
            degree=1 if this.fit_curve else 2
        )
        joints = []
        for i in range(len(this.handles)):
            handle = this.handles[i]
            joint = handle.create_child(
                Joint
            )
            joints.append(joint)
            handle.plugs['translate'].connect_to(
                base_curve.plugs['controlPoints'].element(i)
            )
            joint.plugs['drawStyle'].set_value(2)
        if this.fit_curve:
            nurbs_curve_transform = this.create_child(
                Transform,
                segment_name='Spline',
            )
            fit_curve = nurbs_curve_transform.create_child(
                NurbsCurve,
                segment_name='Spline',
            )
            fit_b_spline_node = fit_curve.create_child(
                DependNode,
                node_type='fitBspline',
            )
            base_curve.plugs['worldSpace'].element(0).connect_to(fit_b_spline_node.plugs['inputCurve'])
            fit_b_spline_node.plugs['outputCurve'].connect_to(fit_curve.plugs['create'])
            fit_b_spline_node.plugs.set_values(
                tolerance=0.001
            )
            base_curve.plugs['intermediateObject'].set_value(True)
            fit_curve.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
                visibility=False
            )
            curve_to_use = fit_curve
        else:
            base_curve.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
                visibility=False
            )
            curve_to_use = base_curve
        spline_joints = []
        segment_parameter = 1.0 / (this.joint_count - 1)
        length_multiply_plug = this.create_plug(
            'lengthMultiply',
            at='double',
            min=0.0,
            max=1.0,
            dv=1.0,
            k=False
        )
        for i in range(this.joint_count):
            index_character = rig_factory.index_dictionary[i].title()
            spline_joint = this.create_child(
                Joint,
                segment_name='Spline%s' % index_character,
                index=i
            )
            point_on_curve_info = spline_joint.create_child(
                DependNode,
                node_type='pointOnCurveInfo',
            )
            parameter_multiply_node = spline_joint.create_child(
                DependNode,
                node_type='multiplyDivide',
            )
            point_on_curve_info.plugs['turnOnPercentage'].set_value(True)
            curve_to_use.plugs['worldSpace'].element(0).connect_to(point_on_curve_info.plugs['inputCurve'])
            point_on_curve_info.plugs['position'].connect_to(spline_joint.plugs['translate'])
            parameter_multiply_node.plugs['input2X'].set_value(segment_parameter * i)
            parameter_multiply_node.plugs['outputX'].connect_to(point_on_curve_info.plugs['parameter'])
            length_multiply_plug.connect_to(parameter_multiply_node.plugs['input1X'])
            spline_joint.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2
            )
            spline_joints.append(spline_joint)
        this.joints = joints
        this.spline_joints = spline_joints

        return this

    def get_blueprint(self):
        blueprint = super(SurfaceSplineGuide, self).get_blueprint()
        blueprint.update(dict(
            handle_data=self.get_handle_data(),
            handle_positions=self.get_handle_positions(),
            handle_vertices=self.get_vertex_data()
        ))
        return blueprint

    def get_toggle_blueprint(self):
        blueprint = super(SurfaceSplineGuide, self).get_toggle_blueprint()
        blueprint['handle_data'] = self.get_handle_data()
        return blueprint

    def get_handle_data(self):
        return [dict(
            klass=handle.__class__.__name__,
            module=handle.__module__,
            vertices=[(x.mesh.get_selection_string(), x.index) for x in handle.vertices],
            matrix=list(handle.get_matrix()),
            root_name=handle.root_name,
            size=handle.plugs['size'].get_value(1.0),
            side=handle.side,
            segment_name=handle.segment_name
        ) for handle in self.handles]

    def get_mirror_blueprint(self):
        sides = dict(left='right', right='left')
        handles = self.handles
        if not all(self.side == x.side for x in handles):
            raise StandardError('Non uniform handle sides not supported in mirror blueprint')
        blueprint = super(SurfaceSplineGuide, self).get_mirror_blueprint()
        handle_data = []
        for handle in self.handles:
            handle_matrix = list(handle.get_matrix())
            handle_matrix[12] = handle_matrix[12]*-1
            handle_properties = dict(
                klass=handle.__class__.__name__,
                module=handle.__module__,
                root_name=handle.root_name,
                size=handle.plugs['size'].get_value(1.0),
                side=sides[handle.side],
                index=handle.index,
                handle_matrix=handle_matrix
            )
            mirror_vertices = []
            for vertex in handle.vertices:
                position = vertex.get_translation()
                position[0] = position[0] * -1
                mirror_index = self.controller.get_closest_vertex_index(
                    vertex.mesh,
                    position,
                )
                mirror_vertex = vertex.mesh.get_vertex(mirror_index)
                mirror_vertices.append(mirror_vertex)
            handle_properties['vertices'] = [(x.mesh.get_selection_string(), x.index) for x in mirror_vertices]
            handle_data.append(handle_properties)
        blueprint['handle_data'] = handle_data
        return blueprint


class SurfaceSpline(Part):

    surface_data = DataProperty(
        name='surface_data'
    )

    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    fit_curve = DataProperty(
        name='fit_curve',
        default_value=False
    )

    follicle_surface = ObjectProperty(
        name='follicle_surface'
    )

    handle_data = DataProperty(
        name='handle_data'
    )

    joint_count = DataProperty(
        name='joint_count'
    )

    spline_curve = ObjectProperty(
        name='spline_curve'
    )

    spline_joints = ObjectListProperty(
        name='spline_joints'
    )

    def __init__(self, **kwargs):
        super(SurfaceSpline, self).__init__(**kwargs)
        self.disconnected_joints = False
        self.joint_chain = False

    @classmethod
    def create(cls, controller, **kwargs):
        handle_data = copy.copy(kwargs.get('handle_data'))
        this = super(SurfaceSpline, cls).create(controller, **kwargs)
        root = this.get_root()
        root_name = this.root_name
        size = this.size
        side = this.side
        joint_parent = this.joint_group
        handles = []
        joints = []
        locators = []
        if this.surface_data:
            positions, knots_u, knots_v, degree_u, degree_v, form_u, form_v = this.surface_data
            surface_transform = this.create_child(
                Transform,
                root_name='%s_surface' % root_name
            )
            this.follicle_surface = surface_transform.create_child(
                NurbsSurface,
                positions=positions,
                knots_u=knots_u,
                knots_v=knots_v,
                degree_u=degree_u,
                degree_v=degree_v,
                form_u=form_u,
                form_v=form_v
            )
            this.follicle_surface.plugs['v'].set_value(False)

        for i, data in enumerate(handle_data):
            vertices = []
            data = copy.copy(data)
            vertex_data = data.pop('vertices', None)
            if vertex_data:
                for mesh_name, vertex_index in vertex_data:
                    geometry = root.get_geometry(mesh_name)
                    if not geometry:
                        print('mesh not found "%s"' % mesh_name)
                    else:
                        vertex = geometry.get_vertex(vertex_index)
                        vertices.append(vertex)
            handle = this.create_handle(
                handle_type=FaceHandle,
                create_gimbal=this.create_gimbal,
                follicle_surface=this.follicle_surface,
                **data
            )
            handle.vertices = vertices
            handle.owner = this
            joint = handle.create_child(
                Joint,
                parent=joint_parent,
                matrix=handle.get_matrix()
            )
            controller.create_parent_constraint(
                handle,
                joint,
                mo=False
            )
            locator = joint.create_child(
                Locator
            )
            # controller.create_matrix_parent_constraint(
            #     handle,
            #     joint
            # )
            if root:
                root.add_plugs(
                    handle.plugs['tx'],
                    handle.plugs['ty'],
                    handle.plugs['tz'],
                    handle.plugs['rx'],
                    handle.plugs['ry'],
                    handle.plugs['rz'],
                    handle.plugs['sx'],
                    handle.plugs['sy'],
                    handle.plugs['sz'],
                )
            joint.plugs['visibility'].set_value(False)
            joint.plugs['radius'].set_value(size)
            handles.append(handle)
            joints.append(joint)
            locators.append(locator)

        positions = [x.get_translation() for x in joints]
        base_curve_transform = this.create_child(
            Transform,
            segment_name='BaseSpline'
        )
        base_curve_transform.plugs.set_values(
            inheritsTransform=False
        )
        base_curve = base_curve_transform.create_child(
            NurbsCurve,
            degree=1 if this.fit_curve else 2,
            positions=positions
        )
        for i in range(len(locators)):
            position_locator = locators[i]

            if this.follicle_surface:
                closest_point_on_surface = position_locator.create_child(
                    DependNode,
                    node_type='closestPointOnSurface',
                )
                position_locator.plugs['worldPosition'].element(0).connect_to(
                    closest_point_on_surface.plugs['inPosition']
                )
                this.follicle_surface.plugs['worldSpace'].element(0).connect_to(
                    closest_point_on_surface.plugs['inputSurface']
                )
                closest_point_on_surface.plugs['result'].child(0).connect_to(
                    base_curve.plugs['controlPoints'].element(i)
                )
            else:
                position_locator.plugs['worldPosition'].element(0).connect_to(
                    base_curve.plugs['controlPoints'].element(i)
                )
            position_locator.plugs['visibility'].set_value(False)

        if this.fit_curve:
            nurbs_curve_transform = this.create_child(
                Transform,
                segment_name='Spline'
            )
            nurbs_curve = nurbs_curve_transform.create_child(
                NurbsCurve,
                root_name=root_name,
            )
            fit_b_spline_node = nurbs_curve.create_child(
                DependNode,
                node_type='fitBspline',
            )
            fit_b_spline_node.plugs.set_values(
                tolerance=0.001
            )
            base_curve.plugs['worldSpace'].element(0).connect_to(fit_b_spline_node.plugs['inputCurve'])
            fit_b_spline_node.plugs['outputCurve'].connect_to(nurbs_curve.plugs['create'])
            base_curve.plugs['intermediateObject'].set_value(True)
            nurbs_curve.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2
            )
            this.spline_curve = nurbs_curve
        else:
            base_curve.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2
            )
            this.spline_curve = base_curve
        this.joints = joints
        return this

    def create_deformation_rig(self, **kwargs):
        super(SurfaceSpline, self).create_deformation_rig(**kwargs)
        root_name = self.root_name
        positions = [x.get_translation() for x in self.joints]
        for deform_joint in self.deform_joints:
            deform_joint.plugs['v'].set_value(False)

        spline_joints = []
        segment_parameter = 1.0 / (self.joint_count - 1)
        length_multiply_plug = self.create_plug(
            'length_multiply',
            at='double',
            min=0.0,
            max=1.0,
            dv=1.0,
            k=False
        )

        # if self.follicle_surface:
        #     surface_curve_transform = self.follicle_surface.create_child(
        #         Transform,
        #         root_name='%s_surface_spline' % root_name,
        #     )
        #     surface_curve = surface_curve_transform.create_child(
        #         NurbsCurve,
        #         degree=1,
        #         create_2d=True,
        #         root_name='%s_surface_spline' % root_name,
        #
        #     )
        #     project_curve = surface_curve_transform.create_child(
        #         DependNode,
        #         node_type='projectCurve',
        #         root_name='%s_surface_spline' % root_name,
        #
        #     )
        #     curve_from_surface = surface_curve_transform.create_child(
        #         DependNode,
        #         node_type='curveFromSurfaceCoS',
        #         root_name='%s_convert' % root_name,
        #
        #     )
        #     joint_spline_transform= self.create_child(
        #         Transform,
        #         root_name='%s_joint_spline' % root_name,
        #     )
        #     joint_curve = joint_spline_transform.create_child(
        #         NurbsCurve,
        #         degree=1,
        #         root_name='%s_joint_spline' % root_name,
        #
        #     )
        #     self.follicle_surface.plugs['worldSpace'].element(0).connect_to(project_curve.plugs['inputSurface'])
        #     self.spline_curve.plugs['worldSpace'].element(0).connect_to(project_curve.plugs['inputCurve'])
        #     project_curve.plugs['useNormal'].set_value(True)
        #     project_curve.plugs['outputCurve'].element(0).connect_to(surface_curve.plugs['create'])
        #     self.follicle_surface.plugs['worldSpace'].element(0).connect_to(curve_from_surface.plugs['inputSurface'])
        #     surface_curve.plugs['worldSpace'].element(0).connect_to(curve_from_surface.plugs['curveOnSurface'])
        #     curve_from_surface.plugs['outputCurve'].connect_to(joint_curve.plugs['create'])
        #     surface_curve.plugs['intermediateObject'].set_value(False)
        #
        #     self.spline_curve = joint_curve

        root_name = self.root_name
        side = self.side
        root = self.get_root()
        joint_parent = root.deform_group

        for i in range(self.joint_count):
            spline_joint = self.create_child(
                Joint,
                root_name='%s_spline' % root_name,
                index=i,
                parent=joint_parent
            )
            spline_joint.zero_rotation()

            spline_joint.plugs.set_values(
                overrideRGBColors=True,
                overrideColorRGB=env.colors['bind_joints'],
                overrideEnabled=True
            )

            point_on_curve_info = spline_joint.create_child(
                DependNode,
                node_type='pointOnCurveInfo',
                index=i,
                root_name='%s_curve' % root_name,
                side=side
            )

            parameter_multiply_node = spline_joint.create_child(
                DependNode,
                node_type='multiplyDivide',
                index=i,
                root_name='%s_curve' % root_name,
                side=side
            )

            if self.follicle_surface:
                closest_point_on_surface = spline_joint.create_child(
                    DependNode,
                    node_type='closestPointOnSurface',
                )
                point_on_surface_info = spline_joint.create_child(
                    DependNode,
                    node_type='pointOnSurfaceInfo',
                )
                translation_transform = self.create_child(
                    Transform,
                    node_type='multiplyDivide',
                    root_name='%s_surface_translation' % root_name,
                    index=i
                )
                aim_transform = self.create_child(
                    Transform,
                    node_type='multiplyDivide',
                    root_name='%s_spline_aim' % root_name,
                    index=i
                )
                orient_transform = self.create_child(
                    Transform,
                    node_type='multiplyDivide',
                    root_name='%s_spline_orient' % root_name,
                    index=i
                )
                orient_transform.plugs.set_values(
                    inheritsTransform=False
                )
                aim_transform.plugs.set_values(
                    inheritsTransform=False
                )
                translation_transform.plugs.set_values(
                    inheritsTransform=False
                )
                up_transform = self.create_child(
                    Transform,
                    node_type='multiplyDivide',
                    root_name='%s_spline_up' % root_name,
                    index=i

                )
                plus_minus_aim = spline_joint.create_child(
                    DependNode,
                    node_type='plusMinusAverage',
                    root_name='%s_spline_aim' % root_name
                )
                plus_minus_up = spline_joint.create_child(
                    DependNode,
                    node_type='plusMinusAverage',
                    root_name='%s_spline_up' % root_name
                )

                curve_position_plug = point_on_curve_info.plugs['result'].child(0)
                surface_position_plug = point_on_surface_info.plugs['result'].child(0)
                curve_tangent_plug = point_on_curve_info.plugs['result'].child(4)
                surface_normal_plug = point_on_surface_info.plugs['result'].child(2)

                surface_position_plug.connect_to(plus_minus_up.plugs['input3D'].element(0))
                surface_normal_plug.connect_to(plus_minus_up.plugs['input3D'].element(1))
                plus_minus_up.plugs['output3D'].connect_to(up_transform.plugs['translate'])
                surface_position_plug.connect_to(plus_minus_aim.plugs['input3D'].element(0))
                curve_tangent_plug.connect_to(plus_minus_aim.plugs['input3D'].element(1))
                plus_minus_aim.plugs['output3D'].connect_to(aim_transform.plugs['translate'])
                point_on_curve_info.plugs['result'].child(0).connect_to(orient_transform.plugs['translate'])
                point_on_curve_info.plugs['result'].child(0).connect_to(closest_point_on_surface.plugs['inPosition'])
                self.spline_curve.plugs['worldSpace'].element(0).connect_to(point_on_curve_info.plugs['inputCurve'])
                self.follicle_surface.plugs['worldSpace'].element(0).connect_to(closest_point_on_surface.plugs['inputSurface'])
                self.follicle_surface.plugs['worldSpace'].element(0).connect_to(point_on_surface_info.plugs['inputSurface'])
                closest_point_on_surface.plugs['result'].child(1).connect_to(point_on_surface_info.plugs['parameterU'])
                closest_point_on_surface.plugs['result'].child(2).connect_to(point_on_surface_info.plugs['parameterV'])
                closest_point_on_surface.plugs['result'].child(0).connect_to(translation_transform.plugs['translate'])
                self.controller.create_aim_constraint(
                    aim_transform,
                    orient_transform,
                    worldUpType='object',
                    worldUpObject=up_transform,
                    aimVector=[x * -1 for x in env.aim_vector],
                    upVector=env.up_vector
                )
                self.controller.create_point_constraint(
                    translation_transform,
                    spline_joint,
                    mo=False
                )
                orient_transform.plugs['rotate'].connect_to(spline_joint.plugs['rotate'])

            point_on_curve_info.plugs['turnOnPercentage'].set_value(True)
            parameter_multiply_node.plugs['input2X'].set_value(segment_parameter * i)
            parameter_multiply_node.plugs['outputX'].connect_to(point_on_curve_info.plugs['parameter'])
            length_multiply_plug.connect_to(parameter_multiply_node.plugs['input1X'])
            spline_joints.append(spline_joint)
        self.spline_joints = spline_joints
        self.deform_joints.extend(spline_joints)


def create_guide_handles_from_data(owner, handle_data):
    root = owner.get_root()
    size_plug = owner.plugs['size']

    size_multiply = owner.create_child(
        DependNode,
        node_type='multiplyDivide',
        segment_name='Size'
    )
    size_plug.connect_to(size_multiply.plugs['input1X'])
    size_plug.connect_to(size_multiply.plugs['input1Y'])
    size_multiply.plugs['input2X'].set_value(1.0)
    size_multiply.plugs['input2Y'].set_value(1.0)

    for data in handle_data:
        vertices = []
        for mesh_name, index in data.pop('vertices', []):
            if mesh_name in root.geometry:
                vertices.append(root.geometry[mesh_name].get_vertex(index))
        data['root_name'] = owner.root_name
        print data
        handle = owner.create_handle(
            vertices=vertices,
            **data
        )
        print handle
        size_multiply.plugs['outputX'].connect_to(handle.plugs['size'])
        handle.vertices = vertices
        side = data['side']
        shader_side = side if side else 'center'
        shading_group = root.shaders[shader_side].shading_group
        handle.mesh.assign_shading_group(shading_group)


def is_even(number):
    if (number % 2) == 0:
        return True
    return False


def create_handle_data(count, side, root_name, size):
    if count < 2:
        raise StandardError('Count must be at-least 2')

    data = []
    if side == 'left':
        for x in range(count):
            data.append(dict(
                root_name=root_name,
                segment_namew=rig_factory.index_dictionary[x].title(),
                size=size,
                side=side,
                matrix=Matrix([(size*2) * x, 0.0, 0.0])
            ))
    elif side == 'right':
        for x in range(count):
            data.append(dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[x].title(),
                size=size,
                side=side,
                matrix=Matrix([(size*-2) * x, 0.0, 0.0])
            ))
    elif side == 'center':
        for x in range(count):
            data.append(dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[x].title(),
                size=size,
                side=side,
                matrix=Matrix([0.0, (size*2) * x, 0.0])
            ))
    elif side is None:
        even_count = is_even(count)
        side_count = count / 2 if even_count else (count - 1) / 2
        for x in range(side_count):
            position = [(size * -2) * (x + 1), 0.0, 0.0]
            if x == 0 and even_count:
                position = [(size * -1) * (x + 1), 0.0, 0.0]
            data.insert(0, dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[x].title(),
                size=size,
                side='right',
                matrix=Matrix(position)
            ))
        if not even_count:
            data.append(dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[0].title(),
                size=size,
                side='center',
                matrix=Matrix([0.0, 0.0, 0.0])
            ))
        for x in range(side_count):
            position = [(size * 2) * (x + 1), 0.0, 0.0]
            if x == 0 and even_count:
                position = [size * (x + 1), 0.0, 0.0]
            data.append(dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[x].title(),
                size=size,
                side='left',
                matrix=Matrix(position)
            ))
    return data

