from rig_factory.objects.part_objects.chain_guide import ChainGuide
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.rig_objects.grouped_handle import LocalHandle, WorldHandle
from rig_factory.objects.base_objects.properties import ObjectProperty
from rig_math.matrix import Matrix
import rig_factory.environment as env
import rig_factory


class QuadrupedSpineFkGuide(ChainGuide):
    default_settings = dict(
        root_name='Spine',
        size=1.0,
        side='center',
        count=5
    )

    def __init__(self, **kwargs):
        super(QuadrupedSpineFkGuide, self).__init__(**kwargs)
        self.toggle_class = QuadrupedSpineFk.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['up_vector_indices'] = [0]
        kwargs.setdefault('root_name', 'Spine')
        segment_names = []
        count = kwargs.get('count', cls.default_settings['count'])
        for i in range(count):
            if i == 0:
                segment_names.append('Hip')
            elif i == count - 2:
                segment_names.append('Chest')
            elif i == count - 1:
                segment_names.append('ChestEnd')
            else:
                segment_names.append(rig_factory.index_dictionary[i - 1].title())
        kwargs['segment_names'] = segment_names
        this = super(QuadrupedSpineFkGuide, cls).create(controller, **kwargs)
        return this

    def get_toggle_blueprint(self):
        blueprint = super(QuadrupedSpineFkGuide, self).get_toggle_blueprint()
        matrices = [list(x.get_matrix()) for x in self.joints]
        blueprint['matrices'] = matrices
        return blueprint


class QuadrupedSpineFk(Part):

    hip_handle = ObjectProperty(
        name='hip_handle'
    )

    def __init__(self, **kwargs):
        super(QuadrupedSpineFk, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        if 'side' not in kwargs:
            raise StandardError('you must provide a "side" keyword argument to create a %s' % cls.__name__)
        this = super(QuadrupedSpineFk, cls).create(controller, **kwargs)

    @staticmethod
    def build_rig(this):
        controller = this.controller
        size = this.size
        side = this.side
        matrices = this.matrices
        joints = []
        handle_parent = this
        joint_parent = this.joint_group
        root = this.get_root()

        hip_matrix = Matrix(matrices[0])
        hip_matrix.set_translation(matrices[1].get_translation())
        hip_handle = this.create_handle(
            handle_type=LocalHandle,
            segment_name='Hip',
            shape='double_triangle_z',
            matrix=hip_matrix,
            rotation_order='xzy'
        )

        for x, matrix in enumerate(matrices):
            if x == 0:
                segment_name = 'Hip'
            elif x == len(matrices) -2:
                segment_name = 'Chest'
            elif x == len(matrices) - 1:
                segment_name = 'ChestEnd'
            else:
                segment_name = rig_factory.index_dictionary[x-1].title()
            joint = this.create_child(
                Joint,
                matrix=matrices[x],
                parent=joint_parent,
                segment_name=segment_name,
            )
            joint.zero_rotation()
            joint.plugs.set_values(
                overrideEnabled=1,
                overrideDisplayType=2,
                visibility=False
            )
            joints.append(joint)
            joint_parent = joint

            if not x == 0 and not x == len(matrices)-1:
                handle = this.create_handle(
                    handle_type=LocalHandle,
                    size=size*1.25,
                    matrix=matrices[x],
                    shape='partial_cube',
                    parent=handle_parent,
                    segment_name=segment_name,
                    rotation_order='xzy'
                )
                handle.stretch_shape(matrices[x + 1])

                handle.multiply_shape_matrix(
                    Matrix(
                        scale=[0.85, 0.85, 0.85]
                    )
                )
                controller.create_parent_constraint(
                    handle.gimbal_handle,
                    joint,
                    mo=True
                )

                if root:
                    root.add_plugs(
                        [
                            handle.plugs['tx'],
                            handle.plugs['ty'],
                            handle.plugs['tz'],
                            handle.plugs['rx'],
                            handle.plugs['ry'],
                            handle.plugs['rz']
                        ]
                    )

                handle_parent = handle.gimbal_handle

        controller.create_parent_constraint(
            hip_handle.gimbal_handle,
            joints[0],
            mo=True
        )
        aim_vector = env.side_aim_vectors[side]
        hip_length = (matrices[1].get_translation() - matrices[0].get_translation()).mag()
        hip_shape_matrix = Matrix(
            hip_length * 0.75 * aim_vector[0] * -1.0,
            hip_length * 0.75 * aim_vector[1] * -1.0,
            hip_length * 0.75 * aim_vector[2] * -1.0
        )
        hip_shape_matrix.set_scale([size, hip_length, size])
        hip_handle.set_shape_matrix(hip_shape_matrix)

        root.add_plugs(
            [
                hip_handle.plugs['tx'],
                hip_handle.plugs['ty'],
                hip_handle.plugs['tz'],
                hip_handle.plugs['rx'],
                hip_handle.plugs['ry'],
                hip_handle.plugs['rz']
            ]
        )
        this.hip_handle = hip_handle
        this.joints = joints
        return this
