

def build_rig(**kwargs):
    build_work = kwargs.get('build_work', False)
    update_geometry = kwargs.get('update_geometry', False)
    build_face = kwargs.get('build_face', True)

    import rig_factory.build.utilities.controller_utilities as cut
    import rig_factory.build.utilities.blueprint_utilities as but
    import rig_factory.utilities.file_utilities as put
    import batch_tasks.rigging_environment as rev

    rev.load_rigging_plugins()

    controller = cut.initialize_rig_controller()
    controller.scene.file(new=True, f=True)

    if build_work:
        controller.build_directory = put.get_user_build_directory()

    else:
        controller.build_directory = put.get_latest_product_directory()

    but.execute_blueprints(
        controller,
        update_geometry=update_geometry,
        build_face=build_face
    )

    return controller

