from base_object import BaseObject


class BaseNode(BaseObject):

    def __setattr__(self, name, value):
        if hasattr(self, name):
            try:
                super(BaseObject, self).__setattr__(name, value)
            except StandardError:
                raise StandardError(
                    'The property "%s" on the node "%s" could not be set to: %s.' % (name, self, value)
                )

        else:
            raise StandardError('The "%s" attribute is not registered with the %s class' % (
                name,
                self.__class__.__name__
            ))

    def __init__(self, *args, **kwargs):
        if not kwargs.get('controller', None):
            raise StandardError(
                'You must provide a controller when creating a %s' % self.__class__.__name__
            )
        super(BaseNode, self).__init__(*args, **kwargs)

    def create_child(self, object_type, *args, **kwargs):
        for key in ['root_name', 'segment_name', 'functionality_name', 'differentiation_name', 'side', 'size', 'index']:
            if key not in kwargs:
                kwargs[key] = self.__getattribute__(key)
        if not kwargs.get('parent', None):
            kwargs['parent'] = self
        node = self.controller.create_object(
            object_type,
            *args,
            **kwargs
        )
        return node
