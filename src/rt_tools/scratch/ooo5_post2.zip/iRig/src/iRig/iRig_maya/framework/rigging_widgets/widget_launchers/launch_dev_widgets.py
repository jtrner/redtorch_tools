import sys
import os
from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
import rigging_widgets

import batch_tasks.rigging_environment as rev



def launch(mock=True):

    style_sheet_path = '%s/rig_builder/qss/slate.qss' % os.path.dirname(rigging_widgets.__file__.replace('\\', '/'))
    with open(style_sheet_path, mode='r') as f:
        style_sheet = f.read()
    if mock:
        rev.load_mock_rigging_environment('RBGB', 'Hopper', dev_mode=True)
    else:
        rev.load_rigging_environment('RBGB', 'Hopper', dev_mode=True)
        rev.load_system_paths(dev_mode=True)

    app = QApplication(sys.argv)
    app.setStyleSheet(style_sheet)
    import rig_factory.build.utilities.controller_utilities as cut
    controller = cut.initialize_rig_controller(mock=True)

    from rigging_widgets.rig_builder.widgets.rig_widget import RigWidget

    body_widget = RigWidget()
    body_widget.set_controller(controller)
    body_widget.show()
    body_widget.raise_()
    sys.exit(app.exec_())


if __name__ == '__main__':
    launch()