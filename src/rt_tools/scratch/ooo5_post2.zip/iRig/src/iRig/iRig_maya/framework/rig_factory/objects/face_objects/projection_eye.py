import os
import rig_factory
from rig_factory.objects.face_objects.eye import Eye, EyeGuide
from rig_factory.objects.base_objects.properties import DataProperty, ObjectProperty, ObjectListProperty
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.node_objects.shader import Shader
from rig_factory.objects.rig_objects.surface_point import SurfacePoint

iris_color_file_path = '%s/static/images/iris_color.tx' % os.path.dirname(rig_factory.__file__.replace('\\', '//'))


class ProjectionEyeGuide(EyeGuide):

    geometry_names = DataProperty(
        name='geometry_names',
        default_value=[]
    )

    default_settings = dict(
        root_name='Eye',
        size=1.0,
        side='left'
    )

    def __init__(self, **kwargs):
        super(ProjectionEyeGuide, self).__init__(**kwargs)
        self.toggle_class = ProjectionEye.__name__

    def set_geometry_names(self, *geometry_names):
        self.geometry_names = geometry_names

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(ProjectionEyeGuide, cls).create(controller, **kwargs)
        return this


class ProjectionEye(Eye):

    geometry_names = DataProperty(
        name='geometry_names',
        default_value=[]
    )

    shader = ObjectProperty(
        name='shader'
    )

    place_texture_group = ObjectProperty(
        name='place_texture_group'
    )

    mesh_node = ObjectProperty(
        name='mesh_node'
    )

    surface_point = ObjectProperty(
        name='surface_point'
    )
    def __init__(self, **kwargs):
        super(ProjectionEye, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):

        this = super(ProjectionEye, cls).create(controller, **kwargs)
        root = this.get_root()
        matrices = this.matrices

        inner_dilation_plug = this.create_plug('InnerDilation', at='double', min=0.0, dv=0.18)
        outer_dilation_plug = this.create_plug('OuterDilation', at='double', min=0.0, dv=0.3)
        hue_plug = this.create_plug('Hue', at='double', min=0.0, dv=0.340)

        set_range = this.create_child(
            DependNode,
            node_type='setRange',
            segment_name='SetRange'
        )

        inner_dilation_plug.connect_to(set_range.plugs['valueX'])
        inner_dilation_clamp = this.create_child(
            DependNode,
            node_type='clamp',
            segment_name='InnerDilation'
        )

        inner_dilation_add = this.create_child(
            DependNode,
            node_type='floatMath',
            segment_name='InnerDilation'
        )

        outer_dilation_clamp = this.create_child(
            DependNode,
            node_type='clamp',
            segment_name='OuterDilation'
        )
        outer_dilation_add = this.create_child(
            DependNode,
            node_type='floatMath',
            segment_name='OuterDilation'
        )

        pupil_remap = this.create_child(
            DependNode,
            node_type='remapHsv',
            segment_name='InnerHSVRemap'
        )
        whites_remap = this.create_child(
            DependNode,
            node_type='remapHsv',
            segment_name='OuterHSVRemap'
        )
        iris_remap = this.create_child(
            DependNode,
            node_type='remapHsv',
            segment_name='IrisHSVRemap'
        )
        iris_ramp = this.create_child(
            DependNode,
            node_type='ramp',
            segment_name='Iris'
        )
        outer_luminance = this.create_child(
            DependNode,
            node_type='luminance',
            segment_name='OuterLuminance'
        )

        inner_luminance = this.create_child(
            DependNode,
            node_type='luminance',
            segment_name='InnerLuminance'
        )
        iris_file = this.create_child(
            DependNode,
            node_type='file',
            segment_name='IrisFile'
        )
        radial_ramp = this.create_child(
            DependNode,
            node_type='ramp',
            segment_name='Radial'
        )
        layared_texture = this.create_child(
            DependNode,
            node_type='layeredTexture',
            segment_name='LayeredTexture'
        )

        plane_transform = this.create_child(
            Transform,
            segment_name='Plane',
            matrix=matrices[0]
        )

        plane_mesh = plane_transform.create_child(
            Mesh,
            segment_name='Plane'
        )

        root.geometry[plane_mesh.name] = plane_mesh

        plane_poly_plane = plane_transform.create_child(
            DependNode,
            node_type='polyPlane',
            segment_name='Plane',
        )
        plane_poly_plane.plugs.set_values(
            subdivisionsWidth=1,
            subdivisionsHeight=1,
        )
        plane_poly_plane.plugs['output'].connect_to(
            plane_mesh.plugs['inMesh'],
        )

        # Surface point for mounting the projections.

        surface_point = this.create_child(
            SurfacePoint,
            segment_name='Follicle',
            surface=plane_mesh,
        )
        surface_point.follicle.plugs.set_values(
            parameterU=.5,
            parameterV=.5,
        )

        place_texture_group = this.joints[0].create_child(
            Transform,
            segment_name='PlaceTexture',
            matrix=surface_point.get_matrix()
        )

        place_texture_group.create_child(Locator)

        place_texture = place_texture_group.create_child(
            Transform,
            node_type='place3dTexture',
            segment_name='PlaceTexture',
            suffix='Plx',
            matrix=surface_point.get_matrix()
        )
        projection = this.create_child(
            DependNode,
            node_type='projection',
            segment_name='Projection'
        )
        shader = this.create_child(
            Shader,
            node_type='lambert',
            segment_name='Lambert',
        )

        controller.create_parent_constraint(
            surface_point,
            this.handles_group,
            mo=True
        )

        iris_ramp.plugs['type'].set_value(4)
        radial_ramp.plugs['type'].set_value(3)
        set_range.plugs['maxX'].set_value(0.260)
        set_range.plugs['outValueX'].connect_to(inner_dilation_clamp.plugs['inputR'])
        inner_dilation_clamp.plugs['outputR'].connect_to(inner_dilation_add.plugs['floatA'])
        inner_dilation_add.plugs['floatB'].set_value(0.02)
        inner_dilation_clamp.plugs['minR'].set_value(0.00)
        inner_dilation_clamp.plugs['maxR'].set_value(0.65)
        outer_dilation_plug.connect_to(outer_dilation_clamp.plugs['inputR'])
        outer_dilation_clamp.plugs['outputR'].connect_to(outer_dilation_add.plugs['floatA'])
        outer_dilation_add.plugs['floatB'].set_value(0.02)
        outer_dilation_clamp.plugs['minR'].set_value(0.02)
        outer_dilation_clamp.plugs['maxR'].set_value(0.67)
        outer_dilation_add.plugs['outFloat'].connect_to(iris_ramp.plugs['colorEntryList'].element(0).child(0))
        iris_ramp.plugs['colorEntryList'].element(0).child(1).set_value([0.0, 0.0, 0.0])
        inner_dilation_clamp.plugs['outputR'].connect_to(iris_ramp.plugs['colorEntryList'].element(1).child(0))
        iris_ramp.plugs['colorEntryList'].element(1).child(1).set_value([1.0, 1.0, 1.0])
        outer_dilation_clamp.plugs['outputR'].connect_to(iris_ramp.plugs['colorEntryList'].element(2).child(0))
        iris_ramp.plugs['colorEntryList'].element(2).child(1).set_value([0.187, 0.187, 0.187])
        inner_dilation_add.plugs['outFloat'].connect_to(iris_ramp.plugs['colorEntryList'].element(3).child(0))
        iris_ramp.plugs['colorEntryList'].element(3).child(1).set_value([1.0, 1.0, 1.0])
        iris_ramp.plugs['outColor'].connect_to(pupil_remap.plugs['color'])
        iris_ramp.plugs['outColor'].connect_to(whites_remap.plugs['color'])
        pupil_remap.plugs['outColor'].connect_to(inner_luminance.plugs['value'])
        whites_remap.plugs['outColor'].connect_to(outer_luminance.plugs['value'])
        radial_ramp.plugs['outAlpha'].connect_to(iris_file.plugs['uCoord'])
        iris_ramp.plugs['outAlpha'].connect_to(iris_file.plugs['vCoord'])
        iris_file.plugs['outColor'].connect_to(iris_remap.plugs['color'])
        inner_luminance.plugs['outValue'].connect_to(layared_texture.plugs['inputs'].element(0).child(1))
        outer_luminance.plugs['outValue'].connect_to(layared_texture.plugs['inputs'].element(1).child(1))
        iris_remap.plugs['outColor'].connect_to(layared_texture.plugs['inputs'].element(2).child(0))
        iris_file.plugs['fileTextureName'].set_value(iris_color_file_path)
        pupil_remap.plugs['value'].element(0).child(0).set_value(0.950)
        pupil_remap.plugs['value'].element(0).child(1).set_value(0.0)
        pupil_remap.plugs['value'].element(1).child(0).set_value(1.0)
        pupil_remap.plugs['value'].element(1).child(1).set_value(1.0)
        whites_remap.plugs['value'].element(0).child(0).set_value(0.0)
        whites_remap.plugs['value'].element(0).child(1).set_value(1.0)
        whites_remap.plugs['value'].element(1).child(0).set_value(0.1)
        whites_remap.plugs['value'].element(1).child(1).set_value(0.0)
        iris_remap.plugs['hue'].element(0).child(0).set_value(1.0)
        iris_remap.plugs['hue'].element(0).child(1).set_value(0.340)
        layared_texture.plugs['hardwareColor'].set_value([0.5, 0.5, 0.5])
        layared_texture.plugs['inputs'].element(1).child(0).set_value([0.865, 0.865, 0.865])
        layared_texture.plugs['outColor'].connect_to(projection.plugs['image'])
        place_texture.plugs['worldInverseMatrix'].element(0).connect_to(projection.plugs['placementMatrix'])
        projection.plugs['outColor'].connect_to(shader.plugs['color'])
        this.scale_multiply_transform.plugs['scaleX'].connect_to(
            surface_point.plugs['scaleX']
        )
        this.scale_multiply_transform.plugs['scaleX'].connect_to(
            surface_point.plugs['scaleY']
        )
        this.scale_multiply_transform.plugs['scaleX'].connect_to(
            surface_point.plugs['scaleZ']
        )
        this.aim_handle.plugs['rz'].connect_to(place_texture.plugs['rz'])
        this.aim_handle.plugs['scale'].connect_to(place_texture.plugs['scale'])


        hue_plug.connect_to(iris_remap.plugs['hue'].element(0).child(1))

        this.mesh_node = plane_mesh
        this.surface_point = surface_point
        this.shader = shader
        this.place_texture_group = place_texture_group
        return this


    def finalize(self):
        super(ProjectionEye, self).finalize()
        self.place_texture_group.plugs['v'].set_value(False)
        self.surface_point.plugs['v'].set_value(False)
        self.mesh_node.plugs['v'].set_value(False)

    def add_geometry_names(self, *geometry_names):
        root = self.get_root()
        self.shader.add_geometries([root.geometry[x] for x in geometry_names if x in root.geometry])
