import sys
import traceback
import inspect
import os
import json
import rig_factory
import rig_factory.objects as obs

framework_directory = os.path.dirname(os.path.dirname(rig_factory.__file__.replace('\\', '/')))
parts_directory = '%s/part_library' % framework_directory
part_versions_directory = '%s/versions' % parts_directory
part_versions_json_path = '%s/versions.json' % part_versions_directory
config_root = 'G:'

LOCALS = locals()

with open(part_versions_json_path, mode='r') as f:
    version_data = json.load(f)


def get_subclasses(base_class):
    sub_classes = list(base_class.__subclasses__())
    for sub_class in sub_classes:
        sub_classes.extend(get_subclasses(sub_class))
    return sub_classes


def load_project_module_versions():
    version_preference = None
    module_versions = dict()

    config_path = '%s/Rigging/Shows/%s/show_config.json' % (
        config_root,
        os.environ.get('TT_PROJCODE')
    )
    if os.path.exists(config_path):
        try:
            with open(config_path, mode='r') as f:
                show_config = json.load(f)
        except StandardError:
            traceback.print_exc()
            raise StandardError('Unable to parse show config json file : %s' % config_path)

        version_preference = show_config['framework_config'].get(
            'module_version_preference',
            None
        )
        module_versions = show_config['framework_config'].get(
            'module_versions',
            dict()
        )

    show_modules = dict()
    part_classes = get_subclasses(obs.BasePart)
    container_classes = get_subclasses(obs.BaseContainer)
    part_classes.extend(container_classes)

    module_names = list(set([x.__module__ for x in part_classes]))
    for module_name in module_names:
        module_short_name = module_name.split('.')[-1]
        if module_short_name in version_data:
            ordered_versions = sorted(version_data[module_short_name].keys())
            if ordered_versions:
                if version_preference == 'oldest':
                    show_modules[module_short_name] = ordered_versions[0]
                elif version_preference == 'newest':
                    show_modules[module_short_name] = ordered_versions[-1]

    show_modules.update(module_versions)
    load_module_versions(**show_modules)


def load_modules():
    for name, obj in inspect.getmembers(obs):
        if inspect.isclass(obj):
            if issubclass(obj, obs.BaseObject):
                LOCALS[name] = obj


def load_module_versions(**module_versions):
    for module_name in module_versions:
        module_version = module_versions[module_name]
        if module_version is not None:
            if module_name not in version_data:
                raise StandardError('The module "%s" does not appear to be a part of the versions library' % module_name)
            module_version_data = version_data[module_name]
            if module_version not in module_version_data:
                raise StandardError('The module version "%s" does not appear to exist' % module_version)
            module_properties = module_version_data[module_version]
            local_path = module_properties['path']
            full_path = '%s%s' % (part_versions_directory, local_path)
            module_directory = os.path.dirname(full_path)
            sys.path.insert(0, module_directory)
            module = __import__(module_name)
            for name, obj in inspect.getmembers(module):
                if inspect.isclass(obj):
                    if issubclass(obj, (obs.BasePart, obs.BaseContainer)):
                        LOCALS[name] = obj
            sys.path.pop(0)
            module = sys.modules[module_name]
            module_version = module.__dict__.get('__version__', None)




load_modules()
