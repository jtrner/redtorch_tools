from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
from rigging_widgets.rig_builder.widgets.fail_widget import FailWidget
from rigging_widgets.rig_builder.widgets.finalized_widget import FinalizedWidget
from rigging_widgets.rig_builder.widgets.geometry_widget import GeometryWidget
from rigging_widgets.rig_builder.widgets.new_container_view import NewContainerView
from rigging_widgets.rig_builder.widgets.new_part_widget import NewPartWidget
from rigging_widgets.rig_builder.widgets.progress_widget import ProgressWidget


class SaveWidget(QDialog):

    save_signal = Signal(str)

    def __init__(self, *args, **kwargs):
        super(SaveWidget, self).__init__(*args, **kwargs)
        self.horizontal_layout = QHBoxLayout(self)
        self.vertical_layout = QVBoxLayout()
        self.buttons_layout = QHBoxLayout()
        self.setWindowTitle('Save Work ')
        self.label = QLabel('Saving Work', self)
        self.comment_label = QLabel('Enter a comment...', self)

        self.label.setFont(QFont('', 18, True))
        self.label.setWordWrap(True)
        self.label.setAlignment(Qt.AlignHCenter)
        self.comments_field = QTextEdit(self)
        self.ok_button = QPushButton('OK!', self)
        self.cancel_button = QPushButton('CANCEL', self)

        self.horizontal_layout.addStretch()
        self.horizontal_layout.addLayout(self.vertical_layout)
        self.horizontal_layout.addStretch()
        self.vertical_layout.addStretch()
        self.vertical_layout.addWidget(self.label)
        self.vertical_layout.addStretch()
        self.vertical_layout.addWidget(self.comment_label)
        self.vertical_layout.addWidget(self.comments_field)
        self.vertical_layout.addStretch()
        self.vertical_layout.addLayout(self.buttons_layout)
        self.buttons_layout.addStretch()
        self.buttons_layout.addWidget(self.ok_button)
        self.buttons_layout.addWidget(self.cancel_button)
        self.vertical_layout.addStretch()
        self.vertical_layout.addStretch()
        self.ok_button.pressed.connect(self.emit_save)
        self.cancel_button.pressed.connect(self.close)


    def emit_save(self):
        self.close()
        self.save_signal.emit(self.comments_field.toPlainText())

    def keyPressEvent(self, event):
        super(SaveWidget, self).keyPressEvent(event)
        key_object = event.key()
        if key_object == Qt.Key_Return:
            self.emit_save()