from dag_node import DagNode
from rig_factory.objects.base_objects.properties import DataProperty


class NurbsCurve(DagNode):

    positions = DataProperty(
        name='positions'
    )
    degree = DataProperty(
        name='degree',
        default_value=2
    )
    form = DataProperty(
        name='form',
        default_value=0
    )
    create_2d = DataProperty(
        name='create_2d',
        default_value=False
    )
    rational = DataProperty(
        name='rational',
        default_value=False
    )

    def __init__(self, **kwargs):
        kwargs['positions'] = [list(x) for x in kwargs.get('positions', [])]
        super(NurbsCurve, self).__init__(**kwargs)
        self.node_type = 'nurbsCurve'

    @classmethod
    def create(cls, controller, **kwargs):
        if not kwargs['parent']:
            raise StandardError('Cannot create a NurbsCurve without a parent')
        return super(NurbsCurve, cls).create(controller, **kwargs)

    def get_curve_data(self):
        return self.controller.get_curve_data(self)

    def create_in_scene(self):
        if self.positions:
            self.m_object = self.controller.scene.draw_nurbs_curve(
                self.positions,
                self.degree,
                self.form,
                self.name,
                self.parent.m_object,
                create_2d=self.create_2d,
                rational=self.rational
            )
        else:
            self.m_object = self.controller.scene.create_dag_node(
                self.node_type,
                self.name,
                self.parent.m_object
            )
