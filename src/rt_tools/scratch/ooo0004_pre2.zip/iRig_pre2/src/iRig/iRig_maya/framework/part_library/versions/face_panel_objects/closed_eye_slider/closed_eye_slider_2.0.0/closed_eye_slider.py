__version__ = '2.0.0'
__developer__ = 'Paxton Gerrish'
__email__ = 'paxtongerrish@gmail.com'
__notes__ = 'Saving v1 for old rig compatibility'

from rig_factory.objects.face_panel_objects.base_slider import BaseSlider, BaseSliderGuide
from rig_math.matrix import Matrix
import rig_factory.utilities.face_panel_utillities as utl
from rig_factory.objects.base_objects.properties import ObjectProperty
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.joint import Joint
import copy


class ClosedEyeSliderGuide(BaseSliderGuide):

    default_settings = dict(
        root_name='closed_eye',
        side='left',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(ClosedEyeSliderGuide, self).__init__(**kwargs)
        self.toggle_class = ClosedEyeSlider.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(BaseSliderGuide, cls).create(controller, **kwargs)
        root_name = this.root_name
        joints = []
        for handle_name in ('lid', 'blink'):
            handle = this.create_handle(
                root_name=root_name + '_' + handle_name
            )
            handle.mesh.assign_shading_group(this.get_root().shaders[this.side].shading_group)
            joint = handle.create_child(
                Joint
            )
            controller.create_parent_constraint(handle, joint)
            joint.plugs['drawStyle'].set_value(2)
            joints.append(joint)
        this.joints = joints
        return this


class ClosedEyeSlider(BaseSlider):

    up_handle = ObjectProperty(
        name='up_handle'
    )

    down_handle = ObjectProperty(
        name='up_handle'
    )

    blink_handle = ObjectProperty(
        name='blink_handle'
    )

    def __init__(self, **kwargs):
        super(ClosedEyeSlider, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(ClosedEyeSlider, cls).create(controller, **kwargs)
        root_name = this.root_name
        side = this.side
        size = this.size
        if len(this.matrices) == 1:
            eye_matrix, blink_matrix = [
                this.matrices[0],
                copy.copy(this.matrices[0])
            ]
        else:
            eye_matrix, blink_matrix = this.matrices

        #  Nodes

        up_handle = this.create_handle(
            root_name='up_' + root_name,
            shape='circle_half_smooth',
            size=size * 0.5,
            matrix=eye_matrix * Matrix(0.0, size, 0.0)
        )
        # utl.set_attr_limit(up_handle, 'TransY', size * -1.25, size * 0.25)
        # utl.set_attr_limit(up_handle, 'TransX', size * -1.0, size)
        utl.set_attr_limit(up_handle, 'TransZ', 0.0, 0.0)
        if side == 'right':
            up_handle.groups[-1].plugs['rotateY'].set_value(180.0)

        down_handle = this.create_handle(
            root_name='down_' + root_name,
            shape='circle_half_smooth',
            size=size * 0.5,
            matrix=eye_matrix * Matrix(0.0, -1.0 * size, 0.0)
        )
        # utl.set_attr_limit(down_handle, 'TransY', size * -0.25, size * 1.25)
        # utl.set_attr_limit(down_handle, 'TransX', size * -1.0, size)
        utl.set_attr_limit(down_handle, 'TransZ', 0.0, 0.0)
        down_handle.multiply_shape_matrix(Matrix(scale=[1.0, -1.0, 1.0]))
        if side == 'right':
            down_handle.groups[-1].plugs['rotateY'].set_value(180.0)
        position_transform = this.create_child(
            Transform,
            matrix=blink_matrix,
            root_name=root_name + '_blink_position',
        )
        outline_curve_wide = position_transform.create_child(
            NurbsCurve,
            root_name=root_name + '_outline_wide',
            degree=1,
            positions=[
                [0.0, size, 0.0],
                [size * -1.25, size, 0.0],
                [size * -1.25, size * -1.0, 0.0],
                [0.0, size * -1.0, 0.0],
                [0.0, size, 0.0]
            ]
        )
        x_curve = position_transform.create_child(
            NurbsCurve,
            root_name=root_name + '_x',
            degree=1,
            positions=[
                [size * -1.25, 0.0, 0.0],
                [0.0, 0.0, 0.0]
            ]
        )
        y_curve = position_transform.create_child(
            NurbsCurve,
            root_name=root_name + '_y',
            degree=1,
            positions=[
                [size * -1.0, size*-1.0, 0.0],
                [size * -1.0, size, 0.0]
            ]
        )

        x_curve.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )
        y_curve.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )
        outline_curve_wide.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )

        blink_handle = this.create_handle(
            root_name=root_name + '_blink',
            shape='star_four',
            axis='z',
            size=size,
            side=side,
            matrix=blink_matrix,
            parent=position_transform
        )
        utl.set_attr_limit(
            blink_handle,
            'TransY',
            size * -1.0,
            size
        )
        utl.set_attr_limit(
            blink_handle,
            'TransX',
            size * -1.25,
            0.0
        )
        utl.set_attr_limit(
            blink_handle,
            'TransZ',
            0.0,
            0.0
        )


        up_lid_blink_driver_plug = this.create_plug(
            'up_lid_blink_driver',
            k=True,
            at='double'
        )

        down_lid_blink_driver_plug = this.create_plug(
            'down_lid_blink_driver',
            k=True,
            at='double'
        )

        up_horizontal_driver = this.create_plug(
            'up_horizontal_driver',
            k=True,
            at='double',
            min=-1.0,
            max=1.0
        )

        down_horizontal_driver = this.create_plug(
            'down_horizontal_driver',
            k=True,
            at='double',
            min=-1.0,
            max=1.0
        )

        up_locator = position_transform.create_child(
            Transform,
            root_name='%s_up_locator' % root_name
        )
        up_locator_shape = up_locator.create_child(Locator)
        up_locator_shape.plugs.set_values(
            localScale=[size*0.5, size*0.5, size*0.5]
        )
        down_locator = position_transform.create_child(
            Transform,
            root_name='%s_down_locator' % root_name
        )
        down_locator_shape = down_locator.create_child(Locator)
        down_locator_shape.plugs.set_values(
            localScale=[size*0.5, size*0.5, size*0.5]
        )
        up_lid_blink_driver_plug.connect_to(up_locator.plugs['ty'])
        down_lid_blink_driver_plug.connect_to(down_locator.plugs['ty'])

        up_locator.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )

        down_locator.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )

        blink_remap_x = blink_handle.plugs['tx'].remap(
            (0.0, 0.0),
            (size*-1, 1.0)
        )
        blink_remap_reverse_x = blink_handle.plugs['tx'].remap(
            (0.0, 1.0),
            (size*-1, 0.0)
        )

        blink_remap_y = blink_handle.plugs['ty'].remap(
            (size * -2.0, -2.0),
            (0.0, 0.0),
            (size*2.0, 2.0)
        )
        up_lid_remap_x = up_handle.plugs['tx'].remap(
            (size * -2.0, -2.0),
            (0.0, 0.0),
            (size*2.0, 2.0)
        )
        up_lid_remap_y = up_handle.plugs['ty'].remap(
            (size * -2.0, -2.0),
            (0.0, 0.0),
            (size*2.0, 2.0)
        )
        down_lid_remap_x = down_handle.plugs['tx'].remap(
            (size * -2.0, -2.0),
            (0.0, 0.0),
            (size*2.0, 2.0)
        )
        down_lid_remap_y = down_handle.plugs['ty'].remap(
            (size * -2.0, -2.0),
            (0.0, 0.0),
            (size*2.0, 2.0)
        )

        lid_up_wide_remap_x = blink_handle.plugs['tx'].remap(
            (size*-1, 0.0),
            ((size*-1.25), 0.25)
        )
        lid_up_wide_remap_y = blink_handle.plugs['ty'].remap(
            (size*-1, 0.0),
            (0.0, 1.0)
        )

        up_wide_plug = lid_up_wide_remap_x.multiply(lid_up_wide_remap_y)

        lid_down_wide_remap_x = blink_handle.plugs['tx'].remap(
            (size*-1, 0.0),
            ((size*-1.25), -0.25)
        )
        lid_down_wide_remap_y = blink_handle.plugs['ty'].remap(
            (size, 0.0),
            (0.0, 1.0)
        )

        down_wide_plug = lid_down_wide_remap_x.multiply(lid_down_wide_remap_y)

        lid_line_multiply = blink_remap_y.multiply(blink_remap_reverse_x)
        lid_line_multiply\
            .add(blink_remap_x)\
            .add(up_lid_remap_y.multiply(blink_remap_x))\
            .add(up_wide_plug)\
            .blend_weighted()\
            .connect_to(up_lid_blink_driver_plug)

        lid_line_multiply\
            .add(blink_remap_x.multiply(-1.0))\
            .add(down_lid_remap_y.multiply(blink_remap_x))\
            .add(down_wide_plug)\
            .blend_weighted()\
            .connect_to(down_lid_blink_driver_plug)

        up_lid_remap_x.blend_weighted().connect_to(up_horizontal_driver)
        down_lid_remap_x.blend_weighted().connect_to(down_horizontal_driver)


        # #  Blink Math Nodes
        # blink_normalizer = this.create_child(
        #     DependNode,
        #     node_type='multiplyDivide',
        #     root_name='%s_blink_normalize' % root_name
        # )
        # blink_normalizer.plugs.set_values(
        #     operation=2,
        #     input2X=size,
        #     input2Y=size,
        #     input2Z=size
        #
        # )
        #
        # blink_handle.plugs['tx'].connect_to(
        #     blink_normalizer.plugs['input1X']
        # )
        # blink_handle.plugs['ty'].connect_to(
        #     blink_normalizer.plugs['input1Y']
        # )




        #
        # #
        # # blink_reverse_multiplier = this.create_child(
        # #     DependNode,
        # #     node_type='multiplyDivide',
        # #     root_name='%s_blink_reverse' % root_name
        # # )
        #
        # # blink_reverse_multiplier.plugs.set_values(
        # #     operation=2,
        # #     input2X=-1.0*size,
        # #     input2Y=-1.0*size,
        # #     input2Z=-1.0*size,
        # #
        # # )
        # blink_x_remap = this.create_child(
        #     DependNode,
        #     node_type='remapValue',
        #     root_name='%s_blink_x' % root_name
        # )
        # blink_x_remap.plugs['value'].element(0).child(0).set_value(0.0)
        # blink_x_remap.plugs['value'].element(0).child(1).set_value(1.0)
        # blink_x_remap.plugs['value'].element(1).child(0).set_value(-1.0)
        # blink_x_remap.plugs['value'].element(1).child(1).set_value(0.0)
        #
        #
        # blink_handle.plugs['tx'].connect_to(
        #     blink_x_reverse_remap.plugs['inputValue']
        # )
        #
        #
        # blink_normalizer.plugs['outputX'].connect_to(blink_x_remap.plugs['inputValue'])
        #
        # blink_crossfader = this.create_child(
        #     DependNode,
        #     node_type='multiplyDivide',
        #     root_name='%s_blink_crossfade' % root_name
        # )
        #
        # blink_x_remap.plugs['outValue'].connect_to(blink_crossfader.plugs['input1X'])
        # blink_normalizer.plugs['outputY'].connect_to(blink_crossfader.plugs['input2X'])
        #
        # x_y_blink_up_add = this.create_child(
        #     DependNode,
        #     node_type='addDoubleLinear',
        #     root_name='%s_x_y_up_blink' % root_name
        # )
        #
        # blink_x_reverse_remap.plugs['outValue'].connect_to(x_y_blink_up_add.plugs['input1'])
        # blink_crossfader.plugs['outputX'].connect_to(x_y_blink_up_add.plugs['input2'])
        #
        # x_y_blink_down_add = this.create_child(
        #     DependNode,
        #     node_type='addDoubleLinear',
        #     root_name='%s_x_y_down_blink' % root_name
        # )
        #
        # blink_normalizer.plugs['outputX'].connect_to(x_y_blink_down_add.plugs['input1'])
        # blink_crossfader.plugs['outputX'].connect_to(x_y_blink_down_add.plugs['input2'])
        #
        #
        # #  Up Lid Math Nodes
        #
        # up_lid_normalizer = this.create_child(
        #     DependNode,
        #     node_type='multiplyDivide',
        #     root_name='%s_up_lid_normalize' % root_name
        # )
        # up_lid_normalizer.plugs.set_values(
        #     operation=2,
        #     input2X=size,
        #     input2Y=size
        # )
        # up_handle.plugs['tx'].connect_to(
        #     up_lid_normalizer.plugs['input1X']
        # )
        # up_handle.plugs['ty'].connect_to(
        #     up_lid_normalizer.plugs['input1Y']
        # )
        #
        # #  Down Lid Math Nodes
        #
        # down_lid_normalizer = this.create_child(
        #     DependNode,
        #     node_type='multiplyDivide',
        #     root_name='%s_down_lid_normalize' % root_name
        # )
        # down_lid_normalizer.plugs.set_values(
        #     operation=2,
        #     input2X=size,
        #     input2Y=size,
        #     input2Z=size
        #
        # )
        # down_handle.plugs['tx'].connect_to(
        #     down_lid_normalizer.plugs['input1X']
        # )
        # down_handle.plugs['ty'].connect_to(
        #     down_lid_normalizer.plugs['input1Y']
        # )
        #
        # #  Combined Lid Math Nodes
        #
        # combine_blinks_multiplier = this.create_child(
        #     DependNode,
        #     node_type='multiplyDivide',
        #     root_name='%s_combine_lid_normalize' % root_name
        # )
        #
        # up_lid_add = this.create_child(
        #     DependNode,
        #     node_type='addDoubleLinear',
        #     root_name='%s_up_lid_add' % root_name
        # )
        #
        # down_lid_add = this.create_child(
        #     DependNode,
        #     node_type='addDoubleLinear',
        #     root_name='%s_down_lid_add' % root_name
        # )
        #
        # up_lid_normalizer.plugs['outputY'].connect_to(combine_blinks_multiplier.plugs['input1X'])
        # down_lid_normalizer.plugs['outputY'].connect_to(combine_blinks_multiplier.plugs['input1Y'])
        # blink_x_reverse_remap.plugs['outValue'].connect_to(combine_blinks_multiplier.plugs['input2X'])
        # blink_x_reverse_remap.plugs['outValue'].connect_to(combine_blinks_multiplier.plugs['input2Y'])
        #
        # #
        #
        # x_y_blink_up_add.plugs['output'].connect_to(up_lid_add.plugs['input1'])
        # x_y_blink_down_add.plugs['output'].connect_to(down_lid_add.plugs['input1'])
        #
        # combine_blinks_multiplier.plugs['outputX'].connect_to(up_lid_add.plugs['input2'])
        # combine_blinks_multiplier.plugs['outputY'].connect_to(down_lid_add.plugs['input2'])

        # Plugs
        #
        # up_lid_blink_driver_plug = this.create_plug(
        #     'up_lid_blink_driver',
        #     k=True,
        #     at='double'
        # )
        #
        # down_lid_blink_driver_plug = this.create_plug(
        #     'down_lid_blink_driver',
        #     k=True,
        #     at='double'
        # )
        #
        #
        # up_lid_blend_weighted = this.create_child(
        #     DependNode,
        #     node_type='blendWeighted',
        #     root_name='%s_up_lid' % root_name
        # )
        #
        # down_lid_blend_weighted = this.create_child(
        #     DependNode,
        #     node_type='blendWeighted',
        #     root_name='%s_down_lid' % root_name
        # )
        #
        # up_lid_add.plugs['output'].connect_to(up_lid_blend_weighted.plugs['input'].element(0))
        # down_lid_add.plugs['output'].connect_to(down_lid_blend_weighted.plugs['input'].element(0))
        #
        # up_lid_blend_weighted.plugs['output'].connect_to(up_lid_blink_driver_plug)
        # down_lid_blend_weighted.plugs['output'].connect_to(down_lid_blink_driver_plug)
        # t = this.create_child(
        #     Transform,
        #     root_name='up_lid'
        # )
        # t.create_child(
        #     Locator
        # )
        # up_lid_blink_driver_plug.connect_to(t.plugs['ty'])
        #
        # t = this.create_child(
        #     Transform,
        #     root_name='down_lid'
        # )
        # t.create_child(
        #     Locator
        # )
        # down_lid_blink_driver_plug.connect_to(t.plugs['ty'])
        #




        #
        # # plugs
        #

        # eyes_up_blink_weighted.plugs['output'].connect_to(
        #     up_lid_blink_driver_plug
        # )
        #

        # eyes_down_blink_weighted.plugs['output'].connect_to(
        #     down_lid_blink_driver_plug
        # )
        #
        # up_horizontal_driver = this.create_plug(
        #     'up_horizontal_driver',
        #     k=True,
        #     at='double',
        #     min=-1.0,
        #     max=1.0
        # )
        # horizontal_mlt_X_weighted.plugs['output'].connect_to(
        #     up_horizontal_driver
        # )
        #

        # horizontal_mlt_Y_weighted.plugs['output'].connect_to(
        #     down_horizontal_driver
        # )

        joint = this.create_child(
            Joint,
            parent=this.joint_group,
            index=1
        )


        root = this.get_root()
        root.add_plugs(
            blink_handle.plugs['tx'],
            blink_handle.plugs['ty'],
            blink_handle.plugs['rz'],
            up_handle.plugs['tx'],
            up_handle.plugs['ty'],
            up_handle.plugs['rz'],
            down_handle.plugs['tx'],
            down_handle.plugs['ty'],
            down_handle.plugs['rz'],
        )

        #  Properties

        this.joints.append(joint)
        this.up_handle = up_handle
        this.down_handle = down_handle
        this.blink_handle = blink_handle

        return this
