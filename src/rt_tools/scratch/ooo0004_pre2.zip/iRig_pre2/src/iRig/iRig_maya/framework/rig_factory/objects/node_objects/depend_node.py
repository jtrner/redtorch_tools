import weakref
from rig_factory.objects.base_objects.base_node import BaseNode
from rig_factory.objects.base_objects.properties import ObjectDictProperty, DataProperty
from rig_factory.objects.node_objects.plug import Plug
from rig_factory.objects.base_objects.weak_list import WeakList


class DependNode(BaseNode):

    existing_plugs = ObjectDictProperty(
        name='existing_plugs'
    )

    node_type = DataProperty(
        name='node_type'
    )

    plugs = []
    m_object = None
    node_delete_callback_id = None
    attribute_delete_callback_id = None

    def __init__(self, **kwargs):
        super(DependNode, self).__init__(**kwargs)
        self.plugs = Plugs(self)
        self.m_object = None

    @classmethod
    def create(cls, controller, **kwargs):
        root_name = kwargs.get('root_name', None)
        if root_name is not None and '.' in root_name and 'root_name':
            raise StandardError('The keyword argument "root_name" has an invalid character : %s' % root_name)
        m_object = kwargs.pop('m_object', None)
        if m_object:
            kwargs['name'] = controller.scene.get_selection_string(m_object)
        this = super(DependNode, cls).create(controller, **kwargs)
        this.m_object = m_object
        if not this.m_object:
            this.create_in_scene()

        if controller.safe_mode:
            this.node_delete_callback_id = controller.scene.add_node_delete_callback(
                this.m_object,
                controller.check_node_deleted
            )
            this.attribute_delete_callback_id = controller.scene.add_attribute_delete_callback(
                this.m_object,
                controller.check_plug_deleted
            )

        return this

    def create_in_scene(self):
        self.m_object = self.controller.scene.create_depend_node(
            self.node_type,
            self.name
        )

    def initialize_plug(self, key):
        if key in self.existing_plugs:
            return self.existing_plugs[key]
        else:
            return self.create_child(
                Plug,
                root_name=key
            )

    def rename(self, name):
        return self.controller.rename(self, name)

    def create_plug(self, name, **kwargs):
        if name in self.existing_plugs:
            raise StandardError('The node "%s" already has a plug named "%s"' % (self, name))
        return self.create_child(
            Plug,
            root_name=name,
            create_kwargs=kwargs,
            user_defined=True
        )

    def get_selection_string(self):
        return self.controller.scene.get_selection_string(self.m_object)

    def __str__(self):
        return self.get_selection_string()

    def teardown(self):
        if self.node_delete_callback_id:
            self.controller.scene.remove_callback(self.node_delete_callback_id)
            self.node_delete_callback_id = None
        if self.attribute_delete_callback_id:
            self.controller.scene.remove_callback(self.attribute_delete_callback_id)
            self.attribute_delete_callback_id = None

        self.controller.nodes_scheduled_for_deletion.append(self.get_selection_string())
        self.m_object = None
        super(DependNode, self).teardown()

    def is_visible(self):
        return self.controller.check_visibility(self)

    def create_node_math_instance(self, plug):
        return NodeMath(plug)


class Plugs(object):
    def __init__(self, owner):
        self.owner = weakref.ref(owner)

    def __getitem__(self, key):
        owner = self.owner()
        if owner:
            if key in owner.existing_plugs:
                return owner.existing_plugs[key]
            else:
                new_plug = owner.initialize_plug(key)
                owner.existing_plugs[key] = new_plug
                return new_plug

    def __setitem__(self, key, val):
        owner = self.owner()
        if owner:
            owner.existing_plugs[key] = val

    def set_values(self, **kwargs):
        for key in kwargs:
            self[key].set_value(kwargs[key])

    def set_locked(self, **kwargs):
        for key in kwargs:
            self[key].set_locked(kwargs[key])

    def get(self, *args):
        return WeakList([self[x] for x in args])

    def exists(self, attribute_name):
        owner = self.owner()
        if owner:
            return owner.controller.scene.objExists('%s.%s' % (owner.get_selection_string(), attribute_name))
        return False


class NodeMath(object):

    def __init__(self, plug):
        super(NodeMath, self).__init__()
        self.plug = plug




    def connect_to(self, target):
        if isinstance(target, NodeMath):
            target = target.plug
        self.plug.connect_to(target)

