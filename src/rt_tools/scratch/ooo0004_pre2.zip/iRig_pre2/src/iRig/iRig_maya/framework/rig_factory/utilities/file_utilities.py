import os
import json
import rig_factory.utilities.default_file_utilities as file_module


def get_standard_build_script_path():
    """Procedural Implementation"""


def get_base_directory():
    """Procedural Implementation"""


def get_all_users_work_scenes():
    """Procedural Implementation"""


def get_next_versions(major_version_up=False):
    """Implemented procedurally"""



def get_current_work_versions():
    """Procedural Implementation"""


def get_latest_product_version():
    """Procedural Implementation"""


def get_pipeline_directory():
    """Procedural Implementation"""


def get_logs_directory():
    """Procedural Implementation"""


def get_work_directory():
    """Procedural Implementation"""


def get_all_users_work_directories():
    """Procedural Implementation"""


def get_user_work_directory():
    """Procedural Implementation"""


def get_user_build_directory():
    """Procedural Implementation"""


def get_products_directory():
    """Procedural Implementation"""


def get_scene_cache_directory():
    """Procedural Implementation"""


def get_elems_directory():
    """Procedural Implementation"""


def get_gen_elems_directory():
    """Procedural Implementation"""


def get_abc_directory():
    """Procedural Implementation"""


def get_latest_abc():
    """Procedural Implementation"""


def get_latest_product_directory():
    """Procedural Implementation"""


def get_project_config_path():
    """Procedural Implementation"""


locals().update(file_module.__dict__)
config_path = file_module.get_project_config_path()
if os.path.exists(config_path):
    with open(config_path, mode='r') as f:
        data = json.load(f)
        if data and 'framework_config' in data:
            file_module_path = data['framework_config'].get('file_module', None)
            if file_module_path:
                file_module = __import__(file_module_path, fromlist=['.'])
                locals().update(file_module.__dict__)
