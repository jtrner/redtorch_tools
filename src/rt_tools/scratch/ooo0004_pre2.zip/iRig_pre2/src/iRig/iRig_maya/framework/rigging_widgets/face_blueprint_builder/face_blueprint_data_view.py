import os
import subprocess
import json
import tempfile
from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
from rigging_widgets.face_blueprint_builder.face_blueprint_data_model import FaceBlueprintDataModel
from rigging_widgets.blueprint_builder.blueprint_items import PartDataItem
import rig_factory.object_versions as obs


class FaceBlueprintDataView(QTableView):

    def __init__(self, *args, **kwargs):
        super(FaceBlueprintDataView, self).__init__(*args, **kwargs)

        self.setIconSize(QSize(30, 30))
        self.horizontalHeader().hide()
        self.verticalHeader().hide()
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setAlternatingRowColors(False)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setDragEnabled(False)
        self.setAcceptDrops(False)
        self.setDropIndicatorShown(False)
        self.horizontalHeader().setStretchLastSection(True)

        try:
            self.horizontalHeader().setResizeMode(QHeaderView.ResizeToContents)
        except StandardError:
            self.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)

        self.god_mode = False

    def set_god_mode(self, value):
        self.god_mode = value
        model = self.model()
        if model:
            self.load_items(model.parts_data)

    def load_items(self, parts_data):
        model_data = []
        for part_data in parts_data:
            for key in part_data:
                model_data.append([key, part_data[key]])
        model = FaceBlueprintDataModel(model_data)
        model.parts_data = parts_data
        self.setModel(model)

    def mouseDoubleClickEvent(self, event):
        model = self.model()
        index = self.indexAt(event.pos())
        item_set = model.get_item(index)
        item_name, item_data = item_set
        if type(item_data) == list:
            data = edit_data_in_notepad(item_data)
            if isinstance(data, list):
                del item_set[1][:]
                item_set[1].extend(data)
            else:
                raise self.raise_error(StandardError('Type must be "list" not "%s"' % type(data)))
        elif type(item_data) == dict:
            data = edit_data_in_notepad(item_data)
            if isinstance(data, dict):
                item_set[1].clear()
                item_set[1].update(data)
            else:
                raise self.raise_error(StandardError('Type must be "dict" not "%s"' % type(data)))
        else:
            self.edit(index)


def edit_data_in_notepad(data):
    script_path = '{0}/BLUEPRINT_TEMP_VAR_EDIT.json'.format(tempfile.gettempdir())
    with open(script_path, mode='w') as f:
        f.write(json.dumps(
            data,
            sort_keys=True,
            indent=4,
            separators=(',', ': ')
        ))
    open_in_notepad(script_path)
    with open(script_path, mode='r') as f:
        return json.load(f)


def open_in_notepad(path):
    print 'Opening: %s' % path
    if os.path.exists('C:/Program Files (x86)/Notepad++/notepad++.exe'):
        prc = subprocess.Popen(
            '"C:/Program Files (x86)/Notepad++/notepad++.exe" -nosession -multiInst -alwaysOnTop %s' % path)
        prc.wait()
    elif os.path.exists('C:/Program Files/Notepad++/notepad++.exe'):
        prc = subprocess.Popen(
            '"C:/Program Files/Notepad++/notepad++.exe" -nosession -multiInst -alwaysOnTop %s' % path)
        prc.wait()
    else:
        raise StandardError('Failed to find the application "Notepad++"')

