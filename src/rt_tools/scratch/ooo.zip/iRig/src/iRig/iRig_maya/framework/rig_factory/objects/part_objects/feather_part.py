"""
Feather Part.

Deformer part consisting of a twist, two bends, and a skinCluster.
The result is a rig designed to move, twist, and bend the attached
geometries in two directions.
"""

from rig_factory.objects.part_objects.handle import HandleGuide
from rig_factory.objects.deformer_objects.bend import Bend
from rig_factory.objects.deformer_objects.twist import Twist
from rig_math.vector import Vector
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.rig_objects.cone import Cone
from rig_factory.objects.rig_objects.line import Line
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.part_objects.chain_guide import ChainGuide


import rig_factory.environment as env


class FeatherPartGuide(ChainGuide):
    default_settings = dict(
        root_name='Feather',
        size=1.0,
        side='center',
    )

    create_gimbal = DataProperty(
        name='create_gimbal',
        default_value=False
    )

    def __init__(self, **kwargs):
        super(FeatherPartGuide, self).__init__(**kwargs)
        self.toggle_class = FeatherPart.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['count'] = 2
        this = super(FeatherPartGuide, cls).create(controller, **kwargs)
        return this


class FeatherPart(Part):

    # Private blueprint attributes.
    _weights = DataProperty(  # Structure: [twist, bendX, bendY]
        name='_weights'
    )
    _geometry_names = DataProperty(
        name='_geometry_names',
        default_value=[]
    )

    # Public object attributes.
    twist = ObjectProperty(
        name='twist'
    )
    bendX = ObjectProperty(
        name='bendX'
    )
    bendY = ObjectProperty(
        name='bendY'
    )
    geometries = ObjectListProperty(
        name='geometries'
    )
    create_gimbal = DataProperty(
        name='create_gimbal',
        default_value=False
    )

    @classmethod
    def create(cls, *args, **kwargs):
        """
        Main entry point which begins the creation of the part in scene.
        """


        this = super(FeatherPart, cls).create(*args, **kwargs)

        joint_1 = this.create_child(
            Joint,
            segment_name='Base',
            matrix=this.matrices[0],
            parent=this.joint_group
        )

        joint_2 = joint_1.create_child(
            Joint,
            segment_name='Tip',
            matrix=this.matrices[1]
        )

        joint_1.zero_rotation()
        joint_2.zero_rotation()

        handle = this.create_handle(
            create_gimbal=this.create_gimbal,
            segment_name='Base',
            matrix=this.matrices[0],
            shape='cube'
        )

        this.controller.create_parent_constraint(handle, joint_1)

        handle.stretch_shape(joint_2)

        this.joints = [joint_1, joint_2]

        return this

    def create_deformation_rig(self, **kwargs):
        """
        Creates the deformers and deformer rig for the part
        Although slinClusters can be created by this part, they are
        not created during part creation; only nonlinear deformers are
        handled with during part creation.
        """

        # Executes the parent class's method.
        super(FeatherPart, self).create_deformation_rig(**kwargs)

        # Gets the part's root object.
        root = self.get_root()

        # Adds target geometries using saved list of geometry names.
        # This also procs the creation of the deformers, as nonLinear
        # deformers cannot exist without geometry it is safer to let the
        # create/remove geometry methods manage their existence.
        if self._geometry_names:
            self.add_geometries([
                root.geometry[geometry_name]
                for geometry_name in self._geometry_names
                if geometry_name in root.geometry
            ])

        # Loads any saved deformer weights.
        if self._weights:
            weights_twist, weights_bendX, weights_bendY = self._weights
            self.twist.set_weights(weights_twist)
            self.bendX.set_weights(weights_bendX)
            self.bendY.set_weights(weights_bendY)

    def create_deformers(self, geometries):
        # type: (List) -> None
        """
        Creates deformers for the part and applies their matrix data.
        """

        # Gets the deform joint to parent the deformers to.
        parent_joint = self.deform_joints[0]

        # Gets the distance between the first and second matrix
        # and uses it for scaling the deformers.
        vector_1 = Vector(self.matrices[0].get_translation())
        vector_2 = Vector(self.matrices[1].get_translation())
        scale_y = (vector_2 - vector_1).magnitude()

        # Creates the deformers using the given geometries.
        self.twist = twist = self.controller.create_nonlinear_deformer(
            Twist,
            geometries,
            side=self.side,
            size=self.size,
            index=self.index,
            parent=parent_joint,
            segment_name='Twist',
            root_name=self.root_name
        )
        self.bendX = bendX = self.controller.create_nonlinear_deformer(
            Bend,
            geometries,
            side=self.side,
            size=self.size,
            index=self.index,
            parent=parent_joint,
            segment_name='BendX',
            root_name=self.root_name
        )
        self.bendY = bendY = self.controller.create_nonlinear_deformer(
            Bend,
            geometries,
            side=self.side,
            size=self.size,
            index=self.index,
            parent=parent_joint,
            segment_name='BendY',
            root_name=self.root_name
        )

        # Applies the guide handle's matrix to deformer handles.
        twist.handle.set_matrix(self.matrices[0])
        bendX.handle.set_matrix(self.matrices[0])
        bendY.handle.set_matrix(self.matrices[0])

        # The BendY handle is offset 90 degrees from the BendX handle
        # so the feather can bend on two axis.
        # I couldn't figure out an elegant way to modify the matrix to
        # get this result so I just rotated it in local space.
        bendY.handle.plugs['ry'].set_value(
            bendY.handle.plugs['ry'].get_value() + 90
        )

        # Applies scale uniformly to all deformers' axis.
        for deformer in twist, bendX, bendY:
            deformer.handle.plugs['sx'].set_value(scale_y)
            deformer.handle.plugs['sy'].set_value(scale_y)
            deformer.handle.plugs['sz'].set_value(scale_y)

    def get_blueprint(self):
        # type: () -> Dict
        """
        :return:
            Blueprint data that can be saved to file.
        """

        # Updates geometry names attribute.
        self._geometry_names = [geometry.name for geometry in self.geometries]

        # Updates the weights attribute.
        # If no target geometries exist then no deformers can exist
        # either so we could not get the deformer weights from them.
        if self.geometries:
            self._weights = [
                self.twist.get_weights(),
                self.bendX.get_weights(),
                self.bendY.get_weights()
            ]
        else:
            self._weights = []

        # Get's default blueprint and updates it with custom part data.
        blueprint = super(FeatherPart, self).get_blueprint()
        blueprint['_geometry_names'] = self._geometry_names
        blueprint['_weights']        = self._weights

        # Returns blueprint.
        return blueprint

    def get_toggle_blueprint(self):
        # type: () -> Dict
        """
        :return:
            Blueprint data used when toggling between guide state and
            rig state.
        """

        # Updates geometry names attribute.
        self._geometry_names = [geometry.name for geometry in self.geometries]

        # Updates the weights attribute.
        # If no target geometries exist then no deformers can exist
        # either so we could not get the deformer weights from them.
        if self.geometries:
            self._weights = [
                self.twist.get_weights(),
                self.bendX.get_weights(),
                self.bendY.get_weights()
            ]
        else:
            self._weights = []

        # Get's default blueprint and updates it with custom part data.
        blueprint = super(FeatherPart, self).get_toggle_blueprint()
        blueprint['rig_data']['_geometry_names'] = self._geometry_names
        blueprint['rig_data']['_weights']        = self._weights

        # Returns blueprint.
        return blueprint

    def add_selected_geometries(self):
        # type: () -> None
        """
        Adds all valid selected geometry as deformation targets.
        Prints a confirmation message to the command line.
        """

        # Gets the geometry objects for all items in the current
        # viewport selection.
        root = self.get_root()
        geometries = [
            root.geometry[x]
            for x in self.controller.get_selected_mesh_names()
            if x in root.geometry
        ]

        # Adds geometries as deformation objects for the part.
        self.add_geometries(geometries, add_skin_clusters=True)

        # Prints a confirmation message to the command line.
        warning = (
            'add_selected_geometries : Set geometries to'
            + ' ' + ' '.join(x.name for x in self.geometries)
        )
        self.controller.scene.warning(warning)

    def add_geometries(self, geometries, add_skin_clusters=False):
        # type: (List, bool) -> None
        """
        Adds given geometries to all deformer sets, as well as skinning
        given geometries to the parts deform joint.
        Ignores geometries that have already been added to the part, or
        are already attached to a skinCluster.
        If no new and unskinned geometries are given, a framework
        warning will be raised.
        :param geometries:
            Mesh objects for geometries to attach to the part.
        :param add_skin_clusters:
            Also adds skinClusters to the given geometries which bind
            them to the parts deform joint. Do not use this flag during 
            part creation since the framework will rebuild previous 
            skinCluster data automatically.
        """

        # Gets Mesh objects for all skinned geometries in the scene.
        root = self.get_root()
        skinned_geometries = {
            root.geometry[geometry_name]
            for skinCluster in self.controller.scene.ls(type='skinCluster')
            for geometry_name in (
                self.controller.scene.skinCluster(
                    skinCluster,
                    query=True,
                    geometry=True
                )
            )
            if geometry_name in root.geometry
        }

        # Filters for all new and unskinned geometries.
        new_geometries = [
            geometry
            for geometry in geometries
            if geometry not in self.geometries
            if geometry not in skinned_geometries
        ]

        # If no new and unskinned geometries were found in the given
        # selection, a framework warning will be raised, and the method
        # will exit.
        if not new_geometries:
            self.controller.raise_warning(
                'add_geometries : No new and unskinned geometries were'
                ' found in the given selection.'
            )
            return None

        # Adds skinClusters to the given geometries, binding them to
        # the only deform join in the part.
        if add_skin_clusters:
            for new_geometry in new_geometries:
                self.controller.scene.skinCluster(
                    new_geometry,
                    self.deform_joints[0],
                    bindMethod=0
                )

        # If target geometries already exist, the given geometries are
        # added to the deformers deformer sets.
        # If not, the deformers are created using the given geometries.
        if self.geometries:
            self.twist.add_geometry(new_geometries)
            self.bendX.add_geometry(new_geometries)
            self.bendY.add_geometry(new_geometries)
        else:
            self.create_deformers(new_geometries)

        # Updates geometries using the twist's deformer set
        # (Any of the three deformers' sets would work).
        self.geometries = list(self.twist.deformer_set.members)

    def remove_selected_geometries(self):
        # type: () -> None
        """
        Removes all valid selected geometry as deformation targets.
        Prints a confirmation message to the command line.
        """

        # Gets the geometry objects for all items in the current
        # viewport selection.
        root = self.get_root()
        geometries = [
            root.geometry[x]
            for x in self.controller.get_selected_mesh_names()
            if x in root.geometry
        ]

        # Removes geometries as deformation objects from the part.
        self.remove_geometries(geometries)

        # Prints a confirmation message to the command line.
        warning = (
            'remove_selected_geometries : Set geometries to'
            + ' ' + ' '.join(x.name for x in self.geometries)
        )
        self.controller.scene.warning(warning)

    def remove_geometries(self, geometries):
        # type: (List) -> None
        """
        Removes given geometries from all deformer sets.
        Ignores geometries that are not attached to the part.
        :param geometries:
            Geometries to add to remove remove from part.
        """

        # Gets all geometries that are attached to the part.
        attached_geometries = [
            geometry for geometry in geometries
            if geometry in self.geometries
        ]

        # If no new and unskinned geometries were found in the given
        # selection, a framework warning will be raised, and the method
        # will exit.
        if not attached_geometries:
            self.controller.raise_warning(
                'remove_geometries : No attached geometries were'
                ' found in the given selection.'
            )
            return None

        # Unbinds all geometries.
        for geometry in attached_geometries:
            self.controller.scene.skinCluster(geometry, edit=True, unbind=True)

        # Gets a list of all geometries that are still attached to the
        # part after the removal process.
        remaining_geometries = [
            geometry for geometry in self.geometries
            if geometry not in attached_geometries
        ]

        # If there are remaining geometries,
        # Removes given geometries from all deformer sets and updates
        # the `geometries` attribute.
        # Otherwise, simply deletes the deformers, and clears the
        # `geometries` attribute.
        if remaining_geometries:
            self.twist.remove_geometry(attached_geometries)
            self.bendX.remove_geometry(attached_geometries)
            self.bendY.remove_geometry(attached_geometries)
            self.geometries = list(self.twist.deformer_set.members)
        else:
            self.controller.schedule_objects_for_deletion(
                self.twist,
                self.bendX,
                self.bendY,
            )
            self.controller.delete_scheduled_objects()
            self.geometries = []

    def finalize(self):
        # type: () -> None
        """
        Finalizes the part, making any last minute changes.
        """
        super(FeatherPart, self).finalize()

        # Hides the deformer handles.
        self.twist.handle.plugs['v'].set_value(False)
        self.bendX.handle.plugs['v'].set_value(False)
        self.bendY.handle.plugs['v'].set_value(False)
