from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.rig_objects.cone import Cone
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_factory.objects.rig_objects.curve_handle import CurveHandle
from rig_factory.utilities import face_panel_utillities as utl
from rig_math.matrix import Matrix

class RollGuide(PartGuide):

    default_settings = dict(
        root_name='Roll',
        size=5.0,
        shape='cube',
        create_gimbal=False
    )

    shape = DataProperty(
        name='shape'
    )

    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    pivots = ObjectListProperty(
        name='pivots'
    )

    def __init__(self, **kwargs):
        super(RollGuide, self).__init__(**kwargs)
        self.toggle_class = Roll.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs.setdefault('side', 'center')
        this = super(RollGuide, cls).create(controller, **kwargs)
        side = this.side
        size = this.size
        position = 2.0 * size

        # Create nodes
        base_joint = this.create_child(
            Joint,
            segment_name='Base'
        )
        panel_joint = this.create_child(
            Joint,
            segment_name='Panel'
        )
        front_joint = this.create_child(
            Joint,
            segment_name='Front'
        )
        back_joint = this.create_child(
            Joint,
            segment_name='Back'
        )
        left_joint = this.create_child(
            Joint,
            segment_name='Left'
        )
        right_joint = this.create_child(
            Joint,
            segment_name='Right'
        )
        base_handle = this.create_handle(
            segment_name='Base'
        )
        panel_handle = this.create_handle(
            segment_name='Panel'
        )
        front_handle = this.create_handle(
            segment_name='Front',
            functionality_name='Pivot'
        )
        back_handle = this.create_handle(
            segment_name='Back',
            functionality_name='Pivot'
        )
        left_handle = this.create_handle(
            segment_name='Left',
            functionality_name='Pivot'
        )
        right_handle = this.create_handle(
            segment_name='Right',
            functionality_name='Pivot'
        )

        base_handle_default_position = [0.0, 0.0, 0.0]
        panel_handle_default_position = [
            base_handle_default_position[0],
            base_handle_default_position[1] + 2.5 * size,
            base_handle_default_position[2]
        ]
        front_handle_default_position = [0.0, 0.0, position]
        back_handle_default_position = [0.0, 0.0, -position]
        left_handle_default_position = [position, 0.0, 0.0]
        right_handle_default_position = [-position, 0.0, 0.0]
        base_handle.plugs['translate'].set_value(base_handle_default_position)
        panel_handle.plugs['translate'].set_value(panel_handle_default_position)
        front_handle.plugs['translate'].set_value(front_handle_default_position)
        back_handle.plugs['translate'].set_value(back_handle_default_position)
        left_handle.plugs['translate'].set_value(left_handle_default_position)
        right_handle.plugs['translate'].set_value(right_handle_default_position)

        cube_transform = this.create_child(
            Transform,
            segment_name='Cube'
        )
        cube_node = cube_transform.create_child(
            DependNode,
            node_type='polyCube'
        )
        cube_mesh = cube_transform.create_child(
            Mesh
        )
        multiply = this.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='ItemSize'
        )
        cone_x = base_joint.create_child(
            Cone,
            segment_name='ConeX',
            size=size,
            axis=[1.0, 0.0, 0.0]
        )
        cone_y = base_joint.create_child(
            Cone,
            segment_name='ConeY',
            size=size,
            axis=[0.0, 1.0, 0.0]
        )
        cone_z = base_joint.create_child(
            Cone,
            segment_name='ConeZ',
            size=size,
            axis=[0.0, 0.0, 1.0]
        )

        # Constraints
        controller.create_point_constraint(
            base_handle,
            base_joint
        )
        controller.create_point_constraint(
            base_handle,
            cube_transform
        )
        controller.create_point_constraint(
            panel_handle,
            panel_joint
        )
        controller.create_point_constraint(
            front_handle,
            front_joint
        )
        controller.create_point_constraint(
            back_handle,
            back_joint
        )
        controller.create_point_constraint(
            left_handle,
            left_joint
        )
        controller.create_point_constraint(
            right_handle,
            right_joint
        )

        # Attributes

        size_plug = this.plugs['size']
        size_plug.connect_to(multiply.plugs['input1X'])
        multiply.plugs['input2X'].set_value(0.25)
        cube_node.plugs['output'].connect_to(cube_mesh.plugs['inMesh'])

        size_plug.connect_to(cube_node.plugs['height'])
        size_plug.connect_to(cube_node.plugs['depth'])
        size_plug.connect_to(cube_node.plugs['width'])
        multiply.plugs['outputX'].connect_to(base_handle.plugs['size'])
        multiply.plugs['outputX'].connect_to(panel_handle.plugs['size'])
        multiply.plugs['outputX'].connect_to(front_handle.plugs['size'])
        multiply.plugs['outputX'].connect_to(back_handle.plugs['size'])
        multiply.plugs['outputX'].connect_to(left_handle.plugs['size'])
        multiply.plugs['outputX'].connect_to(right_handle.plugs['size'])

        cube_mesh.plugs['overrideEnabled'].set_value(True)
        cube_mesh.plugs['overrideDisplayType'].set_value(2)
        cube_transform.plugs['overrideEnabled'].set_value(True)
        cube_transform.plugs['overrideDisplayType'].set_value(2)
        for joint in [base_joint, panel_joint, front_joint, back_joint, left_joint, right_joint]:
            joint.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
                radius=size*0.25
            )
        base_handle.plugs['radius'].set_value(size * 0.75)
        panel_handle.plugs['radius'].set_value(size * 0.25)
        front_handle.plugs['radius'].set_value(size*0.25)
        back_handle.plugs['radius'].set_value(size*0.25)
        left_handle.plugs['radius'].set_value(size*0.25)
        right_handle.plugs['radius'].set_value(size * 0.25)

        size_plug.connect_to(cone_x.plugs['size'])
        size_plug.connect_to(cone_y.plugs['size'])
        size_plug.connect_to(cone_z.plugs['size'])
        cone_x.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
        )
        cone_y.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
        )
        cone_z.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
        )

        # Shaders
        root = this.get_root()
        cube_mesh.assign_shading_group(root.shaders[side].shading_group)
        base_handle.mesh.assign_shading_group(root.shaders[side].shading_group)
        panel_handle.mesh.assign_shading_group(root.shaders[side].shading_group)
        front_handle.mesh.assign_shading_group(root.shaders[side].shading_group)
        back_handle.mesh.assign_shading_group(root.shaders[side].shading_group)
        left_handle.mesh.assign_shading_group(root.shaders[side].shading_group)
        right_handle.mesh.assign_shading_group(root.shaders[side].shading_group)
        cone_x.mesh.assign_shading_group(root.shaders['x'].shading_group)
        cone_y.mesh.assign_shading_group(root.shaders['y'].shading_group)
        cone_z.mesh.assign_shading_group(root.shaders['z'].shading_group)

        root = this.get_root()
        if root:
            root.add_plugs(
                [
                    base_handle.plugs['tx'],
                    base_handle.plugs['ty'],
                    base_handle.plugs['tz'],
                    panel_handle.plugs['tx'],
                    panel_handle.plugs['ty'],
                    panel_handle.plugs['tz'],
                    front_handle.plugs['tx'],
                    front_handle.plugs['ty'],
                    front_handle.plugs['tz'],
                    back_handle.plugs['tx'],
                    back_handle.plugs['ty'],
                    back_handle.plugs['tz'],
                    left_handle.plugs['tx'],
                    left_handle.plugs['ty'],
                    left_handle.plugs['tz'],
                    right_handle.plugs['tx'],
                    right_handle.plugs['ty'],
                    right_handle.plugs['tz']
                ]
            )
        this.base_handles = [
            base_handle,
            panel_handle,
            front_handle,
            back_handle,
            left_handle,
            right_handle
        ]
        this.joints = [base_joint]
        this.pivots = [
            panel_joint,
            front_joint,
            back_joint,
            left_joint,
            right_joint
        ]
        return this

    def get_toggle_blueprint(self):
        blueprint = super(RollGuide, self).get_toggle_blueprint()
        blueprint['pivot_positions'] = [x.get_matrix() for x in self.pivots]

        return blueprint

class Roll(Part):

    deformers = ObjectListProperty(
        name='deformers'
    )

    geometry = ObjectListProperty(
        name='geometry'
    )

    shape = DataProperty(
        name='shape'
    )

    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    def __init__(self, **kwargs):
        super(Roll, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(Roll, cls).create(controller, **kwargs)
        pivot_positions = kwargs.get('pivot_positions', None)
        if not pivot_positions:
            raise StandardError('Missing pivot positions from guide state.')
        size = this.size
        side = this.side
        matrices = this.matrices + pivot_positions
        (
            front_pivot_matrix,
            back_pivot_matrix,
            left_pivot_matrix,
            right_pivot_matrix
        ) = pivot_positions[-4:]

        joint = this.create_child(
            Joint,
            index=0,
            matrix=matrices[0],
            parent=this.joint_group
        )
        handle = this.create_handle(
            handle_type=GroupedHandle,
            shape=this.shape if this.shape else 'cube',
            size=size,
            matrix=matrices[0],
            create_gimbal=this.create_gimbal
        )

        roll_top_transform = this.create_child(
            Transform,
            segment_name='Top'
        )

        limits_curve = roll_top_transform.create_child(
            CurveHandle,
            segment_name='Square',
            shape='square',
            size=size,
            matrix=matrices[1]
        )
        limits_curve_matrix = Matrix(scale=[2.5, 1.0, 2.5])
        limits_curve.plugs['shapeMatrix'].set_value(limits_curve_matrix)
        utl.set_color_index(limits_curve, 1)  # Black
        limits_curve.plugs['overrideDisplayType'].set_value(2)

        roll_handle = this.create_handle(
            handle_typ=GroupedHandle,
            segment_name='Roll',
            shape='circle',
            size=size,
            matrix=matrices[1],
            parent=roll_top_transform
        )
        roll_handle_matrix = Matrix(scale=[0.4, 1.0, 0.4])
        roll_handle.plugs['shapeMatrix'].set_value(roll_handle_matrix)
        utl.set_attr_limit(roll_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(roll_handle, 'TransZ', -1.0, 1.0)
        roll_handle.create_plug(
            'multiplicator',
            at='float',
            k=True,
            min=0,
            max=100,
            dv=100
        )

        # Scale up the top group to keep shapes working correctly
        roll_top_transform.plugs['sx'].set_value(size / 2.5)
        roll_top_transform.plugs['sz'].set_value(size / 2.5)

        right_placement = this.create_child(
            Transform,
            segment_name='RightPlacement',
            matrix=right_pivot_matrix
        )
        left_placement = right_placement.create_child(
            Transform,
            segment_name='LeftPlacement',
            matrix=left_pivot_matrix
        )
        front_placement = left_placement.create_child(
            Transform,
            segment_name='FrontPlacement',
            matrix=front_pivot_matrix
        )
        back_placement = front_placement.create_child(
            Transform,
            segment_name='BackPlacement',
            matrix=back_pivot_matrix
        )
        controller.create_parent_constraint(
            back_placement,
            handle.groups[0],
            mo=True
        )

        # Nodes to create rolling
        for transform in [front_placement, back_placement, left_placement, right_placement]:
            reverse_md = None
            if transform == front_placement:
                name = 'Front'
                driver_plug = 'tz'
                driven_plug = 'rx'
                condition_operation = 2
            elif transform == back_placement:
                name = 'Back'
                driver_plug = 'tz'
                driven_plug = 'rx'
                condition_operation = 4
            elif transform == left_placement:
                name = 'Left'
                driver_plug = 'tx'
                driven_plug = 'rz'
                condition_operation = 2
                reverse_md = this.create_child(
                    DependNode,
                    node_type='multiplyDivide',
                    segment_name='{0}ReverseMD'.format(name)
                )
            elif transform == right_placement:
                name = 'Right'
                driver_plug = 'tx'
                driven_plug = 'rz'
                condition_operation = 4
                reverse_md = this.create_child(
                    DependNode,
                    node_type='multiplyDivide',
                    segment_name='{0}ReverseMD'.format(name)
                )

            condition = this.create_child(
                DependNode,
                node_type='condition',
                segment_name='{0}Condition'.format(name)
            )
            condition.plugs['operation'].set_value(condition_operation)  # Greater than or Less than operation
            condition.plugs['colorIfFalseR'].set_value(0.0)
            if reverse_md:
                reverse_md.plugs['input2X'].set_value(-1)
                condition.plugs['outColorR'].connect_to(reverse_md.plugs['input1X'])
                reverse_md.plugs['outputX'].connect_to(transform.plugs[driven_plug])
            else:
                condition.plugs['outColorR'].connect_to(transform.plugs[driven_plug])
            roll_handle.plugs[driver_plug].connect_to(condition.plugs['firstTerm'])

            multiply_divide = this.create_child(
                DependNode,
                node_type='multiplyDivide',
                segment_name='{0}MD'.format(name)
            )
            roll_handle.plugs[driver_plug].connect_to(multiply_divide.plugs['input1X'])
            roll_handle.plugs['multiplicator'].connect_to(multiply_divide.plugs['input2X'])
            multiply_divide.plugs['outputX'].connect_to(condition.plugs['colorIfTrueR'])

        joint.zero_rotation()
        joint.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2
        )

        if handle.gimbal_handle:
            controller.create_parent_constraint(
                handle.gimbal_handle,
                joint
            )
            controller.create_scale_constraint(
                handle.gimbal_handle,
                joint
            )
        else:
            controller.create_parent_constraint(
                handle,
                joint
            )
            controller.create_scale_constraint(
                handle,
                joint
            )

        root = this.get_root()
        if root:
            root.add_plugs(
                [
                    handle.plugs['tx'],
                    handle.plugs['ty'],
                    handle.plugs['tz'],
                    handle.plugs['rx'],
                    handle.plugs['ry'],
                    handle.plugs['rz'],
                    handle.plugs['sx'],
                    handle.plugs['sy'],
                    handle.plugs['sz'],
                    roll_handle.plugs['tx'],
                    roll_handle.plugs['tz'],
                    roll_handle.plugs['multiplicator']
                ]
            )

        this.joints = [joint]
        return this
