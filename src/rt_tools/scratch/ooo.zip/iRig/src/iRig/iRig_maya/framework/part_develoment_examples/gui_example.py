import sys
import os
from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
import rigging_widgets
import batch_tasks.rigging_environment as rev
from part_develoment_examples.base_chain_example import BaseChainGuide
MOCK = True
STANDALONE = False

if MOCK is STANDALONE:
    raise Exception('MOCK and STANDALONE are mutually exclusive.')


if __name__ == '__main__':
    style_sheet_path = '%s/rig_builder/qss/slate.qss' % os.path.dirname(rigging_widgets.__file__.replace('\\', '/'))
    with open(style_sheet_path, mode='r') as f:
        style_sheet = f.read()
    if MOCK:
        rev.load_mock_rigging_environment('RBGB', 'Hopper', dev_mode=True)
    else:
        rev.load_rigging_environment('RBGB', 'Hopper', dev_mode=True)
        rev.load_system_paths(dev_mode=True)

    app = QApplication(sys.argv)
    app.setStyleSheet(style_sheet)
    import rig_factory.build.utilities.controller_utilities as cut
    controller = cut.initialize_rig_controller(mock=MOCK, standalone=STANDALONE)



    from rigging_widgets.rig_builder.widgets.rig_widget import RigWidget

    body_widget = RigWidget()
    body_widget.show()
    body_widget.raise_()

    # Make parts

    container = controller.create_object('ContainerGuide')
    chain_part = container.create_part(BaseChainGuide)
    chain_part.post_create()
    controller.set_root(container)

    del container, chain_part

    body_widget.set_controller(controller)

    sys.exit(app.exec_())
