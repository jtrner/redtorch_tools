"""
TODD:
    Check all menu functions.
    Check blueprint support.

Part used to create lattice deformers.
Differs from other parts in that, this part does not use any handles.
Shaping and positioning of the lattice and base lattice are recorded
in guide state automatically, and can optionally be captured in rig
state as well.
"""


import collections
from pprint import pprint
from typing import *
from rig_factory.objects.part_objects.part import PartGuide, Part
from rig_factory.objects.deformer_objects.lattice import Lattice
from rig_factory.objects.base_objects.properties import (
    ObjectProperty, ObjectListProperty, DataProperty
)
from rig_math.matrix import Matrix


__all__ = (
    'LatticePartGuide',
    'LatticePart'
)

class LatticePartGuide(PartGuide):

    # Private variables for tracking blueprint data.
    _lattice_matrix = DataProperty(
        name='_lattice_matrix'
    )
    _base_lattice_matrix = DataProperty(
        name='_base_lattice_matrix'
    )

    # Default settings for the part, also displayed by the part
    # creation widget.
    default_settings = collections.OrderedDict((
        ('root_name', 'SimpleLattice'),
        ('s_divisions', 5),
        ('t_divisions', 5),
        ('u_divisions', 5)
    ))

    # Public variables for tracking blueprint data.
    s_divisions = DataProperty(
        name='s_divisions'
    )
    t_divisions = DataProperty(
        name='t_divisions'
    )
    u_divisions = DataProperty(
        name='u_divisions'
    )
    lattice_points = DataProperty(
        name='lattice_points'
    )

    # Public properties for accessing the parts framework objects.
    lattice_transform = ObjectProperty(
        name='lattice'
    )
    geometry = ObjectListProperty(
        name='geometry'
    )

    def __init__(self, **kwargs):
        super(LatticePartGuide, self).__init__(**kwargs)
        self.toggle_class = LatticePart.__name__

    @classmethod
    def create(cls, *args, **kwargs):
        # type: (Any, Any) -> LatticePartGuide
        """
        Main entry point that starts the creation of the Lattice part
        guide in scene.
        :return:
            Instantiated Lattice part guide object.
        """
        this = super(LatticePartGuide, cls).create(*args, **kwargs)

        # Creates a Lattice object and loads in any default settings
        # or blueprint data.
        this.lattice_transform = this.create_child(
            Lattice,
            segment_name='Lattice'
        )
        this.lattice_transform.lattice_transform.set_matrix(Matrix(this._lattice_matrix))
        this.lattice_transform.lattice_base_transform.set_matrix(Matrix(this._base_lattice_matrix))
        this.lattice_transform.lattice_shape.plugs['sDivisions'].set_value(
            this.s_divisions
        )
        this.lattice_transform.lattice_shape.plugs['tDivisions'].set_value(
            this.t_divisions
        )
        this.lattice_transform.lattice_shape.plugs['uDivisions'].set_value(
            this.u_divisions
        )

        # Loads and applies any saved lattice point data.
        this.load_lattice_shape()

        return this

    def get_toggle_blueprint(self):
        # type: () -> Dict
        """
        :return:
            Blueprint data used when toggling between guide state and
            rig state.
        """

        # Updates lattice point data attribute.
        attr = self.lattice_transform.lattice_shape.name + '.pt[:]'
        self.lattice_points = map(list, self.controller.scene.getAttr(attr))

        # Updates the matrix attributes for the lattice
        # and base lattice.
        self._lattice_matrix = list(
            self.lattice_transform.lattice_transform.get_matrix()
        )
        self._base_lattice_matrix = list(
            self.lattice_transform.lattice_base_transform.get_matrix()
        )

        # Returns blueprint data.
        return super(LatticePartGuide, self).get_toggle_blueprint()

    def get_blueprint(self):
        # type: () -> Dict
        """
        :return:
            Blueprint data that can be saved to file.
        """

        # Updates lattice point data attribute.
        attr = self.lattice_transform.lattice_shape.name + '.pt[:]'
        self.lattice_points = map(list, self.controller.scene.getAttr(attr))

        # Updates the matrix attributes for the lattice
        # and base lattice.
        self._lattice_matrix = list(
            self.lattice_transform.lattice_transform.get_matrix()
        )
        self._base_lattice_matrix = list(
            self.lattice_transform.lattice_base_transform.get_matrix()
        )

        # Returns blueprint data.
        return super(LatticePartGuide, self).get_blueprint()

    def load_lattice_shape(self):
        # type: () -> None
        """
        Loads and applies any saved lattice point data.
        Discards data if the number of lattice point datums is not
        identical to the number of expected lattice points derived
        from the current S, T, and U divisions.
        Prints a message to the command line if there is any kind of
        mismatch.
        """

        # Exits if no lattice point data is available.
        if not self.lattice_points:
            return None

        # Computes the expected length of the lattice point data based
        # on the number of S, T, and U divisions.
        expected_length = (
            (self.s_divisions + 1)
            * (self.t_divisions + 1)
            * (self.u_divisions + 1)
        )

        # Exits if the number of saved lattice point datums doesn't
        # match the expected length.
        # Prints a message to the command line.
        if len(self.lattice_points) != expected_length:
            print (
                'load_lattice_shape :'
                ' The number of datums in the lattice point data does'
                ' not match the total number of expected'
                ' lattice points.'
            )
            return None

        # Applies any saved lattice point data to the lattice shape.
        self.controller.scene.setAttr(
            self.lattice_transform.lattice_shape.name + '.pt[:]',
            *sum(self.lattice_points, [])
        )

    def reset_lattice_shape(self):
        # type: () -> None
        """
        Returns the lattice shape to a standard 3d voxel cube.
        Prints a confirmation message to the command line.
        """

        # Generates lattice point data using the number of s, t, and u
        # divisions.
        point_positions = (
            (
                s / (self.s_divisions - 1.0) - 0.5,
                t / (self.t_divisions - 1.0) - 0.5,
                u / (self.u_divisions - 1.0) - 0.5,
            )
            for u in range(self.u_divisions)
            for t in range(self.t_divisions)
            for s in range(self.s_divisions)
        )

        # Sets lattice point data and prints out a confirmation in the
        # script editor/command line.
        self.controller.scene.setAttr(
            self.lattice_transform.lattice_shape.name + '.pt[:]',
            *sum(point_positions, tuple())
        )
        print 'reset_lattice_shape : Reset lattice shape'


class LatticePart(Part):

    # Privates constant of lattice attributes who's values should be
    # saved in blueprint data.
    _lattice_attributes = (
        'local',
        'localInfluenceS',
        'localInfluenceT',
        'localInfluenceU',
        'outsideLattice',
        'outsideFalloffDist',
        'usePartialResolution',
        'partialResolution',
        'freezeGeometry'
    )

    # Private variables for tracking blueprint data.
    _lattice_matrix = DataProperty(
        name='_lattice_matrix'
    )
    _base_lattice_matrix = DataProperty(
        name='_base_lattice_matrix'
    )

    # Public variables for tracking blueprint data
    s_divisions = DataProperty(
        name='s_divisions'
    )
    t_divisions = DataProperty(
        name='t_divisions'
    )
    u_divisions = DataProperty(
        name='u_divisions'
    )
    lattice_points = DataProperty(
        name='lattice_points'
    )
    lattice_data = DataProperty(
        name='lattice_data',
        default_value={'local': True}
    )

    weights = DataProperty(
        name='weights'
    )
    geometry_names = DataProperty(
        name='geometry_names',
        default_value=[]
    )

    # Public properties for accessing the parts framework objects.
    lattice_transform = ObjectProperty(
        name='lattice'
    )
    geometry = ObjectListProperty(
        name='geometry'
    )

    @classmethod
    def create(cls, *args, **kwargs):
        # type: (Any, Any) -> LatticePartGuide
        """
        Main entry point that starts the creation of the Lattice part
        in scene.
        :return:
            Instantiated Lattice part object.
        """
        this = super(LatticePart, cls).create(*args, **kwargs)
        root = this.get_root()

        # Creates a Lattice object and loads in any default settings
        # or blueprint data.
        this.lattice_transform = this.create_child(
            Lattice,
            parent=this,
            segment_name='Lattice'
        )
        this.lattice_transform.lattice_transform.set_matrix(Matrix(this._lattice_matrix))
        this.lattice_transform.lattice_base_transform.set_matrix(Matrix(this._base_lattice_matrix))
        this.lattice_transform.lattice_shape.plugs['sDivisions'].set_value(
            this.s_divisions
        )
        this.lattice_transform.lattice_shape.plugs['tDivisions'].set_value(
            this.t_divisions
        )
        this.lattice_transform.lattice_shape.plugs['uDivisions'].set_value(
            this.u_divisions
        )

        # Loads any saved attribute settings.
        this.load_attribute_settings()

        # Loads and applies any saved lattice point data.
        this.load_lattice_shape()

        # Adds any saved geometries to the deformer.
        this.add_geometry(
            root.geometry[geometry_name]
            for geometry_name in this.geometry_names
            if geometry_name in root.geometry
        )

        # Loads deformer weight data.
        if this.weights:
            this.lattice_transform.set_weights(this.weights)

        return this

    def get_toggle_blueprint(self):
        # type: () -> Dict
        """
        :return:
            Blueprint data used when toggling between guide state and
            rig state.
        """

        # Updates geometry and weights.
        self.geometry_names = [x.name for x in self.geometry]
        self.weights = self.lattice_transform.get_weights()

        # Updates the saved lattice attribute data.
        self.save_attribute_settings()

        # Creates a blueprint dict.
        blueprint = super(LatticePart, self).get_toggle_blueprint()

        # Updates blueprint with the current object data.
        blueprint['_lattice_matrix']            = self._lattice_matrix
        blueprint['_base_lattice_matrix']       = self._base_lattice_matrix
        blueprint['lattice_points']             = self.lattice_points
        blueprint['rig_data']['geometry_names'] = self.geometry_names
        blueprint['rig_data']['weights']        = self.weights
        blueprint['rig_data']['lattice_data']   = self.lattice_data

        return blueprint

    def get_blueprint(self):
        # type: () -> Dict
        """
        :return:
            Blueprint data that can be saved to file.
        """

        # Updates geometry and weights.
        self.geometry_names = [x.name for x in self.geometry]
        self.weights = self.lattice_transform.get_weights()

        # Updates the saved lattice attribute data.
        self.save_attribute_settings()

        # Creates a blueprint dict.
        blueprint = super(LatticePart, self).get_blueprint()

        # Updates blueprint with the current object data.
        blueprint['_lattice_matrix']        = self._lattice_matrix
        blueprint['_base_lattice_matrix']   = self._base_lattice_matrix
        blueprint['lattice_points']         = self.lattice_points
        blueprint['geometry_names']         = self.geometry_names
        blueprint['weights']                = self.weights
        blueprint['lattice_data']           = self.lattice_data

        return blueprint

    def load_lattice_shape(self):
        # type: () -> None
        """
        Loads and applies any saved lattice point data.
        Discards data if the number of lattice point datums is not
        identical to the number of expected lattice points derived
        from the current S, T, and U divisions.
        Prints a message to the command line if there is any kind of
        mismatch.
        """

        # Exits if no lattice point data is available.
        if not self.lattice_points:
            return None

        # Computes the expected length of the lattice point data based
        # on the number of S, T, and U divisions.
        expected_length = (
            (self.s_divisions + 1)
            * (self.t_divisions + 1)
            * (self.u_divisions + 1)
        )

        # Exits if the number of saved lattice point datums doesn't
        # match the expected length.
        # Prints a message to the command line.
        if len(self.lattice_points) != expected_length:
            print (
                'load_lattice_shape :'
                ' The number of datums in the lattice point data does'
                ' not match the total number of expected'
                ' lattice points.'
            )
            return None

        # Applies any saved lattice point data to the lattice shape.
        self.controller.scene.setAttr(
            self.lattice_transform.lattice_shape.name + '.pt[:]',
            *sum(self.lattice_points, [])
        )

    def reset_lattice_shape(self):
        # type: () -> None
        """
        Returns the lattice shape to a standard 3d voxel cube.
        Prints a confirmation message to the command line.
        """

        # Generates lattice point data using the number of s, t, and u
        # divisions.
        point_positions = (
            (
                s / (self.s_divisions - 1.0) - 0.5,
                t / (self.t_divisions - 1.0) - 0.5,
                u / (self.u_divisions - 1.0) - 0.5,
            )
            for u in range(self.u_divisions)
            for t in range(self.t_divisions)
            for s in range(self.s_divisions)
        )

        # Sets lattice point data and prints out a confirmation in the
        # script editor/command line.
        self.controller.scene.setAttr(
            self.lattice_transform.lattice_shape.name + '.pt[:]',
            *sum(point_positions, tuple())
        )
        print 'reset_lattice_shape : Reset lattice shape'

    def save_lattice_shape(self):
        # type: () -> None
        """
        Captures the lattices's current shape as the new guide shape.
        Prints a confirmation message to the command line.
        """
        attr = self.lattice_transform.lattice_shape.name + '.pt[:]'
        self.lattice_points = map(list, self.controller.scene.getAttr(attr))
        print 'save_lattice_shape : Set lattice shape to'
        pprint(self.lattice_points)

    def add_selected_geometry(self):
        # type: () -> None
        """
        Adds all valid selected geometry as deformation targets.
        Prints a confirmation message to the command line.
        """

        # Gets the geometry objects for all items in the current
        # viewport selection.
        root = self.get_root()
        geometries = [
            root.geometry[x]
            for x in self.controller.get_selected_mesh_names()
            if x in root.geometry
        ]

        # Adds geometries as deformation objects for the lattice.
        # Prints a confirmation message to the command line.
        self.add_geometry(geometries)
        print 'add_selected_geometry : Set geometry to'
        print([x.name for x in self.geometry])

    def add_geometry(self, geometry):
        # type: (List) -> None
        """
        Adds given geometries to the lattice's deformer set.
        :param geometry:
            Geometries to add to the lattice's deformer set.
        """
        self.lattice_transform.add_geometry(geometry)
        self.geometry = list(self.lattice_transform.ffd.deformer_set.members)

    def remove_selected_geometry(self):
        # type: () -> None
        """
        Removes all valid selected geometry as deformation targets.
        Prints a confirmation message to the command line.
        """

        # Gets the geometry objects for all items in the current
        # viewport selection.
        root = self.get_root()
        geometries = [
            root.geometry[x]
            for x in self.controller.get_selected_mesh_names()
            if x in root.geometry
        ]

        # Removes geometries as deformation objects from the lattice.
        # Prints a confirmation message to the command line.
        self.remove_geometry(geometries)
        print 'remove_selected_geometry : Set geometry to'
        print([x.name for x in self.geometry])

    def remove_geometry(self, geometry):
        # type: (List) -> None
        """
        Removes given geometries from the lattice's deformer set.
        :param geometry:
            Geometries to add to the lattice's deformer set.
        """
        self.lattice_transform.remove_geometry(geometry)
        self.geometry = list(self.lattice_transform.ffd.deformer_set.members)

    def save_attribute_settings(self):
        # type: () -> None
        """
        Updates the data reflecting the attribute settings for the
        lattice deformer.
        Prints a confirmation message to the command line.
        """
        self.lattice_data = {
            k: self.lattice_transform.ffd.plugs[k].get_value()
            for k in self._lattice_attributes
        }
        pprint(self.lattice_data)

    def load_attribute_settings(self):
        # type: () -> None
        """
        Applies the saved attribute settings data to the
        squash deformer.
        Prints a confirmation message to the command line.
        """

        # Exits the method if their isn't any saved lattice data to
        # load.
        if self.lattice_data is None:
            return None

        # Sets lattice attribute data.
        # Prints a confirmation message to the command line.
        for k, v in self.lattice_data.items():
            self.lattice_transform.ffd.plugs[k].set_value(v)
        print 'load_attribute_settings : Loaded attribute data  '

    def save_lattice_matrix(self):
        # type: () -> None
        """
        Updates the saved matrix for the lattice to reflect the
        position of the current lattice in scene.
        Prints a confirmation message to the command line.
        """
        self._lattice_matrix = list(self.lattice_transform.lattice_transform.get_matrix())
        print 'save_lattice_matrix : Set matrix to'
        pprint(self._lattice_matrix)

    def save_base_lattice_matrix(self):
        # type: () -> None
        """
        Updates the saved matrix for the base lattice to reflect the
        position of the current base lattice in scene.
        Prints a confirmation message to the command line.
        """
        self._base_lattice_matrix = list(
            self.lattice_transform.lattice_base_transform.get_matrix()
        )
        print 'save_base_lattice_matrix : Set matrix to'
        pprint(self._base_lattice_matrix)

    def finalize(self):
        super(LatticePart, self).finalize()
        self.lattice_transform.lattice_base_transform.plugs['visibility'].set_value(False)
        self.lattice_transform.lattice_transform.plugs['visibility'].set_value(False)
