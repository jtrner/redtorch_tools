from rig_factory.objects.base_objects.properties import DataProperty, ObjectProperty, ObjectListProperty
from rig_factory.objects.base_objects.base_node import BaseNode
from rig_factory.objects.sdk_objects.sdk_keyframe import SDKKeyFrame


class KeyframeGroup(BaseNode):

    sdk_group = ObjectProperty(
        name='sdk_group'
    )
    keyframes = ObjectListProperty(
        name='keyframes'
    )
    in_value = DataProperty(
        name='in_value'
    )
    in_tangent_type = DataProperty(
        name='in_tangent_type'
    )
    out_tangent_type = DataProperty(
        name='out_tangent_type'
    )

    suffix = 'Kfg'

    def __init__(self, **kwargs):
        super(KeyframeGroup, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        controller.scene.autoKeyframe(state=False)
        sdk_group = kwargs.get('sdk_group', None)
        in_value = kwargs.get('in_value', None)
        isolate = kwargs.get('isolate', True)
        kwargs.setdefault('parent', sdk_group)
        kwargs.setdefault('root_name', sdk_group.root_name)
        if not isinstance(in_value, float):
            raise Exception(
                'You must provide an "in_value" keyword argument of type "float" to create a %s, %s' % (
                    KeyframeGroup,
                    in_value
                )
            )
        if in_value in [x.in_value for x in sdk_group.keyframe_groups]:
            raise Exception(
                'A keyframe group with the in_value "%s" already exists' % in_value
            )
        kwargs['name'] = '%s_%s' % (
            sdk_group.name,
            len(sdk_group.keyframe_groups) + 1
        )

        controller.start_sdk_ownership_signal.emit(None, sdk_group)
        this = super(KeyframeGroup, cls).create(controller, **kwargs)
        this.sdk_group = sdk_group
        sdk_group.keyframe_groups.append(this)
        controller.end_sdk_ownership_signal.emit(this, sdk_group)
        this.sdk_group.isolate()
        this.update()
        return this

    def update(self):
        sdk_group = self.sdk_group
        for driven_plug in sdk_group.sdk_network.driven_plugs:
            animation_curve = sdk_group.animation_curves.get(driven_plug.name, None)
            default_value = round(driven_plug.default_value, 5)
            if default_value == -0.0:
                default_value = 0.0
            current_value = round(driven_plug.get_value(), 5)
            if current_value == -0.0:
                current_value = 0.0
            non_default_value = default_value != current_value
            if not animation_curve and not non_default_value:
                continue  # No need to do anything for this plug
            if animation_curve and self.in_value in animation_curve.keyframes:
                self.controller.change_keyframe(
                    animation_curve.keyframes[self.in_value],
                    out_value=driven_plug.get_value()
                )
            else:
                min_in_value = float('-inf')
                max_in_value = float('inf')
                next_key_group = None
                previous_key_group = None

                for key_group in sdk_group.keyframe_groups:
                    if min_in_value < key_group.in_value < self.in_value:
                        min_in_value = key_group.in_value
                        previous_key_group = key_group
                    elif max_in_value > key_group.in_value > self.in_value:
                        max_in_value = key_group.in_value
                        next_key_group = key_group


                non_default_neighbors = False

                if animation_curve:
                    if previous_key_group:
                        if min_in_value in animation_curve.keyframes:
                            if animation_curve.keyframes[min_in_value].out_value != driven_plug.default_value:
                                non_default_neighbors = True
                    if next_key_group:
                        if max_in_value in animation_curve.keyframes and animation_curve.keyframes[max_in_value].out_value != driven_plug.default_value:
                            non_default_neighbors = True
                # print driven_plug
                if non_default_value :
                    animation_curve = self.sdk_group.get_animation_curve(driven_plug)
                    #
                    # print('Current value for %s is non default %s != %s. Creating Keyframe' % (
                    #     driven_plug,
                    #     driven_plug.default_value,
                    #     current_value
                    # ))

                    new_keyframe = sdk_group.create_child(
                        SDKKeyFrame,
                        animation_curve=animation_curve,
                        in_value=self.in_value,
                        parent=animation_curve
                    )
                    self.keyframes.append(new_keyframe)

                    #  Add default neighbor keys value keys if needed
                    all_curve_in_values = animation_curve.keyframes.keys()
                    if next_key_group and max_in_value not in all_curve_in_values:
                        # print('Next in value %s is not represented in the animation curve. Creating Key' % max_in_value)
                        new_keyframe = sdk_group.create_child(
                            SDKKeyFrame,
                            animation_curve=animation_curve,
                            in_value=max_in_value,
                            out_value=default_value,
                            parent=animation_curve
                        )
                        next_key_group.keyframes.append(new_keyframe)

                    if previous_key_group and min_in_value not in all_curve_in_values:
                        # print('Previous in value %s is not represented in the animation curve. Creating Key' % min_in_value)
                        new_keyframe = sdk_group.create_child(
                            SDKKeyFrame,
                            animation_curve=animation_curve,
                            in_value=min_in_value,
                            out_value=default_value,
                            parent=animation_curve
                        )
                        previous_key_group.keyframes.append(new_keyframe)

                elif non_default_neighbors:
                    # print('The driven plug %s has non_default_neighborss. Creating Key' % driven_plug)

                    animation_curve = self.sdk_group.get_animation_curve(driven_plug)
                    new_keyframe = sdk_group.create_child(
                        SDKKeyFrame,
                        animation_curve=animation_curve,
                        in_value=self.in_value,
                        parent=animation_curve
                    )
                    self.keyframes.append(new_keyframe)
        self.controller.dg_dirty()

    def set_keyframe_tangents(self, tangent_type):

        self.in_tangent_type = tangent_type
        self.out_tangent_type = tangent_type

        self.controller.change_keyframe(
            self,
            in_tangent=tangent_type,
            out_tangent=tangent_type
        )

    def get_blueprint(self):
        blueprint = dict(
            klass=self.__class__.__name__,
            module=self.__module__,
            root_name=self.root_name,
            segment_name=self.segment_name,
            in_value=self.in_value
        )
        return blueprint

    def teardown(self):

        self.controller.start_sdk_disown_signal.emit(self, self.sdk_group)
        curve_names = [key.animation_curve.name for key in self.keyframes]
        if curve_names:
            self.controller.scene.select(cl=True)
            self.controller.scene.selectKey(*curve_names, cl=True)

            self.controller.scene.selectKey(
                [key.animation_curve.name for key in self.keyframes],
                float=(self.in_value,),
                keyframe=True
            )

            self.controller.scene.cutKey(
                animation='keys',
                clear=True,
            )
        sdk_group = self.sdk_group
        self.sdk_group.keyframe_groups.remove(self)
        self.sdk_group = None
        super(KeyframeGroup, self).teardown()
        self.controller.end_sdk_disown_signal.emit(self, sdk_group)
