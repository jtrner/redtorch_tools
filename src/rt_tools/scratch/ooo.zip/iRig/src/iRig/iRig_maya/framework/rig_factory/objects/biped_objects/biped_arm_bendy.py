
import rig_factory
from rig_factory.objects.base_objects.properties import ObjectListProperty, DataProperty, ObjectProperty
from rig_factory.objects.biped_objects.biped_arm import BipedArmGuide, BipedArm
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.dag_node import DagNode
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_factory.objects.part_objects.part import Part
import rig_factory.environment as env
import rig_factory.utilities.node_utilities.ik_handle_utilities as iks
from rig_math.vector import Vector
from rig_math.matrix import Matrix


class BipedArmBendyGuide(BipedArmGuide):

    default_settings = {
        'root_name': 'Arm',
        'size': 4.0,
        'side': 'left',
        'squash': 1,
    }

    squash = DataProperty(
        name='squash',
    )
    segment_names = DataProperty(
        name='segment_names',
        default_value=['Clavicle', 'Shoulder', 'Elbow', 'Hand', 'HandEnd']
    )

    def __init__(self, **kwargs):
        super(BipedArmBendyGuide, self).__init__(**kwargs)
        self.toggle_class = BipedArmBendy.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(BipedArmBendyGuide, cls).create(controller, **kwargs)
        this.create_plug(
            'squash',
            defaultValue=this.squash,
            keyable=True,
        )

        return this

    def get_blueprint(self):

        blueprint = super(BipedArmBendyGuide, self).get_blueprint()

        blueprint['squash'] = self.plugs['squash'].get_value()

        return blueprint

    def get_toggle_blueprint(self):

        blueprint = super(BipedArmBendyGuide, self).get_toggle_blueprint()

        blueprint['squash'] = self.plugs['squash'].get_value()

        return blueprint


class BipedArmBendy(Part):

    spline_joints = ObjectListProperty(
        name='spline_joints'
    )

    squash = DataProperty(
        name='squash',
        default_value=1,
    )

    settings_handle = ObjectProperty(
        name='settings_handle'
    )

    clavicle_handle = ObjectProperty(
        name='clavicle_handle'
    )
    base_joints = ObjectListProperty(
        name='base_joints'
    )
    wrist_handle = ObjectProperty(
        name='wrist_handle'
    )
    wrist_handle_gimbal = ObjectProperty(
        name='wrist_handle_gimbal'
    )
    elbow_handle = ObjectProperty(
        name='elbow_handle'
    )
    ik_group = ObjectProperty(
        name='ik_group'
    )
    ik_joints = ObjectListProperty(
        name='ik_joints'
    )
    isolate_ik_joints = ObjectListProperty(
        name='isolate_ik_joints'
    )
    fk_joints = ObjectListProperty(
        name='fk_joints'
    )
    ik_handles = ObjectListProperty(
        name='ik_handles'
    )
    fk_handles = ObjectListProperty(
        name='fk_handles'
    )
    stretchable_plugs = ObjectListProperty(
        name='stretchable_plugs'
    )
    elbow_line = ObjectProperty(
        name='elbow_line'
    )
    isolate_group = ObjectProperty(
        name='isolate_group'
    )
    segment_names = DataProperty(
        name='segment_names',
        default_value=['Clavicle', 'Shoulder', 'Elbow', 'Hand', 'HandEnd']
    )

    def __init__(self, **kwargs):
        super(BipedArmBendy, self).__init__(**kwargs)

    @classmethod
    def create(cls, *args, **kwargs):
        this = super(BipedArmBendy, cls).create(*args, **kwargs)
        BipedArm.build_rig(this)
        return this

    def create_deformation_rig(self, **kwargs):
        super(BipedArmBendy, self).create_deformation_rig(**kwargs)

        side = self.side
        size = self.size
        controller = self.controller
        deform_joints = self.deform_joints
        joints = self.joints
        spline_joints = []
        matrices = [x.get_matrix() for x in deform_joints]
        root = self.get_root()
        curve_degree = 2
        segment_joint_count = 6
        settings_handle = self.settings_handle
        squash = self.squash

        for deform_joint in deform_joints[1:-1]:
            deform_joint.plugs.set_values(
                radius=0
            )

        bendy_elbow_handle = self.create_handle(
            handle_type=GroupedHandle,
            segment_name='%s%s' % (
                self.segment_names[1].title(),
                self.segment_names[2].title()
            ),
            functionality_name='Bendy',
            shape='ball',
            matrix=matrices[2],
            parent=joints[2],
            size=size*0.75
        )

        bendy_up_arm = self.create_handle(
            handle_type=GroupedHandle,
            segment_name=self.segment_names[1].title(),
            functionality_name='Bendy',
            shape='ball',
            matrix=matrices[1],
            parent=joints[1],
            size=size*0.75
        )

        bendy_forearm = self.create_handle(
            handle_type=GroupedHandle,
            segment_name='%s' % self.segment_names[2].title(),
            functionality_name='Bendy',
            shape='ball',
            matrix=matrices[2],
            parent=joints[2],
            size=size*0.75
        )

        bendy_elbow_handle.plugs.set_values(
            overrideEnabled=True,
            overrideRGBColors=True,
            overrideColorRGB=env.secondary_colors[side]
        )

        bendy_up_arm.plugs.set_values(
            overrideEnabled=True,
            overrideRGBColors=True,
            overrideColorRGB=env.secondary_colors[side]
        )
        bendy_forearm.plugs.set_values(
            overrideEnabled=True,
            overrideRGBColors=True,
            overrideColorRGB=env.secondary_colors[side]
        )
        shoulder_orient_group_1 = deform_joints[0].create_child(
            Transform,
            segment_name='ShoulderOrientBase',
            matrix=matrices[1]
        )
        shoulder_orient_group_2 = deform_joints[1].create_child(
            Transform,
            segment_name='ShoulderOrientTip',
            matrix=matrices[1],
        )
        shoulder_orient_group = deform_joints[0].create_child(
            Transform,
            segment_name='ShoulderOrient',
            matrix=matrices[1],
        )
        elbow_orient_group = deform_joints[1].create_child(
            Transform,
            segment_name='ElbowOrient',
            matrix=matrices[2],

        )
        wrist_orient_group = deform_joints[3].create_child(
            Transform,
            segment_name='WristOrient',
            matrix=matrices[3],
        )
        shoulder_up_group = shoulder_orient_group.create_child(
            Transform,
            segment_name='ShoulderUp',
        )

        up_group_distance = [x * size * 5 for x in env.side_up_vectors[side]]
        shoulder_up_group.plugs['translate'].set_value(up_group_distance)
        elbow_up_group = elbow_orient_group.create_child(
            Transform,
            segment_name='ElbowUp',
        )
        elbow_up_group.plugs['translate'].set_value(up_group_distance)
        wrist_up_group = wrist_orient_group.create_child(
            Transform,
            segment_name='WristUp',
        )
        wrist_up_group.plugs['translate'].set_value(up_group_distance)

        controller.create_point_constraint(
            deform_joints[1],
            bendy_elbow_handle,
            bendy_up_arm.groups[0]
        )
        controller.create_point_constraint(
            bendy_elbow_handle,
            deform_joints[3],
            bendy_forearm.groups[0]
        )

        locators = []
        for x in [deform_joints[1], bendy_up_arm, bendy_elbow_handle, bendy_forearm, deform_joints[3]]:
            locator = x.create_child(Locator)
            locators.append(locator)
            locator.plugs['visibility'].set_value(False)

        constraint = controller.create_orient_constraint(
            shoulder_orient_group_1,
            shoulder_orient_group_2,
            shoulder_orient_group,
            skip='y',
        )
        constraint.plugs['interpType'].set_value(2)
        constraint = controller.create_orient_constraint(
            deform_joints[1],
            deform_joints[2],
            elbow_orient_group,
            skip='y'
        )
        constraint.plugs['interpType'].set_value(2)
        constraint = controller.create_orient_constraint(
            deform_joints[2],
            deform_joints[3],
            wrist_orient_group,
            skip='y'

        )
        constraint.plugs['interpType'].set_value(2)

        controller.create_point_constraint(
            deform_joints[1],
            shoulder_orient_group
        )
        controller.create_point_constraint(
            deform_joints[2],
            elbow_orient_group
        )
        controller.create_point_constraint(
            deform_joints[3],
            wrist_orient_group
        )

        scale_blenders = []

        # Up Arm

        nurbs_curve_transform = self.create_child(
            Transform,
            segment_name='BendyUp',
            parent=root.deform_group
        )
        nurbs_curve_transform.plugs['visibility'].set_value(False)
        nurbs_curve_transform.plugs['inheritsTransform'].set_value(False)

        nurbs_curve = nurbs_curve_transform.create_child(
            NurbsCurve,
            degree=curve_degree,
            positions=[[0.0, 0.0, 0.0]] * 3,
        )

        curve_info = self.create_child(
            DependNode,
            segment_name='BendyUp',
            node_type='curveInfo'
        )
        nurbs_curve.plugs['worldSpace'].element(0).connect_to(
            curve_info.plugs['inputCurve'],
        )
        locators[0].plugs['worldPosition'].element(0).connect_to(
            nurbs_curve.plugs['controlPoints'].element(0)
        )
        locators[1].plugs['worldPosition'].element(0).connect_to(
            nurbs_curve.plugs['controlPoints'].element(1)
        )
        locators[2].plugs['worldPosition'].element(0).connect_to(
            nurbs_curve.plugs['controlPoints'].element(2)
        )

        scale_divide = self.create_child(
            DependNode,
            segment_name='BendyUpScaleDivide',
            node_type='multiplyDivide'
        )
        scale_divide.plugs['operation'].set_value(2)
        curve_info.plugs['arcLength'].connect_to(scale_divide.plugs['input1X'])
        curve_info.plugs['arcLength'].connect_to(scale_divide.plugs['input1Y'])
        curve_info.plugs['arcLength'].connect_to(scale_divide.plugs['input1Z'])
        self.scale_multiply_transform.plugs['scale'].connect_to(scale_divide.plugs['input2'])

        length_divide = self.create_child(
            DependNode,
            segment_name='BendyUpLengthDivide',
            node_type='multiplyDivide'
        )
        length_divide.plugs['operation'].set_value(2)
        length_divide.plugs['input2X'].set_value(
            -(segment_joint_count - 1)
            if side == 'right' else
            segment_joint_count - 1
        )
        scale_divide.plugs['output'].connect_to(length_divide.plugs['input1'])

        rebuild_curve = nurbs_curve.create_child(
            DependNode,
            node_type='rebuildCurve'
        )
        rebuild_curve.plugs.set_values(
            keepRange=0,
            keepControlPoints=1,
        )
        nurbs_curve.plugs['worldSpace'].element(0).connect_to(
            rebuild_curve.plugs['inputCurve'],
        )
        nurbs_curve.plugs['degree'].connect_to(
            rebuild_curve.plugs['degree'],
        )

        settings_handle.create_plug(
            'squash',
            attributeType='float',
            keyable=True,
            defaultValue=squash,
        )
        settings_handle.create_plug(
            'squashMin',
            attributeType='float',
            keyable=True,
            defaultValue=0.1,
        )
        settings_handle.create_plug(
            'squashMax',
            attributeType='float',
            keyable=True,
            defaultValue=5,
        )
        root.add_plugs(
            [
                settings_handle.plugs['squash'],
                settings_handle.plugs['squashMin'],
                settings_handle.plugs['squashMax'],
            ],
        )

        spline_joint_parent = deform_joints[1]
        start_position = deform_joints[1].get_translation()
        end_position = deform_joints[2].get_translation()
        up_arm_spline_joints = []
        arc_length_dimension_parameter = 1.0 / (segment_joint_count - 1)
        previous_spline_joint = None
        previous_arc_length_dimension = None
        for i in range(segment_joint_count):
            index_character = rig_factory.index_dictionary[i].title()
            position_weight = 1.0 / (segment_joint_count - 1) * i
            spline_joint_matrix = deform_joints[1].get_matrix()
            weighted_end_vector = end_position * position_weight
            weighted_start_vector = start_position * (1.0 - position_weight)
            position = weighted_end_vector + weighted_start_vector
            spline_joint_matrix.set_translation(position)

            spline_joint = spline_joint_parent.create_child(
                Joint,
                segment_name='%sSecondary%s' % (self.segment_names[1], index_character),
                matrix=spline_joint_matrix
            )
            spline_joint.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.colors['bindJoints'],
                overrideDisplayType=0
            )
            if previous_spline_joint:
                previous_spline_joint.plugs['scale'].connect_to(
                    spline_joint.plugs['inverseScale'],
                )
            root.add_plugs(
                [
                    spline_joint.plugs['rx'],
                    spline_joint.plugs['ry'],
                    spline_joint.plugs['rz'],
                ],
                keyable=False
            )

            spline_joint.zero_rotation()
            up_arm_spline_joints.append(spline_joint)
            spline_joints.append(spline_joint)

            spline_joint_parent = spline_joint
            if i > 0:
                length_divide.plugs['outputX'].connect_to(
                    spline_joint.plugs['t{0}'.format(env.aim_vector_axis)],
                )

            if i not in (0, segment_joint_count - 1):
                arc_length_dimension = spline_joint.create_child(
                    DagNode,
                    segment_name='UpperArc%s' % index_character,
                    node_type='arcLengthDimension',
                    parent=self.utility_group
                )
                arc_length_dimension.plugs.set_values(
                    uParamValue=arc_length_dimension_parameter * i,
                    visibility=False,
                )
                rebuild_curve.plugs['outputCurve'].connect_to(
                    arc_length_dimension.plugs['nurbsGeometry'],
                )

                plus_minus_average = spline_joint.create_child(
                    DependNode,
                    node_type='plusMinusAverage',
                )
                plus_minus_average.plugs['operation'].set_value(2)
                arc_length_dimension.plugs['arcLength'].connect_to(
                    plus_minus_average.plugs['input1D'].element(0),
                )
                if previous_arc_length_dimension:
                    previous_arc_length_dimension.plugs['arcLength'].connect_to(
                        plus_minus_average.plugs['input1D'].element(1),
                    )

                multiply_divide = spline_joint.create_child(
                    DependNode,
                    node_type='multiplyDivide',
                )
                multiply_divide.plugs['operation'].set_value(2)
                plus_minus_average_value = plus_minus_average.plugs['output1D'].get_value()
                multiply_divide.plugs.set_values(
                    input1X=plus_minus_average_value,
                    input1Y=1,
                    input1Z=plus_minus_average_value,
                )
                plus_minus_average.plugs['output1D'].connect_to(
                    multiply_divide.plugs['input2X'],
                )
                plus_minus_average.plugs['output1D'].connect_to(
                    multiply_divide.plugs['input2Z'],
                )

                inverse_scale = spline_joint.create_child(
                    DependNode,
                    node_type='multiplyDivide',
                    segment_name='UpperInverseScale%s' % index_character,
                )
                inverse_scale.plugs['operation'].set_value(1)
                multiply_divide.plugs['output'].connect_to(
                    inverse_scale.plugs['input1'],
                )
                self.scale_multiply_transform.plugs['scaleX'].connect_to(
                    inverse_scale.plugs['input2X'],
                )
                self.scale_multiply_transform.plugs['scaleZ'].connect_to(
                    inverse_scale.plugs['input2Z'],
                )

                blend_colors = spline_joint.create_child(
                    DependNode,
                    node_type='blendColors',
                )
                blend_colors.plugs['color2R'].set_value(1)
                inverse_scale.plugs['output'].connect_to(
                    blend_colors.plugs['color1'],
                )
                settings_handle.plugs['squash'].connect_to(
                    blend_colors.plugs['blender'],
                )

                scale_control_blender = spline_joint.create_child(
                    DependNode,
                    node_type='blendColors',
                    segment_name='UpperInverseScale%s' % index_character,
                )
                scale_control_blender.plugs.set_values(blender=1)
                scale_blenders.append(scale_control_blender)

                scale_control_multiply = spline_joint.create_child(
                    DependNode,
                    node_type='multiplyDivide',
                    segment_name='UpperScaleControl%s' % index_character
                )
                scale_control_blender.plugs['output'].connect_to(
                    scale_control_multiply.plugs['input1'],
                )
                blend_colors.plugs['output'].connect_to(
                    scale_control_multiply.plugs['input2'],
                )

                clamp = spline_joint.create_child(
                    DependNode,
                    node_type='clamp',
                )
                scale_control_multiply.plugs['output'].connect_to(
                    clamp.plugs['input'],
                )
                settings_handle.plugs['squashMin'].connect_to(
                    clamp.plugs['minR'],
                )
                settings_handle.plugs['squashMin'].connect_to(
                    clamp.plugs['minB'],
                )
                settings_handle.plugs['squashMax'].connect_to(
                    clamp.plugs['maxR'],
                )
                settings_handle.plugs['squashMax'].connect_to(
                    clamp.plugs['maxB'],
                )
                clamp.plugs['outputR'].connect_to(
                    spline_joint.plugs['scaleX'],
                )
                clamp.plugs['outputB'].connect_to(
                    spline_joint.plugs['scaleZ'],
                )

                previous_arc_length_dimension = arc_length_dimension

            else:

                blender = spline_joint.create_child(
                    DependNode,
                    node_type='blendColors',
                    segment_name='UpperDummy%s' % index_character,
                )
                blender.plugs.set_values(
                    blender=1.0,
                    color1=(1, 1, 1),
                )
                scale_blenders.append(blender)

                clamp = spline_joint.create_child(
                    DependNode,
                    node_type='clamp',
                    segment_name='UpperDummy%s' % index_character,
                )
                blender.plugs['output'].connect_to(
                    clamp.plugs['input'],
                )
                settings_handle.plugs['squashMin'].connect_to(
                    clamp.plugs['minR'],
                )
                settings_handle.plugs['squashMin'].connect_to(
                    clamp.plugs['minB'],
                )
                settings_handle.plugs['squashMax'].connect_to(
                    clamp.plugs['maxR'],
                )
                settings_handle.plugs['squashMax'].connect_to(
                    clamp.plugs['maxB'],
                )
                clamp.plugs['outputR'].connect_to(
                    spline_joint.plugs['scaleX'],
                )
                clamp.plugs['outputB'].connect_to(
                    spline_joint.plugs['scaleZ'],
                )

            previous_spline_joint = spline_joint

        spline_ik_handle = iks.create_spline_ik(
            up_arm_spline_joints[0],
            up_arm_spline_joints[-1],
            nurbs_curve,
            world_up_object=shoulder_up_group,
            world_up_object_2=elbow_up_group,
            side=side
        )

        spline_ik_handle.plugs['visibility'].set_value(False)

        # Forearm

        nurbs_curve_transform = self.create_child(
            Transform,
            segment_name='BendyForearm',
            parent=root.deform_group
        )
        nurbs_curve_transform.plugs['visibility'].set_value(False)
        nurbs_curve_transform.plugs['inheritsTransform'].set_value(False)

        nurbs_curve = nurbs_curve_transform.create_child(
            NurbsCurve,
            degree=curve_degree,
            positions=[[0.0, 0.0, 0.0]] * 3,
        )
        locators[2].plugs['worldPosition'].element(0).connect_to(
            nurbs_curve.plugs['controlPoints'].element(0)
        )
        locators[3].plugs['worldPosition'].element(0).connect_to(
            nurbs_curve.plugs['controlPoints'].element(1)
        )
        locators[4].plugs['worldPosition'].element(0).connect_to(
            nurbs_curve.plugs['controlPoints'].element(2)
        )

        curve_info = self.create_child(
            DependNode,
            segment_name='BendyForearm',
            node_type='curveInfo',

        )

        scale_divide = self.create_child(
            DependNode,
            segment_name='BendyForearmScaleDivide',
            node_type='multiplyDivide'
        )
        scale_divide.plugs['operation'].set_value(2)
        curve_info.plugs['arcLength'].connect_to(
            scale_divide.plugs['input1X'],
        )
        curve_info.plugs['arcLength'].connect_to(
            scale_divide.plugs['input1Y'],
        )
        curve_info.plugs['arcLength'].connect_to(
            scale_divide.plugs['input1Z'],
        )
        nurbs_curve.plugs['worldSpace'].element(0).connect_to(
            curve_info.plugs['inputCurve'],
        )
        self.scale_multiply_transform.plugs['scale'].connect_to(
            scale_divide.plugs['input2'],
        )

        length_divide = self.create_child(
            DependNode,
            segment_name='BendyForearmLengthDivide',
            node_type='multiplyDivide',
        )
        length_divide.plugs['operation'].set_value(2)
        length_divide.plugs['input2Y'].set_value(
            (segment_joint_count - 1) * -1
            if side == 'right' else
            segment_joint_count - 1
        )
        scale_divide.plugs['output'].connect_to(
            length_divide.plugs['input1'],
        )

        rebuild_curve = nurbs_curve.create_child(
            DependNode,
            node_type='rebuildCurve'
        )
        rebuild_curve.plugs.set_values(
            keepRange=0,
            keepControlPoints=1,
        )
        nurbs_curve.plugs['worldSpace'].element(0).connect_to(
            rebuild_curve.plugs['inputCurve'],
        )
        nurbs_curve.plugs['degree'].connect_to(
            rebuild_curve.plugs['degree'],
        )

        forearm_spline_joints = []
        spline_joint_parent = deform_joints[1]
        start_position = deform_joints[2].get_translation()
        end_position = deform_joints[3].get_translation()
        arc_length_dimension_parameter = 1.0 / (segment_joint_count - 1)
        previous_spline_joint = None
        previous_arc_length_dimension = None
        for i in range(segment_joint_count):
            index_character = rig_factory.index_dictionary[i].title()

            position_weight = 1.0 / (segment_joint_count - 1) * i
            spline_joint_matrix = deform_joints[2].get_matrix()
            weighted_end_vector = end_position * position_weight
            weighted_start_vector = start_position * (1.0 - position_weight)
            position = weighted_end_vector + weighted_start_vector
            spline_joint_matrix.set_translation(position)

            spline_joint = spline_joint_parent.create_child(
                Joint,
                segment_name='%sSecondary%s' % (self.segment_names[2], index_character),
                index=i,
                matrix=spline_joint_matrix
            )
            spline_joint.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.colors['bindJoints'],
                overrideDisplayType=0
            )
            if previous_spline_joint:
                previous_spline_joint.plugs['scale'].connect_to(
                    spline_joint.plugs['inverseScale'],
                )
            root.add_plugs(
                [
                    spline_joint.plugs['rx'],
                    spline_joint.plugs['ry'],
                    spline_joint.plugs['rz']
                ],
                keyable=False
            )

            spline_joint.zero_rotation()
            spline_joints.append(spline_joint)
            forearm_spline_joints.append(spline_joint)

            spline_joint_parent = spline_joint
            if i > 0:
                length_divide.plugs['outputY'].connect_to(
                    spline_joint.plugs['t{0}'.format(env.aim_vector_axis)],
                )

            # Creates squash logic for all joints in between the
            # starting and ending spline joints.
            if 0 < i < segment_joint_count - 1:

                arc_length_dimension = spline_joint.create_child(
                    DagNode,
                    segment_name='LowerDimension%s' % index_character,
                    node_type='arcLengthDimension',
                    parent=self.utility_group
                )
                arc_length_dimension.plugs.set_values(
                    uParamValue=arc_length_dimension_parameter * i,
                    visibility=False,
                )
                rebuild_curve.plugs['outputCurve'].connect_to(
                    arc_length_dimension.plugs['nurbsGeometry'],
                )

                plus_minus_average = spline_joint.create_child(
                    DependNode,
                    node_type='plusMinusAverage',
                )
                plus_minus_average.plugs['operation'].set_value(2)
                arc_length_dimension.plugs['arcLength'].connect_to(
                    plus_minus_average.plugs['input1D'].element(0),
                )
                if previous_arc_length_dimension:
                    previous_arc_length_dimension.plugs['arcLength'].connect_to(
                        plus_minus_average.plugs['input1D'].element(1),
                    )

                multiply_divide = spline_joint.create_child(
                    DependNode,
                    node_type='multiplyDivide',
                )
                multiply_divide.plugs['operation'].set_value(2)
                plus_minus_average_value = plus_minus_average.plugs['output1D'].get_value()
                multiply_divide.plugs.set_values(
                    input1X=plus_minus_average_value,
                    input1Y=1,
                    input1Z=plus_minus_average_value,
                )
                plus_minus_average.plugs['output1D'].connect_to(
                    multiply_divide.plugs['input2X'],
                )
                plus_minus_average.plugs['output1D'].connect_to(
                    multiply_divide.plugs['input2Z'],
                )

                inverse_scale = spline_joint.create_child(
                    DependNode,
                    node_type='multiplyDivide',
                    segment_name='LowerInverseScale%s' % index_character,
                )
                inverse_scale.plugs['operation'].set_value(1)
                multiply_divide.plugs['output'].connect_to(
                    inverse_scale.plugs['input1'],
                )
                self.scale_multiply_transform.plugs['scaleX'].connect_to(
                    inverse_scale.plugs['input2X'],
                )
                self.scale_multiply_transform.plugs['scaleZ'].connect_to(
                    inverse_scale.plugs['input2Z'],
                )

                blend_colors = spline_joint.create_child(
                    DependNode,
                    node_type='blendColors',
                )
                blend_colors.plugs['color2R'].set_value(1)
                inverse_scale.plugs['output'].connect_to(
                    blend_colors.plugs['color1'],
                )
                settings_handle.plugs['squash'].connect_to(
                    blend_colors.plugs['blender'],
                )

                scale_control_blender = spline_joint.create_child(
                    DependNode,
                    node_type='blendColors',
                    segment_name='LowerScaleControl%s' % index_character,
                )
                scale_control_blender.plugs.set_values(blender=1)
                scale_blenders.append(scale_control_blender)

                scale_control_multiply = spline_joint.create_child(
                    DependNode,
                    node_type='multiplyDivide',
                    segment_name='LowerScaleControl%s' % index_character,
                )
                scale_control_blender.plugs['output'].connect_to(
                    scale_control_multiply.plugs['input1'],
                )
                blend_colors.plugs['output'].connect_to(
                    scale_control_multiply.plugs['input2'],
                )

                clamp = spline_joint.create_child(
                    DependNode,
                    node_type='clamp',
                )
                scale_control_multiply.plugs['output'].connect_to(
                    clamp.plugs['input'],
                )
                settings_handle.plugs['squashMin'].connect_to(
                    clamp.plugs['minR'],
                )
                settings_handle.plugs['squashMin'].connect_to(
                    clamp.plugs['minB'],
                )
                settings_handle.plugs['squashMax'].connect_to(
                    clamp.plugs['maxR'],
                )
                settings_handle.plugs['squashMax'].connect_to(
                    clamp.plugs['maxB'],
                )
                clamp.plugs['outputR'].connect_to(
                    spline_joint.plugs['scaleX'],
                )
                clamp.plugs['outputB'].connect_to(
                    spline_joint.plugs['scaleZ'],
                )

                # The second joint of the lower spline attaches it's
                # logic to the first joint of the lower spline to
                # create a smooth transition from the upper to the lower
                # arm.
                if i == 1:
                    clamp.plugs['outputR'].connect_to(
                        forearm_spline_joints[0].plugs['scaleX'],
                    )
                    clamp.plugs['outputB'].connect_to(
                        forearm_spline_joints[0].plugs['scaleZ'],
                    )

                previous_arc_length_dimension = arc_length_dimension

            # Creates a simpler version of the squash logic for the
            # final spline joint as arc lengths are not needed if the
            # joint is directly on top of the control.
            elif i == segment_joint_count - 1:

                blender = spline_joint.create_child(
                    DependNode,
                    node_type='blendColors',
                    segment_name='LowerDummy%s' % index_character,
                )
                blender.plugs.set_values(
                    blender=1.0,
                    color1=(1, 1, 1),
                )
                scale_blenders.append(blender)

                clamp = spline_joint.create_child(
                    DependNode,
                    node_type='clamp',
                    segment_name='LowerDummy%s' % index_character,
                )
                blender.plugs['output'].connect_to(
                    clamp.plugs['input'],
                )
                settings_handle.plugs['squashMin'].connect_to(
                    clamp.plugs['minR'],
                )
                settings_handle.plugs['squashMin'].connect_to(
                    clamp.plugs['minB'],
                )
                settings_handle.plugs['squashMax'].connect_to(
                    clamp.plugs['maxR'],
                )
                settings_handle.plugs['squashMax'].connect_to(
                    clamp.plugs['maxB'],
                )
                clamp.plugs['outputR'].connect_to(
                    spline_joint.plugs['scaleX'],
                )
                clamp.plugs['outputB'].connect_to(
                    spline_joint.plugs['scaleZ'],
                )

            previous_spline_joint = spline_joint


        bendy_handles = bendy_up_arm, bendy_elbow_handle, bendy_forearm

        controller.create_point_constraint(
            bendy_elbow_handle,
            forearm_spline_joints[0],
            mo=False
        )

        parameter = (len(bendy_handles) - 1.0) / (len(scale_blenders) - 1.0)
        for i, blender in enumerate(scale_blenders):
            connection_1 = int(parameter * i // 1.0)
            connection_2 = connection_1 + 1
            blender_value = 1 - (parameter * i - connection_1)

            if len(bendy_handles) - 1 < connection_2:
                break

            bendy_handles[connection_1].plugs['scale'].connect_to(
                blender.plugs['color1'],
            )
            bendy_handles[connection_2].plugs['scale'].connect_to(
                blender.plugs['color2'],
            )
            blender.plugs.set_values(blender=blender_value)

        spline_ik_handle = iks.create_spline_ik(
            forearm_spline_joints[0],
            forearm_spline_joints[-1],
            nurbs_curve,
            world_up_object=elbow_up_group,
            world_up_object_2=wrist_up_group,
            side=side
        )

        spline_ik_handle.plugs['visibility'].set_value(False)

        root.add_plugs(
            bendy_elbow_handle.plugs.get('tx', 'ty', 'tz'),
            bendy_elbow_handle.plugs.get('sx', 'sz'),
        )
        root.add_plugs(
            bendy_up_arm.plugs.get('tx', 'ty', 'tz'),
            bendy_up_arm.plugs.get('sx', 'sz'),
        )
        root.add_plugs(
            bendy_forearm.plugs.get('tx', 'ty', 'tz'),
            bendy_forearm.plugs.get('sx', 'sz'),
        )

        self.secondary_handles = [
            bendy_elbow_handle,
            bendy_up_arm,
            bendy_forearm,
        ]
        self.spline_joints = spline_joints
        self.deform_joints.extend(spline_joints)



    def toggle_ik(self):
        value = self.settings_handle.plugs['ikSwitch'].get_value()
        if value > 0.5:
            self.match_to_fk()
        else:
            self.match_to_ik()

    def match_to_fk(self):
        self.settings_handle.plugs['ikSwitch'].set_value(0.0)
        positions = [x.get_matrix() for x in self.ik_joints]
        for i in range(len(positions[0:3])):
            self.fk_handles[i].set_matrix(Matrix(positions[i]))

    def match_to_ik(self):
        self.settings_handle.plugs['ikSwitch'].set_value(1.0)
        positions = [x.get_matrix() for x in self.fk_joints]
        self.wrist_handle.set_matrix(positions[2])
        vector_multiplier = self.size * 10
        if self.side == 'left':
            vector_multiplier = vector_multiplier * -1
        z_vector_1 = Vector(positions[0].data[2][0:3]).normalize()
        z_vector_2 = Vector(positions[1].data[2][0:3]).normalize()
        z_vector = (z_vector_1 + z_vector_2) * 0.5
        pole_position = positions[1].get_translation() + (z_vector * vector_multiplier)
        self.elbow_handle.set_matrix(Matrix(pole_position))
