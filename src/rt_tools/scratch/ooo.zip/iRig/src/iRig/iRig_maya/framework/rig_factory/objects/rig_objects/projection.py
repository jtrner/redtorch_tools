from rig_factory.objects.node_objects.place_3d_texture import Place3dTexture
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.shader import Shader
from rig_factory.objects.base_objects.properties import ObjectProperty


class Projection(DependNode):
    """
    Small 3 node shader network representing the minimum nodes required
    for a 3d projection.
    """

    place_3d_texture = ObjectProperty(
        name='place_3d_texture_node'
    )

    projection = ObjectProperty(
        name='projection_node'
    )

    shader = ObjectProperty(
        name='shader'
    )

    def __init__(self, **kwargs):
        super(Projection, self).__init__(**kwargs)
        self.node_type = 'projection'

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(Projection, cls).create(controller, **kwargs)

        # place 3d texture object.

        this.place_3d_texture = place_3d_texture = this.create_child(
            Place3dTexture,
            parent=this.parent,
            root_name=this.root_name + '_place3dTexture'
        )

        # projection node.

        this.projection = projection = this.create_child(
            DependNode,
            node_type='projection',
            root_name=this.root_name + '_projection'
        )
        place_3d_texture.plugs['worldInverseMatrix'].element(0).connect_to(
            projection.plugs['placementMatrix']
        )
        this.m_object = projection

        # shader object.

        this.shader = shader = this.create_child(
            Shader,
            node_type='lambert',
            root_name=this.root_name + '_shader'
        )
        projection.plugs['outColor'].connect_to(
            shader.plugs['color']
        )

        return this