import rig_factory
from rig_factory.objects.part_objects.chain_guide import ChainGuide
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.node_objects.joint import Joint
from rig_math.matrix import Matrix
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle, GimbalHandle
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty


class FkChainGuide(ChainGuide):

    default_settings = dict(
        root_name='Chain',
        count=5,
        size=1.0,
        side='center',
        up_vector_indices=[0],
        create_gimbals=False,
        create_tweaks=False
    )

    create_gimbals = DataProperty(
        name='create_gimbals'
    )

    create_tweaks = DataProperty(
        name='create_tweaks'
    )

    def __init__(self, **kwargs):
        super(FkChainGuide, self).__init__(**kwargs)
        self.toggle_class = FkChain.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(FkChainGuide, cls).create(controller, **kwargs)
        return this


class FkChain(Part):

    create_gimbals = DataProperty(
        name='create_gimbals'
    )

    create_tweaks = DataProperty(
        name='create_tweaks'
    )

    base_handles = ObjectListProperty(
        name='base_handles'
    )

    def __init__(self, **kwargs):
        super(FkChain, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(FkChain, cls).create(controller, **kwargs)
        matrices = this.matrices
        size = this.size
        side = this.side
        joints = this.joints

        root = this.get_root()

        joint_parent = this.joint_group
        handle_parent = this
        handles = []

        for x, matrix in enumerate(matrices):
            segment_name = rig_factory.index_dictionary[x].title()
            joint = this.create_child(
                Joint,
                segment_name=segment_name,
                matrix=matrix,
                parent=joint_parent
            )
            joint_parent = joint
            joint.zero_rotation()
            joint.plugs.set_values(
                overrideEnabled=1,
                overrideDisplayType=2
            )
            joints.append(joint)
            if x != len(matrices)-1:
                handle = this.create_handle(
                    handle_type=GimbalHandle if this.create_gimbals else GroupedHandle,
                    segment_name=segment_name,
                    size=size*2.5,
                    matrix=matrix,
                    side=side,
                    shape='circle',
                    parent=handle_parent
                )
                handles.append(handle)

                handle_parent = handle.gimbal_handle if this.create_gimbals else handle

                # handle.stretch_shape(matrices[x + 1].get_translation())
                # shape_scale = [
                #     0.8,
                #     0.8,
                #     -1.0 if side == 'right' else 1.0,
                # ]
                # handle.multiply_shape_matrix(Matrix(scale=shape_scale))
                handle.plugs['scale'].connect_to(joint.plugs['scale'])
                handle.plugs['rotateOrder'].connect_to(joint.plugs['rotateOrder'])
                if this.create_tweaks:
                    tweak_handle = this.create_handle(
                        segment_name='Tweak%s' % segment_name,
                        size=size * 2,
                        matrix=matrix,
                        side=side,
                        shape='diamond',
                        create_gimbal=False,
                        parent=handle.gimbal_handle if this.create_gimbals else handle
                    )
                    joint_driver = tweak_handle
                    root.add_plugs(
                        tweak_handle.plugs['rx'],
                        tweak_handle.plugs['ry'],
                        tweak_handle.plugs['rz'],
                        tweak_handle.plugs['tx'],
                        tweak_handle.plugs['ty'],
                        tweak_handle.plugs['tz'],
                        tweak_handle.plugs['sx'],
                        tweak_handle.plugs['sy'],
                        tweak_handle.plugs['sz']
                    )
                elif this.create_gimbals:
                    joint_driver = handle.gimbal_handle
                else:
                    joint_driver = handle

                controller.create_parent_constraint(
                    joint_driver,
                    joint
                )

                controller.create_scale_constraint(
                    joint_driver,
                    joint
                )

                root.add_plugs(
                    handle.plugs['rx'],
                    handle.plugs['ry'],
                    handle.plugs['rz'],
                    handle.plugs['tx'],
                    handle.plugs['ty'],
                    handle.plugs['tz'],
                    handle.plugs['sx'],
                    handle.plugs['sy'],
                    handle.plugs['sz']
                )


        joints[0].plugs['type'].set_value(1)
        for joint in joints[1:]:
            joint.plugs['type'].set_value(6)
        this.base_handles = handles
        return this
