from rig_factory.objects.base_objects.properties import DataProperty, ObjectProperty, ObjectListProperty, ObjectDictProperty
from rig_factory.objects.base_objects.base_node import BaseNode
from rig_factory.objects.sdk_objects.sdk_curve import SDKCurve
from rig_factory.objects.sdk_objects.keyframe_group import KeyframeGroup
from rig_factory.objects.node_objects.plug import Plug

foo = list()


class SDKGroup(BaseNode):

    sdk_network = ObjectProperty(
        name='sdk_network'
    )
    driver_plug = ObjectProperty(
        name='driver_plug'
    )
    animation_curves = ObjectDictProperty(
        name='animation_curves'
    )
    keyframe_groups = ObjectListProperty(
        name='keyframe_groups'
    )
    active = DataProperty(
        name='active'
    )
    suffix = 'Skp'

    def __init__(self, **kwargs):
        super(SDKGroup, self).__init__(**kwargs)

    def isolate(self):
        """
        Subtract the effect of all but this group from the driven plugs
        :param SDKGroup:
        :return: None
        """

        sdk_network = self.sdk_network
        sdk_groups = sdk_network.sdk_groups
        driven_plugs = sdk_network.driven_plugs
        for driven_plug in driven_plugs:
            difference = 0.0
            for gi in range(len(sdk_groups)):
                if self.index != gi:
                    blend_input_plug = driven_plug.relationships['blend_node'].plugs['input'].element(gi)
                    difference += blend_input_plug.get_value(0.0)
            driven_plug.set_value(driven_plug.get_value(0.0) - difference)

    def set_active(self, value):
        self.controller.set_active(self, value)

    def set_weight(self, value):
        self.controller.set_weight(self, value)

    def create_keyframe_group(self, **kwargs):
        return self.controller.create_object(
            KeyframeGroup,
            sdk_group=self,
            **kwargs
        )

    def get_blueprint(self):
        blueprint = dict(
            klass=self.__class__.__name__,
            module=self.__module__,
            root_name=self.root_name,
            segment_name=self.segment_name,
            side=self.side,
            size=self.size,
            index=self.index,
            driver_plug='%s.%s' % (
                self.driver_plug.get_node().get_selection_string(),
                self.driver_plug.root_name
            )
        )
        return blueprint

    def get_animation_curve_data(self):
        curves_data = dict()
        for driver_plug_name in self.animation_curves:
            animation_curve = self.animation_curves[driver_plug_name]
            curve_data = dict()
            for in_value in animation_curve.keyframes:
                curve_data[in_value] = animation_curve.keyframes[in_value].out_value
            curves_data[driver_plug_name] = curve_data
        return curves_data

    @classmethod
    def create(cls, controller, **kwargs):
        sdk_network = kwargs.get('sdk_network', None)
        if not isinstance(kwargs.get('driver_plug', None), Plug):
            raise Exception(
                'Cannot create an %s without a "driver_plug" keyword argument' % SDKGroup.__name__
            )
        if not sdk_network or not sdk_network.__class__.__name__ == 'SDKNetwork':
            raise Exception(
                'You must provide an SDKNetwork as the keyword argument'
            )
        kwargs.setdefault('parent', sdk_network)
        controller.start_sdk_ownership_signal.emit(None, sdk_network)
        kwargs['index'] = sdk_network.get_next_avaliable_index()
        this = super(SDKGroup, cls).create(
            controller,
            **kwargs
        )
        sdk_network.sdk_groups.append(this)
        controller.end_sdk_ownership_signal.emit(this, sdk_network)
        return this

    def get_animation_curve(self, driven_plug):
        if driven_plug.name in self.animation_curves:
            return self.animation_curves[driven_plug.name]
        default_value = driven_plug.get_value()
        driver_plug = self.driver_plug
        driver_node_name, driver_attribute_name = driver_plug.name.split('.')
        driven_node_name, driven_attribute_name = driven_plug.name.split('.')

        segment_name = '{}_{}_{}_{}'.format(
            underscore_to_camelcase(driver_node_name),
            driver_attribute_name.title(),
            underscore_to_camelcase(driven_node_name),
            driven_attribute_name.title()
        )

        animation_curve = self.controller.create_object(
            SDKCurve,
            sdk_group=self,
            parent=self,
            root_name=self.root_name,
            segment_name=segment_name,
            driven_plug=driven_plug,
            index=len(self.animation_curves)
        )
        self.animation_curves[driven_plug.name] = animation_curve
        if self.sdk_network.lock_curves:
            self.controller.scene.lock_node(animation_curve, lock=True)
        animation_curve.plugs['output'].set_value(default_value)
        return animation_curve

    def teardown(self):
        self.controller.start_sdk_disown_signal.emit(
            self,
            self.sdk_network
        )
        self.controller.schedule_objects_for_deletion(
            self.animation_curves.values()
        )
        sdk_network = self.sdk_network
        sdk_network.sdk_groups.remove(self)
        self.sdk_network = None
        super(SDKGroup, self).teardown()
        self.controller.end_sdk_disown_signal.emit(self, sdk_network)


def underscore_to_camelcase(value):
    def camelcase():
        while True:
            yield str.capitalize

    c = camelcase()
    return "".join(c.next()(str(x)) if x else '_' for x in value.split("_"))