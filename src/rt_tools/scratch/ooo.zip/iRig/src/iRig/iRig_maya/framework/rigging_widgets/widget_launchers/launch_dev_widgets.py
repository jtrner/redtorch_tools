import sys
import os
from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
import rigging_widgets

import batch_tasks.rigging_environment as rev



def launch(mock=False, standalone=False):
    if mock:
        standalone = False
    if standalone:
        mock = False
    style_sheet_path = '%s/rig_builder/qss/slate.qss' % os.path.dirname(rigging_widgets.__file__.replace('\\', '/'))
    with open(style_sheet_path, mode='r') as f:
        style_sheet = f.read()
    if mock:
        rev.load_mock_rigging_environment(
            'SUPA',
            'GenManA',
            dev_mode=True
        )
    else:
        rev.load_rigging_environment(
            'SUPA',
            'GenManA',
            dev_mode=True
        )
        rev.load_system_paths(dev_mode=True)

    app = QApplication(sys.argv)
    app.setStyleSheet(style_sheet)
    import rig_factory.build.utilities.controller_utilities as cut
    controller = cut.initialize_rig_controller(mock=mock, standalone=standalone)
    if not mock:
        rev.load_rigging_plugins()

    from rigging_widgets.rig_builder.widgets.rig_widget import RigWidget
    body_widget = RigWidget()
    body_widget.set_controller(controller)
    body_widget.show()
    body_widget.raise_()

    from rigging_widgets.face_builder.widgets.face_widget import FaceWidget
    face_widget = FaceWidget()
    face_widget.set_controller(controller)
    face_widget.show()
    face_widget.raise_()
    sys.exit(app.exec_())


if __name__ == '__main__':
    launch(mock=True)
