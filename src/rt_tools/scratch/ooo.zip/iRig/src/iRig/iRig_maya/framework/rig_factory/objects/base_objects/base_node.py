from rig_factory.objects.base_objects.base_object import BaseObject


class BaseNode(BaseObject):

    def __setattr__(self, name, value):
        if hasattr(self, name):
            try:
                super(BaseObject, self).__setattr__(name, value)
            except Exception:
                raise Exception(
                    'The property "%s" on the %s named "%s" could not be set to: type<%s> %s.' % (
                        name,
                        type(self),
                        self.name,
                        type(value),
                        value
                    )
                )

        else:
            raise Exception('The "%s" attribute is not registered with the %s class' % (
                name,
                self.__class__.__name__
            ))

    def __init__(self, *args, **kwargs):

        super(BaseNode, self).__init__(*args, **kwargs)

    def create_child(self, object_type, *args, **kwargs):
        for key in ['root_name', 'segment_name', 'functionality_name', 'differentiation_name', 'side', 'size', 'index']:
            if key not in kwargs:
                kwargs[key] = self.__getattribute__(key)
        if not kwargs.get('parent', None):
            kwargs['parent'] = self
        node = self.controller.create_object(
            object_type,
            *args,
            **kwargs
        )
        return node
