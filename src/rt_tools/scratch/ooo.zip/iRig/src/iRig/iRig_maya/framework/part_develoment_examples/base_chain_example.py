from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.part_objects.chain_guide import ChainGuide
from rig_factory.objects.node_objects.joint import Joint
import rig_factory


class BaseChainGuide(ChainGuide):

    default_settings = dict(
        root_name='Chain',
        size=1.0,
        side='center',
        count=5
    )

    def __init__(self, **kwargs):
        super(BaseChainGuide, self).__init__(**kwargs)
        self.toggle_class = 'BaseChain'


class BaseChain(Part):

    @classmethod
    def create(cls, *args, **kwargs):
        this = super(BaseChain, cls).create(*args, **kwargs)
        joint_parent = this.joint_group
        joints = []
        for i in range(len(this.matrices)):
            joint = this.create_child(
                Joint,
                matrix=this.matrices[i],
                segment_name=rig_factory.index_dictionary[i].title(),
                parent=joint_parent
            )
            joints.append(joint)
            joint_parent = joint
            handle = this.create_handle(
                matrix=this.matrices[i],
                segment_name=rig_factory.index_dictionary[i].title(),
            )
            this.controller.create_parent_constraint(handle, joint)
        this.joints = joints
        return this
