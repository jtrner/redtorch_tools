import rig_factory.object_versions as obs
from rig_factory.controllers.rig_controller import RigController

controller = RigController.get_controller(mock=True)


def test_transform():
    obj = controller.create_object(
        obs.Transform,
        root_name='Root',
        segment_name='Segment'

    )
    return obj

