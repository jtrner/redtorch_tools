from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.dag_node import DagNode
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.nurbs_surface import NurbsSurface
from rig_factory.objects.rig_objects.line import Line
import rig_factory.environment as env
from rig_factory.objects.rig_objects.capsule import Capsule
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.rig_objects.cone import Cone
from rig_factory.objects.rig_objects.ribbon import Ribbon
from rig_math.vector import Vector
import rig_factory


class TailGuide(PartGuide):

    default_settings = {
        'root_name': 'Tail',
        'size': 1.0,
        'side': 'right',
        'count': 5,
        'joint_count': 25,
        'ribbon_degree': 2,
        'create_gimbals': False,
        'fk_mode': True
    }

    joint_count = DataProperty(
        name='joint_count'
    )
    count = DataProperty(
        name='count'
    )
    secondary_count = DataProperty(
        name='secondary_count'
    )
    ribbon_degree = DataProperty(
        name='ribbon_degree',
        default_value=2
    )
    create_gimbals = DataProperty(
        name='create_gimbals'
    )
    create_tweaks = DataProperty(
        name='create_tweaks'
    )
    up_handle = ObjectProperty(
        name='count'
    )
    fk_mode = DataProperty(
        name='fk_mode'
    )

    def __init__(self, **kwargs):
        super(TailGuide, self).__init__(**kwargs)
        self.toggle_class = Tail.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(TailGuide, cls).create(controller, **kwargs)
        handle_positions = kwargs.get('handle_positions', dict())
        size = this.size
        side = this.side
        spacing = size * 2.0
        root = this.get_root()
        size_plug = this.plugs['size']
        size_multiply = this.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='Size'
        )
        ribbon_width_plug = this.create_plug(
            'RibbonWidth',
            at='double',
            k=True,
            min=0.01,
            max=1.0,
            dv=0.5
        )

        size_plug.connect_to(size_multiply.plugs['input1X'])
        size_plug.connect_to(size_multiply.plugs['input1Y'])
        size_plug.connect_to(size_multiply.plugs['input1Z'])
        size_multiply.plugs['input2X'].set_value(0.5)
        size_multiply.plugs['input2Y'].set_value(0.25)
        size_multiply.plugs['input2Z'].set_value(0.5)

        joints = []
        locators = []
        handles = []
        base_handles = []
        capsules = []

        up_handle = this.create_handle(
            segment_name='Up'
        )
        up_locator = up_handle.create_child(Locator)
        up_locator.plugs['v'].set_value(False)
        up_handle.plugs['translate'].set_value(handle_positions.get(up_handle.name, [0.0, 0.0, size*2.0]))
        up_handle.mesh.assign_shading_group(this.get_root().shaders[side].shading_group)
        size_plug.connect_to(up_handle.plugs['size'])

        root.add_plugs(
            [
                up_handle.plugs['tx'],
                up_handle.plugs['ty'],
                up_handle.plugs['tz']
            ]
        )

        for i in range(this.count):
            index_character = rig_factory.index_dictionary[i].upper()
            joint = this.create_child(
                Joint,
                segment_name=index_character
            )
            handle = this.create_handle(
                segment_name=index_character
            )
            position = handle_positions.get(handle.name, [0.0, spacing*i, 0.0])
            handle.plugs['translate'].set_value(position)
            root.add_plugs(
                [
                    handle.plugs['tx'],
                    handle.plugs['ty'],
                    handle.plugs['tz']
                ]
            )
            cone_x = joint.create_child(
                Cone,
                segment_name='ConeX%s' % index_character,
                axis=[1.0, 0.0, 0.0]
            )
            cone_y = joint.create_child(
                Cone,
                segment_name='ConeY%s' % index_character,
                axis=[0.0, 1.0, 0.0]
            )
            cone_z = joint.create_child(
                Cone,
                segment_name='ConeZ%s' % index_character,
                axis=[0.0, 0.0, 1.0]
            )
            locator = joint.create_child(
                Locator
            )
            controller.create_point_constraint(
                handle,
                joint,
                mo=False
            )

            size_multiply.plugs['outputX'].connect_to(handle.plugs['size'])
            size_multiply.plugs['outputX'].connect_to(cone_x.plugs['size'])
            size_multiply.plugs['outputX'].connect_to(cone_y.plugs['size'])
            size_multiply.plugs['outputX'].connect_to(cone_z.plugs['size'])
            joint.plugs.set_values(
                drawStyle=2
            )
            cone_x.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
            )
            cone_y.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
            )
            cone_z.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
            )
            locator.plugs.set_values(
                visibility=False
            )
            locator.plugs['visibility'].set_value(False)
            handle.mesh.assign_shading_group(root.shaders[side].shading_group)
            cone_x.mesh.assign_shading_group(root.shaders['x'].shading_group)
            cone_y.mesh.assign_shading_group(root.shaders['y'].shading_group)
            cone_z.mesh.assign_shading_group(root.shaders['z'].shading_group)

            joints.append(joint)
            locators.append(locator)
            handles.append(handle)
            base_handles.append(handle)

        for i in range(this.count):
            if i < this.count - 1:
                segment_name = rig_factory.index_dictionary[i].upper()
                capsule = this.create_child(
                    Capsule,
                    index=i,
                    segment_name='%sFkSegment' % segment_name,
                    parent=this
                )
                capsule.mesh.assign_shading_group(this.get_root().shaders[side].shading_group)
                size_plug.connect_to(capsule.plugs['size'])
                locator_1 = locators[i]
                locator_2 = locators[i + 1]
                joint_1 = joints[i]
                joint_2 = joints[i + 1]
                locator_1.plugs['worldPosition'].element(0).connect_to(capsule.plugs['position1'])
                locator_2.plugs['worldPosition'].element(0).connect_to(capsule.plugs['position2'])
                controller.create_point_constraint(joint_1, joint_2, capsule)
                controller.create_aim_constraint(
                    joint_2,
                    capsule,
                    aimVector=env.aim_vector
                )
                controller.create_aim_constraint(
                    handles[i + 1],
                    joints[i],
                    worldUpType='object',
                    worldUpObject=up_handle.get_selection_string(),
                    aimVector=env.side_aim_vectors[side],
                    upVector=env.side_up_vectors[side]
                )
                capsules.append(capsule)
            else:
                controller.create_aim_constraint(
                    handles[i - 1],
                    joints[i],
                    worldUpType='object',
                    worldUpObject=up_handle,
                    aimVector=[x * -1 for x in env.side_aim_vectors[side]],
                    upVector=env.side_up_vectors[side]
                )

        this.joints = joints
        ribbon_transform = this.create_child(
            Transform,
            segment_name='Ribbon'
        )

        ribbon_base_curve = ribbon_transform.create_child(
            NurbsCurve,
            degree=2,
            segment_name='RibbonBase',
            positions=[x.get_translation() for x in this.joints]
        )
        ribbon_base_curve.plugs['intermediateObject'].set_value(True)
        ribbon_surface = ribbon_transform.create_child(NurbsSurface)

        for i, joint in enumerate(joints):
            joint.plugs['translate'].connect_to(ribbon_base_curve.plugs['controlPoints'].element(i))

        extrude = this.create_child(
            DependNode,
            node_type='extrude',
            segment_name='Extrude'
        )
        extrude_vector_subtract = this.create_child(
            DependNode,
            node_type='plusMinusAverage',
            segment_name='Extrude'
        )
        ribbon_width_multiply = this.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='LengthMultiply'
        )
        ribbon_transform.plugs['translate'].set_locked(True)
        ribbon_transform.plugs['rotate'].set_locked(True)
        ribbon_transform.plugs['scale'].set_locked(True)
        ribbon_transform.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2
        )
        size_plug.connect_to(ribbon_width_multiply.plugs['input1X'])
        ribbon_width_plug.connect_to(ribbon_width_multiply.plugs['input2X'])
        extrude_vector_subtract.plugs['operation'].set_value(2)
        locators[0].plugs['worldPosition'].element(0).connect_to(extrude_vector_subtract.plugs['input3D'].element(0))
        up_locator.plugs['worldPosition'].element(0).connect_to(extrude_vector_subtract.plugs['input3D'].element(1))
        extrude.plugs['extrudeType'].set_value(0)
        extrude.plugs['useProfileNormal'].set_value(False)
        extrude_vector_subtract.plugs['output3D'].connect_to(extrude.plugs['direction'])
        ribbon_width_multiply.plugs['outputX'].connect_to(extrude.plugs['length'])
        extrude.plugs['outputSurface'].connect_to(ribbon_surface.plugs['create'])
        ribbon_base_curve.plugs['worldSpace'].element(0).connect_to(extrude.plugs['profile'])
        ribbon_surface.assign_shading_group(root.shaders['highlight'].shading_group)

        up_vector_line = this.create_child(
            Line,
            segment_name='Line'
        )
        locators[0].plugs['worldPosition'].element(0).connect_to(up_vector_line.curve.plugs['controlPoints'].element(0))
        up_locator.plugs['worldPosition'].element(0).connect_to(up_vector_line.curve.plugs['controlPoints'].element(1))
        up_vector_line.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
        )
        transforms = create_ribbon_transforms(this, ribbon_surface)

        locators = []
        capsule_start_width = size
        capsule_end_width = size*0.2

        for i, transform in enumerate(transforms):
            locator = transform.create_child(Locator)
            locator.plugs['v'].set_value(False)
            locators.append(locator)
            if i != 0:

                end_segment_width = capsule_end_width / len(transforms) * i
                start_segment_width = capsule_start_width - (capsule_start_width / len(transforms) * i)

                index_character = rig_factory.index_dictionary[i-1]
                capsule = transform.create_child(
                    Capsule,
                    segment_name='Segment%s' % index_character,
                    parent=this
                )
                multiply_node = capsule.create_child(
                    DependNode,
                    node_type='multDoubleLinear'
                )
                size_plug.connect_to(multiply_node.plugs['input1'])

                multiply_node.plugs['input2'].set_value(start_segment_width + end_segment_width)
                multiply_node.plugs['output'].connect_to(capsule.plugs['size'])
                capsule.poly_cylinder.plugs['roundCap'].set_value(0)
                capsule.mesh.assign_shading_group(root.shaders[side].shading_group)
                locators[i-1].plugs['worldPosition'].element(0).connect_to(capsule.plugs['position1'])
                locators[i].plugs['worldPosition'].element(0).connect_to(capsule.plugs['position2'])
                controller.create_point_constraint(transforms[i-1], transforms[i], capsule)
                controller.create_aim_constraint(
                    transform,
                    capsule,
                    aimVector=env.aim_vector,
                    upVector=env.up_vector,
                    worldUpObject=transforms[i-1],
                    worldUpType='objectRotation',
                    worldUpVector=[1.0, 0.0, 0.0]
                )

        this.up_handle = up_handle

        return this

    def get_toggle_blueprint(self):
        blueprint = super(TailGuide, self).get_toggle_blueprint()
        position_1 = self.handles[0].get_matrix().get_translation()
        position_2 = self.handles[1].get_matrix().get_translation()
        blueprint.update(
            matrices=[list(x.get_matrix()) for x in self.joints],
            up_vector=(position_2 - position_1).normalize().data
        )
        return blueprint


class Tail(Part):

    add_root = DataProperty(
        name='add_root'
    )
    fk_mode = DataProperty(
        name='fk_mode'
    )
    create_tweaks = DataProperty(
        name='create_tweaks'
    )
    create_gimbals = DataProperty(
        name='create_gimbals'
    )
    up_vector = DataProperty(
        name='up_vector'
    )
    settings_handle = ObjectProperty(
        name='settings_handle'
    )
    joint_matrices = DataProperty(
        name='joint_matrices'
    )
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )
    joint_count = DataProperty(
        name='joint_count'
    )
    secondary_count = DataProperty(
        name='secondary_count'
    )

    def __init__(self, *args, **kwargs):
        super(Tail, self).__init__(**kwargs)
        self.joint_chain = False

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(Tail, cls).create(controller, **kwargs)
        matrices = this.matrices
        size = this.size
        side = this.side
        joints = this.joints

        root = this.get_root()

        joint_parent = this.joint_group
        handle_parent = this
        handles = []


        for x, matrix in enumerate(matrices):
            segment_name = rig_factory.index_dictionary[x].title()
            joint = this.create_child(
                Joint,
                segment_name=segment_name,
                matrix=matrix,
                parent=joint_parent
            )
            # joint_parent = joint
            joint.zero_rotation()
            joint.plugs.set_values(
                overrideEnabled=1,
                overrideDisplayType=2
            )
            joints.append(joint)
            handle = this.create_handle(
                segment_name=segment_name,
                size=size,
                matrix=matrix,
                side=side,
                shape='circle',
                parent=handle_parent,
                create_gimbal=this.create_gimbals
            )
            handles.append(handle)

            if this.fk_mode:
                handle_parent = handle.gimbal_handle if this.create_gimbals else handle

            # handle.stretch_shape(matrices[x + 1].get_translation())
            # shape_scale = [
            #     0.8,
            #     0.8,
            #     -1.0 if side == 'right' else 1.0,
            # ]
            # handle.multiply_shape_matrix(Matrix(scale=shape_scale))
            handle.plugs['scale'].connect_to(joint.plugs['scale'])
            handle.plugs['rotateOrder'].connect_to(joint.plugs['rotateOrder'])
            joint_driver = handle

            if this.create_tweaks:
                tweak_handle = this.create_handle(
                    segment_name='Tweak%s' % segment_name,
                    size=size * 0.75,
                    matrix=matrix,
                    side=side,
                    shape='diamond',
                    create_gimbal=False,
                    parent=handle.gimbal_handle if this.create_gimbals else handle
                )
                joint_driver = tweak_handle
                root.add_plugs(
                    tweak_handle.plugs['rx'],
                    tweak_handle.plugs['ry'],
                    tweak_handle.plugs['rz'],
                    tweak_handle.plugs['tx'],
                    tweak_handle.plugs['ty'],
                    tweak_handle.plugs['tz'],
                    tweak_handle.plugs['sx'],
                    tweak_handle.plugs['sy'],
                    tweak_handle.plugs['sz']
                )
            elif this.create_gimbals:
                joint_driver = handle.gimbal_handle

            controller.create_parent_constraint(
                joint_driver,
                joint
            )

            controller.create_scale_constraint(
                joint_driver,
                joint
            )

            root.add_plugs(
                handle.plugs['rx'],
                handle.plugs['ry'],
                handle.plugs['rz'],
                handle.plugs['tx'],
                handle.plugs['ty'],
                handle.plugs['tz'],
                handle.plugs['sx'],
                handle.plugs['sy'],
                handle.plugs['sz']
            )


        settings_matrix = joints[0].get_matrix()
        settings_handle = this.create_handle(
            shape='gear',
            segment_name='Settings',
            matrix=settings_matrix,
            parent=joints[0],
            create_gimbal=False

        )
        settings_handle.groups[0].plugs['tz'].set_value(size * 5 if side == 'right' else size * -5)

        this.settings_handle = settings_handle


        joints[0].plugs['type'].set_value(1)
        for joint in joints[1:]:
            joint.plugs['type'].set_value(6)
        return this

    def create_deformation_rig(self, **kwargs):
        super(Tail, self).create_deformation_rig(**kwargs)

        root = self.get_root()

        ribbon = self.create_child(
            Ribbon,
            [list(x.get_translation()) for x in self.matrices],
            segment_name='Secondary',
            vector=(Vector(self.up_vector) * (self.size * 0.05)).data,
            extrude=True,
            degree=2
        )
        ribbon.plugs['visibility'].set_value(False)
        self.controller.scene.reverseSurface(ribbon.nurbs_surface, ch=False, d=3, rpo=1)
        self.controller.scene.skinCluster(
            self.base_deform_joints,
            ribbon.nurbs_surface,
            toSelectedBones=True,
            maximumInfluences=1
        )

        transforms = create_ribbon_transforms(self, ribbon.nurbs_surface, tangent_parameter_value=0.5)


        slide_plug = self.settings_handle.create_plug(
            'Slide',
            at='double',
            k=True,
            min=0.0,
            max=1.0,
            dv=1.0
        )
        grow_plug = self.settings_handle.create_plug(
            'Grow',
            at='double',
            k=True,
            min=0.001,
            max=1.0,
            dv=1.0
        )

        lock_length_plug = self.settings_handle.create_plug(
            'LockLength',
            at='double',
            k=True,
            min=0.0,
            max=1.0,
            dv=0.0
        )

        slide_plug.connect_to(self.plugs['Slide'])
        grow_plug.connect_to(self.plugs['Grow'])
        lock_length_plug.connect_to(self.plugs['LockLength'])

        root.add_plugs(
            slide_plug,
            grow_plug,
            lock_length_plug
        )

        joint_parent = root.deform_group
        for i, transform in enumerate(transforms):
            segment_name = rig_factory.index_dictionary[i].title()
            deform_joint = self.create_child(
                Joint,
                segment_name='SecondaryBind%s' % segment_name,
                parent=joint_parent
            )
            deform_joint.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.colors['bindJoints'],
                overrideDisplayType=0
            )
            self.controller.create_parent_constraint(
                transform,
                deform_joint,
                mo=False
            )
            joint_parent = deform_joint


def create_ribbon_transforms(part, ribbon_surface, tangent_parameter_value=0.0):
    motion_path_spans = 32
    root = part.get_root()
    side = part.side
    controller = part.controller
    slide_plug = part.create_plug(
        'Slide',
        at='double',
        k=True,
        min=0.0,
        max=1.0,
        dv=1.0
    )
    grow_plug = part.create_plug(
        'Grow',
        at='double',
        k=True,
        min=0.001,
        max=1.0,
        dv=1.0
    )

    lock_length_plug = part.create_plug(
        'LockLength',
        at='double',
        k=True,
        min=0.0,
        max=1.0,
        dv=0.0
    )

    curves_group = part.create_child(
        Transform,
        segment_name='Curves'
    )
    curves_group.plugs.set_values(
        overrideEnabled=True,
        overrideDisplayType=2,
    )
    tangent_base_curve = curves_group.create_child(
        NurbsCurve,
        segment_name='TangentBase'
    )
    tangent_curve = curves_group.create_child(
        NurbsCurve,
        segment_name='Tangent'
    )
    up_base_curve = curves_group.create_child(
        NurbsCurve,
        segment_name='UpBase'
    )
    up_curve = curves_group.create_child(
        NurbsCurve,
        segment_name='Up'
    )
    tangent_curve_from_surface = curves_group.create_child(
        DependNode,
        node_type='curveFromSurfaceIso'
    )
    up_curve_from_surface = curves_group.create_child(
        DependNode,
        node_type='curveFromSurfaceIso',
        segment_name='Up',
    )
    grow_multiply = part.create_child(
        DependNode,
        node_type='multiplyDivide',
        segment_name='Grow'
    )
    arc_length_dimension = part.create_child(
        DagNode,
        segment_name='Length',
        node_type='arcLengthDimension',
        parent=part.utility_group
    )

    tangent_base_curve.plugs['intermediateObject'].set_value(True)
    tangent_curve.plugs['intermediateObject'].set_value(True)
    up_base_curve.plugs['intermediateObject'].set_value(True)
    up_curve.plugs['intermediateObject'].set_value(True)


    # Curve stacks
    ribbon_surface.plugs['worldSpace'].element(0).connect_to(tangent_curve_from_surface.plugs['inputSurface'])
    tangent_curve_from_surface.plugs['outputCurve'].connect_to(tangent_base_curve.plugs['create'])
    tangent_base_curve.plugs['worldSpace'].element(0).connect_to(tangent_curve.plugs['create'])
    tangent_curve.plugs['worldSpace'].element(0).connect_to(arc_length_dimension.plugs['nurbsGeometry'])

    ribbon_surface.plugs['worldSpace'].element(0).connect_to(up_curve_from_surface.plugs['inputSurface'])
    up_curve_from_surface.plugs['outputCurve'].connect_to(up_base_curve.plugs['create'])
    up_base_curve.plugs['worldSpace'].element(0).connect_to(up_curve.plugs['create'])


    # Set attributes
    tangent_curve_from_surface.plugs['isoparmDirection'].set_value(0)
    tangent_curve_from_surface.plugs['isoparmValue'].set_value(tangent_parameter_value)
    tangent_base_curve.plugs['intermediateObject'].set_value(True)

    up_curve_from_surface.plugs['isoparmDirection'].set_value(0)
    up_curve_from_surface.plugs['isoparmValue'].set_value(1.0)
    up_base_curve.plugs['intermediateObject'].set_value(True)

    grow_plug.connect_to(grow_multiply.plugs['input1X'])
    ribbon_surface.plugs['spansU'].connect_to(grow_multiply.plugs['input2X'])
    arc_length_dimension.plugs.set_values(
        uParamValue=ribbon_surface.plugs['spansU'].get_value(),
        visibility=False,
    )

    starting_length = arc_length_dimension.plugs['arcLength'].get_value()
    transforms = []
    for i in range(part.joint_count):
        index_character = rig_factory.index_dictionary[i].upper()
        transform = curves_group.create_child(
            Transform,
            segment_name='Ribbon%s' % index_character
        )
        up_transform = curves_group.create_child(
            Transform,
            segment_name='RibbonUp%s' % index_character
        )
        motion_path = transform.create_child(
            DependNode,
            node_type='motionPath',
            suffix='Mpth'
        )
        tangent_point_on_curve_info = transform.create_child(
            DependNode,
            node_type='pointOnCurveInfo'
        )
        up_point_on_curve_info = transform.create_child(
            DependNode,
            node_type='pointOnCurveInfo',
            segment_name='Up%s' % index_character
        )

        blend_parameters = transform.create_child(
            DependNode,
            node_type='blendColors'
        )
        nearest_point_on_curve = transform.create_child(
            DependNode,
            node_type='nearestPointOnCurve',
            suffix='Npoc'
        )

        lock_length_divide = transform.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='LockLengthDivide%s' % index_character
        )
        lock_length_parameter = transform.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='LockLengthParemetere%s' % index_character
        )
        grow_multiply = transform.create_child(
            DependNode,
            node_type='multDoubleLinear',
            segment_name='Grow%s' % index_character
        )

        lock_length_multiply = transform.create_child(
            DependNode,
            node_type='multDoubleLinear',
            segment_name='LockLength%s' % index_character
        )
        blend_lock_length = transform.create_child(
            DependNode,
            node_type='blendColors',
            segment_name='BlendLockLength%s' % index_character
        )

        #  Divide total length by starting length
        lock_length_divide.plugs['operation'].set_value(2)
        lock_length_parameter.plugs['operation'].set_value(2)

        lock_length_divide.plugs['input1X'].set_value(starting_length)
        arc_length_dimension.plugs['arcLength'].connect_to(lock_length_divide.plugs['input2X'])

        lock_length_divide.plugs['outputX'].connect_to(lock_length_parameter.plugs['input1X'])
        lock_length_parameter.plugs['input2X'].set_value(float(part.joint_count - 1))

        lock_length_parameter.plugs['outputX'].connect_to(lock_length_multiply.plugs['input1'])
        lock_length_multiply.plugs['input2'].set_value(float(i))

        lock_length_plug.connect_to(blend_lock_length.plugs['blender'])
        blend_lock_length.plugs['color2R'].set_value(1.0 / (part.joint_count - 1) * i)
        lock_length_multiply.plugs['output'].connect_to(blend_lock_length.plugs['color1R'])
        blend_lock_length.plugs['outputR'].connect_to(motion_path.plugs['uValue'])

        tangent_point_on_curve_info.plugs['turnOnPercentage'].set_value(False)
        tangent_curve.plugs['worldSpace'].element(0).connect_to(tangent_point_on_curve_info.plugs['inputCurve'])
        motion_path.plugs['fractionMode'].set_value(True)
        tangent_curve.plugs['worldSpace'].element(0).connect_to(motion_path.plugs['geometryPath'])
        motion_path.plugs['allCoordinates'].connect_to(nearest_point_on_curve.plugs['inPosition'])
        tangent_curve.plugs['worldSpace'].element(0).connect_to(nearest_point_on_curve.plugs['inputCurve'])
        nearest_point_on_curve.plugs['parameter'].connect_to(blend_parameters.plugs['color1R'])
        blend_parameters.plugs['color2R'].set_value(float(ribbon_surface.plugs['spansU'].get_value()) / (part.joint_count - 1) * i)
        slide_plug.connect_to(blend_parameters.plugs['blender'])
        blend_parameters.plugs['outputR'].connect_to(grow_multiply.plugs['input1'])
        grow_plug.connect_to(grow_multiply.plugs['input2'])
        grow_multiply.plugs['output'].connect_to(tangent_point_on_curve_info.plugs['parameter'])
        tangent_point_on_curve_info.plugs['position'].connect_to(transform.plugs['translate'])
        up_point_on_curve_info.plugs['turnOnPercentage'].set_value(False)
        up_curve.plugs['worldSpace'].element(0).connect_to(up_point_on_curve_info.plugs['inputCurve'])
        grow_multiply.plugs['output'].connect_to(up_point_on_curve_info.plugs['parameter'])
        up_point_on_curve_info.plugs['position'].connect_to(up_transform.plugs['translate'])

        controller.create_tangent_constraint(
            tangent_curve,
            transform,
            aimVector=env.side_aim_vectors[part.side],
            upVector=env.side_up_vectors[part.side],
            worldUpType='object',
            worldUpObject=up_transform.name
        )
        transforms.append(transform)

    return transforms

