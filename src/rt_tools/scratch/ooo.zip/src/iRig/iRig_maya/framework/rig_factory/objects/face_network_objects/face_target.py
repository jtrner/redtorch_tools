from rig_factory.objects.blendshape_objects.blendshape import BlendshapeInbetween, Blendshape
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.plug import Plug
from rig_factory.objects.base_objects.properties import DataProperty, ObjectProperty, ObjectListProperty
import rig_factory
import rig_math.utilities as rmu


class FaceTarget(Transform):

    attribute_values = DataProperty(
        name='attribute_values'
    )
    driver_value = DataProperty(
        name='driver_value'
    )
    face_group = ObjectProperty(
        name='face_group'
    )
    keyframe_group = ObjectProperty(
        name='keyframe_group'
    )
    blendshape_inbetween = ObjectProperty(
        name='blendshape_inbetween'
    )
    target_meshs = ObjectListProperty(
        name='target_meshs'
    )
    # deformed_meshs = ObjectListProperty(
    #     name='deformed_meshs'
    # )
    # result_meshs = ObjectListProperty(
    #     name='result_meshs'
    # )
    geometry_group = ObjectProperty(
        name='geometry_group'
    )
    @classmethod
    def create(cls, controller, **kwargs):
        geometry = list(kwargs.pop('geometry', []))
        face_group = kwargs.pop('face_group', None)

        snap_to_mesh = kwargs.get('snap_to_mesh', True)
        keyframe_data = kwargs.get('keyframe_data', None)
        isolate = kwargs.get('isolate', True)

        if not face_group:
            raise Exception('You must provide a "face_group" keyword argument')
        driver_value = round(kwargs.get('driver_value', 0.0), 3)
        if driver_value in [x.driver_value for x in face_group.face_targets]:
            raise Exception(
                'A face target with the driver value "%s" already exists' % driver_value
            )
        if not isinstance(driver_value, float):
            raise Exception(
                'you must provide a "driver_value" keyword argument of type(float) to create a %s' % Plug
            )

        face_network = face_group.face_network

        next_valiable_index = face_group.get_next_avaliable_index()

        kwargs['index'] = next_valiable_index

        kwargs['segment_name'] = '%s%s' % (
                face_group.segment_name,
                rig_factory.index_dictionary[next_valiable_index].title()
        )
        kwargs['side'] = face_group.side
        kwargs['face_group'] = face_group
        kwargs['driver_value'] = driver_value

        kwargs.setdefault('parent', face_group)

        # if geometry and snap_to_mesh:
        #     face_network.snap_to_mesh(*list(geometry))
        # face_network.consolidate_handle_positions()
        controller.face_target_start_ownership_signal.emit(
            None,
            face_group
        )
        this = super(FaceTarget, cls).create(
            controller,
            **kwargs
        )

        face_group.face_targets.append(this)
        controller.face_target_end_ownership_signal.emit(
            this,
            face_group
        )
        sdk_group = face_group.sdk_group

        if sdk_group:
            this.keyframe_group = sdk_group.create_keyframe_group(
                in_value=driver_value,
                isolate=isolate,
                parent=this,
                keyframe_data=keyframe_data
            )
            controller.dg_dirty()

        if geometry:
            this.create_blendshape_inbetween(*geometry)

        return this

    def create_blendshape_inbetween(self, *geometry):

        controller = self.controller
        face_group = self.face_group
        face_network = face_group.face_network
        blendshape = face_network.blendshape
        blendshape_group = face_group.blendshape_group

        if not blendshape:
            raise Exception('The FaceNetwork has no blendshape')
        if not blendshape_group:
            raise Exception('The FaceGroup has no blendshape group')
        if not geometry:
            if not face_network.geometry:
                raise Exception('The FaceNetwork had no base geometry set')
            else:
                geometry = face_network.geometry
        driver_value = self.driver_value

        if blendshape_group and driver_value != 0.0:
            blendshape = blendshape_group.blendshape
            face_group.driver_plug.set_value(driver_value)
            targets = create_target_geometry(self, *geometry)
            blendshape_group.disconnnect_targets()
            index = self.index
            root_name = blendshape_group.segment_name
            # controller.start_ownership_signal.emit(
            #     None,
            #     blendshape_group
            # )
            blendshape_inbetween = face_group.blendshape_group.create_child(
                BlendshapeInbetween,
                index=index,
                segment_name='%s%s' % (
                    face_group.segment_name,
                    rig_factory.index_dictionary[index]
                ),
                tangent_space=True,
            )

            blendshape_inbetween.blendshape_group = blendshape_group
            blendshape_group.blendshape_inbetweens.append(blendshape_inbetween)
            # controller.end_ownership_signal.emit(
            #     blendshape_inbetween,
            #     blendshape_group
            # )
            self.blendshape_inbetween = blendshape_inbetween
            controller.register_item(blendshape_inbetween)

            for g in range(len(blendshape.base_geometry)):
                blendshape_inbetween.create_blendshape_target(
                    targets[g]
                )
            min_driver_value, min_weight, max_driver_value, max_weight = face_group.calculate_driver_values()
            for face_target in face_group.face_targets:
                if face_target.driver_value != 0.0:
                    if face_target.blendshape_inbetween:
                        if face_target.driver_value > 0.0:
                            weight = rmu.remap_value(
                                face_target.driver_value,
                                0.0,
                                max_driver_value,
                                0.0,
                                1.0
                            )
                        else:
                            weight = rmu.remap_value(
                                face_target.driver_value,
                                min_driver_value,
                                0.0,
                                -1.0,
                                0.0
                            )
                        weight = round(weight, 3)
                        face_target.blendshape_inbetween.weight = weight
            face_group.connect_blendshape_targets()
            face_group.create_driver_curve()
            for mesh in blendshape.base_geometry:
                mesh.redraw()

    def delete_blendshape_inbetween(self):
        if not self.blendshape_inbetween:
            raise Exception('No blendshape inbetween found.')
        self.controller.schedule_objects_for_deletion(
            self.blendshape_inbetween,
            self.geometry_group
        )
        self.controller.delete_scheduled_objects()
        self.face_group.create_driver_curve()

    def update(self):
        if self.keyframe_group:
            self.keyframe_group.update()

    def __init__(self, **kwargs):
        super(FaceTarget, self).__init__(**kwargs)
        # self.controller.face_target_created_signal.emit(self)

    def teardown(self):
        self.controller.face_target_start_disown_signal.emit(self, self.face_group)
        self.controller.schedule_objects_for_deletion(
            self.keyframe_group,
            self.blendshape_inbetween
        )
        self.face_group.face_targets.remove(self)
        self.face_group.members.remove(self)
        face_group = self.face_group
        self.face_group = None
        super(FaceTarget, self).teardown()
        self.controller.face_target_end_disown_signal.emit(self, face_group)
        del face_group



def create_target_geometry(face_target, *geometry):

    """
    Builds blendshape Corrective target geometry

    :param face_target:
    :param geometry:  Mesh shapes
    :return:
    """

    if isinstance(face_target, FaceTarget):
        face_group = face_target.face_group
        face_network = face_group.face_network
        blendshape = face_network.blendshape
        blendshape_group = face_group.blendshape_group
        if face_target.driver_value == 0.0:
            raise Exception('Cannot create_face_target_geometry with driver value of 0.0')
        if not blendshape_group:
            raise Exception('blendshape_group not found')
        controller = face_target.controller
        similar_geometry = dict()
        for input_geo in geometry:
            similar_mesh = controller.find_similar_mesh(input_geo, blendshape.base_geometry)
            if similar_mesh:
                similar_geometry[similar_mesh.name] = input_geo
            else:
                raise Exception('No similar geometry fornd for : %s' % input_geo)
        face_group = face_target.face_group
        face_network = face_group.face_network
        blendshape_group_index = blendshape_group.index
        main_group = face_target.create_child(
            Transform,
            segment_name='%sGeometry' % face_target.segment_name
        )

        if len(geometry) == len(face_network.geometry):
            for g in range(len(face_network.geometry)):
                base_geometry = face_network.geometry[g]
                input_mesh = geometry[g]
                geo_name = str(input_mesh)
                existing_geometry = controller.scene.ls(geo_name)
                if len(existing_geometry) > 1:
                    raise Exception('Duplicate geometry name : "%s"' % geo_name)
                target_parent = main_group.create_child(
                    Transform,
                    segment_name='%sTarget%s' % (
                        main_group.segment_name,
                        rig_factory.index_dictionary[g]
                    )
                )
                target_mesh = controller.copy_mesh(
                    geo_name,
                    target_parent
                )
                face_target.target_meshs.append(target_mesh)
                controller.assign_shading_group(
                    face_network.sculpt_shader.shading_group,
                    target_mesh
                )

        else:
            for g in range(len(face_network.geometry)):
                base_geometry = face_network.geometry[g]
                if base_geometry.name in similar_geometry:
                    input_mesh = similar_geometry[base_geometry.name]
                    geo_name = str(input_mesh)
                    existing_geometry = controller.scene.ls(geo_name)
                    if len(existing_geometry) > 1:
                        raise Exception('Duplicate geometry name : "%s"' % geo_name)
                    target_parent = main_group.create_child(
                        Transform,
                        segment_name='%sTarget%s' % (
                            main_group.segment_name,
                            rig_factory.index_dictionary[g]
                        )
                    )
                    target_mesh = controller.copy_mesh(
                        geo_name,
                        target_parent
                    )
                    face_target.target_meshs.append(target_mesh)
                    controller.assign_shading_group(
                        face_network.sculpt_shader.shading_group,
                        target_mesh
                    )

                else:
                    raise Exception('Similar mesh not found for : %s' % base_geometry.name)
        face_target.geometry_group = main_group
        return face_target.target_meshs

    else:
        raise Exception('Cannot create_face_group_geometry on a %s' % type(face_target))

