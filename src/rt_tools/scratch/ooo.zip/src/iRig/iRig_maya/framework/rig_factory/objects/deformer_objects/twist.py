from nonlinear import NonLinear


class Twist(NonLinear):

    deformer_type = 'twist'
    handle_type = 'deformTwist'
    suffix = 'Twist'

    def __init__(self, **kwargs):
        super(Twist, self).__init__(**kwargs)
