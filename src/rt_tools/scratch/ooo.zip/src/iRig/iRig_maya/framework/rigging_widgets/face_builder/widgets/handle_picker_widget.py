import copy
from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
from rigging_widgets.face_builder.models.handle_model import HandleModel
import rig_factory.object_versions as obs
import rigging_widgets.face_builder.environment as env
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_factory.objects.face_objects.face_handle import FaceHandle

def get_selected_handles(self):
    ob = self.controller.named_objects
    selected_transforms = self.controller.get_selected_transform_names()
    return [ob[x] for x in selected_transforms if x in ob and isinstance(ob[x], (GroupedHandle,FaceHandle))]


class DrivenHandleWidget(QFrame):

    canceled_signal = Signal()
    ok_signal = Signal(list)

    def __init__(self, *args, **kwargs):
        super(DrivenHandleWidget, self).__init__(*args, **kwargs)
        title_font = QFont('', 18, True)
        title_font.setWeight(100)
        self.horizontal_layout = QHBoxLayout(self)
        self.vertical_layout = QVBoxLayout()
        self.button_layout = QHBoxLayout()
        self.bottom_button_layout = QHBoxLayout()

        self.label = QLabel('Driven Handles', self)
        # self.ok_button = QPushButton('OK', self)
        # self.cancel_button = QPushButton('Cancel', self)

        self.mesh_pixmap = QPixmap('%s/transform.png' % env.images_directory)
        self.image_label = QLabel(self)
        self.add_button = QPushButton('Add Selected', self)
        # self.reset_button = QPushButton('Clear', self)
        self.handle_view = HandleView(self)

        # self.horizontal_layout.addStretch()
        self.horizontal_layout.addLayout(self.vertical_layout)
        # self.horizontal_layout.addStretch()
        self.vertical_layout.addSpacerItem(QSpacerItem(25, 25))
        self.button_layout.addStretch()

        # self.button_layout.addWidget(self.reset_button)
        self.button_layout.addWidget(self.add_button)
        self.button_layout.addStretch()
        self.vertical_layout.addWidget(self.image_label)

        self.vertical_layout.addWidget(self.label)
        self.vertical_layout.addLayout(self.button_layout)
        self.vertical_layout.addWidget(self.handle_view)
        self.vertical_layout.addLayout(self.bottom_button_layout)
        self.bottom_button_layout.addStretch()
        # self.bottom_button_layout.addWidget(self.cancel_button)
        # self.bottom_button_layout.addWidget(self.ok_button)
        # self.vertical_layout.addStretch()
        self.label.setFont(title_font)
        self.label.setAlignment(Qt.AlignCenter)
        self.image_label.setPixmap(self.mesh_pixmap)
        self.image_label.setAlignment(Qt.AlignCenter)

        self.label.setWordWrap(True)
        self.add_button.pressed.connect(self.add_selected_handles)
        # self.ok_button.pressed.connect(self.emit_selected_handles)
        # self.cancel_button.pressed.connect(self.canceled_signal.emit)

        # self.reset_button.pressed.connect(self.reset)
        self.controller = None

    def set_controller(self, controller):
        self.handle_view.set_controller(controller)
        self.controller = controller

    # def emit_selected_handles(self):
    #     if not self.controller:
    #         self.raise_error(Exception('No Controller loaded'))
    #     if not self.controller.face_network:
    #         self.raise_error(Exception('No Face Network loaded'))
    #     model = self.handle_view.model()
    #     if not model:
    #         self.raise_error(Exception('No Handles Model loaded'))
    #     if not model.handles:
    #         reply = QMessageBox.question(
    #             self,
    #             "No Handles Selected",
    #             'No handles have been selected. \nDo you wish to continue?',
    #             QMessageBox.Yes | QMessageBox.No
    #         )
    #         if reply == QMessageBox. No:
    #             return
    #     if not model.handles:
    #         self.raise_error(Exception('Select some Handles'))
    #     self.ok_signal.emit(model.handles)

    def add_selected_handles(self):
        valid_handles = self.controller.face_network.add_selected_driven_handles()
        if valid_handles:
            shortened_handle_names = [valid_handles[i].name for i in range(len(valid_handles)) if i < 11]
            if len(valid_handles) > 10:
                shortened_handle_names.append('etc...')
            self.raise_warning('Added Handles: \n\n%s' % '\n'.join(shortened_handle_names))
        else:
            self.raise_warning('No valid handles selected.')

        self.reset()

    def reset(self, *args):
        model = self.handle_view.model()
        model.modelAboutToBeReset.emit()
        model.modelReset.emit()
        model.handles = [x.name for x in self.controller.face_network.driven_handles]
        model.modelReset.emit()

    def raise_message(self, message):
            print message
            message_box = QMessageBox(self)
            message_box.setWindowTitle('Message')
            message_box.setText(message)
            message_box.exec_()


    def raise_warning(self, message):
            print message
            message_box = QMessageBox(self)
            message_box.setWindowTitle('Warning')
            message_box.setText(message)
            message_box.exec_()


    def raise_error(self, exception):
        QMessageBox.critical(
            self,
            'Critical Error',
            exception.message
        )
        self.setEnabled(True)
        raise exception

class HandleView(QListView):
    def __init__(self, *args, **kwargs):
        super(HandleView, self).__init__(*args, **kwargs)
        self.setModel(HandleModel())
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setStyleSheet('border: 2px; background-color: rgb(80 ,80 ,80); padding: 0px 0px 0px 0px;')
        self.controller = None

    def set_controller(self, controller):
        self.model().set_controller(controller)
        self.controller = controller

    def keyPressEvent(self, event):

        model = self.model()
        if model:
            key_object = event.key()
            if key_object == Qt.Key_Delete:
                model.delete_items([i for i in self.selectedIndexes() if i.column() == 0])
        super(HandleView, self).keyPressEvent(event)

def test():
    import sys
    import os
    from rig_factory.controllers.face_controller import FaceController
    import sdk_builder
    style_sheet_path = '%s/qss/slate.qss' % os.path.dirname(sdk_builder.__file__.replace('\\', '/'))
    with open(style_sheet_path, mode='r') as f:
        style_sheet = f.read()
    app = QApplication(sys.argv)
    app.setStyleSheet(style_sheet)
    controller = FaceController.get_controller(standalone=True)
    controller.load_from_json_file()
    sdk_widget = DrivenHandleWidget()
    sdk_widget.set_controller(controller)
    sdk_widget.show()
    sdk_widget.raise_()
    sys.exit(app.exec_())

if __name__ == '__main__':
    test()
