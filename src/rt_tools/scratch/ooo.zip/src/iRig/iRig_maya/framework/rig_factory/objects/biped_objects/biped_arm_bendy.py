from rig_factory.objects.base_objects.properties import ObjectListProperty, DataProperty, ObjectProperty
from rig_factory.objects.biped_objects.biped_arm import BipedArmGuide, BipedArm
from rig_factory.objects.rig_objects.limb_segment import LimbSegment
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint

from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_factory.objects.part_objects.part import Part
import rig_factory.environment as env
from rig_math.vector import Vector
from rig_math.matrix import Matrix


class BipedArmBendyGuide(BipedArmGuide):

    default_settings = {
        'root_name': 'Arm',
        'size': 4.0,
        'side': 'left',
        'squash': 1,
        'create_bendy_hand': False
    }

    squash = DataProperty(
        name='squash'
    )
    segment_names = DataProperty(
        name='segment_names',
        default_value=['Clavicle', 'Shoulder', 'Elbow', 'Hand', 'HandEnd']
    )
    create_bendy_hand = DataProperty(
        name='create_bendy_hand'
    )

    def __init__(self, **kwargs):
        super(BipedArmBendyGuide, self).__init__(**kwargs)
        self.toggle_class = BipedArmBendy.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(BipedArmBendyGuide, cls).create(controller, **kwargs)
        this.create_plug(
            'squash',
            defaultValue=this.squash,
            keyable=True,
        )

        return this

    def get_blueprint(self):

        blueprint = super(BipedArmBendyGuide, self).get_blueprint()

        blueprint['squash'] = self.plugs['squash'].get_value()

        return blueprint

    def get_toggle_blueprint(self):

        blueprint = super(BipedArmBendyGuide, self).get_toggle_blueprint()

        blueprint['squash'] = self.plugs['squash'].get_value()

        return blueprint


class BipedArmBendy(Part):

    spline_joints = ObjectListProperty(
        name='spline_joints'
    )

    squash = DataProperty(
        name='squash',
        default_value=1,
    )

    settings_handle = ObjectProperty(
        name='settings_handle'
    )

    clavicle_handle = ObjectProperty(
        name='clavicle_handle'
    )
    base_joints = ObjectListProperty(
        name='base_joints'
    )
    wrist_handle = ObjectProperty(
        name='wrist_handle'
    )
    wrist_handle_gimbal = ObjectProperty(
        name='wrist_handle_gimbal'
    )
    elbow_handle = ObjectProperty(
        name='elbow_handle'
    )
    ik_group = ObjectProperty(
        name='ik_group'
    )
    ik_joints = ObjectListProperty(
        name='ik_joints'
    )
    isolate_ik_joints = ObjectListProperty(
        name='isolate_ik_joints'
    )
    fk_joints = ObjectListProperty(
        name='fk_joints'
    )
    ik_handles = ObjectListProperty(
        name='ik_handles'
    )
    fk_handles = ObjectListProperty(
        name='fk_handles'
    )
    stretchable_plugs = ObjectListProperty(
        name='stretchable_plugs'
    )
    elbow_line = ObjectProperty(
        name='elbow_line'
    )
    isolate_group = ObjectProperty(
        name='isolate_group'
    )
    segment_names = DataProperty(
        name='segment_names',
        default_value=['Clavicle', 'Shoulder', 'Elbow', 'Hand', 'HandEnd']
    )
    limb_segments = ObjectListProperty(
        name='limb_segments'
    )
    create_bendy_hand = DataProperty(
        name='create_bendy_hand'
    )

    def __init__(self, **kwargs):
        super(BipedArmBendy, self).__init__(**kwargs)

    @classmethod
    def create(cls, *args, **kwargs):
        this = super(BipedArmBendy, cls).create(*args, **kwargs)
        BipedArm.build_rig(this)
        return this

    def create_deformation_rig(self, **kwargs):
        super(BipedArmBendy, self).create_deformation_rig(**kwargs)

        side = self.side
        size = self.size
        controller = self.controller
        deform_joints = self.deform_joints
        joints = self.joints
        spline_joints = []
        matrices = [x.get_matrix() for x in deform_joints]
        root = self.get_root()
        curve_degree = 2
        segment_joint_count = 6
        settings_handle = self.settings_handle
        squash = self.squash
        self.secondary_handles = []

        for deform_joint in deform_joints[1:-1]:
            deform_joint.plugs.set_values(
                radius=0
            )

        bendy_elbow_handle = self.create_handle(
            handle_type=GroupedHandle,
            segment_name='%s%s' % (
                self.segment_names[1].title(),
                self.segment_names[2].title()
            ),
            functionality_name='Bendy',
            shape='ball',
            matrix=matrices[2],
            parent=joints[2],
            size=size*0.75
        )

        root.add_plugs(
            bendy_elbow_handle.plugs['tx'],
            bendy_elbow_handle.plugs['ty'],
            bendy_elbow_handle.plugs['tz'],
            bendy_elbow_handle.plugs['rx'],
            bendy_elbow_handle.plugs['ry'],
            bendy_elbow_handle.plugs['rz'],
            bendy_elbow_handle.plugs['sx'],
            bendy_elbow_handle.plugs['sy'],
            bendy_elbow_handle.plugs['sz'],
        )

        bendy_elbow_handle.plugs.set_values(
            overrideEnabled=True,
            overrideRGBColors=True,
            overrideColorRGB=env.secondary_colors[side]
        )

        shoulder_orient_group_1 = deform_joints[0].create_child(
            Transform,
            segment_name='ShoulderOrientBase',
            matrix=matrices[1]
        )
        shoulder_orient_group_2 = deform_joints[1].create_child(
            Transform,
            segment_name='ShoulderOrientTip',
            matrix=matrices[1],
        )
        shoulder_orient_group = deform_joints[0].create_child(
            Transform,
            segment_name='ShoulderOrient',
            matrix=matrices[1],
        )
        elbow_orient_group = deform_joints[1].create_child(
            Transform,
            segment_name='ElbowOrient',
            matrix=matrices[2],

        )
        wrist_orient_group = deform_joints[3].create_child(
            Transform,
            segment_name='WristOrient',
            matrix=matrices[3],
        )
        shoulder_up_group = shoulder_orient_group.create_child(
            Transform,
            segment_name='ShoulderUp',
        )

        up_group_distance = [x * size * -5.0 for x in env.side_cross_vectors[side]]
        shoulder_up_group.plugs['translate'].set_value(up_group_distance)
        elbow_up_group = elbow_orient_group.create_child(
            Transform,
            segment_name='ElbowUp',
        )
        elbow_up_group.plugs['translate'].set_value(up_group_distance)
        wrist_up_group = wrist_orient_group.create_child(
            Transform,
            segment_name='WristUp',
        )
        wrist_up_group.plugs['translate'].set_value(up_group_distance)

        hand_up_group = deform_joints[4].create_child(
            Transform,
            segment_name='HandUp',
        )
        hand_up_group.plugs['translate'].set_value(up_group_distance)

        constraint = controller.create_orient_constraint(
            shoulder_orient_group_1,
            shoulder_orient_group_2,
            shoulder_orient_group,
            skip='y',
        )
        constraint.plugs['interpType'].set_value(2)

        constraint = controller.create_orient_constraint(
            deform_joints[2],
            deform_joints[3],
            wrist_orient_group,
            skip='y'
        )
        constraint.plugs['interpType'].set_value(2)

        controller.create_point_constraint(
            deform_joints[1],
            shoulder_orient_group
        )
        controller.create_point_constraint(
            deform_joints[2],
            elbow_orient_group
        )
        controller.create_point_constraint(
            deform_joints[3],
            wrist_orient_group
        )

        # elbow flip fix in extreme twists
        # creating additional single chain setup to calculate upvector for elbow bendy segments aim constraints
        joint_parent = deform_joints[0]
        clavholderjoint = deform_joints[0].create_child(
            Joint,
            segment_name="{}clavholdtwistfix".format(self.segment_names[0]),
            parent=joint_parent,
            matrix=matrices[0],
        )
        clavholderjoint.zero_rotation()
        root.add_plugs(
            clavholderjoint.plugs['rx'],
            clavholderjoint.plugs['ry'],
            clavholderjoint.plugs['rz']
        )

        shouldtwistnegate_pv_group = deform_joints[1].create_child(
            Transform,
            segment_name='ShouldtwistnegatePV',
            matrix=matrices[1]
           )
        shouldtwistnegate_pv_group.plugs['translate'].set_value(up_group_distance)
        shouldertwistnegatelist = []
        shouldiksinglechain = self.segment_names[1:3]

        joint_parent = clavholderjoint
        i = 1
        for segment_name in shouldiksinglechain:
            joint = clavholderjoint.create_child(
                Joint,
                segment_name="{}shouldiktwistfix".format(segment_name),
                parent=joint_parent,
                matrix=matrices[i],
            )
            joint.zero_rotation()
            root.add_plugs(
                joint.plugs['rx'],
                joint.plugs['ry'],
                joint.plugs['rz']
            )
            shouldertwistnegatelist.append(joint)
            joint_parent = joint
            i = i + 1

        shouldtwistnegate_ik_solver = controller.create_ik_handle(
            shouldertwistnegatelist[0],
            shouldertwistnegatelist[1],
            parent=clavholderjoint,
            solver='ikRPSolver'
        )
        controller.create_point_constraint(deform_joints[1], shouldertwistnegatelist[0])
        controller.create_point_constraint(deform_joints[2], shouldtwistnegate_ik_solver)
        controller.create_pole_vector_constraint(shouldtwistnegate_pv_group,shouldtwistnegate_ik_solver)
        elbowtwistnegate_pv_group = deform_joints[2].create_child(
            Transform,
            segment_name='ElbowtwistwistnegatePV',
            matrix=matrices[1]
        )
        elbowtwistnegate_pv_group.plugs['translate'].set_value(up_group_distance)
        elbowtwistnegatelist = []
        elbowiksinglechain = self.segment_names[2:4]

        joint_parent = clavholderjoint
        i = 1
        for segment_name in elbowiksinglechain:
            joint = clavholderjoint.create_child(
                Joint,
                segment_name="{}elbowiktwistfix".format(segment_name),
                parent=joint_parent,
                matrix=matrices[i],
            )
            joint.zero_rotation()
            root.add_plugs(
                joint.plugs['rx'],
                joint.plugs['ry'],
                joint.plugs['rz']
            )
            elbowtwistnegatelist.append(joint)
            joint_parent = joint
            i = i + 1

        elbowtwistnegate_ik_solver = controller.create_ik_handle(
            elbowtwistnegatelist[0],
            elbowtwistnegatelist[1],
            parent=clavholderjoint,
            solver='ikRPSolver'
        )
        controller.create_point_constraint(deform_joints[2], elbowtwistnegatelist[0])
        controller.create_point_constraint(deform_joints[3], elbowtwistnegate_ik_solver)
        controller.create_pole_vector_constraint(elbowtwistnegate_pv_group, elbowtwistnegate_ik_solver)

        elbow_orientfix_group = deform_joints[1].create_child(
            Transform,
            segment_name='ElbowOrientFix',
            matrix=matrices[2],

        )

        elboworifix_up_group = elbow_orientfix_group.create_child(
            Transform,
            segment_name='ElbowUpOrientFix',
        )
        elboworifix_up_group.plugs['translate'].set_value(up_group_distance)

        constraint = controller.create_orient_constraint(
            shouldertwistnegatelist[0],
            elbowtwistnegatelist[0],
            elbow_orient_group
        )
        # as the control needs less twist from elbow than shoulder
        constVal=0.7
        constraint.plugs[shouldertwistnegatelist[0].name + 'W0'].set_value(constVal)
        constraint.plugs[elbowtwistnegatelist[0].name + 'W1'].set_value(1.0 - constVal)
        constraint.plugs['interpType'].set_value(2)

        constraint = controller.create_orient_constraint(
            shouldertwistnegatelist[0],
            elbowtwistnegatelist[0],
            elbow_orientfix_group
        )
        constraint.plugs['interpType'].set_value(2)

        controller.create_point_constraint(
            deform_joints[2],
            elbow_orientfix_group
        )

        clavholderjoint.plugs['visibility'].set_value(False)
        elbowtwistnegate_ik_solver.plugs['visibility'].set_value(False)
        shouldtwistnegate_ik_solver.plugs['visibility'].set_value(False)

        settings_handle.create_plug(
            'squash',
            attributeType='float',
            keyable=True,
            defaultValue=squash,
            dv=1.0
        )
        settings_handle.create_plug(
            'squashMin',
            attributeType='float',
            keyable=True,
            defaultValue=-0.5,
        )
        settings_handle.create_plug(
            'squashMax',
            attributeType='float',
            keyable=True,
            defaultValue=0.5,
        )
        root.add_plugs(settings_handle.plugs['squash'])
        root.add_plugs(
            settings_handle.plugs['squashMin'],
            settings_handle.plugs['squashMax'],
            keyable=False
        )

        bendy_joints = []

        #  Up Arm Bendy's

        up_arm_segment = self.create_child(
            LimbSegment,
            owner=self,
            segment_name=self.segment_names[1],
            matrices=[matrices[1], matrices[2]],
            joint_count=segment_joint_count,
            functionality_name='Bendy'
        )
        up_arm_segment.joints[0].set_parent(deform_joints[1])
        deform_joints[1].plugs['scale'].connect_to(
            up_arm_segment.joints[0].plugs['inverseScale'],
        )

        for segment in up_arm_segment.handles:
            segment.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.secondary_colors[side]
            )
            self.secondary_handles.append(segment)

        self.controller.create_aim_constraint(
            up_arm_segment.handles[1],
            up_arm_segment.handles[0].groups[0],
            aimVector=env.side_aim_vectors[side],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=shoulder_up_group
        )
        self.controller.create_aim_constraint(
            up_arm_segment.handles[1],
            up_arm_segment.handles[2].groups[0],
            aimVector=[x * -1.0 for x in env.side_aim_vectors[side]],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=elbow_up_group
        )

        self.controller.create_point_constraint(
            deform_joints[1],
            bendy_elbow_handle,
            up_arm_segment.handles[1].groups[0],
            mo=False
        )

        self.controller.create_point_constraint(
            deform_joints[1],
            up_arm_segment.handles[0].groups[0],
            mo=False
        )

        self.controller.create_point_constraint(
            bendy_elbow_handle,
            up_arm_segment.handles[2].groups[0],
            mo=False
        )
        self.controller.create_aim_constraint(
            bendy_elbow_handle,
            up_arm_segment.handles[1].groups[0],
            aimVector=[x * -1.0 for x in env.side_aim_vectors[side]],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=shoulder_up_group
        )

        bendy_joints.extend(up_arm_segment.joints)

        #  Elbow Bendy's

        elbow_segment = self.create_child(
            LimbSegment,
            owner=self,
            segment_name=self.segment_names[2],
            functionality_name='Bendy',
            matrices=[matrices[2], matrices[3]],
            joint_count=segment_joint_count
        )
        elbow_segment.joints[0].set_parent(deform_joints[2])
        deform_joints[2].plugs['scale'].connect_to(
            elbow_segment.joints[0].plugs['inverseScale'],
        )

        for segment in elbow_segment.handles:
            segment.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.secondary_colors[side]
            )
            self.secondary_handles.append(segment)

        self.controller.create_aim_constraint(
            elbow_segment.handles[1],
            elbow_segment.handles[0].groups[0],
            aimVector=env.side_aim_vectors[side],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=elboworifix_up_group
        )
        self.controller.create_aim_constraint(
            elbow_segment.handles[1],
            elbow_segment.handles[2].groups[0],
            aimVector=[x * -1.0 for x in env.side_aim_vectors[side]],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=wrist_up_group
        )

        self.controller.create_point_constraint(
            bendy_elbow_handle,
            deform_joints[3],
            elbow_segment.handles[1].groups[0],
            mo=False
        )

        self.controller.create_point_constraint(
            bendy_elbow_handle,
            elbow_segment.handles[0].groups[0],
            mo=False
        )

        self.controller.create_point_constraint(
            deform_joints[3],
            elbow_segment.handles[2].groups[0],
            mo=False
        )
        self.controller.create_aim_constraint(
            deform_joints[3],
            elbow_segment.handles[1].groups[0],
            aimVector=[x * -1.0 for x in env.side_aim_vectors[side]],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=elboworifix_up_group
        )

        bendy_joints.extend(elbow_segment.joints)

        up_arm_segment.setup_scale_joints()
        elbow_segment.setup_scale_joints()

        limb_segments = [up_arm_segment, elbow_segment]

        #  Hand Bendy

        if self.create_bendy_hand:

            hand_segment = self.create_child(
                LimbSegment,
                owner=self,
                segment_name=self.segment_names[3],
                functionality_name='Bendy',
                matrices=[matrices[3], matrices[4]],
                joint_count=segment_joint_count
            )
            hand_segment.joints[0].set_parent(deform_joints[3])
            deform_joints[3].plugs['scale'].connect_to(
                hand_segment.joints[0].plugs['inverseScale'],
            )

            for secondary_handle in hand_segment.handles:
                secondary_handle.plugs.set_values(
                    overrideEnabled=True,
                    overrideRGBColors=True,
                    overrideColorRGB=env.secondary_colors[side]
                )
                self.secondary_handles.append(secondary_handle)

            self.controller.create_aim_constraint(
                hand_segment.handles[1],
                hand_segment.handles[0].groups[0],
                aimVector=env.side_aim_vectors[side],
                upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
                worldUpType='object',
                worldUpObject=wrist_up_group
            )
            self.controller.create_aim_constraint(
                hand_segment.handles[1],
                hand_segment.handles[2].groups[0],
                aimVector=[x * -1.0 for x in env.side_aim_vectors[side]],
                upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
                worldUpType='object',
                worldUpObject=hand_up_group
            )

            self.controller.create_point_constraint(
                deform_joints[3],
                deform_joints[4],
                hand_segment.handles[1].groups[0],
                mo=False
            )

            self.controller.create_point_constraint(
                deform_joints[3],
                hand_segment.handles[0].groups[0],
                mo=False
            )

            self.controller.create_point_constraint(
                deform_joints[4],
                hand_segment.handles[2].groups[0],
                mo=False
            )
            self.controller.create_aim_constraint(
                deform_joints[4],
                hand_segment.handles[1].groups[0],
                aimVector=[x * -1.0 for x in env.side_aim_vectors[side]],
                upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
                worldUpType='object',
                worldUpObject=wrist_up_group
            )
            bendy_joints.extend(hand_segment.joints)
            hand_segment.setup_scale_joints()
            settings_handle.plugs['squash'].connect_to(hand_segment.plugs['AutoVolume'])
            settings_handle.plugs['squashMin'].connect_to(hand_segment.plugs['MinAutoVolume'])
            settings_handle.plugs['squashMax'].connect_to(hand_segment.plugs['MaxAutoVolume'])
            deform_joints[4].plugs['sx'].connect_to(hand_segment.handles[0].plugs['EndScaleX'])
            deform_joints[4].plugs['sz'].connect_to(hand_segment.handles[0].plugs['EndScaleZ'])
            limb_segments.append(hand_segment)

        settings_handle.plugs['squash'].connect_to(up_arm_segment.plugs['AutoVolume'])
        settings_handle.plugs['squashMin'].connect_to(up_arm_segment.plugs['MinAutoVolume'])
        settings_handle.plugs['squashMax'].connect_to(up_arm_segment.plugs['MaxAutoVolume'])

        settings_handle.plugs['squash'].connect_to(elbow_segment.plugs['AutoVolume'])
        settings_handle.plugs['squashMin'].connect_to(elbow_segment.plugs['MinAutoVolume'])
        settings_handle.plugs['squashMax'].connect_to(elbow_segment.plugs['MaxAutoVolume'])

        bendy_elbow_handle.plugs['sx'].connect_to(up_arm_segment.handles[-1].plugs['EndScaleX'])
        bendy_elbow_handle.plugs['sz'].connect_to(up_arm_segment.handles[-1].plugs['EndScaleZ'])
        bendy_elbow_handle.plugs['sx'].connect_to(elbow_segment.handles[0].plugs['EndScaleX'])
        bendy_elbow_handle.plugs['sz'].connect_to(elbow_segment.handles[0].plugs['EndScaleZ'])

        self.spline_joints = bendy_joints
        self.deform_joints.extend(bendy_joints)
        self.limb_segments = limb_segments
        self.secondary_handles.append(bendy_elbow_handle)

    def toggle_ik(self):
        value = self.settings_handle.plugs['ikSwitch'].get_value()
        if value > 0.5:
            self.match_to_fk()
        else:
            self.match_to_ik()

    def match_to_fk(self):
        self.settings_handle.plugs['ikSwitch'].set_value(0.0)
        positions = [x.get_matrix() for x in self.ik_joints]
        for i in range(len(positions[0:3])):
            self.fk_handles[i].set_matrix(Matrix(positions[i]))

    def match_to_ik(self):
        self.settings_handle.plugs['ikSwitch'].set_value(1.0)
        positions = [x.get_matrix() for x in self.fk_joints]
        self.wrist_handle.set_matrix(positions[2])
        vector_multiplier = self.size * 10
        if self.side == 'left':
            vector_multiplier = vector_multiplier * -1
        z_vector_1 = Vector(positions[0].data[2][0:3]).normalize()
        z_vector_2 = Vector(positions[1].data[2][0:3]).normalize()
        z_vector = (z_vector_1 + z_vector_2) * 0.5
        pole_position = positions[1].get_translation() + (z_vector * vector_multiplier)
        self.elbow_handle.set_matrix(Matrix(pole_position))
