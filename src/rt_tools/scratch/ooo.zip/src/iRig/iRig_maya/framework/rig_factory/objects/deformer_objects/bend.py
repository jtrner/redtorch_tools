from nonlinear import NonLinear


class Bend(NonLinear):

    deformer_type = 'bend'
    handle_type = 'deformBend'

    def __init__(self, **kwargs):
        super(Bend, self).__init__(**kwargs)
