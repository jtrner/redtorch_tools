from rig_factory.objects.node_objects.dag_node import DagNode
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.base_objects.properties import ObjectProperty, DataProperty, ObjectListProperty
from rig_factory.objects.node_objects.object_set import ObjectSet
from rig_factory.objects.deformer_objects.deformer import Deformer


class NonLinear(Transform):

    deformer = ObjectProperty(
        name='deformer'
    )
    deformer_set = ObjectProperty(
        name='deformer_set'
    )
    handle_shape = ObjectProperty(
        name='handle_shape'
    )
    handle_type = DataProperty(
        name='handle_type'
    )
    geometry = ObjectListProperty(
        name='geometry'
    )

    suffix = 'Nlr'

    deformer_type = None

    @classmethod
    def create(cls, controller, **kwargs):
        f = controller.scene.create_nonlinear_deformer
        geometry = kwargs.pop('geometry', [])
        deformer_m_object, handle_m_object, handle_shape_m_object, deformer_set_m_object = f(
            cls.deformer_type,
            [x.get_selection_string() for x in geometry]
        )

        kwargs['m_object'] = handle_m_object
        this = super(NonLinear, cls).create(controller, **kwargs)

        this.deformer = this.create_child(
            Deformer,
            m_object=deformer_m_object
        )

        this.handle_shape = this.create_child(
            DagNode,
            m_object=handle_shape_m_object,
            suffix='Dhd'
        )

        this.deformer_set = this.create_child(
            ObjectSet,
            m_object=deformer_set_m_object,
            suffix='Ost'
        )

        this.add_geometry(this.geometry)

        return this

    def __init__(self, **kwargs):
        super(NonLinear, self).__init__(**kwargs)

    def get_weights(self):
        return self.deformer.get_weights()

    def set_weights(self, weights):
        return self.deformer.set_weights(weights)


    def add_geometry(self, geometry):
        member_names = {x.name for x in self.deformer_set.members}
        new_geometry = [x for x in geometry if x.name not in member_names]
        self.deformer_set.members.extend(new_geometry)
        self.controller.add_deformer_geometry(self, new_geometry)

    def remove_geometry(self, geometries):
        geometry_names = {x.name for x in geometries}
        valid_members = [
            member for member in self.deformer_set.members
            if member.name not in geometry_names
        ]
        if not valid_members:
            raise RuntimeError(
                'Nonlinear deformers must contain at least one geometry'
            )
        self.deformer_set.members = valid_members
        self.controller.remove_deformer_geometry(self, geometries)

    def teardown(self):
        self.controller.schedule_objects_for_deletion(
            self.deformer_set,
            self.handle,
            self.handle_shape
        )
        super(NonLinear, self).teardown()
