__version__ = '0.0.0'
import PySignal
from rig_factory.objects.sdk_objects.sdk_network import SDKNetwork
from rig_factory.objects.sdk_objects.sdk_group import SDKGroup
from rig_factory.objects.sdk_objects.keyframe_group import KeyframeGroup
from rig_factory.objects.node_objects.animation_curve import AnimationCurve, KeyFrame
from rig_factory.controllers.node_controller import NodeController
import rig_factory.utilities.sdk_utilities.sdk_blueprint_utilities as btl


class SDKController(NodeController):

    sdk_network_changed_signal = PySignal.ClassSignal()
    start_sdk_ownership_signal = PySignal.ClassSignal()
    end_sdk_ownership_signal = PySignal.ClassSignal()
    start_sdk_disown_signal = PySignal.ClassSignal()
    end_sdk_disown_signal = PySignal.ClassSignal()

    def __init__(self):
        super(SDKController, self).__init__()

    def reset(self, *args):
        super(SDKController, self).reset()

    def view_blueprint(self):
        btl.view_blueprint(self)

    def get_blueprint(self, rig):
        return btl.get_blueprint(rig)

    def build_blueprint(self, blueprint, **kwargs):
        return btl.build_blueprint(self, blueprint, **kwargs)

    def prune_curves(self, item, threshold=0.0001):
        if isinstance(item, SDKNetwork):
            for sdk_group in item.sdk_groups:
                self.prune_curves(sdk_group)
        if isinstance(item, SDKGroup):
            for driver_plug_name in item.animation_curves:
                self.prune_curves(item.animation_curves[driver_plug_name])
        elif isinstance(item, AnimationCurve):
            for animation_curve in item.keyframes:
                for i, key in enumerate(animation_curve.keys):
                    if i > 0:
                        movement_value = key.out_value - animation_curve.keys[i-1].out_value
                        if movement_value < threshold or movement_value < threshold*-1:
                            animation_curve.keys[i-1].delete()
                    else:
                        pass
        else:
            raise Exception('Cannot prune_curves on a : %s' % type(item))

    def create_sdk_network(self, **kwargs):
        this = self.create_object(
            SDKNetwork,
            **kwargs
        )
        return this
    #
    # def get_selected_driven_plugs(self):
    #     plugs = []
    #     for node in self.get_selected_nodes():
    #         for attr in self.scene.get_selected_attribute_names():
    #             plugs.append(self.get_driven_plug(node, attr))
    #     return plugs
    #
    # def get_driven_plug(self, node, plug_name):
    #     driven_plug = DrivenPlug(
    #         controller=self,
    #         parent=node,
    #         name=plug_name
    #     )
    #     #self.register_item(driven_plug)
    #     self.scene.initialize_plug(driven_plug)
    #     return driven_plug

    @staticmethod
    def set_active(item, value):
        raise Exception('Cannot "set_active" on a : %s' % type(item))

    def deserialize(self, *args, **kwargs):
        items = super(SDKController, self).deserialize(*args, **kwargs)
        return items

    def change_keyframe(self, item, **kwargs):
        if isinstance(item, KeyFrame):
            if 'in_value' in kwargs:
                item.in_value = kwargs['in_value']
            self.scene.change_keyframe(
                item.animation_curve.m_object,
                item.in_value,
                **kwargs
            )
            for key in kwargs:
                setattr(item, key, kwargs[key])

        elif isinstance(item, KeyframeGroup):
            for keyframe in item.keyframes:
                self.change_keyframe(
                    keyframe,
                    **kwargs
                )
        else:
            raise Exception('Unsupported type "%s"' % type(item))

def flatten_items(*args):
    items = []
    for arg in args:
        if isinstance(arg, (list, tuple, set)):
            items.extend(flatten_items(*arg))
        else:
            items.append(arg)
    return items