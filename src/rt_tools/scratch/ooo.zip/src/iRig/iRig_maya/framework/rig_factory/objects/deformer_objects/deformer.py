from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.base_objects.properties import ObjectProperty, ObjectListProperty
from rig_factory.utilities.decorators import flatten_args


class Deformer(DependNode):

    deformer_set = ObjectProperty(
        name='deformer_set'
    )
    geometry = ObjectListProperty(
        name='geometry'
    )

    weight_map_groups = ObjectListProperty(
        name='weight_map_groups'
    )
    weight_maps = ObjectListProperty(
        name='weight_maps'
    )

    suffix = 'Def'

    def __init__(self, **kwargs):
        super(Deformer, self).__init__(**kwargs)

    @flatten_args
    def add_geometry(self, *geometry):
        clashing_members = [g.name for g in geometry if g in self.deformer_set.members]
        if clashing_members:
            raise Exception('Specified geometry "%s" were already members of : %s ' % (clashing_members, self.name))

        self.controller.scene.add_deformer_geometry(
            self.name,
            [x.name for x in geometry]
        )
        self.deformer_set.members.extend(geometry)

    @flatten_args
    def remove_geometry(self, *geometry):
        missing_members = [g.name for g in geometry if g not in self.deformer_set.members]
        if missing_members:
            raise Exception('Specified geometry "%s" were not members of : %s ' % (missing_members, self.name))
        for geo in geometry:
            self.deformer_set.members.remove(geo)
        self.controller.scene.remove_deformer_geometry(
            self.name,
            [x.name for x in geometry]
        )

    def get_weights(self):
        return self.controller.scene.get_deformer_weights(self.m_object)

    def set_weights(self, weights):
        self.controller.scene.set_deformer_weights(self.m_object, weights)

#
#     def initialize_weight_map(self, plug, **kwargs):
#         kwargs['parent'] = self
#         self.weight_maps.append(
#             WeightMap(
#                 plug=plug,
#                 **kwargs
#             )
#         )
#
#     def initialize_weight_map_group(self, **kwargs):
#         kwargs['parent'] = self
#         self.weight_map_groups.append(
#             WeightMapGroup(
#                 **kwargs
#             )
#         )
#
#
# class WeightMap(BaseObject):
#
#     plug = ObjectProperty(
#         name='plug'
#     )
#
#     def __init__(self, **kwargs):
#         super(WeightMap, self).__init__(**kwargs)
#
#
# class WeightMapGroup(BaseObject):
#
#     weight_maps = ObjectListProperty(
#         name='weight_maps'
#     )
#
#     def __init__(self, **kwargs):
#         super(WeightMapGroup, self).__init__(**kwargs)
#
#     def initialize_weight_map(self, plug, **kwargs):
#         kwargs['parent'] = self
#         self.weight_maps.append(
#             WeightMap(
#                 plug=plug,
#                 **kwargs
#             )
#         )
