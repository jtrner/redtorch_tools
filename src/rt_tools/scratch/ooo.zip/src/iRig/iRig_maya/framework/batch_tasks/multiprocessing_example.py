"""
This is the simplest possible multiprocessing example using mayapy standalone
"""

import multiprocessing
import maya.standalone as standalone
import maya.cmds as mc

standalone.initialize(name='python')


def build_sphere(name):
    sphere = mc.polySphere(name=name)
    mc.file(rn='G:/Rigging/Users/paxtong/batch_junk/%s.mb' % name)
    mc.file(save=True, f=True)
    return sphere


if __name__ == "__main__":
    entities = [
        'Robot_Hopper',
        'Robot_Shelly',
        'Robot_Boomer',
        'Robot_Gimme_pig',
        'Robot_Allie',
        'Robot_Winger'
    ]
    p = multiprocessing.Pool(len(entities))
    result = p.map_async(build_sphere, entities)
    print result.get()
