import traceback
from rig_factory.objects.face_objects.face import Face
from rig_factory.objects.face_objects.face_handle import FaceHandle
from rig_factory.objects.rig_objects.curve_handle import CurveHandle
from rig_factory.objects.part_objects.base_part import BasePart
from rig_factory.objects.part_objects.base_container import BaseContainer
import rig_factory.utilities.decorators as dec
from rig_factory.objects.node_objects.plug import Plug
from rig_factory.objects.node_objects.transform import Transform

shard_group_index = -3


def get_shard_driven_groups(controller):
    if controller.root:
        face_container = controller.root.find_first_part(Face)
        if face_container:
            shard_handles = get_shard_handles(face_container)
            return [x.groups[shard_group_index] for x in shard_handles]


def get_shard_driven_plugs(controller):
    shard_driven_plugs = list()
    if controller.root:
        face_container = controller.root.find_first_part(Face)
        if face_container:
            shard_handles = get_shard_handles(face_container)
            if shard_handles:
                for x in [x.groups[shard_group_index] for x in shard_handles]:
                    shard_driven_plugs.extend([x.plugs[attr] for attr in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz']])
    return shard_driven_plugs


def float_range(minimum, maximum, count):
    total = maximum - minimum
    return [round(minimum + (x * (float(total)/(count-1))), 4) for x in range(count)]


def bake_corrective_data(driven_transforms, drivers, inbetweens=2, rounding=5, is_corrective=False):
    if len(drivers) < 1:
        raise Exception('you must provide at least one driver')
    if not driven_transforms:
        raise Exception('You must provide some driven transforms to bake plug data')
    for driven_transform in driven_transforms:
        if not isinstance(driven_transform, Transform):
            raise Exception('driven transforms must be type(Transform)')
    for d in drivers:
        if not isinstance(d[0], Plug):
            raise Exception('driver_plug must be type(Plug)')
        if not isinstance(d[1], float):
            raise Exception('minimum must be type(Float)')
        if not isinstance(d[2], float):
            raise Exception('maximum must be type(Float)')
    if not isinstance(inbetweens, int):
        raise Exception('inbetweens must be type(Int)')
    if inbetweens < 2:
        raise Exception('Minimum inbetweens is 2')
    default_driver_values = [round(x[0].get_value(), rounding) for x in drivers]
    plug_return_data = []
    for i in range(inbetweens):
        matrix_data = []
        return_drivers = []
        for d in drivers:
            value = round(float_range(d[1], d[2], inbetweens)[i], rounding)
            try:
                d[0].set_value(value)
            except Exception as e:
                traceback.print_exc()
            return_drivers.append((d[0], value))
        for driven_transform in driven_transforms:
            matrix_data.append((driven_transform, driven_transform.get_matrix()))
        plug_return_data.append((return_drivers, matrix_data))
    [drivers[i][0].set_value(default_driver_values[i]) for i in range(len(drivers))]
    return plug_return_data


def bake_plug_data(driven_plugs, drivers, inbetweens=2, rounding=5):
    if len(drivers) < 1:
        raise Exception('you must provide at least one driver')
    if not driven_plugs:
        raise Exception('You must provide some driven plugs to bake plug data')
    for driven_plug in driven_plugs:
        if not isinstance(driven_plug, Plug):
            raise Exception('driven_plugs must be type(Plug)')
    for d in drivers:
        if not isinstance(d[0], Plug):
            raise Exception('driver_plug must be type(Plug)')
        if not isinstance(d[1], float):
            raise Exception('minimum must be type(Float)')
        if not isinstance(d[2], float):
            raise Exception('maximum must be type(Float)')
    if not isinstance(inbetweens, int):
        raise Exception('inbetweens must be type(Int)')
    if inbetweens < 2:
        raise Exception('Minimum inbetweens is 2')
    default_driver_values = [round(x[0].get_value(), rounding) for x in drivers]
    default_driven_values = [x.get_value() for x in driven_plugs]
    plug_return_data = dict()
    for i in range(inbetweens):
        driven_plug_data = []
        for d in drivers:
            value = round(float_range(d[1], d[2], inbetweens)[i], rounding)
            try:
                d[0].set_value(value)
            except Exception as e:
                traceback.print_exc()

        driver_value = round(
            float_range(drivers[0][1], drivers[0][2], inbetweens)[i],
            rounding
        )
        for driven_plug in driven_plugs:
            current_value = driven_plug.get_value()
            relative_value = current_value - default_driven_values[i]
            if abs(round(relative_value, rounding)) != 0.0 or abs(driver_value) == 0.0:
                driven_plug_data.append((driven_plug, relative_value))
        plug_return_data[driver_value] = driven_plug_data
    [drivers[i][0].set_value(default_driver_values[i]) for i in range(len(drivers))]
    [x.get_value()for x in driven_plugs] #  Clean the DG
    return plug_return_data

def get_shard_skin_cluster_data(*args):
    data = []
    shards = get_shard_mesh_nodes(*args)
    for shard in shards:
        if shard:
            skin_cluster = shard.controller.find_skin_cluster(shard)
            if skin_cluster:
                try:
                    data.append(shard.controller.scene.get_skin_data(skin_cluster))
                except Exception as e:
                    print('Unable to get skin cluster from shard : %s' % shard)
    return data


@dec.flatten_args
def copy_selected_skin_to_shards(*parts_or_handles):
    """

    GET RID OF CMDS

    """
    import maya.cmds as mc
    import maya.mel as mel

    if parts_or_handles:
        controller = parts_or_handles[0].controller
        mesh_names = []
        for mesh_name in controller.get_selected_mesh_names():
            if not mc.getAttr('%s.intermediateObject' % mesh_name):
                mesh_names.append(mesh_name)

        skin_mesh = mesh_names[0]
        influences = mc.skinCluster(skin_mesh, q=True, influence=True)
        shards = get_shard_mesh_nodes(*parts_or_handles)
        if not shards:
            raise Exception('No Shards found')
        mc.select(shards)
        for shard in shards:
            skin_m_object = controller.scene.find_skin_cluster(shard.get_selection_string())
            if skin_m_object:
                skin = controller.scene.get_selection_string(skin_m_object)
                controller.scene.skinCluster(skin, e=True, ub=True)
            mc.skinCluster(influences, shard, tsb=True)
            mc.copySkinWeights(skin_mesh, shard, noMirror=True, surfaceAssociation='closestPoint',
                               influenceAssociation='oneToOne')
            floodSkin(shard, operation='smooth', doInternal=False, iters=1)
        mc.select(shards)
        mel.eval('removeUnusedInfluences;')
    else:
        raise Exception('You must provide some parts of handles')

@dec.flatten_args
def get_handles(*parts_or_handles):
    handles = []
    for item in parts_or_handles:
        if isinstance(item, CurveHandle):
            handles.append(item)
        if isinstance(item, (BasePart, BaseContainer)):
            handles.extend(item.get_handles())
    return list(set(handles))

@dec.flatten_args
def get_shard_mesh_nodes(*parts_or_handles):
    handles = get_handles(*parts_or_handles)
    shards = [x.shard_mesh for x in handles if isinstance(x, FaceHandle)]
    shards.extend([x.utility_nodes['shard_mesh'] for x in handles if 'shard_mesh' in x.utility_nodes])
    return shards

@dec.flatten_args
def get_shard_transforms(*parts_or_handles):
    handles = get_handles(*parts_or_handles)
    shard_transforms = [x.shard_transform for x in handles if isinstance(x, FaceHandle)]
    shard_transforms.extend([x.utility_nodes['shard_transform'] for x in handles if 'shard_transform' in x.utility_nodes])
    return shard_transforms

@dec.flatten_args
def get_shard_matrix_nodes(*parts_or_handles):
    handles = get_handles(*parts_or_handles)
    shard_matrix_nodes = [x.shard_matrix for x in handles if isinstance(x, FaceHandle)]
    shard_matrix_nodes.extend([x.utility_nodes['shard_matrix'] for x in handles if 'shard_matrix' in x.utility_nodes])
    return shard_matrix_nodes

@dec.flatten_args
def get_shard_handles(*parts_or_handles):
    handles = get_handles(*parts_or_handles)
    shard_handles = [x for x in handles if isinstance(x, FaceHandle)]
    shard_handles.extend([x for x in handles if 'shard_matrix' in x.utility_nodes])
    return shard_handles

def floodSkin (targetMesh, operation = 'smooth', doInternal = False, iters = 2):
    """

    GET RID OF CMDS

    """
    import maya.cmds as mc

    targetSkin = findSkinCluster (targetMesh)
    normalization = mc.skinCluster (targetSkin, query = True, normalizeWeights = True)
    skinContext = initWeightPaintTool (targetMesh, operation = operation, normalize = 2)

    if not skinContext:
        return

    # run a timer along with the smooth command
    mc.timer (s = True, name = operation)
    floodJointWeights (targetMesh, targetSkin, skinContext, doInternal, iters = iters)
    smoothTime = mc.timer (e = True, name = operation)

    skinContext = initWeightPaintTool (targetMesh, operation = operation, normalize = normalization)

    print '%s skin weights: %s seconds, %s influences\n' %(operation, smoothTime, len(findInfluences(targetMesh)))


def floodJointWeights (targetMesh, targetSkin, skinContext, doInternal = False, iters = 2):
    """

    GET RID OF CMDS

    """
    import maya.cmds as mc

    if targetSkin is None:
        targetSkin = findSkinCluster (targetMesh)
        if not targetSkin:
            return

    skinJnts = findInfluences (targetMesh)

    for jnt in skinJnts:
        if mc.getAttr ('%s.liw' %(jnt)) == 0:
            # selectVerts if only smoothing internally
            if doInternal:
                mc.skinCluster (targetSkin, edit = True, influence = jnt, selectInfluenceVerts = jnt)

            toggleSkinInf (targetSkin, jnt)
            for i in range(iters):
                mc.artAttrSkinPaintCtx (skinContext, edit = True, influence = jnt, clear = True)

            # deselectVerts if only smoothing internally
            if doInternal:
                mc.skinCluster (targetSkin, edit = True, removeFromSelection = True, selectInfluenceVerts = jnt)

    mc.skinCluster (targetSkin, edit = True, forceNormalizeWeights = True)

# connect an influence to the skinCluster for painting, disconnect if one already connected
def toggleSkinInf (targetSkin, jnt, doConnect = True):
    """

    GET RID OF CMDS

    """
    import maya.cmds as mc

    paintTransJnt = mc.listConnections ('%s.paintTrans' %(targetSkin), s = True, d = True)
    if paintTransJnt is not None:
        mc.disconnectAttr ('%s.message' %(paintTransJnt[0]), '%s.paintTrans' %(targetSkin))
    if doConnect:
        mc.connectAttr ('%s.message' %(jnt), '%s.paintTrans' %(targetSkin), f = True)



# return the all influences attached to a skinCluster
def findInfluences (targetMesh):
    """

    GET RID OF CMDS

    """
    import maya.cmds as mc

    targetSkin = findSkinCluster (targetMesh)
    if not targetSkin:
        return False

    # create a list of only joints
    skinJnts = []
    plugs = mc.listAttr ('%s.matrix' %(targetSkin), multi = True)
    for plug in plugs:
        skinJnt = mc.listConnections ('%s.%s' %(targetSkin, plug), s = True, d = True)[0]
        skinJnts.append(skinJnt)

    return skinJnts

def findSkinCluster (targetMesh):
    """

    GET RID OF CMDS

    """
    import maya.cmds as mc
    # find skinCluster for declared mesh
    targetSkin = []
    for connect in mc.listHistory (targetMesh):
        if mc.objectType (connect) == 'skinCluster':
            targetSkin = connect
            break

    if targetSkin == []:
        mc.warning ('%s has no skinCluster' %(targetMesh))
        return False

    return targetSkin



# initialize the weightPaint tool for the given mesh and operation
def initWeightPaintTool (targetMesh, operation = 'smooth', value = 1.0, normalize = 2):
    import maya.cmds as mc

    if not findSkinCluster(targetMesh):
        return False

    if operation == 'replace':
        operation = 'absolute'
    if operation == 'add':
        operation = 'additive'

    validOperations = ['absolute', 'additive', 'scale', 'smooth']
    if operation not in validOperations:
        print 'Valid operations: \'replace\', \'absolute\', \'add\', \'additive\', \'scale\', \'smooth\''
        mc.warning ('Invalid operation type.')
        return False

    # create or edit artisan context. Ensure it's in 'skinWeights' mode
    contexts = mc.lsUI (contexts = True)
    skinContexts = [ctx for ctx in contexts if 'artAttrSkin' in ctx]

    if skinContexts == []:
        skinContext = mc.artAttrSkinPaintCtx('artAttrSkinContext', whichTool = 'skinWeights')
    else:
        skinContext = mc.artAttrSkinPaintCtx(skinContexts[0], edit = True, whichTool = 'skinWeights')

    # select object and set normalization
    mc.select (targetMesh, r = True)
    mc.skinCluster (findSkinCluster (targetMesh), edit = True, normalizeWeights = normalize, forceNormalizeWeights = True)

    # open weightPaint tool
    mc.setToolTo(skinContext)
    mc.artAttrSkinPaintCtx (skinContext, edit = True, value = value, selectedattroper = operation)

    return skinContext