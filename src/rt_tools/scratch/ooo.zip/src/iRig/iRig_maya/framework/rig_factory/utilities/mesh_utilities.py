import os

from rig_factory.objects.part_objects.base_container import BaseContainer
from rig_factory.objects.part_objects.container import ContainerGuide
from rig_factory.objects.node_objects.mesh import Mesh
import rig_factory.utilities.list_utilities as lsu


def apply_bind_state_delta(container):
    controller = container.controller
    open_eye_path = '%s/bind_state_origin.abc' % controller.build_directory
    closed_eye_path = '%s/bind_state.abc' % controller.build_directory
    if os.path.exists(open_eye_path) and os.path.exists(closed_eye_path):
        controller.scene.update_mesh_deltas(
            container.geometry.keys(),
            open_eye_path,
            closed_eye_path
        )


def get_shape_descendants(controller, node):
    node.plugs['v'].set_value(True)
    mesh_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='mesh',
        f=True
    )
    nurbs_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='nurbsSurface',
        f=True
    )
    descendants = []
    if mesh_relatives:
        descendants = [controller.initialize_node(x, parent=node) for x in mesh_relatives]
    if nurbs_relatives:
        descendants = [controller.initialize_node(x, parent=node) for x in nurbs_relatives]
    transform_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='transform',
        f=True
    )
    if transform_relatives:
        transforms = [controller.initialize_node(x, parent=node) for x in transform_relatives]
        for transform in transforms:
            descendants.extend(controller.get_shape_descendants(transform))

    for descendant in descendants:
        descendant.plugs['v'].set_value(True)

    return descendants


def import_geometry(controller, rig, path, parent=None):
    """
    Imports geo from give path and add the path to
    controller.root.geometry_paths which gets saved in blueprint
    :param controller: framework's brain
    :param rig: rig top group, eg: "Container"
    :param path: path to geometry we want to import. Can be either absolute or relative.
                 If path starts with / it means it's a relative path to user's build direcotry.
                 absolute path example: 'D:/ZZZ/model/test_model.abc'
                 relative path example: '/my_test_model.ma'
    :param parent: imported geos will be parented under this group if given
    :return: imported geometries
    """
    if not isinstance(rig, BaseContainer):
        raise Exception('You cannot import geometry into a %s' % type(rig))

    if rig.parent is not None:
        print('%s has a parent. unable to import geometry' % rig)
        return

    if parent is None:
        parent = rig.geometry_group

    # path is relative or absolute
    if path.startswith('/'):
        absolute_path = '%s%s' % (controller.build_directory, path)
    else:
        absolute_path = path

    # add given path to current geometry_paths
    if os.path.exists(absolute_path):
        rig.geometry_paths.append(path)
    else:
        print('could not find %s' % path)
        return

    # remove possible duplicate geo paths
    rig.geometry_paths = lsu.remove_duplicates(rig.geometry_paths)

    # import geo
    root_nodes = controller.scene.import_geometry(absolute_path)

    if root_nodes:
        # add imported geo shapes to container.geometry dict
        new_geometry = dict()
        for geometry_root in [controller.initialize_node(x, parent=parent) for x in root_nodes]:
            shapes = get_shape_descendants(controller, geometry_root)
            new_geometry.update(dict((x.name, x) for x in shapes if isinstance(x, Mesh)))
            controller.scene.select(cl=True)
        rig.geometry.update(new_geometry)

        # assign shaders
        if isinstance(rig, ContainerGuide):
            for mesh in new_geometry.values():
                mesh.assign_shading_group(rig.shaders[None].shading_group)

        # smooth normals
        if new_geometry and rig.smooth_mesh_normals:
            controller.smooth_normals(new_geometry.values())

        # fit view to imported geo and clear selection
        controller.scene.fit_view(rig.geometry.keys())
        controller.scene.select(cl=True)

        return new_geometry
    else:
        print('Warning ! No geometry roots found in %s' % absolute_path)


def import_utility_geometry(rig, path):
    controller = rig.controller
    if rig.parent is not None:
        print('%s has a parent. unable to import geometry' % rig)
        return

    container_paths = list(set(rig.utility_geometry_paths))
    existing_paths = []
    for x in container_paths:
        if os.path.exists(x):
            existing_paths.append(x)
    rig.utility_geometry_paths = list(existing_paths)
    root_nodes = controller.scene.import_geometry(path)
    if root_nodes:
        new_geometry = dict()
        controller.root_about_to_change_signal.emit(controller.root)
        for geometry_root in [controller.initialize_node(x, parent=rig.utility_geometry_group) for x in root_nodes]:
            shapes = get_shape_descendants(controller, geometry_root)
            new_geometry.update(dict((x.name, x) for x in shapes if isinstance(x, Mesh)))
            controller.scene.select(cl=True)
        rig.geometry.update(new_geometry)

        # assign shaders
        if isinstance(rig, ContainerGuide):
            for mesh in new_geometry.values():
                mesh.assign_shading_group(rig.shaders[None].shading_group)

        # update UI
        controller.root_finished_change_signal.emit(controller.root)

        # fit view to imported geo and clear selection
        controller.scene.fit_view(rig.geometry.keys())
        controller.scene.select(cl=True)

        return new_geometry
    else:
        print('Warning ! No geometry roots found in %s' % path)


def import_low_geometry(rig, path):
    controller = rig.controller
    if rig.parent is not None:
        print('%s has a parent. unable to import geometry' % rig)
        return

    # path is relative or absolute
    if path.startswith('/'):
        absolute_path = '%s%s' % (controller.build_directory, path)
    else:
        absolute_path = path

    # add given path to current geometry_paths
    if os.path.exists(absolute_path):
        rig.low_geometry_paths.append(path)
    else:
        print('could not find %s' % path)
        return

    # remove possible duplicate geo paths
    rig.low_geometry_paths = list(set(rig.low_geometry_paths))

    # import geo
    root_nodes = controller.scene.import_geometry(absolute_path)

    if root_nodes:
        # add imported geo shapes to container.geometry dict
        new_geometry = dict()
        controller.root_about_to_change_signal.emit(controller.root)
        for geometry_root in [controller.initialize_node(x, parent=rig.low_geometry_group) for x in root_nodes]:
            shapes = get_shape_descendants(controller, geometry_root)
            new_geometry.update(dict((x.name, x) for x in shapes if isinstance(x, Mesh)))
            controller.scene.select(cl=True)
        rig.geometry.update(new_geometry)

        # assign shaders
        if isinstance(rig, ContainerGuide):
            for mesh in new_geometry.values():
                mesh.assign_shading_group(rig.shaders[None].shading_group)

        # update UI
        controller.root_finished_change_signal.emit(controller.root)

        # fit view to imported geo and clear selection
        controller.scene.fit_view(rig.geometry.keys())
        controller.scene.select(cl=True)

        return new_geometry
    else:
        print('Warning ! No geometry roots found in %s' % path)


def gather_mesh_children(transform):
    mesh_children = []
    for child in transform.children:
        if isinstance(child, Mesh):
            mesh_children.append(child)
        else:
            mesh_children.extend(gather_mesh_children(child))
    return mesh_children
