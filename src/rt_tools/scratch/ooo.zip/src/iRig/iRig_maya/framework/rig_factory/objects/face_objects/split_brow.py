from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.part_objects.part_array import PartArrayGuide, PartArray
from rig_factory.objects.part_objects.surface_spline import SurfaceSplineGuide, SurfaceSpline
import rig_factory.utilities.spline_builders as spb
from rig_math.matrix import Matrix
import rig_factory.environment as env


class SplitBrowGuide(PartArrayGuide):

    center_secondary_count = DataProperty(
        name='center_secondary_count',
        default_value=3

    )
    default_settings = {
        'root_name': 'Brow',
        'size': 1.0,
        'center_secondary_count': 3
    }

    def __init__(self, **kwargs):
        super(SplitBrowGuide, self).__init__(**kwargs)
        self.toggle_class = SplitBrow.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['side'] = None
        this = super(SplitBrowGuide, cls).create(controller, **kwargs)
        return this

    def create_members(self):

        self.create_part(
            SurfaceSplineGuide,
            root_name=self.root_name,
            side='left',
            count=5
        )
        self.create_part(
            SurfaceSplineGuide,
            root_name=self.root_name,
            side='right',
            count=5
        )


class SplitBrow(PartArray):

    center_secondary_count = DataProperty(
        name='center_secondary_count',
        default_value=3
    )

    def create_deformation_rig(self, **kwargs):
        super(SplitBrow, self).create_deformation_rig(**kwargs)

        left_brow = self.find_first_part(SurfaceSpline, side='left')
        right_brow = self.find_first_part(SurfaceSpline, side='right')
        if left_brow and right_brow:
            spline_joints = []
            root = self.get_root()
            handle_data = spb.create_handle_data(
                self.center_secondary_count,
                None,
                self.root_name,
                self.size,
                segment_name_token='CenterSecondary'
            )
            for i, data in enumerate(handle_data):
                spline_joint = self.create_child(
                    Joint,
                    parent=root.deform_group,
                    **data
                )
                getter_data = data.copy()
                getter_data['segment_name'] = '%sGetter' % getter_data['segment_name']
                getter_transform = self.create_child(
                    Transform,
                    **getter_data
                )
                spline_handle = self.create_handle(
                    create_gimbal=False,
                    shape='triangle',
                    axis='x',
                    **data
                )
                spline_joint.plugs.set_values(
                    overrideRGBColors=True,
                    overrideColorRGB=env.secondary_colors['bindJoints'],
                    overrideEnabled=True,
                    type=18,
                    otherType='Spline'
                )
                handle_size = spline_handle.size * 0.5
                shape_matrix = Matrix()
                shape_matrix.set_scale([handle_size, handle_size, handle_size * -2.0])
                spline_handle.set_shape_matrix(shape_matrix)
                constraint = self.controller.create_parent_constraint(
                    left_brow.handles[0],
                    right_brow.handles[0],
                    spline_handle.groups[0],
                    mo=False
                )
                constraint_weight = 1.0 / (self.center_secondary_count + 1) * (i + 1)
                constraint.get_weight_plug(left_brow.handles[0]).set_value(constraint_weight)
                constraint.get_weight_plug(right_brow.handles[0]).set_value(1.0 - constraint_weight)

                self.controller.create_parent_constraint(
                    spline_handle,
                    getter_transform,
                    mo=False
                )

                getter_transform.plugs['translate'].connect_to(spline_joint.plugs['translate'])
                getter_transform.plugs['rotate'].connect_to(spline_joint.plugs['rotate'])

                root.add_plugs(
                    spline_handle.plugs['tx'],
                    spline_handle.plugs['ty'],
                    spline_handle.plugs['tz'],
                    spline_handle.plugs['rx'],
                    spline_handle.plugs['ry'],
                    spline_handle.plugs['rz']
                )
                spline_joints.append(spline_joint)

            self.deform_joints.extend(spline_joints)
