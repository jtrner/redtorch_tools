from rig_factory.objects.part_objects.container import Container, ContainerGuide


class VehicleGuide(ContainerGuide):

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['root_name'] = None
        return super(VehicleGuide, cls).create(controller, **kwargs)

    def __init__(self, **kwargs):
        super(VehicleGuide, self).__init__(**kwargs)
        self.toggle_class = Vehicle.__name__

    def post_create(self, **kwargs):
        super(VehicleGuide, self).post_create(**kwargs)


class Vehicle(Container):

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['root_name'] = None
        return super(Vehicle, cls).create(controller, **kwargs)

    def post_create(self, **kwargs):
        super(Vehicle, self).post_create(**kwargs)
