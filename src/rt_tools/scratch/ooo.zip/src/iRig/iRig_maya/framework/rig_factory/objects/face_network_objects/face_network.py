from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.shader import Shader
from rig_factory.objects.base_objects.properties import DataProperty, ObjectProperty, ObjectListProperty
import rig_factory.utilities.face_utilities.decorators as dec
from rig_factory.objects.face_network_objects.face_group import FaceGroup
from rig_factory.objects.face_objects.face_handle import FaceHandle
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_factory.objects.base_objects.weak_list import WeakList
from rig_factory.objects.blendshape_objects.blendshape import Blendshape
from rig_factory.objects.sdk_objects.sdk_network import SDKNetwork

from rig_math.vector import Vector

import rig_factory

class FaceNetwork(Transform):

    sdk_network = ObjectProperty(
        name='sdk_network'
    )
    blendshape = ObjectProperty(
        name='blendshape'
    )
    target_shader = ObjectProperty(
        name='target_shader'
    )
    members = ObjectListProperty(
        name='members'
    )
    driven_handles = ObjectListProperty(
        name='driven_handles'
    )
    geometry = ObjectListProperty(
        name='geometry'
    )
    base_geometry = ObjectListProperty(
        name='base_geometry'
    )
    base_geometry_group = ObjectProperty(
        name='base_geometry_group'
    )
    transformed_geometry = ObjectListProperty(
        name='transformed_geometry'
    )
    driver_group_index = DataProperty(
        name='driver_group_index',
        default_value=-2
    )
    sculpt_shader = ObjectProperty(
        name='sculpt_shader'
    )
    selected_face_groups = ObjectListProperty(
        name='selected_face_groups'
    )
    selected_face_targets = ObjectListProperty(
        name='selected_face_targets'
    )

    suffix = 'Fnw'
    has_been_finalized = False

    @property
    def face_groups(self):
        return self.get_members()

    def get_members(self):
        members = WeakList()
        members.extend(self.members)
        for member in self.members:
            members.extend(member.get_members())
        return members

    @classmethod
    def create(cls, controller, *geometry, **kwargs):
        kwargs.setdefault('root_name', 'Face')
        kwargs.setdefault('segment_name', 'Base')

        this = super(FaceNetwork, cls).create(controller, **kwargs)
        sculpt_shader = this.create_child(
            Shader,
            node_type='lambert',
            segment_name='SculptShader'
        )
        sculpt_shader.plugs['ambientColorR'].set_value(0.0)
        sculpt_shader.plugs['ambientColorG'].set_value(0.5)
        sculpt_shader.plugs['ambientColorB'].set_value(1)
        sculpt_shader.plugs['colorR'].set_value(0.175)
        sculpt_shader.plugs['colorG'].set_value(0.509)
        sculpt_shader.plugs['colorB'].set_value(0.739)
        sculpt_shader.plugs['incandescenceR'].set_value(0.0)
        sculpt_shader.plugs['incandescenceG'].set_value(0.0)
        sculpt_shader.plugs['incandescenceB'].set_value(0.0)
        sculpt_shader.plugs['diffuse'].set_value(0.5)
        this.sculpt_shader = sculpt_shader
        this.plugs['visibility'].set_value(False)
        this.plugs['nodeState'].connect_to(sculpt_shader.plugs['nodeState'])
        return this

    def __init__(self, **kwargs):
        super(FaceNetwork, self).__init__(**kwargs)

    def create_blendshape(self, *geometry):
        return self.add_geometry(*geometry)

    def create_group(self, *geometry, **kwargs):
        driver_plug = kwargs.get('driver_plug', None)
        if driver_plug is None:
            raise Exception('You must provide  driver plug to create a FaceGroup')
        elif str(driver_plug) in [g.driver_plug.name for g in self.face_groups]:
            raise Exception('A FaceGroup with the driver plug "%s" already exists' % driver_plug)
        kwargs['owner'] = self
        kwargs['parent'] = self
        kwargs['geometry'] = geometry
        return self.create_child(FaceGroup, **kwargs)

    def clear_target_selection(self):
        self.deselect_face_groups(self.selected_face_groups)

    def clear_group_selection(self):
        self.deselect_face_targets(self.selected_face_targets)

    @dec.flatten_args
    def select_face_groups(self, *face_groups):
        for x in face_groups:
            if isinstance(x, FaceGroup):
                if x not in self.selected_face_groups:
                    self.selected_face_groups.append(x)
        # self.controller.face_groups_selected_signal.emit(face_groups)

    @dec.flatten_args
    def deselect_face_groups(self, *face_groups):
        for face_group_name in face_groups:
            if face_group_name in self.selected_face_groups:
                self.selected_face_groups.remove(face_group_name)
        # self.controller.face_groups_deselected_signal.emit(face_groups)


    @dec.flatten_args
    def select_face_targets(self, *face_targets):
        for face_target_name in face_targets:
            if face_target_name not in self.selected_face_targets:
                self.selected_face_targets.append(face_target_name)
        # self.controller.face_targets_selected_signal.emit(face_targets)

    @dec.flatten_args
    def deselect_face_targets(self, *face_targets):
        for face_target_name in face_targets:
            if face_target_name in self.selected_face_targets:
                self.selected_face_targets.remove(face_target_name)
        # self.controller.face_targets_deselected_signal.emit(face_targets)

    def get_next_avaliable_index(self):
        existing_indices = [x.index for x in self.members]
        i = 0
        while True:
            if i not in existing_indices:
                return i
            i += 1


    @dec.flatten_args
    def add_geometry(self, *geometry):

        """
        This can currently only happen once...
        It would be good to let rigger add geo on the fly

        :param geometry:
        :return:
        """
        controller = self.controller
        self.geometry.extend(geometry)
        if not self.base_geometry_group:
            self.base_geometry_group = self.create_child(
                Transform,
                segment_name='%sBase' % self.segment_name
            )
        self.base_geometry_group.plugs['visibility'].set_value(False)

        for g in range(len(geometry)):
            index_character = rig_factory.index_dictionary[g].title()
            base_mesh_parent = self.base_geometry_group.create_child(
                Transform,
                segment_name='%s%s' % (self.segment_name, index_character)
            )
            base_mesh = controller.copy_mesh(
                geometry[g].get_selection_string(),
                base_mesh_parent
            )
            self.base_geometry.append(base_mesh)

        if geometry:
            if not self.blendshape:
                self.blendshape = self.create_child(
                    Blendshape,
                    *geometry,
                    parallel=True,
                    frontOfChain=True,
                    segment_name='Blend',
                    parent=self
                )
            else:
                self.blendshape.add_base_geometry(*geometry)
            return self.blendshape

    def add_selected_driven_handles(self, **kwargs):
        return self.add_driven_handles(
            *self.controller.scene.get_selected_transform_names(),
            **kwargs
        )

    def add_driven_handles(self, *handles, **kwargs):
        if not self.sdk_network:
            self.sdk_network = self.create_child(SDKNetwork)
        kwargs.pop('index', None)
        valid_handles = []
        invalid_handles = []
        missing_handles = []
        for i, handle in enumerate(list(handles)):
            if isinstance(handle, basestring):
                handle_name = handle
                handle = self.controller.named_objects.get(handle_name, None)
                if handle is None:
                    missing_handles.append(handle_name)
            if handle is None:
                pass
            elif not isinstance(handle, (GroupedHandle, FaceHandle)):
                invalid_handles.append(handle)
            else:
                driven_handle = self.add_driven_handle(
                    handle,
                    **kwargs
                )
                valid_handles.append(driven_handle)
        if invalid_handles:
            warning_string = '\n'.join([str(invalid_handles[x]) for x in range(len(invalid_handles)) if x < 10])
            print('Some invalid handles were skipped: \n%s' % warning_string)
            self.controller.raise_warning('Some invalid handles were skipped: \n%s' % warning_string)
        if missing_handles:
            warning_string = '\n'.join([str(missing_handles[x]) for x in range(len(missing_handles)) if x < 10])
            print('Some handle names did not exist in the controller: \n%s' % warning_string)
            self.controller.raise_warning('Some handle names did not exist in the controller: \n%s' % warning_string)

        return valid_handles

    def add_driven_handle(self, handle, **kwargs):

        controller = self.controller
        if isinstance(handle, basestring):
            handle = controller.named_objects.get(handle, None)
        if handle is None:
            raise Exception(
                'The handle "%s" was not found in the controllers named_objects' % handle
            )


        if handle not in self.driven_handles:
            self.driven_handles.append(handle)
        #     self.controller.schedule_objects_for_deletion(handle.existing_plugs.values())  # Clear cached plug objects (faster)
        # self.controller.delete_scheduled_objects()

        if self.sdk_network:
            attributes = kwargs.pop(
                'attributes',
                ['tx', 'ty', 'tz', 'rx', 'ry', 'rz']
            )
            driven_plugs = []
            if isinstance(handle, (GroupedHandle, FaceHandle)):
                for attribute in attributes:
                    driven_plug = handle.groups[self.driver_group_index].plugs[attribute]
                    if driven_plug not in self.sdk_network.driven_plugs:
                        driven_plugs.append(driven_plug)
            else:
                print('Handle had no groups. skipping translate/rotate plugs')
            for attribute in ['ParameterU', 'ParameterV']:
                if handle.plugs.exists(attribute):
                    driven_plug = handle.plugs[attribute]
                    if driven_plug not in self.sdk_network.driven_plugs:
                        driven_plugs.append(driven_plug)

            self.sdk_network.add_driven_plugs(driven_plugs)
        return handle

    def get_similar_mesh_map(self, *geometry):
        controller = self.controller
        similar_geometry = dict()
        for input_geo in geometry:
            similar_mesh = controller.find_similar_mesh(input_geo, geometry=self.geometry)
            if similar_mesh:
                similar_geometry[similar_mesh.name] = input_geo
            else:
                raise Exception('similar_mesh not found for "%s" ' % input_geo)
        return similar_geometry

    def snap_to_mesh(self, *geometry):
        controller = self.controller
        similar_geometry_map = self.get_similar_mesh_map(*geometry)

        for handle in self.driven_handles:
            if handle.vertices:
                vertex_strings = []
                for x in handle.vertices:
                    if x.mesh.name in similar_geometry_map:
                        vertex_strings.append('%s.vtx[%s]' % (similar_geometry_map[x.mesh.name], x.index))
                    else:
                        print 'Mesh not found in similar geometry: %s' % x.mesh.name
                if vertex_strings:
                    bounding_box_center = Vector(controller.scene.get_bounding_box_center(*vertex_strings))
                    #  this would not work if vertices are from different meshs that have different transforms
                    parent = controller.scene.listRelatives(vertex_strings[0].split('.')[0], p=True)[0]
                    transform_position = Vector(controller.scene.xform(parent, ws=True, t=True, q=True))
                    local_position = bounding_box_center - transform_position
                    controller.xform(handle, t=local_position.data, ws=True)
                else:
                    print 'Handle "%s" no vertex_strings found' % handle

            else:
                print 'Handle "%s" had no vertices' % handle

    def consolidate_handle_positions(self, surfaces=True, groups=True):
        """
        Move all handle values to appropriate positions to create sdks
        """
        missing_connections = []
        for handle in self.driven_handles:
            if isinstance(handle, (GroupedHandle, FaceHandle)):
                world_matrix = handle.get_matrix()
                follicle_surface = None
                default_position = None
                if isinstance(handle, FaceHandle): # Get rid of this once FaceHandle is gone
                    follicle_surface = handle.follicle_surface
                    default_position = handle.default_position
                if handle.plugs.exists('ParameterU', 'ParameterV'):
                    follicle_surface = handle.utility_nodes.get('follicle_surface', None)
                    default_position = handle.handle_metadata.get('default_position', None)
                if surfaces and follicle_surface and default_position:

                    for attr in ['ParameterU', 'ParameterV']:  # Check if driven plugs are connected.
                        connections = self.controller.scene.listConnections(
                            handle.plugs[attr].name,
                            s=True,
                            d=False
                        )
                        if not connections:
                            missing_connections.append(handle.plugs[attr].name)

                    u, v = self.controller.scene.get_closest_surface_uv(
                        follicle_surface.m_object,
                        list(handle.get_translation())
                    )
                    u_spans = follicle_surface.plugs['spansU'].get_value()
                    v_spans = follicle_surface.plugs['spansV'].get_value()
                    handle.plugs['ParameterU'].set_value((u/u_spans) - default_position[0])
                    handle.plugs['ParameterV'].set_value((v/v_spans) - default_position[1])
                    if not groups:
                        handle.groups[self.driver_group_index].plugs['translate'].set_value([0.0, 0.0, 0.0])
                        handle.groups[self.driver_group_index].plugs['rotate'].set_value([0.0, 0.0, 0.0])
                        handle.plugs['translate'].set_value([0.0, 0.0, 0.0])
                        handle.plugs['rotate'].set_value([0.0, 0.0, 0.0])
                if groups:

                    handle_group = handle.groups[self.driver_group_index]
                    if not surfaces and follicle_surface:
                        handle.plugs['ParameterU'].set_value(0.0)
                        handle.plugs['ParameterV'].set_value(0.0)

                    for attr in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz']:  # Check if driven plugs are connected.
                        connections = self.controller.scene.listConnections(
                            handle_group.plugs[attr].name,
                            s=True,
                            d=False
                        )
                        if not connections:
                            missing_connections.append(handle_group.plugs[attr].name)

                    handle_group.set_matrix(world_matrix)
                    handle.set_matrix(world_matrix)
            else:
                print('Cannot consolidate handle: %s type(%s)' % (handle, type(handle)))

        if missing_connections:
            shortened_connections = [missing_connections[x] for x in range(len(missing_connections)) if x < 10]
            self.controller.raise_warning('Plugs were unconnected. Unable to consolidate:\n\n %s' % '\n'.join(shortened_connections))

    def get_altered_driver_values(self):
        altered_values = []
        for other_group in self.members:
            other_driver_plug = other_group.driver_plug
            current_value = other_driver_plug.get_value()
            if current_value != other_group.initial_value:
                altered_values.append((
                    other_driver_plug.name,
                    current_value
                ))
        return altered_values

    def mirror_face_groups(self, plug_prefixes=('left_', 'right_')):
        return self.controller.mirror_face_groups(
            self,
            plug_prefixes=plug_prefixes
        )

    def reset_driver_plugs(self):
        failed_plugs = []
        for group in self.controller.face_network.face_groups:
            try:
                group.driver_plug.set_value(0.0)
            except Exception:
                failed_plugs.append(group.driver_plug.name)
        if failed_plugs:
            shortened_plugs  = [failed_plugs[x]for x in range(len(failed_plugs)) if x < 10]
            self.controller.raise_warning(
                'Warning: Unable to set values on the following plugs:\n%s' % '\n'.join(shortened_plugs)
            )


    def reset_driven_handles(self):
        failed_plugs = []
        for handle in self.controller.face_network.driven_handles:
            for attribute in ['tx', 'ty', 'tz', 'rx', 'ry', 'rz']:
                try:
                    handle.plugs[attribute].set_value(0.0)
                except Exception:
                    failed_plugs.append(handle.plugs[attribute].name)
            for attribute in ['sx', 'sy', 'sz']:
                try:
                    handle.plugs[attribute].set_value(1.0)
                except Exception:
                    failed_plugs.append(handle.plugs[attribute].name)
        if failed_plugs:
            shortened_plugs = [failed_plugs[x]for x in range(len(failed_plugs)) if x < 10]
            self.controller.raise_warning(
                'Warning: Unable to set values on the following plugs:\n%s' % '\n'.join(shortened_plugs)
            )

    def update_blendshapes(self):
        if not self.blendshape:
            raise Exception('No blendshape found')

        self.reset_driver_plugs()
        self.reset_driven_handles()
        self.blendshape.plugs['envelope'].set_value(0.0)
        for face_group in self.face_groups:
            initial_value = face_group.driver_plug.get_value()
            for face_target in face_group.face_targets:
                face_group.driver_plug.set_value(face_target.driver_value)
                for i in range(len(self.geometry)):
                    if face_target.deformed_meshs:
                        self.controller.copy_mesh_in_place(
                            self.geometry[i],
                            face_target.deformed_meshs[i]
                        )
            face_group.driver_plug.set_value(initial_value)
        self.blendshape.plugs['envelope'].set_value(1.0)
        self.controller.dg_dirty()

    def teardown(self):

        self.reset_driver_plugs()
        # self.reset_driven_plugs()

        if self.controller.face_network == self:
            self.controller.set_face_network(None)

        self.clear_target_selection()
        self.deselect_face_groups()

        self.controller.schedule_objects_for_deletion(
            self.members,
            self.blendshape,
            self.sdk_network,
            self.sculpt_shader
        )

        super(FaceNetwork, self).teardown()


"""

        if isinstance(face_network, FaceNetwork):
            base_geometry = face_network.base_geometry
            if len(base_geometry) > 1:
                raise Exception('Mirroring multiple base meshs not supported')

            base_mesh = base_geometry[0].get_selection_string()

            # map template
            vertex_count = mc.polyEvaluate(base_mesh, v=True)
            point_positions = []
            for i in range(vertex_count):
                point = mc.pointPosition(
                    '{0}.vtx[{1}]'.format(base_mesh, i),
                    l=True
                )
                point_positions.append(point)

            reverse_index_list = []
            for i in range(vertex_count):
                closest_distance = 100000.0
                closest_point = None
                mirror_position = (point_positions[i][0] * -1, point_positions[i][1], point_positions[i][2])
                for j in range(vertex_count):
                    xpos = mirror_position[0] - (point_positions[j][0])
                    ypos = mirror_position[1] - (point_positions[j][1])
                    zpos = mirror_position[2] - (point_positions[j][2])
                    total = abs(xpos) + abs(ypos) + abs(zpos)
                    if total < closest_distance:
                        closest_point = j
                        closest_distance = total
                reverse_index_list.append(closest_point)

            for group in face_network.face_groups:
                if group.side == 'left':
                    mirror_group = con
                    if isinstance(group, FaceGroup):
                        if not group.mirror_group:
                            for target in group.face_targets:

                                target_mesh = target.target_meshs[0].get_selection_string()

                                temp_mesh_parent = controller.create_object(
                                    Transform,
                                    root_name='%s_TEMP' % mesh.split('|')[-1]
                                )
                                temp_mesh = temp_mesh_parent.create_child(
                                    Mesh,
                                    index=0
                                )
                                controller.assign_shading_group(
                                    face_network.sculpt_shader.shading_group,
                                    temp_mesh
                                )
                                controller.copy_mesh_shape(
                                    mesh,
                                    face_target.target_meshs[i]
                                )

                                # reverse shape
                                for sel in mc.ls(sl=True, fl=True):
                                    selIndex = int(sel.split('.vtx[')[-1][:-1])
                                    pp = mc.pointPosition(sel, l=True)
                                    revPos = (pp[0] * -1, pp[1], pp[2])
                                    revIndex = reverse_index_list[selIndex]
                                    mc.xform('{0}.vtx[{1}]'.format(target_mesh, revIndex), os=True, t=revPos)


"""



