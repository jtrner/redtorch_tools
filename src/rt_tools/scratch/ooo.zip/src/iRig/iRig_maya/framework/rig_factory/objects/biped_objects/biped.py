import copy
from rig_factory.objects.part_objects.container_array import ContainerArray, ContainerArrayGuide
from rig_factory.objects.biped_objects.biped_main import BipedMainGuide, BipedMain
from rig_factory.objects.biped_objects.biped_spine import BipedSpineGuide, BipedSpine
from rig_factory.objects.biped_objects.biped_arm import BipedArmGuide, BipedArm
from rig_factory.objects.biped_objects.biped_arm_bendy import BipedArmBendyGuide, BipedArmBendy
from rig_factory.objects.biped_objects.biped_leg import BipedLegGuide, BipedLeg
from rig_factory.objects.biped_objects.biped_neck import BipedNeckGuide, BipedNeck
from rig_factory.objects.biped_objects.biped_hand import BipedHandGuide, BipedHand
from rig_factory.objects.base_objects.properties import ObjectListProperty
from rig_factory.objects.base_objects.properties import ObjectProperty
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_factory.objects.base_objects.weak_list import WeakList
from rig_factory.objects.sdk_objects.sdk_network import SDKNetwork
from rig_math.vector import Vector
from rig_math.matrix import Matrix
import rig_factory.positions as pos


class BipedMixin(object):

    main = ObjectProperty(
        name='main'
    )
    spine = ObjectProperty(
        name='spine'
    )
    neck = ObjectProperty(
        name='neck'
    )
    left_arm = ObjectProperty(
        name='left_arm'
    )
    right_arm = ObjectProperty(
        name='right_arm'
    )
    left_leg = ObjectProperty(
        name='left_leg'
    )
    right_leg = ObjectProperty(
        name='right_leg'
    )
    left_hand = ObjectProperty(
        name='left_hand'
    )
    right_hand = ObjectProperty(
        name='right_hand'
    )
    extra_parts = ObjectListProperty(
        name='extra_parts'
    )
    face_shape_network = ObjectProperty(
        name='face_shape_network'
    )


class BipedGuide(ContainerArrayGuide, BipedMixin):

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['root_name'] = None
        return super(BipedGuide, cls).create(controller, **kwargs)


    def __init__(self, **kwargs):
        super(BipedGuide, self).__init__(**kwargs)
        self.toggle_class = Biped.__name__

    def create_part(self, object_type, **kwargs):
        part = super(BipedGuide, self).create_part(object_type, **kwargs)

        if isinstance(part, BipedMainGuide):
            self.main = part
        if isinstance(part, BipedSpineGuide):
            self.spine = part
        if isinstance(part, BipedNeckGuide):
            self.neck = part
        if isinstance(part, (BipedArmGuide, BipedArmBendyGuide)):
            if part.side == 'left':
                self.left_arm = part
            if part.side == 'right':
                self.right_arm = part
        if isinstance(part, BipedLegGuide):
            if part.side == 'left':
                self.left_leg = part
            if part.side == 'right':
                self.right_leg = part
        if isinstance(part, BipedHandGuide):
            if part.side == 'left':
                self.left_hand = part
            if part.side == 'right':
                self.right_hand = part
        return part

    def post_create(self, **kwargs):
        super(BipedGuide, self).post_create(**kwargs)

    def create_members(self):
        super(BipedGuide, self).create_members()
        controller = self.controller

        controller.progress_signal.emit(
            message='Building Biped Member: Spine',
            maximum=7,
            value=0
        )
        main = self.create_part(
            'BipedMainGuide',
            root_name='main',
            size=15.0
        )

        spine = self.create_part(
            'BipedSpineGuide',
            root_name='spine',
            size=15.0
        )
        controller.progress_signal.emit(
            message='Building Biped Member: Neck',
            value=1
        )
        neck = self.create_part(
            'BipedNeckGuide',
            root_name='neck',
            size=5.0
        )
        controller.progress_signal.emit(
            message='Building Biped Member: Left Arm',
            value=2
        )
        left_arm = self.create_part(
            'BipedArmBendyGuide',
            root_name='arm',
            side='left',
            size=7.0
        )
        controller.progress_signal.emit(
            message='Building Biped Member: Right Arm',
            value=3
        )
        right_arm = self.create_part(
            'BipedArmBendyGuide',
            root_name='arm',
            side='right',
            size=7.0
        )
        controller.progress_signal.emit(
            message='Building Biped Member: Left Leg',
            value=4
        )
        left_leg = self.create_part(
            'BipedLegBendyGuide',
            root_name='leg',
            side='left',
            size=9.0
        )
        controller.progress_signal.emit(
            message='Building Biped Member: Right Leg',
            value=5
        )
        right_leg = self.create_part(
            'BipedLegBendyGuide',
            root_name='leg',
            side='right',
            size=9.0
        )
        controller.progress_signal.emit(
            message='Building Biped Member: Left Hand',
            value=6
        )
        left_hand = self.create_part(
            'BipedHandGuide',
            root_name='hand',
            side='left',
            size=2.5
        )

        left_hand.create_part(
            'BipedFingerGuide',
            side=left_hand.side,
            size=left_hand.size,
            root_name='thumb',
            count=4
        )

        for index_name in ['pointer', 'middle', 'ring', 'pinky']:
            left_hand.create_part(
                'BipedFingerGuide',
                side=left_hand.side,
                size=left_hand.size,
                root_name='finger_%s' % index_name
            )

        controller.progress_signal.emit(
            message='Building Biped Member: Left Hand',
            value=7
        )
        right_hand = self.create_part(
            'BipedHandGuide',
            root_name='hand',
            side='right',
            size=2.5
        )

        right_hand.create_part(
            'BipedFingerGuide',
            side=right_hand.side,
            size=right_hand.size,
            root_name='thumb',
            count=4
        )
        for index_name in ['pointer', 'middle', 'ring', 'pinky']:
            right_hand.create_part(
                'BipedFingerGuide',
                side=right_hand.side,
                size=right_hand.size,
                root_name='finger_%s' % index_name
            )

        spine.set_parent_joint(main.joints[-1])
        neck.set_parent_joint(spine.joints[-1])
        left_arm.set_parent_joint(spine.joints[-1])
        right_arm.set_parent_joint(spine.joints[-1])
        left_leg.set_parent_joint(spine.joints[0])
        right_leg.set_parent_joint(spine.joints[0])
        left_hand.set_parent_joint(left_arm.joints[-1])
        right_hand.set_parent_joint(right_arm.joints[-1])

        self.rig_data['space_switchers'] = copy.copy(pos.BIPED_HANDLE_SPACES)

        controller.progress_signal.emit(
            done=True
        )


class Biped(ContainerArray, BipedMixin):

    mocap_joints = ObjectListProperty(
        name='mocap_joints'
    )
    character_node = ObjectProperty(
        name='character_node'
    )

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['root_name'] = None
        return super(Biped, cls).create(controller, **kwargs)

    def __init__(self, **kwargs):
        super(Biped, self).__init__(**kwargs)

    def create_part(self, object_type, **kwargs):
        part = super(Biped, self).create_part(object_type, **kwargs)
        if isinstance(part, BipedMain):
            self.main = part
        if isinstance(part, BipedSpine):
            self.spine = part
        if isinstance(part, BipedNeck):
            self.neck = part
        if isinstance(part, (BipedArm, BipedArmBendy)):
            if part.side == 'left':
                self.left_arm = part
            if part.side == 'right':
                self.right_arm = part
        if isinstance(part, BipedLeg):
            if part.side == 'left':
                self.left_leg = part
            if part.side == 'right':
                self.right_leg = part
        if isinstance(part, BipedHand):
            if part.side == 'left':
                self.left_hand = part
            if part.side == 'right':
                self.right_hand = part
        return part

    def finish_create(self, **kwargs):
        super(Biped, self).finish_create(**kwargs)
        self.setup_t_pose()

    def setup_t_pose(self):

        handle_group_index = -2
        if self.left_arm and self.right_arm:

            sdk_handles = WeakList()
            sdk_handles.extend(self.left_arm.fk_handles)
            sdk_handles.extend(self.right_arm.fk_handles)
            sdk_handles.extend([self.left_arm.wrist_handle, self.left_arm.elbow_handle, self.left_arm.clavicle_handle])
            sdk_handles.extend([self.right_arm.wrist_handle, self.right_arm.elbow_handle, self.right_arm.clavicle_handle])
            sdk_handle_groups = [x.groups[handle_group_index] for x in sdk_handles if isinstance(x, GroupedHandle)]
            sdk_network = self.create_child(
                SDKNetwork,
                segment_name='TPose',
                lock_curves=False
            )
            sdk_network.initialize_driven_plugs(
                sdk_handle_groups,
                ['rx', 'ry', 'rz', 'tx', 'ty', 'tz']
            )
            t_pose_plug = self.settings_handle.create_plug(
                'TPose',
                at='double',
                dv=0.0,
                keyable=True,
                min=0.0,
                max=1.0
            )
            sdk_group = sdk_network.create_group(
                driver_plug=t_pose_plug,
            )
            sdk_group.create_keyframe_group(
                in_value=0.0
            )
            self.solve_t_pose()
            self.left_arm.match_to_ik()
            self.right_arm.match_to_ik()
            for x in sdk_handles:
                matrix = x.get_matrix()
                x.groups[handle_group_index].set_matrix(matrix)
                x.set_matrix(matrix)
            sdk_group.create_keyframe_group(
                in_value=1.0
            )
            t_pose_plug.set_value(0.0)

            self.left_arm.settings_handle.plugs['ikSwitch'].set_value(0.0)
            self.right_arm.settings_handle.plugs['ikSwitch'].set_value(0.0)

    def finalize(self):
        super(Biped, self).finalize()
        if self.settings_handle.plugs.exists('TPose'):
            self.settings_handle.plugs['TPose'].set_locked(False)
            self.settings_handle.plugs['TPose'].set_value(1.0)

    def solve_t_pose(self):

        for handle in self.left_arm.fk_handles:
            position = handle.get_translation()
            matrix = compose_matrix(
                position,
                position + Vector([20 * self.size, 0.0, 0.0]),
                position + Vector([0.0, 0.0, -20 * self.size]),
                rotation_order='xyz'
            )
            handle.set_matrix(matrix)
        for handle in self.right_arm.fk_handles:
            position = handle.get_translation()
            matrix = compose_matrix(
                position,
                position + Vector([20 * self.size, 0.0, 0.0]),
                position + Vector([0.0, 0.0, 20 * self.size]),
                rotation_order='xyz'
            )
            handle.set_matrix(matrix)


def compose_matrix(position, aim_position, up_position, rotation_order='xyz'):
    z_vector = up_position - position
    y_vector = aim_position - position
    x_vector = z_vector.cross_product(y_vector)
    z_vector = x_vector.cross_product(y_vector)
    matrix_list = []
    vector_dictionary = dict(
        x=x_vector,
        y=y_vector,
        z=z_vector
    )
    vector_list = [x for x in rotation_order]
    for i in range(3):
        matrix_list.extend(vector_dictionary[vector_list[i]].unit().data)
        matrix_list.append(0.0)
    matrix_list.extend(position.data)
    matrix_list.append(1.0)
    return Matrix(matrix_list)
