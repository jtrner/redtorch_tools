import os
import copy
import json
import subprocess
import shutil
import rig_factory.utilities.file_utilities as fut
import rig_factory.object_versions as obs
import rig_factory.build.utilities.finalize as fin
import rig_factory.utilities.geometry_utilities as gtl
import rig_math.utilities as rmu
import rig_factory
this_directory = os.path.dirname(__file__).replace('\\', '/')


def build_realtime_rig_product(controller, build_directory=None):

    # Block signals so we dot get popup warnongs
    controller.raise_warning_signal._block = True

    # Construct file paths
    major_version, minor_version = fut.get_current_work_versions()
    latest_product_build_directory = fut.get_latest_product_directory()
    realtime_directory = '%s/rig_build_realtime' % fut.get_products_directory()
    realtime_versions_directory = '%s/rig_build_realtime_v%s' % (
        realtime_directory,
        major_version
    )
    face_blueprint_path = '%s/face_blueprint.json' % realtime_versions_directory
    rig_blueprint_path = '%s/rig_blueprint.json' % realtime_versions_directory
    if not build_directory:
        build_directory = latest_product_build_directory
    # Copy build directory from product build
    controller.build_directory = realtime_versions_directory
    if not os.path.exists(realtime_directory):
        os.makedirs(realtime_directory)
    if os.path.exists(realtime_directory):
        proc = subprocess.Popen(
            'rmdir /s/q "%s"' % realtime_directory,
            shell=True
        )
        print('Attempting to remove existing directory: %s' % realtime_directory)
        proc.wait()
    proc = subprocess.Popen(
        'robocopy %s %s /E /S' % (
            build_directory,
            realtime_versions_directory,
        ),
        shell=True
    )
    print('Attempting to copy latest build product to: %s' % realtime_versions_directory)
    proc.wait()

    if not os.path.exists(rig_blueprint_path):
        raise Exception('rig_blueprint.json not found. %s ' % rig_blueprint_path)

    # Execute rig/face blueprints
    with open(rig_blueprint_path, mode='r') as f:
        blueprint = json.load(f)
    controller.root = controller.execute_blueprint(blueprint)
    if isinstance(controller.root, obs.ContainerGuide):
        controller.root = controller.toggle_state()
    if os.path.exists(face_blueprint_path):
        face_network = controller.import_face(face_blueprint_path)
        face_network.mirror_face_groups()

    # Bake face into blendshape data
    blendshape_data = None
    if controller.face_network:
        blendshape_data = bake_face_rig(controller)

    controller.scene.file(new=True, force=True)
    controller.reset()

    # Execute blueprint
    with open(rig_blueprint_path, mode='r') as f:
        blueprint = json.load(f)
    controller.root = controller.execute_blueprint(blueprint)

    # Make sure rig is in guide state
    if isinstance(controller.root, obs.Container):
        controller.root = controller.toggle_state()

    # Process guide blueprint
    guide_blueprint = process_guide_blueprint(controller.get_blueprint(controller.root))
    controller.scene.file(new=True, force=True)
    controller.reset()
    controller.root = controller.execute_blueprint(guide_blueprint)
    controller.root = controller.toggle_state()

    # Process rig blueprint
    rig_blueprint = process_rig_blueprint(controller.get_blueprint(controller.root))
    controller.scene.file(new=True, force=True)
    controller.reset()

    # Execute fully processed rig blueprint
    controller.root = controller.execute_blueprint(rig_blueprint)

    # Save processed rig blueprint
    with open(rig_blueprint_path, mode='w') as f:
        json.dump(
            rig_blueprint,
            f,
            sort_keys=True,
            indent=4,
            separators=(',', ': ')
        )
    if blendshape_data:
        # Import baked face shape alembic file
        baked_face_geometry_path = '%s/baked_face.abc' % controller.build_directory
        controller.scene.loadPlugin('AbcImport')
        gtl.import_geo(
            controller,
            baked_face_geometry_path,
            parent=controller.root
        )
        # Build face blendshapes
        build_face_blendshapes(controller, blendshape_data)

        # Delete alembic geo
        controller.schedule_objects_for_deletion(controller.named_objects['BakeGeometry'])
        controller.delete_scheduled_objects()
    if controller.root:  # Find out why root=None on variation rigs.
        fin.finalize(controller)
    save_realtime_rig_product(controller, major_version)
    controller.root_finished_change_signal.emit(controller.root)
    controller.raise_warning_signal._block = False


def save_realtime_rig_product(controller, version):
    products_directory = '%s/rig_realtime' % fut.get_products_directory()
    if not os.path.exists(products_directory):
        os.makedirs(str(products_directory))
    ext = '.mb' if os.environ.get('TT_MAYAFILETYPE') == 'mayaBinary' else '.ma'
    file_name = os.environ['TT_ENTNAME'] + '_rig_realtime_v' + version + ext
    pub_file = '%s/%s' % (products_directory, file_name)
    if os.path.exists(pub_file):
        controller.raise_warning('Product "%s" already existed. Overwriting file.' % pub_file)
    controller.scene.file(rn=str(pub_file))
    controller.scene.file(save=True, force=True, type='mayaAscii')
    controller.raise_warning('Success! created rig product: %s' % pub_file)


def generate_corrective_meshs(controller, base_geometry, plug_1, plug_2, value_1, value_2, mesh_names):
    node_1, attr_1 = plug_1.split('.')
    node_2, attr_2 = plug_2.split('.')
    plug_1 = controller.named_objects[node_1].plugs[attr_1]
    plug_2 = controller.named_objects[node_2].plugs[attr_2]
    old_value_1 = plug_1.get_value()
    old_value_2 = plug_2.get_value()

    mesh_group = controller.named_objects['BakeGeometry']
    result_mesh_objects = []
    for i in range(len(base_geometry)):
        mesh_parent_name = controller.scene.listRelatives(mesh_names[i], p=True)[0]
        result_transform = mesh_group.create_child(
            obs.Transform,
            name='%sResult' % mesh_parent_name,
        )
        result_mesh = controller.copy_mesh(
            base_geometry[i].name,
            result_transform,
            name='%sShape' % result_transform.name
        )
        result_mesh_objects.append(result_mesh)

    plug_1.set_value(value_1)
    plug_2.set_value(value_2)
    for i in range(len(base_geometry)):
        base_mesh = base_geometry[i]
        mesh_name = mesh_names[i]
        result_mesh = result_mesh_objects[i]
        mesh_parent_name = controller.scene.listRelatives(mesh_name, p=True)[0]
        deformed_transform = mesh_group.create_child(
            obs.Transform,
            name='%sDeformed' % mesh_parent_name,
        )
        deformed_mesh = controller.copy_mesh(
            base_mesh.name,
            deformed_transform,
            name='%sShape' % deformed_transform.name
        )
        target_transform = mesh_group.create_child(
            obs.Transform,
            name='%sTarget' % mesh_parent_name,
        )
        target_mesh = controller.copy_mesh(
            mesh_name,
            target_transform,
            name='%sShape' % target_transform.name
        )
        blendshape = controller.scene.blendShape(
            deformed_mesh.name,
            target_mesh.name,
            result_mesh.name
        )[0]
        controller.scene.setAttr('%s.weight[0]' % blendshape, -1.0)
        controller.scene.setAttr('%s.weight[1]' % blendshape, 1.0)
        controller.scene.delete(result_mesh.name, ch=True)
        result_mesh.redraw()
    plug_1.set_value(old_value_1)
    plug_2.set_value(old_value_2)
    return result_mesh_objects


def build_face_blendshapes(controller, blendshape_data):
    base_geometry = [controller.named_objects[x] for x in blendshape_data['base_geometry']]

    """
    Make one blendshpe node per geo for paralell
    """
    blendshape = controller.root.create_child(
        obs.Blendshape,
        *base_geometry,
        frontOfChain=True,
        segment_name='Blend'
    )
    for group_data in blendshape_data['groups']:
        blendshape_group = blendshape.create_group(
            segment_name='%sBake' % group_data['segment_name'],
            tangent_space=False,
            side=group_data['side']
        )
        driver_values = []
        secondary_driver_values = []
        for target_data in group_data['targets']:
            mesh_objects = [controller.named_objects[x] for x in target_data['mesh_objects']]
            driver_values.append(target_data['driver_value'])
            if 'secondary_driver_value' in target_data:
                secondary_driver_values.append(target_data['secondary_driver_value'])
                mesh_objects = generate_corrective_meshs(
                    controller,
                    base_geometry,
                    group_data['driver_plug'],
                    group_data['secondary_driver_plug'],
                    target_data['driver_value'],
                    target_data['secondary_driver_value'],
                    target_data['mesh_objects']
                )
            print('Creating Blendshape target %s = %s' % (
                group_data['segment_name'],
                target_data['driver_value']
            ))
            blendshape_group.create_inbetween(
                *mesh_objects,
                weight=target_data['weight'],
                tangent_space=False
            )
        if driver_values:
            driver_values = sorted(driver_values)
            minimum_driver_value = driver_values[0]
            maximum_driver_value = driver_values[-1]
            driver_node, driver_attribute = group_data['driver_plug'].split('.')
            driver_plug = controller.named_objects[driver_node].plugs[driver_attribute]
            if secondary_driver_values:
                assert len(secondary_driver_values) == 1
                secondary_driver_values = sorted(secondary_driver_values)
                secondary_driver_node, secondary_driver_attribute = group_data['secondary_driver_plug'].split('.')
                secondary_driver_plug = controller.named_objects[secondary_driver_node].plugs[secondary_driver_attribute]
                corrective_plug = create_corrective_driver(
                    driver_plug,
                    secondary_driver_plug,
                    driver_values[0],
                    secondary_driver_values[0],
                    blendshape_group.segment_name,
                    blendshape_group.side
                )
                corrective_plug.connect_to(blendshape_group.get_weight_plug())
            else:
                maximum_weight = 1.0
                if minimum_driver_value < 0.0:
                    minumum_weight = -1.0
                else:
                    minumum_weight = 0.0
                segment_name = '%s%sBlendDriver' % (
                    blendshape_group.root_name,
                    driver_plug.name.replace('.', '_').split('|')[-1]
                )
                remap_node = blendshape_group.create_child(
                    obs.DependNode,
                    node_type='remapValue',
                    segment_name=segment_name
                )
                blend_node = blendshape_group.create_child(
                    obs.DependNode,
                    node_type='blendWeighted',
                    segment_name=segment_name
                )
                driver_plug.connect_to(remap_node.plugs['inputValue'])
                remap_node.plugs['outValue'].connect_to(blend_node.plugs['input'].element(0))
                remap_node.plugs['value'].element(0).child(0).set_value(minimum_driver_value)
                remap_node.plugs['value'].element(0).child(1).set_value(minumum_weight)
                remap_node.plugs['value'].element(1).child(0).set_value(0.0)
                remap_node.plugs['value'].element(1).child(1).set_value(0.0)
                remap_node.plugs['value'].element(2).child(0).set_value(maximum_driver_value)
                remap_node.plugs['value'].element(2).child(1).set_value(maximum_weight)
                blend_node.plugs['output'].connect_to(blendshape_group.get_weight_plug())

    return blendshape


def bake_face_rig(controller):

    face_schema_path = '%s/face_bake_schema.json' % controller.build_directory

    if not os.path.exists('%s/face_bake_schema.json' % controller.build_directory):
        shutil.copyfile(
            '%s/face_bake_schema.json' % this_directory,
            face_schema_path
        )

    with open(face_schema_path, mode='r') as f:
        face_schema = json.load(f)

    bake_geometry_group = controller.create_object(
        obs.Transform,
        name='BakeGeometry'
    )

    data = dict(
        base_geometry=face_schema['geometry_names'],
        groups=bake_face_targets(
            controller,
            bake_geometry_group,
            face_schema
        )
    )

    controller.schedule_objects_for_deletion(bake_geometry_group)
    del bake_geometry_group
    controller.delete_scheduled_objects()
    return data


def process_guide_blueprint(blueprint):
    blueprint = copy.deepcopy(blueprint)
    blueprint['rig_lod'] = 'rig_realtime'
    blueprint['parts'] = process_guide_blueprints(blueprint['parts'])
    return blueprint


def process_rig_blueprint(blueprint):
    blueprint = copy.deepcopy(blueprint)
    blueprint['rig_lod'] = 'rig_realtime'
    blueprint['parts'] = process_guide_blueprints(blueprint['parts'])
    return blueprint


def process_guide_blueprints(part_blueprints):
    exclude_parts = ['DynamicsGuide', 'FaceGuide']
    replace_parts = dict()
    part_blueprints = copy.deepcopy(part_blueprints)
    new_part_blueprints = []
    for part_blueprint in part_blueprints:
        part_klass = part_blueprint['klass']
        if part_klass not in exclude_parts:
            part_blueprint['klass'] = replace_parts.get(part_klass, part_klass)
            if 'parts' in part_blueprint:
                part_blueprint['parts'] = process_guide_blueprints(part_blueprint.pop('parts', []))
            new_part_blueprints.append(part_blueprint)
    return new_part_blueprints


def process_rig_blueprints(part_blueprints):
    part_blueprints = copy.deepcopy(part_blueprints)
    new_part_blueprints = []
    for part_blueprint in part_blueprints:
        part_klass = part_blueprint['klass']
        if part_klass == 'LatticePart':
            part_blueprint['geometry_names'] = []
            part_blueprint['weights'] = {}
    if 'parts' in part_blueprint:
        part_blueprint['parts'] = process_guide_blueprints(part_blueprint.pop('parts', []))
    new_part_blueprints.append(part_blueprint)
    return new_part_blueprints


def bake_face_targets(controller, geometry_group, face_schema):

    geometry_names = face_schema['geometry_names']
    inbetweens = face_schema['inbetweens']
    corrective_data = face_schema['correctives']

    groups_data = []
    face_network = controller.face_network
    if face_network:
        for face_group in face_network.face_groups:
            sorted_face_targets = sorted(face_group.face_targets, key=lambda x: x.driver_value)
            driver_values = [x.driver_value for x in sorted_face_targets]
            baked_driver_values = []
            for i in range(len(driver_values)):
                if inbetweens and i != 0:
                    inbetween_count = inbetweens.get(face_group.segment_name, 0)
                    current_item = driver_values[i]
                    last_item = driver_values[i - 1]
                    for x in range(inbetween_count):
                        baked_driver_values.append(last_item + (current_item - last_item) / (inbetween_count + 1))
                baked_driver_values.append(driver_values[i])
            minimum_driver_value = round(baked_driver_values[0], 3)
            maximum_driver_value = round(baked_driver_values[-1], 3)

            targets_data = []
            for i, driver_value in enumerate(baked_driver_values):
                if driver_value != 0.0:
                    if driver_value > 0.0:
                        weight = rmu.remap_value(
                            driver_value,
                            0.0,
                            maximum_driver_value,
                            0.0,
                            1.0
                        )
                    else:
                        weight = rmu.remap_value(
                            driver_value,
                            minimum_driver_value,
                            0.0,
                            -1.0,
                            0.0
                        )
                    face_group.driver_plug.set_locked(False)
                    face_group.driver_plug.set_value(driver_value)
                    mesh_objects = []
                    for m, face_mesh_name in enumerate(geometry_names):
                        face_mesh = controller.named_objects[face_mesh_name]
                        mesh_parent = face_mesh.parent
                        segment_name = '%s%s%s%s' % (
                                face_mesh.parent.name,
                                face_group.segment_name,
                                rig_factory.index_dictionary[i].upper(),
                                rig_factory.index_dictionary[m].upper()
                            )
                        target_mesh_group = mesh_parent.create_child(
                            obs.Transform,
                            root_name='Bake',
                            segment_name=segment_name,
                            side=face_group.side,
                            parent=geometry_group
                        )
                        new_mesh = controller.copy_mesh(
                            face_mesh.name,
                            target_mesh_group,
                            name='%sShape' % target_mesh_group.name
                        )
                        new_mesh.redraw()
                        mesh_objects.append(new_mesh.name)

                    targets_data.append(dict(
                        weight=round(weight, 3),
                        driver_value=driver_value,
                        mesh_objects=mesh_objects

                    ))
                    face_group.driver_plug.set_value(face_group.initial_value)
                    controller.refresh()

            if targets_data:
                group_data = dict(
                    segment_name=face_group.segment_name,
                    side=face_group.side,
                    targets=targets_data,
                    driver_plug=face_group.driver_plug.name
                )
                groups_data.append(group_data)
            controller.refresh()

        controller.refresh()
        controller.dg_dirty()

        for data in corrective_data:
            node_1, plug_1 = data['plug_values'][0][0].split('.')
            node_2, plug_2 = data['plug_values'][1][0].split('.')
            groups_data.append(
                bake_corrective_target(
                    geometry_names,
                    controller.named_objects[node_1].plugs[plug_1],
                    controller.named_objects[node_2].plugs[plug_2],
                    data['plug_values'][0][1],
                    data['plug_values'][1][1],
                    geometry_group,
                    segment_name=data['segment_name'],
                    side=data['side']
                )
            )
        controller.refresh()
        controller.dg_dirty()

        controller.export_alembic(
            '%s/baked_face.abc' % controller.build_directory,
            geometry_group
        )

    return groups_data


def bake_corrective_target(geometry, plug_1, plug_2, value_1, value_2, parent, **kwargs):
    inbetweens = kwargs.pop('inbetweens', 1)
    segment_name = kwargs.pop('segment_name')
    side = kwargs.get('side', None)
    controller = parent.controller
    default_value_1 = plug_1.get_value()
    default_value_2 = plug_2.get_value()
    target_data = []
    for i in range(inbetweens):
        index_character = rig_factory.index_dictionary[i].upper()
        inbetween_value_1 = float(value_1) / inbetweens * (i+1)
        inbetween_value_2 = float(value_2) / inbetweens * (i+1)
        plug_1.set_value(inbetween_value_1)
        plug_2.set_value(inbetween_value_2)

        mesh_objects = []
        for s, face_mesh in enumerate(geometry):
            target_segment_name = '%s%s%s' % (
                segment_name,
                rig_factory.index_dictionary[i].upper(),
                rig_factory.index_dictionary[s].upper()
            )
            mesh_group = parent.create_child(
                obs.Transform,
                segment_name=target_segment_name,
                side=side
            )
            new_mesh = controller.copy_mesh(
                face_mesh,
                mesh_group,
                name='%sShape' % mesh_group.name
            )
            mesh_objects.append(new_mesh.name)
            controller.refresh()
        target_data.append(
            dict(
                mesh_objects=mesh_objects,
                weight=1.0 / inbetweens * (i+1),
                driver_value=inbetween_value_1,
                secondary_driver_value=inbetween_value_2
            )
        )

    plug_1.set_value(default_value_1)
    plug_2.set_value(default_value_2)
    controller.refresh()
    controller.dg_dirty()

    return dict(
        segment_name=segment_name,
        side=side,
        driver_plug=plug_1.name,
        secondary_driver_plug=plug_2.name,
        targets=target_data,
    )


def create_corrective_driver(plug_1, plug_2, in_value_1, in_value_2, segment_name, side):
    node_1 = plug_1.get_node()

    condition_node = node_1.create_child(
        obs.DependNode,
        node_type='condition',
        segment_name=segment_name,
        side=side
    )

    remap_node_1 = node_1.create_child(
        obs.DependNode,
        node_type='remapValue',
        segment_name='%sA' % segment_name,
        side=side
    )
    remap_node_2 = node_1.create_child(
        obs.DependNode,
        node_type='remapValue',
        segment_name='%sB' % segment_name,
        side=side
    )
    remap_node_1.plugs['value'].element(0).child(0).set_value(0.0)
    remap_node_1.plugs['value'].element(0).child(1).set_value(0.0)
    remap_node_1.plugs['value'].element(1).child(0).set_value(in_value_1)
    remap_node_1.plugs['value'].element(1).child(1).set_value(1.0)
    remap_node_2.plugs['value'].element(0).child(0).set_value(0.0)
    remap_node_2.plugs['value'].element(0).child(0).set_value(0.0)
    remap_node_2.plugs['value'].element(1).child(0).set_value(in_value_2)
    remap_node_2.plugs['value'].element(1).child(1).set_value(1.0)
    plug_1.connect_to(remap_node_1.plugs['inputValue'])
    plug_2.connect_to(remap_node_2.plugs['inputValue'])
    condition_node.plugs['operation'].set_value(5)

    remap_node_1.plugs['outValue'].connect_to(condition_node.plugs['firstTerm'])
    remap_node_2.plugs['outValue'].connect_to(condition_node.plugs['secondTerm'])
    remap_node_1.plugs['outValue'].connect_to(condition_node.plugs['colorIfTrueR'])
    remap_node_2.plugs['outValue'].connect_to(condition_node.plugs['colorIfFalseR'])

    blend_node = node_1.create_child(
        obs.DependNode,
        node_type='blendWeighted',
        segment_name=segment_name,
        side=side
    )

    condition_node.plugs['outColorR'].connect_to(blend_node.plugs['input'].element(0))
    return blend_node.plugs['output']
