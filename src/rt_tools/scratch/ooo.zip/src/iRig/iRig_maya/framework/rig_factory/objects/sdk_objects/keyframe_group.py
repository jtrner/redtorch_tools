from rig_factory.objects.base_objects.properties import DataProperty, ObjectProperty, ObjectListProperty
from rig_factory.objects.base_objects.base_node import BaseNode
from rig_factory.objects.sdk_objects.sdk_keyframe import SDKKeyFrame
from rig_factory.objects.node_objects.plug import Plug


class KeyframeGroup(BaseNode):

    sdk_group = ObjectProperty(
        name='sdk_group'
    )
    keyframes = ObjectListProperty(
        name='keyframes'
    )
    in_value = DataProperty(
        name='in_value'
    )
    in_tangent_type = DataProperty(
        name='in_tangent_type'
    )
    out_tangent_type = DataProperty(
        name='out_tangent_type'
    )

    suffix = 'Kfg'

    def __init__(self, **kwargs):
        super(KeyframeGroup, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        controller.scene.autoKeyframe(state=False)
        sdk_group = kwargs.get('sdk_group', None)
        in_value = kwargs.get('in_value', None)
        isolate = kwargs.get('isolate', True)
        keyframe_data = kwargs.get('keyframe_data', None)

        kwargs.setdefault('parent', sdk_group)
        kwargs.setdefault('root_name', sdk_group.root_name)
        if not isinstance(in_value, float):
            raise Exception(
                'You must provide an "in_value" keyword argument of type "float" to create a %s, %s' % (
                    KeyframeGroup,
                    in_value
                )
            )
        if in_value in [x.in_value for x in sdk_group.keyframe_groups]:
            raise Exception(
                'A keyframe group with the in_value "%s" already exists' % in_value
            )
        kwargs['name'] = '%s_%s' % (
            sdk_group.name,
            len(sdk_group.keyframe_groups) + 1
        )

        # controller.start_sdk_ownership_signal.emit(None, sdk_group)
        this = super(KeyframeGroup, cls).create(controller, **kwargs)
        this.sdk_group = sdk_group
        sdk_group.keyframe_groups.append(this)
        # controller.end_sdk_ownership_signal.emit(this, sdk_group)
        if keyframe_data is not None:
            this.update_from_data(keyframe_data)
        else:
            if isolate:
                this.sdk_group.isolate()
            this.update()
        return this

    def update_from_data(self, keyframe_data):
        """
        Creates keys based on the provided data
        """

        sdk_group = self.sdk_group
        all_plugs = [x[0] for x in keyframe_data]
        if len(all_plugs) != len(list(set(all_plugs))):
            raise Exception('Duplicate plugs found: %s' % all_plugs)
        for plug, value in keyframe_data:
            plug = find_plug_object(self.controller, plug)
            if plug:
                animation_curve = self.sdk_group.get_animation_curve(plug)
                if self.in_value != 0.0 and 0.0 not in animation_curve.keyframes:
                    """
                    When a Non-zero key is being set,
                    and a key with a 0.0 driven value does not exist on the curve,
                    create a key with the driven value of 0.0 to hold the default pose
                    """
                    zero_group = dict((x.in_value, x) for x in self.sdk_group.keyframe_groups).get(0.0, None)
                    if zero_group:
                        zero_keyframe = zero_group.create_child(
                            SDKKeyFrame,
                            animation_curve=animation_curve,
                            in_value=0.0,
                            out_value=0.0,
                            parent=animation_curve
                        )
                        zero_group.keyframes.append(zero_keyframe)
                new_keyframe = sdk_group.create_child(
                    SDKKeyFrame,
                    animation_curve=animation_curve,
                    in_value=self.in_value,
                    out_value=value,
                    parent=animation_curve
                )
                self.keyframes.append(new_keyframe)

    def update(self):
        """
        Creates keyframes based on the driven plugs current positions and other near-by keys

        """
        sdk_group = self.sdk_group
        for driven_plug in sdk_group.sdk_network.driven_plugs:
            animation_curve = sdk_group.animation_curves.get(driven_plug.name, None)
            current_value = driven_plug.get_value()
            default_value = driven_plug.default_value
            if not animation_curve and abs(round(current_value - default_value, 5)) == 0.0 and abs(round(default_value, 5)) == 0.0:
                """
                If NO animation curve yet,
                and current value is zero (relative to default),
                and default value is zero,
                Nothing has changed, no need to do set key on this plug
                """
                continue
            """
            Check for neighbouring KeyframeGroups
            """
            previous_driver_value = float('-inf')
            next_driver_value = float('inf')
            next_key_group = None
            previous_key_group = None
            for key_group in sdk_group.keyframe_groups:
                if key_group != self:
                    if key_group.in_value > previous_driver_value < self.in_value:
                        previous_driver_value = key_group.in_value
                        previous_key_group = key_group
                    elif key_group.in_value < next_driver_value > self.in_value:
                        next_driver_value = key_group.in_value
                        next_key_group = key_group
            """
            Check for non-zero neighbouring Keyframes on the curve
            """
            non_zero_neighbors = False
            if animation_curve:
                if previous_key_group:
                    if previous_driver_value in animation_curve.keyframes:
                        if animation_curve.keyframes[previous_driver_value].out_value != 0.0:
                            non_zero_neighbors = True
                if next_key_group:
                    if next_driver_value in animation_curve.keyframes:
                        if animation_curve.keyframes[next_driver_value].out_value != 0.0:
                            non_zero_neighbors = True
            current_keyframe = None
            if animation_curve and self.in_value in animation_curve.keyframes:
                """
                If Keyframe already exists,
                Re-Key It! (at the driven plugs current value!)
                """
                current_keyframe = animation_curve.keyframes[self.in_value]
                self.controller.change_keyframe(
                    current_keyframe,
                    out_value=driven_plug.get_value() - default_value
                )
            if not current_keyframe and abs(round(current_value - default_value, 11)) != 0.0:
                """
                If no keyframe has been created yet,
                and current driven plug value is not zero,
                Key It!
                """
                animation_curve = self.sdk_group.get_animation_curve(driven_plug)
                current_keyframe = sdk_group.create_child(
                    SDKKeyFrame,
                    animation_curve=animation_curve,
                    in_value=self.in_value,
                    out_value=current_value-default_value,
                    parent=animation_curve
                )
                self.keyframes.append(current_keyframe)
            if not current_keyframe and abs(round(default_value, 11)) != 0.0 and animation_curve is None:
                """
                If no keyframe has been created yet,
                and default driven plug value is not zero,
                and no curve/keys exist yet,
                Create a curve and Key It!
                """
                animation_curve = self.sdk_group.get_animation_curve(driven_plug)
                current_keyframe = sdk_group.create_child(
                    SDKKeyFrame,
                    animation_curve=animation_curve,
                    in_value=self.in_value,
                    out_value=0.0,
                    parent=current_keyframe
                )
                self.keyframes.append(current_keyframe)
            if not current_keyframe and non_zero_neighbors:
                """
                If no keyframe has been created yet,
                and there are neighbouring keys with non-zero values,
                Key It!
                """
                animation_curve = self.sdk_group.get_animation_curve(driven_plug)
                current_keyframe = sdk_group.create_child(
                    SDKKeyFrame,
                    animation_curve=animation_curve,
                    in_value=self.in_value,
                    out_value=0.0,
                    parent=animation_curve
                )
                self.keyframes.append(current_keyframe)
            all_curve_in_values = animation_curve.keyframes.keys()

            if next_key_group and next_driver_value not in all_curve_in_values:
                """
                If the neighbouring (NEXT) KeyframeGroup driver value is not represented in the animation curve,
                Key It! (with the DRIVER value of the KeyframeGroup and DRIVEN value of 0.0)
                """
                # print("Next key --->> ", driven_plug, next_driver_value)
                next_keyframe = next_key_group.create_child(
                    SDKKeyFrame,
                    animation_curve=animation_curve,
                    in_value=next_driver_value,
                    out_value=0.0,
                    parent=animation_curve
                )
                next_key_group.keyframes.append(next_keyframe)

            if previous_key_group and previous_driver_value not in all_curve_in_values:
                """
                If the neighbouring (PREVIOUS) KeyframeGroup driver value is not represented in the animation curve,
                Key It! (with the DRIVER value of the KeyframeGroup and DRIVEN value of 0.0)
                """
                # print("Previous key --->> ", driven_plug, next_driver_value)
                previous_keyframe = previous_key_group.create_child(
                    SDKKeyFrame,
                    animation_curve=animation_curve,
                    in_value=previous_driver_value,
                    out_value=0.0,
                    parent=animation_curve
                )
                previous_key_group.keyframes.append(previous_keyframe)

            driven_plug.get_value()  # Clean The Graph

    def set_keyframe_tangents(self, tangent_type):

        self.in_tangent_type = tangent_type
        self.out_tangent_type = tangent_type

        self.controller.change_keyframe(
            self,
            in_tangent=tangent_type,
            out_tangent=tangent_type
        )

    def teardown(self):

        self.controller.start_sdk_disown_signal.emit(self, self.sdk_group)
        curve_names = [key.animation_curve.name for key in self.keyframes]
        self.controller.schedule_objects_for_deletion(self.keyframes)
        if curve_names and self.keyframes:
            self.controller.scene.select(cl=True)
            self.controller.scene.selectKey(*curve_names, cl=True)

            self.controller.scene.selectKey(
                [key.animation_curve.name for key in self.keyframes],
                float=(self.in_value,),
                keyframe=True
            )

            self.controller.scene.cutKey(
                animation='keys',
                clear=True,
            )
        self.keyframes = []

        sdk_group = self.sdk_group
        self.sdk_group.keyframe_groups.remove(self)
        self.sdk_group = None
        super(KeyframeGroup, self).teardown()
        self.controller.end_sdk_disown_signal.emit(self, sdk_group)


def find_plug_object(controller, plug):
    if isinstance(plug, Plug):
        return plug
    elif isinstance(plug, basestring):
        node_name, attribute_name = plug.split('.')
        if node_name in controller.named_objects:
            node = controller.named_objects[node_name]
            if node.plugs.exists(attribute_name):
                return node.plugs[attribute_name]

