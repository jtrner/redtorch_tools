import shutil
import os
import glob
import json
import subprocess
import rig_factory.build.utilities.blueprint_utilities as but
import rig_factory.build.utilities.asset_info_utilities as ast
import rig_factory.build.utilities.finalize as fin
import rig_factory.object_versions as obs
import rig_factory.build.build as brg
import rig_factory.utilities.file_utilities as fut


def mock_publish_rig(controller, log=None, build_face=True, comment=None, **kwargs):
    import log_tools
    log = log_tools.access(log)

    but.execute_blueprints(controller, log=log, build_face=build_face)
    if comment is None:
        comment = 'mock_test'
    save_work_scene(
        controller,
        major_version_up=False,
        comment=comment
    )
    ast.add_asset_info_node(controller, log=log)
    fin.finalize(controller)


def publish_rig(controller, log=None, build_face=True, comment=None, **kwargs):
    import shotgun
    sg = shotgun.connect()
    import log_tools
    log = log_tools.access(log)
    but.execute_blueprints(controller, log=log, build_face=build_face)

    save_work_scene(
        controller,
        major_version_up=True,
        comment=comment
    )
    ast.add_asset_info_node(controller, log=log)
    fin.finalize(controller)
    publish_build_directory(controller, log=log)
    controller.reset()
    controller.__del__()  # Disconnect save callbacks
    major_version, minor_version = fut.get_current_work_versions()
    save_rig_product(controller, major_version, log=log)
    version_string = "v%s" % major_version
    sg.create('Version', {
        'code': '%s Rig %s' % (os.environ['TT_ENTNAME'], version_string),
        'description': str(comment),
        'entity': {'type': "Asset", 'id': int(os.environ['TT_ENTID'])},
        'user': {'id': int(os.environ['TT_USERID']), 'type': 'HumanUser'},
        'project': {'type': 'Project', 'id': int(os.environ['TT_PROJID'])},
        'sg_path_to_frames': None,
        'sg_path_to_movie': None,
        'image': None,
        'sg_first_frame': None,
        'sg_last_frame': None,
        'sg_movie_has_slate': False,
        'sg_task': {'type': 'Task', 'id': int(os.environ['TT_TASKID'])},
        'sg_product_information': None,
        'sg_version_number': int(major_version),
        'tags': [],
        'published_files': []
    })

    shotgun.updateStatus(
        sg,
        'rev',
        taskId=int(os.environ['TT_TASKID'])
    )
    log.info('Shotgun Version complete. %s' % '%s  %s' % (os.environ['TT_ENTNAME'], version_string))


def publish_build_directory(controller, log=None):
    import log_tools
    log = log_tools.access(log)
    log.info('Copying over build directory')
    if not os.path.exists(controller.build_directory):
        raise IOError('build directory not found: %s' % controller.build_directory)
    major_version, minor_version = fut.get_next_versions()
    build_product_directory = '%s/rig_build' % fut.get_products_directory()
    if not os.path.exists(build_product_directory):
        os.makedirs(build_product_directory)
    pub_builds_directory = '%s/rig_build_v%s' % (
        build_product_directory,
        major_version
    )
    if os.path.exists(pub_builds_directory):
        shutil.rmtree(pub_builds_directory)
        log.critical('WARNING: published builds directory already existed.. Replacing.')
    shutil.copytree(
        controller.build_directory,
        pub_builds_directory
    )
    temp_text_file_directory = '%s/TEMP_FILE_FOR_FOLDER_DATE_TIME.txt' % pub_builds_directory
    with open(temp_text_file_directory, mode='w') as f:
        f.write('This is a test')
    os.remove(temp_text_file_directory)
    log.info('Publish build directory complete: %s' % pub_builds_directory)


def save_rig_product(controller, version, log=None):
    import log_tools
    log = log_tools.access(log)
    products_directory = '%s/rig' % fut.get_products_directory()
    if not os.path.exists(products_directory):
        os.makedirs(str(products_directory))
    ext = '.mb' if os.environ.get('TT_MAYAFILETYPE') == 'mayaBinary' else '.ma'
    file_name = os.environ['TT_ENTNAME'] + '_rig_v' + version + ext
    pub_file = '%s/%s' % (products_directory, file_name)
    log.info('Publish file:', type(pub_file), pub_file)
    if os.path.exists(pub_file):
        controller.raise_warning('Product "%s" already existed. Overwriting file.' % pub_file)
    controller.scene.file(rn=str(pub_file))
    controller.scene.file(save=True, force=True, type='mayaAscii')
    controller.raise_warning('Success! created rig product: %s' % pub_file)
    log.info('Save rig product complete: %s' % pub_file)
    return pub_file


def add_comment(version, comment):
    comments_directory = '%s/comments' % fut.get_logs_directory()
    comments_json = '%s/%s_rig_comments.json' % (comments_directory, os.environ['TT_ENTNAME'])
    comments_data = dict()
    if os.path.exists(comments_json):
        with open(comments_json, mode='r') as f:
            comments_data = json.load(f)
    comments_data[version] = comment
    with open(comments_json, mode='w') as f:
        json.dump(comments_data, f, sort_keys=True, indent=4, separators=(',', ': '))


def save_work_scene(controller, major_version_up=False, comment=None, **kwargs):

    wip_directory = fut.get_user_work_directory()

    if not os.path.exists(wip_directory):
        os.makedirs(str(wip_directory))
    ext = '.mb' if os.environ.get('TT_MAYAFILETYPE') == 'mayaBinary' else '.ma'
    major_version,  minor_version = fut.get_next_versions(
        major_version_up=major_version_up
    )
    file_name = os.environ['TT_ENTNAME'] + '_rig_v' + major_version + '.' + minor_version + ext
    wip_file = '%s/%s' % (wip_directory, file_name)
    if os.path.exists(wip_file):
        controller.raise_warning('Product "%s" already existed. Overwriting file.' % file_name)
    controller.scene.file(rn=wip_file)
    controller.scene.file(save=True, force=True, type='mayaAscii')
    version_up_build_directory(controller)
    print 'Created work file: %s' % wip_file
    if comment:
        add_comment('v%s.%s' % (major_version, minor_version), comment)
    return wip_file


def version_up_build_directory(controller, log=None):
    import log_tools
    log = log_tools.access(log)

    evaluation_mode = str(controller.scene.evaluationManager(q=True, mode=True)[0])
    controller.scene.evaluationManager(mode="off")

    log.info(
        'Found controller root node: %s name="%s"' % (
            type(controller.root),
            controller.root.get_selection_string()
        )
    )

    if controller.currently_saving:
        raise Exception('A save is already in progress')
    if isinstance(controller.root, obs.Container) and controller.root.has_been_finalized:
        raise Exception('The rig has been finalized.\nA blueprint cannot be saved.')
    if isinstance(controller.face_network, obs.FaceNetwork) and controller.face_network.has_been_finalized:
        raise Exception('The face has been finalized.\nA bluprint cannot be saved.')

    controller.currently_saving = True

    scene_name = controller.scene.file(q=True, sn=True)

    if not os.path.exists(scene_name):
        raise Exception('Save Callback Failed. Check script editor for details')

    versioned_directory_name_base_name = os.path.basename(scene_name).replace('.ma', '').replace('.mb', '')

    user_build_directory = fut.get_user_build_directory()

    current_build_directory = controller.build_directory

    if user_build_directory != current_build_directory:
        if os.path.exists(user_build_directory):
            proc = subprocess.Popen(
                'rmdir /s/q "%s"' % user_build_directory,
                shell=True
            )
            proc.wait()
        try:
            proc = subprocess.Popen(
                'robocopy %s %s /E /S' % (
                    current_build_directory,
                    user_build_directory,
                ),
                shell=True
            )
            proc.wait()

        except Exception, e:
            controller.raise_warning('Windows Network Drive Error. unable to copy %s to %s' % (
                current_build_directory,
                user_build_directory
            ))
            raise e
    elif not os.path.isdir(user_build_directory):
        os.makedirs(user_build_directory)

    try:
        rig_blueprint_path = '%s/rig_blueprint.json' % user_build_directory
        with open(rig_blueprint_path, mode='w') as f:
            json.dump(
                controller.get_blueprint(controller.root),
                f,
                sort_keys=True,
                indent=4,
                separators=(',', ': ')
            )
            log.info('Rig blueprint exported to: %s' % rig_blueprint_path)
    except Exception as e:
        controller.currently_saving = False
        raise e
    if controller.face_network:
        face_blueprint_path = '%s/face_blueprint.json' % user_build_directory
        controller.export_face_blueprint(file_name=face_blueprint_path)
        log.info('Face blueprint exported to: %s' % face_blueprint_path)

    #  Copy build script
    build_script_path = '%s/build.py' % user_build_directory
    standard_build_script_path = brg.__file__.replace('\\', '/').replace('.pyc', '.py')
    if not os.path.exists(build_script_path):
        shutil.copyfile(
            standard_build_script_path,
            build_script_path
        )

    version_directory = '%s_versions/%s' % (
        user_build_directory,
        versioned_directory_name_base_name
    )

    if os.path.isdir(version_directory):
        proc = subprocess.Popen(
            'rmdir /s/q "%s"' % version_directory,
            shell=True
        )
        proc.wait()

    proc = subprocess.Popen(
        'robocopy %s %s /E /S' % (
            user_build_directory,
            version_directory
        ),
        shell=True
    )
    proc.wait()

    temp_text_file_directory = '%s/TEMP_FILE_FOR_FOLDER_DATE_TIME.txt' % version_directory
    with open(temp_text_file_directory, mode='w') as f:
        f.write('This is a test')
    os.remove(temp_text_file_directory)
    controller.build_directory = user_build_directory
    controller.scene_got_saved_signal.emit(scene_name)
    # except Exception, e:
    #     controller.raise_warning('Callback Error. SAVE FAILED!: \n%s' % e.message)
    #     controller.currently_saving = False
    #     controller.scene.evaluationManager(mode=evaluation_mode)
    #     raise
    controller.currently_saving = False
    controller.scene.evaluationManager(mode=evaluation_mode)

