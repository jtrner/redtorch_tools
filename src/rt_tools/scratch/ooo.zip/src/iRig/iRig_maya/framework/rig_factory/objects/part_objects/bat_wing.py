from rig_factory.objects.part_objects.base_wing import BaseWing, BaseWingGuide


class BatWingGuide(BaseWingGuide):

    default_settings = {
        'root_name': 'Wing',
        'size': 1.0,
        'side': 'left',
        'primary_digit_count': 4,
        'secondary_digit_count': 1,
        'tertiary_digit_count': 1

    }

    def __init__(self, **kwargs):
        super(BatWingGuide, self).__init__(**kwargs)
        self.toggle_class = BatWing.__name__

class BatWing(BaseWing):

    def finish_create(self, **kwargs):
        super(BatWing, self).finish_create()
