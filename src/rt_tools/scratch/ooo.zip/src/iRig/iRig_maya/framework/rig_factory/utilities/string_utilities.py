def underscore_to_camelcase(value):
    if value[0].isupper():
        new_name = value.replace('_', '')
        return new_name

    def camelcase():
        while True:
            yield str.capitalize

    c = camelcase()
    new_name = "".join(c.next()(str(x)) if x else '_' for x in value.split("_"))
    return new_name
