from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.depend_node import DependNode
import rig_factory.environment as env
from rig_factory.objects.rig_objects.line import Line
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.base_objects.properties import ObjectProperty
from rig_factory.objects.part_objects.handle import HandleGuide
import rig_factory.positions as pos
from rig_math.matrix import Matrix
from rig_math.vector import Vector


class EyeGuide(HandleGuide):

    default_settings = dict(
        root_name='Eye',
        size=1.0,
        side='left'
    )

    def __init__(self, **kwargs):
        super(EyeGuide, self).__init__(**kwargs)
        self.toggle_class = Eye.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(EyeGuide, cls).create(controller, **kwargs)
        eye_joint = this.joints[0]
        lid_joint = this.create_child(
            Joint,
            segment_name='Lid',
            matrix=eye_joint.get_matrix()
        )
        lid_joint.zero_rotation()
        lid_joint.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
            radius=0.0
        )
        eye_joint.plugs['translate'].connect_to(lid_joint.plugs['translate'])
        this.joints.append(lid_joint)
        this.set_handle_positions(pos.BIPED_POSITIONS)
        return this


class Eye(Part):

    arrow_handle = ObjectProperty(
        name='arrow_handle'
    )

    aim_handle = ObjectProperty(
        name='aim_handle'
    )


    def __init__(self, **kwargs):
        super(Eye, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(Eye, cls).create(controller, **kwargs)
        size = this.size
        matrix = this.matrices[0]

        eye_joint = this.create_child(
            Joint,
            matrix=matrix,
            parent=this.joint_group
        )
        lid_joint = eye_joint.create_child(
            Joint,
            segment_name='Lid',
            matrix=matrix
        )
        lid_locator = lid_joint.create_child(Locator)
        lid_locator.plugs['visibility'].set_value(False)
        eye_arrow = this.create_handle(
            shape='arrow',
            size=size * 4,
            matrix=matrix,
            segment_name='Base'
        )
        aim_vector = Vector([matrix.data[1][0], matrix.data[1][1], matrix.data[1][2]])
        aim_position = matrix.get_translation() + (aim_vector * (20.0*size))
        eye_aim_handle = this.create_handle(
            shape='teardrop',
            size=size,
            matrix=Matrix(aim_position),
            segment_name='Aim',
            axis='y'
        )
        eye_up_transform = this.create_child(
            Transform,
            segment_name='UpAxis',
            matrix=Matrix(matrix.get_translation() + Vector([0.0, 5.0*size, 0.0]))
        )
        eye_joint.zero_rotation()
        lid_joint.zero_rotation()
        eye_joint.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
            radius=0.0
        )
        lid_joint.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
            radius=0.0
        )
        aim_matrix = eye_aim_handle.get_matrix()

        lid_aim_group = this.create_child(
            Transform,
            segment_name='LidTop',
            matrix=aim_matrix
        )
        lid_aim_transform = lid_aim_group.create_child(
            Transform,
            segment_name='LidAim',
            matrix=aim_matrix,
        )
        lid_aim_getter = lid_aim_group.create_child(
            Transform,
            segment_name='LidAimGetter',
            matrix=aim_matrix
        )
        lid_aim_multiply = lid_aim_group.create_child(
            DependNode,
            node_type='multiplyDivide',
            matrix=aim_matrix
        )
        controller.create_parent_constraint(
            eye_arrow,
            eye_joint
        )
        controller.create_aim_constraint(
            eye_aim_handle,
            eye_arrow.groups[2],
            aimVector=env.aim_vector,
            upVector=env.up_vector,
            worldUpType='object',
            worldUpObject=eye_up_transform
        )
        controller.create_aim_constraint(
            lid_aim_transform,
            lid_joint,
            aimVector=env.aim_vector,
            upVector=env.up_vector,
            worldUpType='object',
            worldUpObject=eye_up_transform
        )
        controller.create_point_constraint(
            eye_aim_handle,
            lid_aim_getter,
            mo=False
        )
        lid_aim_getter.plugs['translate'].connect_to(lid_aim_multiply.plugs['input1'])
        lid_aim_multiply.plugs['input2'].set_value([0.25, 0.25, 0.75])
        lid_aim_multiply.plugs['output'].connect_to(lid_aim_transform.plugs['translate'])
        locator_1 = eye_joint.create_child(Locator)
        locator_2 = eye_aim_handle.create_child(Locator)

        line = this.create_child(Line)
        locator_1.plugs['worldPosition'].element(0).connect_to(line.curve.plugs['controlPoints'].element(0))
        locator_2.plugs['worldPosition'].element(0).connect_to(line.curve.plugs['controlPoints'].element(1))
        locator_1.plugs['visibility'].set_value(False)
        locator_2.plugs['visibility'].set_value(False)

        root = this.get_root()
        if root:
            root.add_plugs(
                [
                    eye_arrow.plugs['rx'],
                    eye_arrow.plugs['ry'],
                    eye_arrow.plugs['rz'],
                    eye_aim_handle.plugs['tx'],
                    eye_aim_handle.plugs['ty'],
                    eye_aim_handle.plugs['tz'],
                    eye_aim_handle.plugs['rz'],
                    eye_aim_handle.plugs['sx'],
                    eye_aim_handle.plugs['sy'],
                    eye_aim_handle.plugs['sz'],

                ]
            )
        this.arrow_handle = eye_arrow
        this.aim_handle = eye_aim_handle
        this.joints = [eye_joint, lid_joint]
        return this
