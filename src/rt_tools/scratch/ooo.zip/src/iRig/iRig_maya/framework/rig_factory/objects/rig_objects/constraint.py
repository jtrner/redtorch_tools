from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.base_objects.properties import DataProperty, ObjectProperty, ObjectListProperty


class Constraint(Transform):

    transform = ObjectProperty(
        name='transform'
    )

    targets = ObjectListProperty(
        name='targets'
    )

    create_kwargs = DataProperty(
        name='create_kwargs'
    )

    suffix = 'Cns'

    @classmethod
    def create(cls, controller, *args, **kwargs):
        targets = args[0:-1]
        transform = args[-1]
        if not isinstance(transform, Transform):
            raise Exception('You cannot constrain a "%s"' % type(transform))
        if not transform.segment_name:
            raise Exception('You cannot constrain a transform without a segment_name')
        # for t in targets:
        #     if not isinstance(t, Transform):
        #         raise Exception('You cannot constrain to a "%s"' % type(t))
        parent = kwargs.pop('parent', transform)
        kwargs['create_kwargs'] = dict(kwargs)
        kwargs.setdefault('root_name', transform.root_name)
        kwargs['segment_name'] = transform.segment_name
        kwargs['differentiation_name'] = transform.differentiation_name

        if transform.functionality_name and transform.suffix:
            kwargs.setdefault('functionality_name', '%s%s' % (
                transform.functionality_name,
                transform.suffix
            ))
        elif transform.functionality_name:
            kwargs.setdefault('functionality_name', transform.functionality_name)
        elif transform.suffix:
            kwargs.setdefault('functionality_name', transform.suffix)

        kwargs.setdefault('index', transform.index)
        kwargs.setdefault('side', transform.side)
        kwargs['parent'] = parent
        kwargs['transform'] = transform  # must exist in kwargs because of create_in_scene()
        kwargs['targets'] = targets  # must exist in kwargs because of create_in_scene()
        this = super(Constraint, cls).create(controller, **kwargs)
        return this

    def __init__(self, **kwargs):
        super(Constraint, self).__init__(**kwargs)

    def create_in_scene(self):
        transforms = list(self.targets)
        transforms.append(self.transform)
        self.m_object = self.controller.scene.create_constraint(
            self.node_type,
            name=self.name,
            parent=self.parent.m_object,
            *[x.m_object for x in transforms],
            **self.create_kwargs
        )

    def get_weight_plug(self, target):
        return self.plugs['%sW%s' % (target, self.targets.index(target))]


class ParentConstraint(Constraint):

    suffix = 'Prc'

    def __init__(self, **kwargs):
        super(ParentConstraint, self).__init__(**kwargs)
        self.node_type = 'parentConstraint'

    @classmethod
    def create(cls, controller, *args, **kwargs):
        if len(args) < 2:
            raise Exception(
                'Cannot make %s with less than 2 transforms passed arguments' % cls.__name__
            )
        if not all([isinstance(x, Transform) for x in args]):
            raise Exception(
                'You Exception use "Transform" as arguments when you create a "%s"' % cls.__name__
            )
        return super(ParentConstraint, cls).create(controller, *args, **kwargs)


class PointConstraint(Constraint):

    suffix = 'Poc'

    def __init__(self, **kwargs):
        super(PointConstraint, self).__init__(**kwargs)
        self.node_type = 'pointConstraint'

    @classmethod
    def create(cls, controller, *args, **kwargs):
        if len(args) < 2:
            raise Exception(
                'Cannot make %s with less than 2 transforms passed arguments' % cls.__name__
            )
        if not all([isinstance(x, Transform) for x in args]):
            raise Exception(
                'You Exception use "Transform" as arguments when you create a "%s"' % cls.__name__
            )
        return super(PointConstraint, cls).create(controller, *args, **kwargs)


class ScaleConstraint(Constraint):

    suffix = 'Scc'

    def __init__(self, **kwargs):
        super(ScaleConstraint, self).__init__(**kwargs)
        self.node_type = 'scaleConstraint'

    @classmethod
    def create(cls, controller, *args, **kwargs):
        if len(args) < 2:
            raise Exception(
                'Cannot make %s with less than 2 transforms passed arguments' % cls.__name__
            )
        if not all([isinstance(x, Transform) for x in args]):
            raise Exception(
                'You Exception use "Transform" as arguments when you create a "%s"' % cls.__name__
            )
        return super(ScaleConstraint, cls).create(controller, *args, **kwargs)


class AimConstraint(Constraint):

    world_up_object = ObjectProperty(
        name='world_up_object'
    )

    suffix = 'Acn'

    def __init__(self, **kwargs):
        super(AimConstraint, self).__init__(**kwargs)
        self.node_type = 'aimConstraint'

    @classmethod
    def create(cls, controller, *args, **kwargs):
        up_object = kwargs.pop('worldUpObject', None)
        if up_object:
            kwargs['worldUpObject'] = str(up_object)
        if len(args) < 2:
            raise Exception(
                'Cannot make %s with less than 2 transforms passed arguments' % cls.__name__
            )
        if not all([isinstance(x, Transform) for x in args]):
            raise Exception(
                'You must use "Transform" as arguments when you create a "%s"' % cls.__name__
            )
        return super(AimConstraint, cls).create(controller, *args, **kwargs)


class OrientConstraint(Constraint):

    suffix = 'Ocn'

    def __init__(self, **kwargs):
        super(OrientConstraint, self).__init__(**kwargs)
        self.node_type = 'orientConstraint'

    @classmethod
    def create(cls, controller, *args, **kwargs):
        if len(args) < 2:
            raise Exception(
                'Cannot make %s with less than 2 transforms passed arguments' % cls.__name__
            )
        if not all([isinstance(x, Transform) for x in args]):
            raise Exception(
                'You Exception use "Transform" as arguments when you create a "%s"' % cls.__name__
            )
        return super(OrientConstraint, cls).create(controller, *args, **kwargs)


class PoleVectorConstraint(Constraint):

    suffix = 'Pvc'

    def __init__(self, **kwargs):
        super(PoleVectorConstraint, self).__init__(**kwargs)
        self.node_type = 'poleVectorConstraint'

    @classmethod
    def create(cls, controller, *args, **kwargs):
        if len(args) < 2:
            raise Exception(
                'Cannot make %s with less than 2 transforms passed arguments' % cls.__name__
            )
        if not all([isinstance(x, Transform) for x in args]):
            raise Exception(
                'You Exception use "Transform" as arguments when you create a "%s"' % cls.__name__
            )
        return super(PoleVectorConstraint, cls).create(controller, *args, **kwargs)


class TangentConstraint(Constraint):

    suffix = 'Tnc'

    def __init__(self, **kwargs):
        super(TangentConstraint, self).__init__(**kwargs)
        self.node_type = 'tangentConstraint'

    @classmethod
    def create(cls, controller, *args, **kwargs):
        if len(args) < 2:
            raise Exception(
                'Cannot make %s with less than 2 objects passed arguments' % cls.__name__
            )
        if len(args) > 2:
            raise Exception(
                'Cannot make %s with more than 2 objects passed arguments' % cls.__name__
            )
        if not isinstance(args[0], NurbsCurve):
            raise Exception(
                'You must use "NurbsCurve" as first argument when you create a "%s"' % cls.__name__
            )
        if not isinstance(args[1], Transform):
            raise Exception(
                'You Exception use "Transform" as second argument when you create a "%s"' % cls.__name__
            )
        return super(TangentConstraint, cls).create(controller, *args, **kwargs)

