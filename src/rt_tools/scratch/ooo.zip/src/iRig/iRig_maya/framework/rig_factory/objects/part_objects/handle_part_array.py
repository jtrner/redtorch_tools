import rig_factory
from rig_factory.objects.part_objects.handle import HandleGuide, Handle
from rig_factory.objects.part_objects.part_array import PartArrayGuide, PartArray
from rig_factory.objects.base_objects.properties import DataProperty


class HandlePartArrayGuide(PartArrayGuide):

    count = DataProperty(
        name='count'
    )

    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    shape = DataProperty(
        name='shape'
    )

    default_settings = dict(
        root_name='HandlePart',
        count=3,
        size=1.0,
        mirror=False,
        side='center',
        shape='cube',
        create_gimbal=False
    )
    
    def __init__(self, **kwargs):
        super(HandlePartArrayGuide, self).__init__(**kwargs)
        self.toggle_class = HandlePartArray.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(HandlePartArrayGuide, cls).create(controller, **kwargs)
        return this

    def create_members(self, **kwargs):
        for i in range(self.count):
            handlepart=self.create_part(
                                        HandleGuide,
                                        root_name=self.root_name + rig_factory.index_dictionary[i].title(),
                                        side=self.side,
                                        size=self.size,
                                        shape=self.shape,
                                        create_gimbal=self.create_gimbal
                                        )

            handlepartlist = handlepart.get_handles()

            for handle in handlepartlist:
                if self.side == 'right':
                    handle.plugs['tx'].set_value(self.size * i * -1)
                elif self.side == 'left':
                    handle.plugs['tx'].set_value(self.size * i )
                else:
                    handle.plugs['ty'].set_value(handle.plugs['ty'].get_value()+self.size * i * 1)
                    print handle


class HandlePartArray(PartArray):
    @classmethod
    def create(cls, controller, **kwargs):
        this = super(HandlePartArray, cls).create(controller, **kwargs)
        return this

    def __init__(self, **kwargs):
        super(HandlePartArray, self).__init__(**kwargs)
        self.joint_chain = False


