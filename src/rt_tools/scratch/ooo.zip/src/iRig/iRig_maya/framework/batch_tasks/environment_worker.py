import sys
import os
import copy
import logging
import traceback

def do_task(data):
    project, entity, options = copy.copy(data)
    dev_mode = options.pop('dev_mode', False)
    import batch_tasks.rigging_environment as rev
    rev.load_system_paths(dev_mode=dev_mode)
    rev.load_rigging_environment(
        project,
        entity,
        dev_mode=dev_mode
    )
    import rig_factory.utilities.file_utilities as fut

    user_logs_directory = '%s/logs' % fut.get_user_work_directory()
    if not os.path.exists(user_logs_directory):
        os.makedirs(user_logs_directory)
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)
    logging.basicConfig(
        filename='%s/batch.log' % user_logs_directory,
        level=logging.DEBUG
    )

    try:

        if options.get('standalone', False):
            import maya.standalone
            maya.standalone.initialize(name='python')

        import rig_factory.utilities.save_utilities as sut
        import rig_factory.build.utilities.vanilla_publish_utilities as put

        script_path = options.get('script_path', None)
        if script_path:
            raise Exception('Script path not supported')

        # controller = None

        # if not script_path:
        import batch_tasks.build_rigs as brg
        controller = brg.build_rig(**options)

        # else:
        #     if not script_path.endswith('.py'):
        #         raise Exception('"script_path" must be .py extension')
        #     base_name = os.path.basename(script_path)
        #     directory_name = os.path.dirname(script_path)
        #     sys.path.append(directory_name)
        #     name = '.'.join(base_name.split('.py')[0:-1])
        #     module = __import__(name)
        #     if not hasattr(module, 'run'):
        #         raise Exception('The module %s has no function "run"' % name)
        #     getattr(module, 'run')(project, entity, **options)

        if not controller:
            raise Exception('No controller returned from function')
        if options.get('mock_publish', False):
            assert controller
            assert controller.root
            sut.mock_publish_rig(
                controller,
                **options
                )

        elif options.get('publish', False):
            assert controller
            assert controller.root
            sut.publish_rig(
                controller,
                **options
                )
        elif options.get('save', False):
            print '>>>>>>>  Save rig...'
            assert controller
            assert controller.root
            sut.save_work_scene(
                controller,
                **options
            )
        # else:
        #     if options.get('publish', False):
        #         put.publish_rig(
        #             **options
        #             )
        #     elif options.get('save', False):
        #         put.save_work_scene(
        #             **options
        #         )

        logging.info(traceback.print_exc())
        logging.info('Success! Built: %s' % entity)
        return entity

    except Exception, e:
        logging.critical(traceback.print_exc())
        logging.critical('Failed to build : %s' % entity)
        raise e