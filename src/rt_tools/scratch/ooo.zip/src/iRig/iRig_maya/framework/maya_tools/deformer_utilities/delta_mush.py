import maya_tools.deformer_utilities.general as gtl
import maya_tools.utilities.decorators as dec
import maya.cmds as mc


def get_delta_mush_nodes(*geometry):
    delta_mush_nodes = []
    for mesh in geometry:
        delta_mush_nodes.extend(gtl.find_deformer_nodes(mesh, 'deltaMush'))
    return list(set(delta_mush_nodes))


@dec.m_object_arg
def get_delta_mush_data(delta_mush_node):
    """
    Create and return a dictionary of delta mush values:
        - name: delta mush node's name
        - geometry: nodes effected by the delta mush
        - plug_values: delta mush node attribute values
        - weights: delta mush weights (list)
    :param mesh: (transform) - node to retrieve delta mesh data from
    :return: (dict) - delta mush data
    """
    node_name = gtl.get_selection_string(delta_mush_node)

    geometry = mc.deltaMush(node_name, q=True, g=True)
    if geometry and len(geometry) > 1:
        raise Exception('Delta mush deformer had multiple pieces of geometry.. only one is currently supported')
    plug_values_dict = {}
    attrs_to_save = [
        'smoothingIterations',
        'smoothingStep',
        'inwardConstraint',
        'outwardConstraint',
        'distanceWeight',
        'displacement',
        'scaleX',
        'scaleY',
        'scaleZ'
    ]

    for attr in attrs_to_save:
        val = mc.getAttr('{node}.{attr}'.format(node=node_name, attr=attr))
        plug_values_dict[str(attr)] = val
    return dict(
        name=node_name,
        geometry=mc.deltaMush(node_name, geometry=True, q=True),
        plug_values=plug_values_dict,
        weights=gtl.get_deformer_weights(delta_mush_node)
        )


def create_delta_mush(data):
    """
    Set the node's delta mush with the delta mush dictionary
    :param data: (dict) - dictionary of values to pass onto node's delta mush
    :return: None
    """

    if isinstance(data, dict):
        data = [data]

    for x in data:
        plug_values_dict = x.get('plug_values', dict())
        weights = x.get('weights', None)
        name = x['name']
        geometry = x['geometry']

        if mc.objExists(name):
            raise Exception('A node with the name "%s" already exists' % name)

        delta_mush_node = mc.deltaMush(
            geometry,
            name=name
        )[0]

        # set attributes of new delta mush
        for plug_key in plug_values_dict.keys():
            value = plug_values_dict[plug_key]
            mc.setAttr('{0}.{1}'.format(delta_mush_node, plug_key), value)
        if weights:
            gtl.set_deformer_weights(delta_mush_node, weights)

