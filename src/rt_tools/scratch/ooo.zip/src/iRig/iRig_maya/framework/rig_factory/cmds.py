import rig_factory.object_versions as obs


def createNode(controller, type, parent=None, segment_name=None):
    if isinstance(parent, basestring):
        parent = controller.named_objects.get(parent, None)
    if type == 'locator':
        return parent.create_child(
            obs.Locator,
            segment_name=segment_name
        )
    elif type == 'transform':
        return parent.create_child(
            obs.Transform,
            segment_name=segment_name
        )
    elif type == 'nurbsCurve':
        return parent.create_child(
            obs.NurbsCurve,
            segment_name=segment_name
        )
    elif type in ['multiplyDivide', 'addDoubleLinear', 'plusMinusAverage', 'blendWeighted', 'blendColors', 'remapValue']:
        return parent.create_child(
            obs.DependNode,
            segment_name=segment_name
        )


def parentConstraint(controller, *args, **kwargs):
    return controller.create_parent_constraint(*args, **kwargs)

def point_Constraint(controller, *args, **kwargs):
    return controller.create_parent_constraint(*args, **kwargs)

def parentConstraint(controller, *args, **kwargs):
    return controller.create_parent_constraint(*args, **kwargs)

def parentConstraint(controller, *args, **kwargs):
    return controller.create_parent_constraint(*args, **kwargs)

