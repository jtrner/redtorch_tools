import os
import json
legacy_handles_path = '%s/legacy_handle_names.json' % os.path.dirname(__file__.replace('\\', '/'))
new_handles_path = '%s/new_handle_names.json' % os.path.dirname(__file__.replace('\\', '/'))
new_old_handle_names_path = '%s/driven_group_handle_map.json' % os.path.dirname(__file__.replace('\\', '/'))

with open(legacy_handles_path, mode='r') as f:
    legacy_handle_names = json.load(f)

with open(new_handles_path, mode='r') as f:
    new_handle_names = json.load(f)

handle_dict = dict()

for x in range(len(legacy_handle_names)):
    handle_dict[legacy_handle_names[x]] = new_handle_names[x]

with open(new_old_handle_names_path, mode='w') as f:
    json.dump(handle_dict, f, sort_keys=True, indent=4, separators=(',', ': '))
