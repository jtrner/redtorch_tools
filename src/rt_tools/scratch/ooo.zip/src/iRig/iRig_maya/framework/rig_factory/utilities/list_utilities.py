from collections import OrderedDict


def remove_duplicates(a_list):
    """
    removes duplicates items from a list, but keeps the order
    example: ['a', 'b', 'a'] -> ['a', 'b']
    """
    a_list = list(OrderedDict.fromkeys(a_list))
    return a_list
