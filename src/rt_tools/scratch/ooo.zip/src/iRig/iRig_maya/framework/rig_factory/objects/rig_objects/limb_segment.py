import copy
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.base_objects.properties import ObjectListProperty, ObjectProperty, DataProperty
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
import rig_factory.utilities.node_utilities.ik_handle_utilities as iks
import rig_factory.utilities.joint_volume_utiilities as jvu
import rig_factory.environment as env
from rig_math.matrix import Matrix
import rig_factory


class LimbSegment(Transform):

    joints = ObjectListProperty(
        name='joints'
    )

    handles = ObjectListProperty(
        name='joints'
    )

    nurbs_curve = ObjectProperty(
        name='nurbs_curve'
    )

    owner = ObjectProperty(
        name='owner'
    )

    joint_count = DataProperty(
        name='joint_count',
        default_value=6
    )

    matrices = []

    def __init__(self, **kwargs):
        super(LimbSegment, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        owner = kwargs.get('owner')
        if not owner:
            raise Exception('You must provide an "owner" keyword argument')
        matrices = kwargs.pop('matrices', [])
        if len(matrices) != 2:
            raise Exception('You must provide exactly two matrices')
        this = super(LimbSegment, cls).create(controller, **kwargs)
        segment_name = this.segment_name
        size = this.size
        side = this.side
        owner = this.owner
        root = owner.get_root()
        positions = [x.get_translation() for x in matrices]
        start_matrix, end_matrix = matrices
        flipped_end_matrix = copy.copy(start_matrix)
        flipped_end_matrix.set_translation(end_matrix.get_translation())
        # flipped_end_matrix.flip_y()
        # flipped_end_matrix.flip_z()
        center_matrix = copy.copy(start_matrix)
        length_vector = positions[1] - positions[0]
        segment_vector = length_vector / 4
        segment_length = segment_vector.mag()
        length = length_vector.mag()
        curve_points = [positions[0] + (segment_vector * x) for x in range(5)]
        center_matrix.set_translation(curve_points[2])
        aim_vector = env.side_aim_vectors[side]
        up_vector = env.side_up_vectors[side]

        base_handle = owner.create_handle(
            handle_type=GroupedHandle,
            segment_name='{0}Base'.format(segment_name),
            shape='circle',
            matrix=start_matrix
        )

        side_segment_length = segment_length * -1 if side == 'right' else segment_length
        base_handle.multiply_shape_matrix(Matrix([0.0, side_segment_length/size, 0.0]))

        end_handle = owner.create_handle(
            handle_type=GroupedHandle,
            segment_name='{0}End'.format(segment_name),
            shape='circle',
            matrix=flipped_end_matrix
        )

        end_handle.multiply_shape_matrix(Matrix([0.0, side_segment_length/size*-1.0, 0.0]))

        nurbs_curve_transform = this.create_child(
            Transform,
            segment_name='{0}Spline'.format(segment_name),
        )
        nurbs_curve_transform.plugs['inheritsTransform'].set_value(False)

        nurbs_curve = nurbs_curve_transform.create_child(
            NurbsCurve,
            degree=3,
            segment_name=segment_name,
            positions=curve_points
        )
        center_handle = owner.create_handle(
            handle_type=GroupedHandle,
            segment_name=segment_name,
            shape='ball',
            size=size,
            matrix=center_matrix,
            functionality_name=this.functionality_name
        )
        #
        # controller.create_point_constraint(
        #     base_handle.groups[0],
        #     end_handle.groups[0],
        #     center_handle.groups[0],
        #     mo=False
        # )

        base_tangent_transform = base_handle.create_child(
            Transform,
            segment_name='{0}BaseTangent'.format(segment_name),
            matrix=curve_points[1]
        )

        end_tangent_transform = end_handle.create_child(
            Transform,
            segment_name='{0}EndTangent'.format(segment_name),
            matrix=curve_points[3]
        )

        curve_info = this.create_child(
            DependNode,
            segment_name='{0}Segment'.format(segment_name),
            node_type='curveInfo',

        )

        scale_divide = this.create_child(
            DependNode,
            segment_name='{0}Segment'.format(segment_name),
            node_type='multiplyDivide'
        )
        scale_divide.plugs['operation'].set_value(2)
        curve_info.plugs['arcLength'].connect_to(
            scale_divide.plugs['input1X'],
        )
        curve_info.plugs['arcLength'].connect_to(
            scale_divide.plugs['input1Y'],
        )
        curve_info.plugs['arcLength'].connect_to(
            scale_divide.plugs['input1Z'],
        )
        nurbs_curve.plugs['worldSpace'].element(0).connect_to(
            curve_info.plugs['inputCurve'],
        )
        owner.scale_multiply_transform.plugs['scale'].connect_to(
            scale_divide.plugs['input2'],
        )
        length_divide = this.create_child(
            DependNode,
            segment_name='{0}BendyLength'.format(segment_name),
            node_type='multiplyDivide',
        )
        length_divide.plugs['operation'].set_value(2)
        length_divide.plugs['input2Y'].set_value(
            (this.joint_count - 1) * -1
            if side == 'right' else
            this.joint_count - 1
        )
        scale_divide.plugs['output'].connect_to(
            length_divide.plugs['input1'],
        )
        curve_control_transforms = [
            base_handle,
            base_tangent_transform,
            center_handle,
            end_tangent_transform,
            end_handle
        ]
        curve_locators = []
        for i, transform in enumerate(curve_control_transforms):
            locator = transform.create_child(Locator)
            locator.plugs['visibility'].set_value(False)
            locator.plugs['worldPosition'].element(0).connect_to(nurbs_curve.plugs['controlPoints'].element(i))
            curve_locators.append(locator)
        segment_joints = []
        joint_parent = this
        joint_spacing_vector = length_vector / this.joint_count
        for i in range(this.joint_count):
            index_character = rig_factory.index_dictionary[i].title()
            matrix = copy.copy(matrices[0])
            matrix.set_translation(matrix.get_translation() + (joint_spacing_vector*i))
            joint = joint_parent.create_child(
                Joint,
                segment_name='{0}Secondary{1}'.format(segment_name, index_character),
                matrix=matrix,
                functionality_name='Bind'
            )
            joint.zero_rotation()
            if i > 0:
                segment_joints[-1].plugs['scale'].connect_to(
                    joint.plugs['inverseScale'],
                )
                length_divide.plugs['outputY'].connect_to(
                    joint.plugs['translateY'],
                )
            root.add_plugs(
                joint.plugs['rx'],
                joint.plugs['ry'],
                joint.plugs['rz'],
                keyable=False
            )
            segment_joints.append(joint)
            joint_parent = joint

        spline_ik_handle = iks.create_spline_ik(
            segment_joints[0],
            segment_joints[-1],
            nurbs_curve,
            side=side,
            world_up_object=base_handle,
            world_up_object_2=end_handle,
            advanced_twist=True
        )
        spline_ik_handle.plugs['v'].set_value(0)
        controller.create_point_constraint(
            base_handle,
            segment_joints[0],
            mo=False
        )

        nurbs_curve.plugs['visibility'].set_value(False)
        spline_ik_handle.plugs['visibility'].set_value(False)

        root = owner.get_root()
        root.add_plugs(
            base_handle.plugs['rx'],
            base_handle.plugs['ry'],
            base_handle.plugs['rz'],
            base_handle.plugs['sx'],
            base_handle.plugs['sz'],
            end_handle.plugs['rx'],
            end_handle.plugs['ry'],
            end_handle.plugs['rz'],
            end_handle.plugs['sx'],
            end_handle.plugs['sz'],
            center_handle.plugs['tx'],
            center_handle.plugs['ty'],
            center_handle.plugs['tz'],
            center_handle.plugs['sx'],
            center_handle.plugs['sz']
        )

        this.joints = segment_joints
        this.handles = [base_handle, center_handle, end_handle]
        this.nurbs_curve = nurbs_curve
        return this

    def setup_scale_joints(self):

        auto_volume_plug = self.create_plug(
            'AutoVolume',
            at='double',
            dv=1.0,
            k=True,
            min=0.0,
            max=10.0
        )
        min_auto_volume_plug = self.create_plug(
            'MinAutoVolume',
            at='double',
            dv=-0.5,
            k=True
        )
        max_auto_volume_plug = self.create_plug(
            'MaxAutoVolume',
            at='double',
            dv=0.5,
            k=True
        )
        base_handle, center_handle, end_handle = self.handles

        base_scale_x_plug = base_handle.create_plug(
            'EndScaleX',
            at='double',
            dv=1.0,
            max=10.0,
            min=0.0
        )
        base_scale_z_plug = base_handle.create_plug(
            'EndScaleZ',
            at='double',
            dv=1.0,
            max=10.0,
            min=0.0
        )
        end_scale_x_plug = end_handle.create_plug(
            'EndScaleX',
            at='double',
            dv=1.0,
            max=10.0,
            min=0.0
        )
        end_scale_z_plug = end_handle.create_plug(
            'EndScaleZ',
            at='double',
            dv=1.0,
            max=10.0,
            min=0.0
        )

        for i, handle in enumerate([base_handle, center_handle, end_handle]):
            segment_character = rig_factory.index_dictionary[i].upper()
            paremeter_plug = handle.create_plug(
                'parameter_driver',
                at='double',
                dv=0.0
            )
            tweak_getter = handle.create_child(
                Locator,
                segment_name='%sGetter%s' % (self.segment_name, segment_character)
            )
            nearest_point = handle.create_child(
                DependNode,
                node_type='nearestPointOnCurve'
            )
            tweak_getter.plugs['visibility'].set_value(False)
            self.nurbs_curve.plugs['worldSpace'].element(0).connect_to(nearest_point.plugs['inputCurve'])
            tweak_getter.plugs['worldPosition'].element(0).connect_to(nearest_point.plugs['inPosition'])
            nearest_point.plugs['parameter'].connect_to(paremeter_plug)
        span_segment = float(self.nurbs_curve.plugs['spans'].get_value()) / (len(self.joints))
        scale_x_secondary_plugs = jvu.generate_distribution_plugs(
            self.nurbs_curve,
            [span_segment * i for i in range(len(self.joints))],
            [
                base_handle.plugs['sx'],
                center_handle.plugs['sx'],
                end_handle.plugs['sx']
            ],
            'SecondarySX%s' % self.segment_name,
            subtract_value=1.0
        )
        scale_z_secondary_plugs = jvu.generate_distribution_plugs(
            self.nurbs_curve,
            [span_segment * i for i in range(len(self.joints))],
            [
                base_handle.plugs['sz'],
                center_handle.plugs['sz'],
                end_handle.plugs['sz']
            ],
            'SecondarySZ%s' % self.segment_name,
            subtract_value=1.0
        )
        scale_x_plugs = jvu.generate_distribution_plugs(
            self.nurbs_curve,
            [span_segment * i for i in range(len(self.joints))],
            [
                base_scale_x_plug,
                end_scale_x_plug
            ],
            'SX%s' % self.segment_name,
            subtract_value=1.0,
            tangent_type=0
        )
        scale_z_plugs = jvu.generate_distribution_plugs(
            self.nurbs_curve,
            [span_segment * i for i in range(len(self.joints))],
            [
                base_scale_z_plug,
                end_scale_z_plug
            ],
            'SZ%s' % self.segment_name,
            subtract_value=1.0,
            tangent_type=0
        )
        squash_plugs = jvu.generate_volume_plugs(
            self.nurbs_curve,
            [span_segment * i for i in range(len(self.joints))]
        )
        if not len(self.joints) == len(scale_x_plugs):
            raise Exception('Mismatched scale x plugs')
        if not len(self.joints) == len(scale_z_plugs):
            raise Exception('Mismatched scale z plugs')
        if not len(self.joints) == len(scale_x_secondary_plugs):
            raise Exception('Mismatched scale x secondary plugs')
        if not len(self.joints) == len(scale_z_secondary_plugs):
            raise Exception('Mismatched scale z_secondary plugs')
        if not len(self.joints) == len(squash_plugs):
            raise Exception('Mismatched squash plugs')
        for i in range(len(self.joints)):
            index_character = rig_factory.index_dictionary[i].upper()
            add_default = self.create_child(
                DependNode,
                segment_name='%sAddDefault%s' % (index_character, self.segment_name),
                node_type='plusMinusAverage'
            )
            squash_plugs[i][0].connect_to(add_default.plugs['input2D'].element(0).child(0))
            squash_plugs[i][1].connect_to(add_default.plugs['input2D'].element(0).child(1))
            scale_x_secondary_plugs[i].connect_to(add_default.plugs['input2D'].element(1).child(0))
            scale_z_secondary_plugs[i].connect_to(add_default.plugs['input2D'].element(1).child(1))
            scale_x_plugs[i].connect_to(add_default.plugs['input2D'].element(2).child(0))
            scale_z_plugs[i].connect_to(add_default.plugs['input2D'].element(2).child(1))
            add_default.plugs['input2D'].element(3).child(0).set_value(1.0)
            add_default.plugs['input2D'].element(3).child(1).set_value(1.0)
            add_default.plugs['output2D'].child(0).connect_to(self.joints[i].plugs['sx'])
            add_default.plugs['output2D'].child(1).connect_to(self.joints[i].plugs['sz'])

        self.owner.scale_multiply_transform.plugs['scaleY'].connect_to(self.nurbs_curve.plugs['GlobalScale'])
        auto_volume_plug.connect_to(self.nurbs_curve.plugs['AutoVolume'])
        min_auto_volume_plug.connect_to(self.nurbs_curve.plugs['MinAutoVolume'])
        max_auto_volume_plug.connect_to(self.nurbs_curve.plugs['MaxAutoVolume'])
        root = self.owner.get_root()
        root.add_plugs(
            auto_volume_plug
        )
