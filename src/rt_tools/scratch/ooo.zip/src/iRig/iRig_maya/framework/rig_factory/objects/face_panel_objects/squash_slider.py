from rig_factory.objects.face_panel_objects.base_slider import BaseSlider, BaseSliderGuide
from rig_factory.objects.rig_objects.curve_handle import CurveHandle
from rig_factory.objects.rig_objects.text_curve import TextCurve
from rig_math.matrix import Matrix
from rig_factory.utilities import face_panel_utillities as utl


class SquashSliderGuide(BaseSliderGuide):
    default_settings = dict(
        differentiation_name='Panel',
        root_name='Squash',
        side='center',
        size=1.0
    )
    def __init__(self, **kwargs):
        super(SquashSliderGuide, self).__init__(**kwargs)
        self.toggle_class = SquashSlider.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(SquashSliderGuide, cls).create(controller, **kwargs)
        return this


class SquashSlider(BaseSlider):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Squash',
        side='center',
        size=1.0
    )
    def __init__(self, **kwargs):
        super(SquashSlider, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(SquashSlider, cls).create(controller, **kwargs)
        size = this.size
        side = this.side
        matrices = this.matrices

        limits_curve = this.create_child(
            CurveHandle,
            segment_name='Square',
            shape='square',
            size=size,
            side=side,
            matrix=matrices[0]
        )
        matrix = Matrix(scale=[0.5, 1.0, 2.0])
        limits_curve.plugs['shapeMatrix'].set_value(matrix)
        limits_curve.plugs['rotateX'].set_value(90)
        utl.set_color_index(limits_curve, 1)  # black
        limits_curve.plugs['overrideDisplayType'].set_value(2)

        handle = this.create_handle(
            segment_name='Main',
            shape='diamond',
            size=size*0.5,
            side=side,
            matrix=matrices[0]
        )
        utl.set_attr_limit(handle, 'TransY', -1.0, 1.0)
        root = this.get_root()
        root.add_plugs([handle.plugs['ty']])

        # Text
        handle_text = this.create_child(
            TextCurve,
            segment_name='Text',
            text_input='Squash',
            matrix=matrices[0] * Matrix(0.0, 1.5, 0.0)
        )
        handle_text.set_size(0.75)
        utl.set_color_index(handle_text, 1)  # black
        handle_text.plugs['overrideDisplayType'].set_value(2)

        return this
