import rig_factory.environment as env
from rig_factory.objects.base_objects.properties import ObjectListProperty, DataProperty, ObjectProperty
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_factory.objects.biped_objects.biped_leg import BipedLeg, BipedLegGuide
from rig_factory.objects.rig_objects.limb_segment import LimbSegment
from rig_factory.objects.part_objects.part import Part
import rig_factory.positions as pos


class BipedLegBendyGuide(BipedLegGuide):

    default_settings = {
        'root_name': 'Leg',
        'size': 4.0,
        'side': 'left',
        'foot_placement_depth': 1.0,
        'squash': 1,
        'master_foot': False,
        'pole_distance_multiplier': 1.0
    }

    segment_names = DataProperty(
        name='segment_names',
        default_value=['Base', 'Hip', 'Knee', 'Foot', 'Toe', 'ToeTip']
    )

    squash = DataProperty(
        name='squash',
    )
    master_foot = DataProperty(
        name='master_foot'
    )
    pole_distance_multiplier = DataProperty(
        name='pole_distance_multiplier',
        default_value=1.0
    )


    def __init__(self, **kwargs):
        super(BipedLegBendyGuide, self).__init__(**kwargs)
        self.toggle_class = BipedLegBendy.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(BipedLegBendyGuide, cls).create(controller, **kwargs)
        this.create_plug(
            'squash',
            defaultValue=this.squash,
            keyable=True,
        )
        this.set_handle_positions(pos.BIPED_POSITIONS)
        return this

    def get_blueprint(self):

        blueprint = super(BipedLegBendyGuide, self).get_blueprint()

        blueprint['squash'] = self.plugs['squash'].get_value()

        return blueprint

    def get_toggle_blueprint(self):

        blueprint = super(BipedLegBendyGuide, self).get_toggle_blueprint()

        blueprint['squash'] = self.plugs['squash'].get_value()

        return blueprint


class BipedLegBendy(Part):

    spline_joints = ObjectListProperty(
        name='spline_joints'
    )

    squash = DataProperty(
        name='squash',
        default_value=1,
    )

    foot_placement_depth = DataProperty(
        name='foot_placement_depth',
        default_value=1.0
    )
    ik_match_joint = ObjectProperty(
        name='ik_match_joint'
    )
    settings_handle = ObjectProperty(
        name='settings_handle'
    )
    heel_placement_node = ObjectProperty(
        name='heel_placement_node'
    )
    ball_placement_node = ObjectProperty(
        name='ball_placement_node'
    )
    ankle_handle = ObjectProperty(
        name='ankle_handle'
    )
    knee_handle = ObjectProperty(
        name='knee_handle'
    )
    toe_handle = ObjectProperty(
        name='toe_handle'
    )
    ik_joints = ObjectListProperty(
        name='ik_joints'
    )
    ik_handles = ObjectListProperty(
        name='ik_handles'
    )
    isolated_joints = ObjectListProperty(
        name='isolated_joints'
    )
    fk_handles = ObjectListProperty(
        name='fk_handles'
    )
    fk_joints = ObjectListProperty(
        name='fk_joints'
    )
    fk_handle_gimbals = ObjectListProperty(
        name='fk_handle_gimbals'
    )
    knee_line = ObjectProperty(
        name='knee_line'
    )
    segment_names = DataProperty(
        name='segment_names',
        default_value=['Base', 'Hip', 'Knee', 'Foot', 'Toe', 'ToeTip']
    )
    master_foot = DataProperty(
        name='master_foot'
    )

    pole_distance_multiplier = DataProperty(
        name='pole_distance_multiplier',
        default_value=1.0
    )

    def __init__(self, **kwargs):
        super(BipedLegBendy, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(BipedLegBendy, cls).create(controller, **kwargs)
        BipedLeg.build_rig(this)
        return this

    def create_deformation_rig(self, **kwargs):
        super(BipedLegBendy, self).create_deformation_rig(**kwargs)
        side = self.side
        size = self.size
        controller = self.controller
        deform_joints = self.deform_joints
        joints = self.joints
        matrices = [x.get_matrix() for x in deform_joints]
        root = self.get_root()
        segment_joint_count = 6
        settings_handle = self.settings_handle
        squash = self.squash
        self.secondary_handles = []

        squash_plug = settings_handle.create_plug(
            'squash',
            attributeType='float',
            keyable=True,
            defaultValue=squash,
            dv=1.0
        )
        squash_min_plug = settings_handle.create_plug(
            'squashMin',
            attributeType='float',
            keyable=True,
            defaultValue=-0.5
        )
        squash_max_plug = settings_handle.create_plug(
            'squashMax',
            attributeType='float',
            keyable=True,
            defaultValue=0.5,
        )

        root.add_plugs(
            squash_plug
        )
        root.add_plugs(
            squash_min_plug,
            squash_max_plug,
            keyable=False
        )

        for deform_joint in deform_joints[1:3]:
            deform_joint.plugs.set_values(
                radius=0
            )
        bendy_knee_handle = self.create_handle(
            handle_type=GroupedHandle,
            segment_name='%s%s' % (
                self.segment_names[1].title(),
                self.segment_names[2].title()
            ),
            functionality_name='Bendy',
            shape='ball',
            matrix=matrices[2],
            parent=joints[2],
            size=size*0.75
        )
        root.add_plugs(
            bendy_knee_handle.plugs['tx'],
            bendy_knee_handle.plugs['ty'],
            bendy_knee_handle.plugs['tz'],
            bendy_knee_handle.plugs['rx'],
            bendy_knee_handle.plugs['ry'],
            bendy_knee_handle.plugs['rz'],
            bendy_knee_handle.plugs['sx'],
            bendy_knee_handle.plugs['sy'],
            bendy_knee_handle.plugs['sz'],
        )
        bendy_knee_handle.plugs.set_values(
            overrideEnabled=True,
            overrideRGBColors=True,
            overrideColorRGB=env.secondary_colors[side]
        )
        hip_orient_group_1 = deform_joints[0].create_child(
            Transform,
            segment_name='HipOrientBase',
            matrix=matrices[1]
        )
        hip_orient_group_2 = deform_joints[1].create_child(
            Transform,
            segment_name='HipOrientTip',
            matrix=matrices[1],
        )
        hip_orient_group = deform_joints[0].create_child(
            Transform,
            segment_name='HipOrient',
            matrix=matrices[1],
        )
        knee_orient_group = deform_joints[1].create_child(
            Transform,
            segment_name='KneeOrient',
            matrix=matrices[2],

        )
        ankle_orient_group = deform_joints[3].create_child(
            Transform,
            segment_name='AnkleOrient',
            matrix=matrices[3],
        )
        hip_up_group = hip_orient_group.create_child(
            Transform,
            segment_name='HipUp',
        )
        up_group_distance = [x * size * -5.0 * self.pole_distance_multiplier for x in env.side_cross_vectors[side]]
        hip_up_group.plugs['translate'].set_value(up_group_distance)  # Use "matrix" kwarg please.(not set_value)
        knee_up_group = knee_orient_group.create_child(
            Transform,
            segment_name='KneeUp',
        )
        knee_up_group.plugs['translate'].set_value(up_group_distance)
        ankle_up_group = ankle_orient_group.create_child(
            Transform,
            segment_name='AnkleUp',
        )
        ankle_up_group.plugs['translate'].set_value(up_group_distance)  # Use "matrix" kwarg please.(not set_value)
        constraint = controller.create_orient_constraint(
            hip_orient_group_1,
            hip_orient_group_2,
            hip_orient_group,
            skip='y',
        )
        constraint.plugs['interpType'].set_value(2)
        constraint = controller.create_orient_constraint(
            deform_joints[1],
            deform_joints[2],
            knee_orient_group,
            skip='y'
        )
        constraint.plugs['interpType'].set_value(2)
        constraint = controller.create_orient_constraint(
            deform_joints[2],
            deform_joints[3],
            ankle_orient_group,
            skip='y'

        )
        constraint.plugs['interpType'].set_value(2)
        controller.create_point_constraint(
            deform_joints[1],
            hip_orient_group
        )
        controller.create_point_constraint(
            deform_joints[2],
            knee_orient_group
        )
        controller.create_point_constraint(
            deform_joints[3],
            ankle_orient_group
        )

        bendy_joints = []

        #  Thigh Bendy's
        thigh_segment = self.create_child(
            LimbSegment,
            owner=self,
            segment_name=self.segment_names[1],
            matrices=[matrices[1], matrices[2]],
            joint_count=segment_joint_count,
            functionality_name='Bendy'
        )
        thigh_segment.joints[0].set_parent(deform_joints[1])
        deform_joints[1].plugs['scale'].connect_to(
            thigh_segment.joints[0].plugs['inverseScale'],
        )
        for segment in thigh_segment.handles:
            segment.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.secondary_colors[side]
            )
            self.secondary_handles.append(segment)
        self.controller.create_aim_constraint(
            thigh_segment.handles[1],
            thigh_segment.handles[0].groups[0],
            aimVector=env.side_aim_vectors[side],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=hip_up_group
        )
        self.controller.create_aim_constraint(
            thigh_segment.handles[1],
            thigh_segment.handles[2].groups[0],
            aimVector=[x * -1.0 for x in env.side_aim_vectors[side]],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=knee_up_group
        )
        self.controller.create_point_constraint(
            deform_joints[1],
            bendy_knee_handle,
            thigh_segment.handles[1].groups[0],
            mo=False
        )
        self.controller.create_point_constraint(
            deform_joints[1],
            thigh_segment.handles[0].groups[0],
            mo=False
        )
        self.controller.create_point_constraint(
            bendy_knee_handle,
            thigh_segment.handles[2].groups[0],
            mo=False
        )
        self.controller.create_aim_constraint(
            bendy_knee_handle,
            thigh_segment.handles[1].groups[0],
            aimVector=[x * -1.0 for x in env.side_aim_vectors[side]],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=hip_up_group,
            mo=False
        )
        bendy_joints.extend(thigh_segment.joints)

        #  Calf Bendy's

        calf_segment = self.create_child(
            LimbSegment,
            owner=self,
            segment_name=self.segment_names[2],
            matrices=[matrices[2], matrices[3]],
            joint_count=segment_joint_count,
            functionality_name='Bendy'
        )
        calf_segment.joints[0].set_parent(deform_joints[2])
        deform_joints[2].plugs['scale'].connect_to(
            calf_segment.joints[0].plugs['inverseScale'],
        )

        for segment in calf_segment.handles:
            segment.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.secondary_colors[side]
            )
            self.secondary_handles.append(segment)
        self.controller.create_aim_constraint(
            calf_segment.handles[1],
            calf_segment.handles[0].groups[0],
            aimVector=env.side_aim_vectors[side],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=knee_up_group
        )
        self.controller.create_aim_constraint(
            calf_segment.handles[1],
            calf_segment.handles[2].groups[0],
            aimVector=[x * -1.0 for x in env.side_aim_vectors[side]],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=ankle_up_group
        )

        self.controller.create_point_constraint(
            bendy_knee_handle,
            deform_joints[3],
            calf_segment.handles[1].groups[0],
            mo=False
        )

        self.controller.create_point_constraint(
            bendy_knee_handle,
            calf_segment.handles[0].groups[0],
            mo=False
        )

        self.controller.create_point_constraint(
            deform_joints[3],
            calf_segment.handles[2].groups[0],
            mo=False
        )
        self.controller.create_aim_constraint(
            deform_joints[3],
            calf_segment.handles[1].groups[0],
            aimVector=[x * -1.0 for x in env.side_aim_vectors[side]],
            upVector=[x * -1.0 for x in env.side_cross_vectors[side]],
            worldUpType='object',
            worldUpObject=knee_up_group,
            mo=False
        )

        calf_segment.setup_scale_joints()
        thigh_segment.setup_scale_joints()

        bendy_knee_handle.plugs['sx'].connect_to(thigh_segment.handles[-1].plugs['EndScaleX'])
        bendy_knee_handle.plugs['sz'].connect_to(thigh_segment.handles[-1].plugs['EndScaleZ'])
        bendy_knee_handle.plugs['sx'].connect_to(calf_segment.handles[0].plugs['EndScaleX'])
        bendy_knee_handle.plugs['sz'].connect_to(calf_segment.handles[0].plugs['EndScaleZ'])

        settings_handle.plugs['squash'].connect_to(thigh_segment.plugs['AutoVolume'])
        settings_handle.plugs['squashMin'].connect_to(thigh_segment.plugs['MinAutoVolume'])
        settings_handle.plugs['squashMax'].connect_to(thigh_segment.plugs['MaxAutoVolume'])

        settings_handle.plugs['squash'].connect_to(calf_segment.plugs['AutoVolume'])
        settings_handle.plugs['squashMin'].connect_to(calf_segment.plugs['MinAutoVolume'])
        settings_handle.plugs['squashMax'].connect_to(calf_segment.plugs['MaxAutoVolume'])


        bendy_joints.extend(calf_segment.joints)

        self.spline_joints = bendy_joints
        self.deform_joints.extend(bendy_joints)
        self.secondary_handles.append(bendy_knee_handle)
