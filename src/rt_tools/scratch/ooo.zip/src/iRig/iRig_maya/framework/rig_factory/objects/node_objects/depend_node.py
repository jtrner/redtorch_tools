import weakref
from rig_factory.objects.base_objects.base_node import BaseNode
from rig_factory.objects.base_objects.properties import ObjectDictProperty, DataProperty
from rig_factory.objects.node_objects.plug import Plug
from rig_factory.objects.base_objects.weak_list import WeakList


class DependNode(BaseNode):

    existing_plugs = ObjectDictProperty(
        name='existing_plugs'
    )

    node_type = DataProperty(
        name='node_type'
    )

    plugs = []
    m_object = None
    node_delete_callback_id = None
    attribute_delete_callback_id = None

    def __init__(self, **kwargs):
        super(DependNode, self).__init__(**kwargs)
        self.plugs = Plugs(self)
        self.m_object = None

    @classmethod
    def create(cls, controller, **kwargs):
        root_name = kwargs.get('root_name', None)
        if root_name is not None and '.' in root_name and 'root_name':
            raise Exception('The keyword argument "root_name" has an invalid character : %s' % root_name)
        node_type = kwargs.get('node_type')
        if node_type in type_suffixes:
            kwargs['suffix'] = type_suffixes[node_type]
        m_object = kwargs.pop('m_object', None)
        this = super(DependNode, cls).create(controller, **kwargs)
        this.m_object = None

        if not m_object:
            this.create_in_scene()
        else:
            this.set_m_object(m_object)

        if controller.safe_mode:
            this.node_delete_callback_id = controller.scene.add_node_delete_callback(
                this.m_object,
                controller.check_node_deleted
            )
            this.attribute_delete_callback_id = controller.scene.add_attribute_delete_callback(
                this.m_object,
                controller.check_plug_deleted
            )
        return this

    def set_m_object(self, m_object):
        self.m_object = m_object
        self.controller.rename(self, self.name)

    def create_in_scene(self):
        self.m_object = self.controller.scene.create_depend_node(
            self.node_type,
            self.name
        )

    def initialize_plug(self, key):
        if key in self.existing_plugs:
            return self.existing_plugs[key]
        else:
            return self.create_child(
                Plug,
                root_name=key,
                name='%s.%s' % (self.name, key)
            )

    def rename(self, name):
        return self.controller.rename(self, name)

    def create_plug(self, name, **kwargs):
        use_existing = kwargs.pop('use_existing', False)
        if use_existing and name in self.existing_plugs:
            return self.existing_plugs[name]
        return self.create_child(
            Plug,
            root_name=name,
            create_kwargs=kwargs,
            user_defined=True
        )

    def get_selection_string(self):
        if self.controller.scene.mock:
            return self.name
        return self.controller.scene.get_selection_string(self.m_object)

    def __str__(self):
        return self.get_selection_string()

    def teardown(self):
        if self.node_delete_callback_id:
            self.controller.scene.remove_callback(self.node_delete_callback_id)
            self.node_delete_callback_id = None
        if self.attribute_delete_callback_id:
            self.controller.scene.remove_callback(self.attribute_delete_callback_id)
            self.attribute_delete_callback_id = None

        self.controller.nodes_scheduled_for_deletion.append(self.get_selection_string())
        self.m_object = None
        super(DependNode, self).teardown()

    def is_visible(self):
        return self.controller.check_visibility(self)

    def create_node_math_instance(self, plug):
        return NodeMath(plug)


class Plugs(object):
    def __init__(self, owner):
        self.owner = weakref.ref(owner)

    def __getitem__(self, key):
        owner = self.owner()
        if owner:
            new_plug = owner.initialize_plug(key)
            owner.existing_plugs[key] = new_plug
            return new_plug

    def __setitem__(self, key, val):
        owner = self.owner()
        if owner:
            owner.existing_plugs[key] = val

    def set_values(self, **kwargs):
        for key in kwargs:
            self[key].set_value(kwargs[key])

    def set_locked(self, **kwargs):
        for key in kwargs:
            self[key].set_locked(kwargs[key])

    def get(self, *args):
        return WeakList([self[x] for x in args])

    def exists(self, *args):
        owner = self.owner()
        if not owner:
            return False
        else:
            for attribute_name in args:
                if not owner.controller.scene.objExists('%s.%s' % (
                    owner.get_selection_string(),
                    attribute_name
                )):
                    return False
        return True


class NodeMath(object):

    def __init__(self, plug):
        super(NodeMath, self).__init__()
        self.plug = plug

    def connect_to(self, target):
        if isinstance(target, NodeMath):
            target = target.plug
        self.plug.connect_to(target)


type_suffixes = dict(
    addDoubleLinear='Adl',
    blendWeighted='Bwt',
    clamp='Clp',
    condition='Cnd',
    decomposeMatrix='Dcm',
    distanceBetween='Dst',
    eulerToQuat='Euq',
    follicle='Flc',
    ikEffector='Ike',
    joint='Jnt',
    locator='Loc',
    mesh='Msh',
    multMatrix='Mmx',
    multiplyDivide='Mlt',
    nurbsCurve='Ncv',
    nurbsSurface='Nsf',
    pairBlend='Pbl',
    plusMinusAverage='Pma',
    polyCone='Pcn',
    polyCube='Pcb',
    polyCylinder='Pcy',
    polyPrimitiveMisc='Sps',
    quatInvert='Qiv',
    quatProd='Qpd',
    quatToEuler='Qte',
    remapValue='Rmp',
    reverse='Rvs',
    setRange='Srg',
    shadingEngine='Shg',
    shardMatrix='Smx',
    transformGeometry='Tgm',
    HIKCharacterNode='Hik',
    rebuildCurve='Rbc',
    hairSystem='Hys',
    nucleus='Nuc',
    polyEdgeToCurve='Pec',
    pointOnSurfaceInfo='Psi',
    pointOnCurveInfo='Pci',
    multDoubleLinear='Mdl',
    fitBspline='Fbs',
    projectCurve='Pjc',
    curveVarGroup='Cvg',
    curveFromSurfaceCoS='Cfs',
    arcLengthDimension='Acd',
    floatMath='Fmh',
    closestPointOnSurface='Cps'
)
