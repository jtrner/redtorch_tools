import functools
import pprint
import traceback
from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
from qtpy.QtWidgets import *
from rigging_widgets.face_blueprint_builder.face_blueprint_tree_model import FaceBlueprintTreeModel
import rigging_widgets.face_blueprint_builder.face_blueprint_items as btm


class FaceBlueprintTreeView(QTreeView):

    items_selected_signal = Signal(list)

    def __init__(self, *args, **kwargs):
        super(FaceBlueprintTreeView, self).__init__(*args, **kwargs)
        self.setIconSize(QSize(18, 18))
        self.setHeaderHidden(True)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setAlternatingRowColors(False)
        self.setHeaderHidden(True)
        self.setSelectionMode(QAbstractItemView.ExtendedSelection);
        self.setDragEnabled(True)
        self.setAcceptDrops(True)
        self.setDragDropMode(QTreeView.DragDrop)
        self.setDropIndicatorShown(True)
        self.header().setStretchLastSection(True)
        try:
            self.header().setResizeMode(QHeaderView.ResizeToContents)
        except Exception:
            self.header().setSectionResizeMode(QHeaderView.ResizeToContents)

    def mousePressEvent(self, event):
        super(FaceBlueprintTreeView, self).mousePressEvent(event)

        if event.type() == QEvent.MouseButtonPress:
            model = self.model()
            if model:
                index = self.indexAt(event.pos())
                if event.button() == Qt.RightButton:
                    menu = QMenu()
                    menu.addAction(
                        'Print Data',
                        functools.partial(
                            self.print_data,
                            index
                        )
                    )
                    menu.exec_(self.mapToGlobal(event.pos()))

    def print_data(self, index):
        item = self.model().get_item(index)
        if item:
            pprint.pprint(item.data)

    def keyPressEvent(self, event):
        model = self.model()
        if model:
            modifiers = QApplication.keyboardModifiers()
            key_object = event.key()
            if key_object == Qt.Key_G:
                if modifiers == Qt.ControlModifier:
                    return
            if key_object == Qt.Key_D:
                if modifiers == Qt.ControlModifier:
                    return
            if key_object == Qt.Key_F:
                return
            if key_object == Qt.Key_Delete:
                self.delete_selected()
                return
        super(FaceBlueprintTreeView, self).keyPressEvent(event)

    def delete_selected(self):
        model = self.model()
        old_indices = [i for i in self.selectedIndexes() if i.column() == 0]
        for name in [model.get_item(x).name for x in old_indices]:
            node_to_delete = model.named_items[name]
            old_parent = node_to_delete.parent
            old_row = old_parent.children.index(node_to_delete)
            old_parent_index = model.get_index_from_item(old_parent)
            model.beginRemoveRows(
                old_parent_index,
                old_row,
                old_row
            )
            node_to_delete.parent = None
            old_parent.children.remove(node_to_delete)
            if old_parent.data:
                if isinstance(old_parent, btm.FaceNetworkItem):
                    old_parent.data['groups'].pop(old_row)
                elif isinstance(old_parent, btm.FaceTargetItem):
                    old_parent.data['targets'].pop(old_row)
                else:
                    self.raise_warning('Delete not supported for that object')
            model.endRemoveRows()

    def raise_warning(self, message):
            print message
            message_box = QMessageBox(self)
            message_box.setWindowTitle('Warning')
            message_box.setText(message)
            message_box.exec_()

    def raise_message(self, message):
            print message
            message_box = QMessageBox(self)
            message_box.setWindowTitle('Message')
            message_box.setText(message)
            message_box.exec_()

    def raise_error(self, exception):
        QMessageBox.critical(
            self,
            'Critical Error',
            exception.message
        )
        self.setEnabled(True)
        traceback.print_exc()
        raise exception

    def load_blueprint(self, data):
        if not data:
            self.setModel(None)
        else:
            root = btm.DataItem('root')
            btm.build_items(
                data,
                parent=root
            )
            model = FaceBlueprintTreeModel(root)
            model.raise_warning_signal.connect(self.raise_warning)
            self.setModel(model)
            self.emit_selected_data()

    def setModel(self, model):
        existing_model = self.model()
        if existing_model:
            selection_model = self.selectionModel()
            selection_model.selectionChanged.disconnect(self.emit_selected_data)
        super(FaceBlueprintTreeView, self).setModel(model)
        if model:
            selection_model = self.selectionModel()
            selection_model.selectionChanged.connect(self.emit_selected_data)

    def emit_selected_data(self, *args):
        model = self.model()
        old_indices = [i for i in self.selectedIndexes() if i.column() == 0]
        items = [model.get_item(x).data for x in old_indices]
        self.items_selected_signal.emit(items)

