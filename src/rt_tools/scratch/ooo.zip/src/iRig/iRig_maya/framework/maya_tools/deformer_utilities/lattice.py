
from typing import *
import maya_tools.deformer_utilities.general as gtl
import maya.cmds as cmds


__all__ =(
    'create_lattice',
)


def create_lattice(*args, **kwargs):
    # type: (Iterable, Any) -> Tuple
    """
    Wrapper function for `cmds.lattice` which returns MObjects
    instead of strings for created nodes.
    :return:
        A tuple consiting of the lattice's:
            ffd,
            lattice transform,
            lattice shape,
            base lattice transform,
            base lattice shape,
            deformer set
    """

    # Creates the lattice using the given args and kwargs.
    # Gets the ffd, lattice transform, and base lattice transform.
    # Passing a `None` instead of an empty iterable prevents the lattice
    # from being created from any currently selected nodes.
    n_ffd, n_lattice, n_base_lattice = cmds.lattice(
        *(args or [None]),
        **kwargs
    )

    # Gets the lattice shape, and base lattice shape
    n_lattice_shape,      = cmds.listRelatives(n_lattice, shapes=True)
    n_lattice_base_shape, = cmds.listRelatives(n_base_lattice, shapes=True)

    # Gets the nodes' MObjects.
    ffd                 = gtl.get_m_object(n_ffd)
    lattice             = gtl.get_m_object(n_lattice)
    base_lattice        = gtl.get_m_object(n_base_lattice)
    lattice_shape       = gtl.get_m_object(n_lattice_shape)
    base_lattice_shape  = gtl.get_m_object(n_lattice_base_shape)

    # Gets the MObject for the ffd's deformer set.
    geometry_functions  = gtl.oma.MFnGeometryFilter(ffd)
    set_m_object        = geometry_functions.deformerSet()

    # Returns all created MObjects.
    return (
        ffd,
        lattice,
        base_lattice,
        lattice_shape,
        base_lattice_shape,
        set_m_object
    )
