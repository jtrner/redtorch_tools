import rig_factory
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.rig_objects.curve_handle import CurveHandle
from rig_factory.objects.base_objects.properties import DataProperty, ObjectProperty, ObjectListProperty, \
    ObjectDictProperty
from rig_math.matrix import Matrix
import rig_factory.environment as env


class GroupedHandle(CurveHandle):

    groups = ObjectListProperty(
        name='groups'
    )
    mirror_plugs = DataProperty(
        name='mirror_plugs',
        default_value=[]
    )
    space_switcher = ObjectProperty(
        name='space_switcher'
    )

    gimbal_handle = ObjectProperty(
        name='gimbal_handle'
    )

    gimbal_scale = DataProperty(
        name='gimbal_scale',
        default_value=0.9
    )

    rotation_order = DataProperty(
        name='rotation_order',
        default_value='xyz'
    )

    visibility_tag = DataProperty(
        name='visibility_tag'
    )


    @classmethod
    def create(cls, controller, **kwargs):

        group_suffixes = kwargs.pop('group_suffixes', None)
        if not group_suffixes:
            group_suffixes = ['Tpx','Tpp','Top','Ofs','Drv','Cns']

        group_count = kwargs.setdefault(
            'group_count',
            4
        )
        parent = kwargs.pop(
            'parent',
            None
        )

        handle_segment_name = kwargs.pop(
            'segment_name',
            None
        )
        index = kwargs.pop(
            'index',
            None
        )


        groups = []

        for g in range(group_count):
            if g == 0:
                suffix = 'Zro'
            else:
                suffix = group_suffixes[len(group_suffixes) - group_count + g]
            group = parent.create_child(
                Transform,
                segment_name=handle_segment_name,
                suffix=suffix,  # Ensure "Cns" is the bottom group suffix
                **kwargs
            )
            parent = group
            groups.append(group)
        this = super(GroupedHandle, cls).create(
            controller,
            parent=parent,
            segment_name=handle_segment_name,
            index=index,
            **kwargs
        )

        this.groups = groups

        if kwargs.get('create_gimbal'):
            side = this.side

            if this.functionality_name:
                functionality_name = '%sGimbal' % this.functionality_name
            else:
                functionality_name = 'Gimbal'

            this.gimbal_handle = this.create_child(
                CurveHandle,
                shape=this.shape,
                axis=this.axis,
                segment_name=this.segment_name,
                functionality_name=functionality_name
            )
            this.gimbal_handle.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.secondary_colors[side]
            )
            shape_matrix = Matrix()
            shape_matrix.set_scale([
                this.size * this.gimbal_scale,
                this.size * this.gimbal_scale,
                this.size * this.gimbal_scale,
            ])
            this.gimbal_handle.plugs['shapeMatrix'].set_value(shape_matrix)
            visibility_plug = this.create_plug(
                'gimbalVisibility',
                at='double',
                k=False,
                dv=0.0,
                min=0.0,
                max=1.0
            )
            visibility_plug.set_channel_box(True)
            for curve in this.gimbal_handle.curves:
                visibility_plug.connect_to(curve.plugs['visibility'])
            this.plugs['rotateOrder'].set_channel_box(True)
            this.plugs['rotateOrder'].connect_to(this.gimbal_handle.plugs['rotateOrder'])

        return this

    def get_current_space_handle(self):
        if self.space_switcher:
            return self.space_switcher.targets[self.plugs['parentSpace'].get_value()]

    def add_standard_plugs(self):
        super(GroupedHandle, self).add_standard_plugs()
        if self.gimbal_handle:
            root = self.owner.get_root()
            if root:
                root.add_plugs(
                    self.plugs['gimbalVisibility'],
                    keyable=False
                    )
        else:
            print 'Warning: Can\'t to find root for "%s". Unable to add standard plugs' % self

    def stretch_shape(self, end_position):

        super(GroupedHandle, self).stretch_shape(
            end_position
        )
        if self.gimbal_handle:
            self.gimbal_handle.stretch_shape(
                end_position
            )

    def set_shape_matrix(self, matrix):
        super(GroupedHandle, self).set_shape_matrix(matrix)
        if self.gimbal_handle:
            gimbal_matrix = Matrix(matrix)
            gimbal_matrix.set_scale([x*self.gimbal_scale for x in matrix.get_scale()])
            self.gimbal_handle.plugs['shapeMatrix'].set_value(list(gimbal_matrix))

    def multiply_shape_matrix(self, matrix):
        super(GroupedHandle, self).multiply_shape_matrix(matrix)
        if self.gimbal_handle:
            gimbal_matrix = Matrix(matrix)
            gimbal_matrix.set_scale([x*self.gimbal_scale for x in matrix.get_scale()])
            self.gimbal_handle.multiply_shape_matrix(gimbal_matrix)

    def get_rotation_order(self):
        return env.rotation_orders[self.plugs['rotateOrder'].get_value()]

    def set_rotation_order(self, value):
        self.plugs['rotateOrder'].set_value(env.rotation_orders.index(value))

    def set_shape(self, new_shape):
        curves = super(GroupedHandle, self).set_shape(
            new_shape
        )
        # if self.gimbal_handle:
        #     gimbal_curves = self.gimbal_handle.set_shape(
        #         new_shape
        #     )
        #     if gimbal_curves:
        #         for curve in gimbal_curves:
        #             self.plugs['gimbalVisibility'].connect_to(curve.plugs['visibility'])
        #     # shape_matrix = self.get_shape_matrix()
        #     # scale = shape_matrix.get_scale()
        #     # shape_matrix.set_scale([
        #     #     scale[0] * self.gimbal_scale,
        #     #     scale[1] * self.gimbal_scale,
        #     #     scale[2] * self.gimbal_scale,
        #     # ])
        #     self.gimbal_handle.set_shape_matrix(shape_matrix)

        return curves

    def normalize_gimbal_shape(self):
        if self.gimbal_handle:
            shape_matrix = self.get_shape_matrix()
            scale = shape_matrix.get_scale()
            shape_matrix.set_scale([
                scale[0] * self.gimbal_scale,
                scale[1] * self.gimbal_scale,
                scale[2]* self.gimbal_scale,
            ])
            self.gimbal_handle.set_shape_matrix(shape_matrix)


class StandardHandle(GroupedHandle):

    named_groups = ObjectDictProperty(
        name='named_groups'
    )

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs.setdefault('create_gimbal', True)
        kwargs['group_count'] = 3
        this = super(StandardHandle, cls).create(controller, **kwargs)
        this.named_groups['top'] = this.groups[0]
        this.named_groups['constraint'] = this.groups[1]
        this.named_groups['anim'] = this.groups[2]
        return this


class GimbalHandle(StandardHandle):

    named_groups = ObjectDictProperty(
        name='named_groups'
    )

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['create_gimbal'] = True
        this = super(GimbalHandle, cls).create(controller, **kwargs)
        return this



class LocalHandle(GroupedHandle):

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs.setdefault('create_gimbal', True)
        this = super(LocalHandle, cls).create(controller, **kwargs)
        if this.side in ['left', 'right']:
            this.mirror_plugs = ['translateX', 'translateY', 'translateZ']
        elif this.side == 'center':
            this.mirror_plugs = ['translateX', 'rotateZ', 'rotateY']
        return this


class WorldHandle(GroupedHandle):

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs.setdefault('create_gimbal', True)
        this = super(WorldHandle, cls).create(controller, **kwargs)
        if this.side in ['left', 'right']:
            this.mirror_plugs = ['translateX', 'rotateZ']
        elif this.side == 'center':
            this.mirror_plugs = ['translateX', 'rotateZ']
        return this


class CogHandle(GroupedHandle):

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs.setdefault('create_gimbal', True)
        this = super(CogHandle, cls).create(controller, **kwargs)
        if this.side == 'center':
            this.mirror_plugs = ['rotateZ']
        return this
