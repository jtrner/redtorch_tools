import os
import traceback

from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.node_objects.transform import Transform
import rig_factory

def get_shape_descendants(controller, node):
    node.plugs['v'].set_value(True)
    mesh_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='mesh',
        f=True
    )
    nurbs_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='nurbsSurface',
        f=True
    )
    descendants = []
    if mesh_relatives:
        descendants = [controller.initialize_node(x, parent=node) for x in mesh_relatives]
    if nurbs_relatives:
        descendants = [controller.initialize_node(x, parent=node) for x in nurbs_relatives]
    transform_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='transform',
        f=True
    )
    if transform_relatives:
        transforms = [controller.initialize_node(x, parent=node) for x in transform_relatives]
        for transform in transforms:
            descendants.extend(controller.get_shape_descendants(transform))

    for descendant in descendants:
        descendant.plugs['v'].set_value(True)

    return descendants


def create_origin_geometry(container, origin_geometry_data):
    controller = container.controller
    error_messages = []
    invalid_geometry_names = []
    for origin_geometry_name in origin_geometry_data:
        if origin_geometry_name in controller.named_objects:
            origin_data = origin_geometry_data[origin_geometry_name]
            faces = origin_data['faces']
            count = origin_data['count']
            geometry_transform = controller.named_objects[origin_geometry_name]
            mesh_objects = [x for x in geometry_transform.children if isinstance(x, Mesh)]
            if len(mesh_objects) < 1:
                error_messages.append('No mesh children found under "%s"' % geometry_transform)
            elif len(mesh_objects) > 1:
                error_messages.append('more than one mesh children found under "%s"' % geometry_transform)
            else:
                current_geometry = origin_geometry_name
                for x in range(count):
                    if x == 0:
                        geo_name = '%s_Origin' % origin_geometry_name
                    else:
                        geo_name = '%s_Origin%s' % (origin_geometry_name, rig_factory.index_dictionary[x-1].upper())
                    origin_geometry_transform = controller.create_object(
                        Transform,
                        name=geo_name,
                        parent=container.origin_geometry_group
                    )
                    origin_mesh = controller.copy_mesh(
                        mesh_objects[0].name,
                        origin_geometry_transform,
                        name='%sShape' % geo_name,
                    )
                    origin_mesh.assign_shading_group(
                        container.shaders['origin'].shading_group
                    )
                    container.geometry[origin_mesh.name] = origin_mesh
                    if faces:
                        index_strings = faces.split('[')[-1].split(']')[0].split(':')
                        start_index, end_index = map(int, index_strings)
                        controller.scene.select('%s.f[%s:%s]' % (origin_mesh, start_index, end_index))
                        controller.scene.select('%s.f[*]' % origin_mesh, tgl=True)
                        controller.scene.delete()
                        controller.scene.delete(origin_mesh, ch=True)
                    blendshape_name = controller.scene.blendShape(
                        origin_mesh,
                        current_geometry,
                        tc=False
                    )[0]
                    controller.scene.setAttr('%s.weight[0]' % blendshape_name, 1.0)
                    current_geometry = origin_geometry_transform


        else:
            invalid_geometry_names.append(origin_geometry_name)

def underscore_to_camelcase(value):
    def camelcase():
        while True:
            yield str.capitalize

    c = camelcase()
    return "".join(c.next()(str(x)) if x else '_' for x in value.split("_"))


def import_geo(controller, path, parent=None):
    root_nodes = controller.scene.import_geometry(path)
    if root_nodes:
        new_geometry = dict()
        for geometry_root in [controller.initialize_node(x, parent=parent) for x in root_nodes]:
            shapes = get_shape_descendants(controller, geometry_root)
            new_geometry.update(dict((x.name, x) for x in shapes if isinstance(x, Mesh)))
            controller.scene.select(cl=True)
        return new_geometry
    else:
        print 'Warning ! No geometry roots found in %s' % path


def import_geometry_paths(container):
    """
    This imports geometries from the given paths and parents them under proper groups
    This does not alter the blueprint geometry paths but import_geometry does
    import_geometry is used to import geometries and update geometry_paths
    """
    geometry_paths = container.geometry_paths
    controller = container.controller
    controller.progress_signal.emit(
        message='Importing Geometry...',
        maximum=len(geometry_paths) + 1,
        value=0
    )

    for i, path in enumerate(geometry_paths):
        controller.progress_signal.emit(
            message='Importing Geometry: %s' % path.split('/')[-1],
            value=i + 1
        )
        if path.startswith('/'):
            path = '%s%s' % (controller.build_directory, path)

        if os.path.exists(path):
            new_geometry = import_geo(
                controller,
                path,
                parent=container.geometry_group
            )

            if new_geometry and container.smooth_mesh_normals:
                smooth_normals(controller, new_geometry.values())

            container.geometry.update(new_geometry)

        else:
            print('The geometry path does not exist: %s' % path)

    # add geo path to group so we can track which model the rig is using
    geometry_path_plug = container.geometry_group.create_plug(
        'geometry_path',
        dt='string'
    )
    geometry_path_plug.set_value(str(geometry_paths))

    controller.progress_signal.emit(done=True)


def import_utility_geometry_paths(container):
    """
    This imports geometries from the given paths and parents them under proper groups
    This does not alter the blueprint geometry paths but import_geometry does
    import_geometry is used to import geometries and update utility_geometry_paths
    """
    utility_geometry_paths = container.utility_geometry_paths
    controller = container.controller
    controller.progress_signal.emit(
        message='Importing Geometry...',
        maximum=len(utility_geometry_paths) + 1,
        value=0
    )

    for i, path in enumerate(utility_geometry_paths):
        controller.progress_signal.emit(
            message='Importing Geometry: %s' % path.split('/')[-1],
            value=i + 1
        )
        if path.startswith('/'):
            path = '%s%s' % (controller.build_directory, path)

        if os.path.exists(path):
            new_geometry = import_geo(
                controller,
                path,
                parent=container.utility_geometry_group
            )

            if new_geometry and container.smooth_mesh_normals:
                smooth_normals(controller, new_geometry.values())

            container.geometry.update(new_geometry)

        else:
            print('The geometry path does not exist: %s' % path)

    # add geo path to group so we can track which model the rig is using
    utility_geometry_path_plug = container.geometry_group.create_plug(
        'utility_geometry_path',
        dt='string'
    )
    utility_geometry_path_plug.set_value(str(utility_geometry_paths))

    controller.progress_signal.emit(done=True)


def import_low_geometry_paths(container):
    """
    This imports geometries from the given paths and parents them under proper groups
    This does not alter the blueprint geometry paths but import_geometry does
    import_geometry is used to import geometries and update low_geometry_paths
    """
    low_geometry_paths = container.low_geometry_paths
    controller = container.controller
    controller.progress_signal.emit(
        message='Importing Geometry...',
        maximum=len(low_geometry_paths) + 1,
        value=0
    )

    for i, path in enumerate(low_geometry_paths):
        controller.progress_signal.emit(
            message='Importing Geometry: %s' % path.split('/')[-1],
            value=i + 1
        )
        if path.startswith('/'):
            path = '%s%s' % (controller.build_directory, path)

        if os.path.exists(path):
            new_geometry = import_geo(
                controller,
                path,
                parent=container.low_geometry_group
            )

            if new_geometry and container.smooth_mesh_normals:
                smooth_normals(controller, new_geometry.values())

            container.geometry.update(new_geometry)

        else:
            print('The geometry path does not exist: %s' % path)

    # add geo path to group so we can track which model the rig is using
    low_geometry_path_plug = container.geometry_group.create_plug(
        'low_geometry_path',
        dt='string'
    )
    low_geometry_path_plug.set_value(str(low_geometry_paths))

    controller.progress_signal.emit(done=True)


def smooth_normals(controller, geometries):
    try:
        controller.scene.select([x.name for x in geometries])
        controller.scene.polyNormalPerVertex(ufn=True)
        for geo in [x.name for x in geometries]:
            controller.scene.polySoftEdge(
                geo,
                a=180,
                ch=False
            )
    except Exception as e:
        traceback.print_exc()
        controller.raise_warning(
            'Something went wrong. Unable to smooth mesh normals. See script editor for details'
        )