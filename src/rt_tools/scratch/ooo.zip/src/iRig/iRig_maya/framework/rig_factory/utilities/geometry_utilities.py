import os
from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.node_objects.transform import Transform
import traceback

def import_geometry(controller, path, parent=None):
    root_nodes = controller.scene.import_geometry(path)
    if root_nodes:
        new_geometry = dict()
        for geometry_root in [controller.initialize_node(x, parent=parent) for x in root_nodes]:
            shapes = get_shape_descendants(controller, geometry_root)
            new_geometry.update(dict((x.name, x) for x in shapes if isinstance(x, Mesh)))
            controller.scene.select(cl=True)
        return new_geometry
    else:
        print 'Warning ! No geometry roots found in %s' % path


def get_shape_descendants(controller, node):
    mesh_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='mesh',
        f=True
    )
    nurbs_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='nurbsSurface',
        f=True
    )
    descendants = []
    if mesh_relatives:
        descendants = [controller.initialize_node(x, parent=node) for x in mesh_relatives]
    if nurbs_relatives:
        descendants = [controller.initialize_node(x, parent=node) for x in nurbs_relatives]
    transform_relatives = controller.scene.listRelatives(
        node,
        c=True,
        type='transform',
        f=True
    )
    if transform_relatives:
        transforms = [controller.initialize_node(x, parent=node) for x in transform_relatives]
        for transform in transforms:
            descendants.extend(controller.get_shape_descendants(transform))
    return descendants


def create_origin_geometry(container, origin_geometry_names):
    controller = container.controller
    error_messages = []
    invalid_geometry_names = []
    for i, origin_geometry_name in enumerate(origin_geometry_names):
        if origin_geometry_name in controller.named_objects:
            origin_geometry_faces = origin_geometry_names[origin_geometry_name]
            geometry_transform = controller.named_objects[origin_geometry_name]
            mesh_objects = [x for x in geometry_transform.children if isinstance(x, Mesh)]
            if len(mesh_objects) < 1:
                error_messages.append('No mesh children found under "%s"' % geometry_transform)
            elif len(mesh_objects) > 1:
                error_messages.append('more than one mesh children found under "%s"' % geometry_transform)
            else:
                origin_geometry_transform = controller.create_object(
                    Transform,
                    name='%s_Origin' % origin_geometry_name,
                    parent=container.origin_geometry_group
                )
                origin_mesh = controller.copy_mesh(
                    mesh_objects[0].name,
                    origin_geometry_transform,
                    name='%s_OriginShape' % origin_geometry_name,
                )
                origin_mesh.assign_shading_group(
                    container.shaders['origin'].shading_group
                )
                container.geometry[origin_mesh.name] = origin_mesh
                if origin_geometry_faces:
                    index_strings = origin_geometry_faces.split('[')[-1].split(']')[0].split(':')
                    start_index, end_index = map(int, index_strings)
                    controller.scene.select('%s.f[%s:%s]' % (origin_mesh, start_index, end_index))
                    controller.scene.select('%s.f[*]' % origin_mesh, tgl=True)
                    controller.scene.delete()
                    controller.scene.delete(origin_mesh, ch=True)

                blendshape_name = controller.scene.blendShape(
                    origin_mesh,
                    mesh_objects[0],
                    tc=False
                )[0]
                controller.scene.setAttr('%s.weight[0]' % blendshape_name, 1.0)
                # difference_blendshape = container.create_child(
                #     Blendshape,
                #     mesh_objects[0],
                #     parent=geometry_transform,
                #     root_name=underscore_to_camelcase(geometry_transform.name.title()),
                #     segment_name='Origin',
                #     tangent_space=False
                # )
                # blendshsape_group = difference_blendshape.create_group(
                #     origin_mesh,
                #     segment_name='Origin%s' % underscore_to_camelcase(origin_mesh.name.title()),
                #     tangent_space=False
                # )
                # blendshsape_group.get_weight_plug().set_value(1.0)

        else:
            invalid_geometry_names.append(origin_geometry_name)

def underscore_to_camelcase(value):
    def camelcase():
        while True:
            yield str.capitalize

    c = camelcase()
    return "".join(c.next()(str(x)) if x else '_' for x in value.split("_"))

def import_geometry_paths(container, geometry_paths):
    """
    WHY does this exist as well as mesh_utilities.import_geometry ??????
    """


    controller = container.controller
    controller.progress_signal.emit(
        message='Importing Geometry...',
        maximum=len(geometry_paths) + 1,
        value=0
    )
    for i, path in enumerate(geometry_paths):
        controller.progress_signal.emit(
            message='Importing Geometry: %s' % path.split('/')[-1],
            value=i+1
        )
        if path.startswith('/'):
            path = '%s/%s' % (controller.build_directory, path)
        if os.path.exists(path):
            new_geometry = import_geometry(
                controller,
                path,
                parent=container.geometry_group
            )
            if new_geometry and container.smooth_mesh_normals:
                try: #aNTIpATTERN
                    controller.scene.select([x.name for x in new_geometry.values()])
                    controller.scene.polyNormalPerVertex(ufn=True)
                    for geo in [x.name for x in new_geometry.values()]:
                        controller.scene.polySoftEdge(
                            geo,
                            a=180,
                            ch=False
                        )
                except Exception as e:
                    traceback.print_exc()
                    controller.raise_warning(
                        'Something went wrong. Unable to smooth mesh normals. See script editor for details'
                    )

            container.geometry.update(new_geometry)

        else:
            print('The geometry path does not exist: %s' % path)
    controller.progress_signal.emit(done=True)
