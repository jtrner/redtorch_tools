
from part_develoment_examples.base_chain_example import BaseChainGuide

def run_mock():
    import rig_factory.build.utilities.controller_utilities as cut
    import batch_tasks.rigging_environment as rev
    rev.load_mock_rigging_environment('RBGB', 'Hopper')
    controller = cut.initialize_base_controller(mock=True)
    controller.root = controller.create_object('ContainerGuide')
    controller.root.create_part(BaseChainGuide)


def run_standalone():
    import rig_factory.build.utilities.controller_utilities as cut
    import batch_tasks.rigging_environment as rev
    rev.load_mock_rigging_environment('RBGB', 'Hopper')
    controller = cut.initialize_base_controller(standalone=True)
    controller.root = controller.create_object('ContainerGuide')
    controller.root.create_part(BaseChainGuide)

if __name__ == '__main__':
    run_standalone()