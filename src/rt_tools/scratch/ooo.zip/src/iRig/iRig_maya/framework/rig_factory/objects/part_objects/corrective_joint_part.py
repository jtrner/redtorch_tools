from rig_factory.objects import DependNode
from rig_factory.objects.base_objects.properties import DataProperty
from rig_factory.objects.part_objects.part import PartGuide, Part
from rig_factory.objects.rig_objects.cone import Cone
from rig_factory.objects.node_objects.joint import Joint


class CorrectiveJointGuide(PartGuide):
    default_settings = dict(
        root_name='CorrectiveJoint',
        size=5.0,
        side='left',
        start='C_Spine_SecondaryI_Bind_Jnt',
        end='L_Arm_ShoulderSecondaryA_Bind_Jnt',
        volume=1
    )
    start = DataProperty(
        name='start'
    )
    end = DataProperty(
        name='end'
    )
    volume = DataProperty(
        name='volume'
    )

    def __init__(self, **kwargs):
        self.default_settings['root_name'] = 'CorrectiveJoint'
        super(CorrectiveJointGuide, self).__init__(**kwargs)
        self.toggle_class = CorrectiveJoint.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        """
        Use corrective Guides
        """
        kwargs.setdefault('side', 'left')
        this = super(CorrectiveJointGuide, cls).create(controller, **kwargs)
        side = this.side
        size = this.size
        size_plug = this.plugs['size']
        this.joint_chain = False

        base_joint = this.create_child(
            Joint,
            index=3,
            segment_name='Base'
        )
        mid_joint = this.create_child(
            Joint,
            index=4,
            segment_name='Mid'
        )
        end_joint = this.create_child(
            Joint,
            index=5,
            segment_name='End'
        )

        this.joints = [base_joint,
                       mid_joint,
                       end_joint]

        for jnt in this.joints:
            jnt.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
                radius=0.5
            )

        # handles
        root = this.get_root()
        base_handle = this.create_handle(
            segment_name='Base'
        )
        base_handle.mesh.assign_shading_group(root.shaders[side].shading_group)
        size_plug.connect_to(base_handle.plugs['size'])

        end_handle = this.create_handle(
            segment_name='End'
        )
        end_handle.mesh.assign_shading_group(root.shaders[side].shading_group)
        size_plug.connect_to(end_handle.plugs['size'])

        controller.create_matrix_parent_constraint(
            base_handle,
            base_joint
        )
        controller.create_matrix_parent_constraint(
            end_handle,
            end_joint
        )
        controller.create_point_constraint(
            base_joint,
            end_joint,
            mid_joint,
            mo=False,
        )
        this.handles = [base_handle, end_handle]

        # cones
        for jnt in this.joints:
            segment_name_X = '{}X'.format(jnt.name)
            segment_name_Y = '{}Y'.format(jnt.name)
            segment_name_Z = '{}Z'.format(jnt.name)
            cone_x = jnt.create_child(
                Cone,
                segment_name=segment_name_X,
                size=size * 0.1,
                axis=[1.0, 0.0, 0.0]
            )
            cone_y = jnt.create_child(
                Cone,
                segment_name=segment_name_Y ,
                size=size * 0.099,
                axis=[0.0, 1.0, 0.0]
            )
            cone_z = jnt.create_child(
                Cone,
                segment_name=segment_name_Z,
                size=size * 0.098,
                axis=[0.0, 0.0, 1.0]
            )
            for obj, axis in zip((cone_x, cone_y, cone_z), ('x', 'y', 'z')):
                obj.mesh.assign_shading_group(root.shaders[axis].shading_group)
                obj.plugs.set_values(
                    overrideEnabled=True,
                    overrideDisplayType=2,
                )
                size_plug.connect_to(obj.plugs['size'])

        return this

    def get_blueprint(self):
        blueprint = super(CorrectiveJointGuide, self).get_blueprint()
        matrices = [list(x.get_matrix()) for x in self.joints]
        blueprint['matrices'] = matrices
        return blueprint

    def get_toggle_blueprint(self):
        blueprint = super(CorrectiveJointGuide, self).get_toggle_blueprint()
        matrices = [list(x.get_matrix()) for x in self.joints]
        blueprint['matrices'] = matrices
        return blueprint

    def post_create(self, *args, **kwargs):
        super(CorrectiveJointGuide, self).post_create(*args, **kwargs)
        pass


class CorrectiveJoint(Part):
    """
    Use corrective build
    """
    start = DataProperty(
        name='start'
    )
    end = DataProperty(
        name='end'
    )
    volume = DataProperty(
        name='volume'
    )

    def __init__(self, **kwargs):
        super(CorrectiveJoint, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(CorrectiveJoint, cls).create(controller, **kwargs)
        size = this.size
        root_name = this.root_name
        matrices = this.matrices
        this.joint_chain = False

        base_joint = this.create_child(
            Joint,
            root_name=root_name,
            segment_name='Base',
            matrix=matrices[0],
        )
        mid_joint = this.create_child(
            Joint,
            root_name=root_name,
            segment_name='Mid',
            matrix=matrices[1],
        )
        end_joint = this.create_child(
            Joint,
            root_name=root_name,
            segment_name='End',
            matrix=matrices[2],
        )
        for jnt in [base_joint, mid_joint, end_joint]:
            jnt.plugs.set_values(
                overrideEnabled=1,
                overrideDisplayType=2
            )

        this.joints = [base_joint,
                       mid_joint,
                       end_joint]

        controller.create_point_constraint(
            base_joint,
            end_joint,
            mid_joint,
            mo=False
        )

        return this

    def finish_create(self, *args, **kwargs):
        super(CorrectiveJoint, self).finish_create(*args, **kwargs)
        if self.side == 'right':
            self.start = self.start.replace('L_', 'R_')
            self.end = self.end.replace('L_', 'R_')
        if self.start in self.controller.named_objects and self.end in self.controller.named_objects:
            start = self.controller.named_objects[self.start]
            end = self.controller.named_objects[self.end]
            volume = self.volume
            base_joint = self.joints[0]
            mid_joint = self.joints[1]
            end_joint = self.joints[2]
            base_bind_joint = self.base_deform_joints[0]
            mid_bind_joint = self.base_deform_joints[1]
            end_bind_joint = self.base_deform_joints[2]
            base_joint.set_parent(start)
            mid_joint.set_parent(start)
            end_joint.set_parent(end)
            base_bind_joint.set_parent(start)
            mid_bind_joint.set_parent(start)
            end_bind_joint.set_parent(end)

            # volume
            part_name = self.name.split('_')
            name = '{}{}'.format(part_name[0], part_name[1])
            scale_ctl = self.controller.named_objects['C_Main_Root_Gimbal_Ctrl']
            dist = self.create_child(DependNode, node_type='distanceBetween', root_name='{}Dist'.format(name))
            div_normalize = self.create_child(DependNode, node_type='multiplyDivide', root_name='{}Normal'.format(name))
            div_scale = self.create_child(DependNode, node_type='multiplyDivide', root_name='{}Scale'.format(name))
            div_volume = self.create_child(DependNode, node_type='multiplyDivide', root_name='{}Volume'.format(name))
            rev = self.create_child(DependNode, node_type='reverse', root_name='{}Rev'.format(name))
            range = self.create_child(DependNode, node_type='setRange', root_name='{}Rng'.format(name))
            div_normalize.plugs['operation'].set_value(2)
            div_scale.plugs['operation'].set_value(2)
            div_volume.plugs['operation'].set_value(1)
            base_joint.plugs['worldMatrix'].child(0).connect_to(dist.plugs['inMatrix1'])
            end_joint.plugs['worldMatrix'].child(0).connect_to(dist.plugs['inMatrix2'])
            dist.plugs['distance'].connect_to(div_normalize.plugs['input1X'])
            div_normalize.plugs['input2'].child(0).set_value(dist.plugs['distance'].get_value())
            div_normalize.plugs['outputX'].connect_to(div_scale.plugs['input1X'])
            scale_ctl.plugs['scaleX'].connect_to(div_scale.plugs['input2X'])
            div_scale.plugs['outputX'].connect_to(rev.plugs['inputX'])
            div_scale.plugs['outputX'].connect_to(rev.plugs['inputY'])
            div_scale.plugs['outputX'].connect_to(rev.plugs['inputZ'])
            rev.plugs['output'].connect_to(div_volume.plugs['input1'])
            div_volume.plugs['input2X'].set_value(volume)
            div_volume.plugs['output'].connect_to(range.plugs['value'])
            range.plugs['minX'].set_value(0.1)
            range.plugs['minY'].set_value(0.1)
            range.plugs['minZ'].set_value(0.1)
            range.plugs['maxX'].set_value(1.9)
            range.plugs['maxY'].set_value(1.9)
            range.plugs['maxZ'].set_value(1.9)
            range.plugs['oldMinX'].set_value(-10)
            range.plugs['oldMinY'].set_value(-10)
            range.plugs['oldMinZ'].set_value(-10)
            range.plugs['oldMaxX'].set_value(10)
            range.plugs['oldMaxY'].set_value(10)
            range.plugs['oldMaxZ'].set_value(10)
            range.plugs['outValueX'].connect_to(mid_joint.plugs['scaleX'])
            range.plugs['outValueY'].connect_to(mid_joint.plugs['scaleY'])
            range.plugs['outValueZ'].connect_to(mid_joint.plugs['scaleZ'])

            return True
        else:
            self.controller.raise_warning('{} , {} does not exist!'.format(self.start, self.end))
            return False





