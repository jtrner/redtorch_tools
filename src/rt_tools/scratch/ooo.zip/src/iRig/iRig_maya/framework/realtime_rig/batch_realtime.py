import multiprocessing
import maya.standalone as standalone

standalone.initialize(name='python')


def batch_function(data):
    project, entity = data
    import batch_tasks.rigging_environment as rev
    rev.load_system_paths(project)
    rev.load_rigging_environment(
        project,
        entity
    )
    rev.load_rigging_plugins()

    import rig_factory.build.utilities.controller_utilities as cut
    controller = cut.initialize_rig_controller(standalone=True)
    import realtime_rig.realtime_rig as rtr
    rtr.build_realtime_rig_product(controller)


if __name__ == "__main__":
    entities = [
        ('SUPA', 'Jessa_Lebron'),
        ('SUPA', 'Braxton'),
    ]
    p = multiprocessing.Pool(len(entities))
    result = p.map_async(batch_function, entities)
    print(result.get())
