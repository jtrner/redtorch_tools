from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.node_objects.nurbs_surface import NurbsSurface
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.joint import Joint
from rig_math.matrix import Matrix
import rig_factory.utilities.spline_builders as spb
import rig_factory
import rig_factory.environment as env


class ArrayMixin(object):

    def __init__(self, **kwargs):
        super(ArrayMixin, self).__init__(**kwargs)

    def get_control_points(self):
        return self.controller.get_control_points(self)

    def snap_to_mesh(self, mesh):
        self.controller.snap_to_mesh(self, mesh)

    def create_points(self, *vertices, **kwargs):
        return self.controller.create_points(self, *vertices, **kwargs)

    def create_point(self, **kwargs):
        return self.controller.create_point(self, **kwargs)


class DoubleSurfaceSplineUpvectorsGuide(PartGuide, ArrayMixin):

    surface_data = DataProperty(
        name='surface_data'
    )
    locators = ObjectListProperty(
        name='locators'
    )
    count = DataProperty(
        name='count'
    )
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )
    spline_handles = ObjectListProperty(
        name='spline_handles'
    )
    joint_count = DataProperty(
        name='joint_count',
        default_value=19
    )
    use_fit_curve = DataProperty(
        name='use_fit_curve',
        default_value=False
    )
    create_gimbal = DataProperty(
        name='create_gimbal'
    )
    threshold = DataProperty(
        name='threshold',
        default_value=0.01
    )
    secondary_parameters = DataProperty(
        name='secondary_parameters'
    )
    secondary_translations = DataProperty(
        name='secondary_translations'
    )
    upper_up_vector_position = DataProperty(
        name='upper_up_vector_position'
    )
    lower_up_vector_position = DataProperty(
        name='lower_up_vector_position'
    )
    follicle_surface = ObjectProperty(
        name='follicle_surface'
    )
    up_vector_transform = ObjectProperty(
        name='up_vector_transform'
    )
    upper_up_vector_transform = ObjectProperty(
        name='upper_up_vector_transform'
    )
    lower_up_vector_transform = ObjectProperty(
        name='lower_up_vector_transform'
    )
    ribbon_surface = ObjectProperty(
        name='ribbon_surface'
    )
    create_shards = DataProperty(
        name='create_shards',
        default_value=False
    )
    create_spline_on_surface = DataProperty(
        name='create_spline_on_surface',
        default_value=False
    )
    create_roll_joints = DataProperty(
        name='create_roll_joints',
        default_value=False
    )
    upper_spline_handles = ObjectListProperty(
        name='upper_spline_handles'
    )
    lower_spline_handles = ObjectListProperty(
        name='lower_spline_handles'
    )
    upper_main_curve = ObjectProperty(
        name='upper_main_curve'
    )
    lower_main_curve = ObjectProperty(
        name='lower_main_curve'
    )

    default_settings = dict(
        root_name='Handle',
        count=5,
        lower_count=None,
        size=3.0,
        mirror=False,
        side=None,
        threshold=0.01,
        create_gimbal=False,
        use_fit_curve=False,
        joint_count=9,
        create_shards=False,
        create_spline_on_surface=True,
        create_roll_joints=False
    )

    def __init__(self, **kwargs):
        super(DoubleSurfaceSplineUpvectorsGuide, self).__init__(**kwargs)
        self.toggle_class = DoubleSurfaceSplineUpvectors.__name__

    @classmethod
    def create(cls, controller, **kwargs):

        this = super(DoubleSurfaceSplineUpvectorsGuide, cls).create(controller, **kwargs)
        count = this.count
        side = this.side
        size = this.size

        size_multiply = this.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='Size'
        )

        size_plug = this.plugs['size']

        size_plug.connect_to(size_multiply.plugs['input1X'])
        size_plug.connect_to(size_multiply.plugs['input1Y'])
        size_multiply.plugs['input2X'].set_value(0.5)
        size_multiply.plugs['input2Y'].set_value(0.5)

        upper_handle_data = create_handle_data(
            count,
            side,
            this.root_name,
            'Upper',
            size
        )

        lower_handle_data = create_handle_data(
            count,
            side,
            this.root_name,
            'Lower',
            size
        )

        if this.surface_data:
            positions, knots_u, knots_v, degree_u, degree_v, form_u, form_v = this.surface_data
            follicle_surface_transform = this.create_child(
                Transform,
                segment_name='Slide'
            )
            this.follicle_surface = follicle_surface_transform.create_child(
                NurbsSurface,
                positions=positions,
                knots_u=knots_u,
                knots_v=knots_v,
                degree_u=degree_u,
                degree_v=degree_v,
                form_u=form_u,
                form_v=form_v
            )
            this.follicle_surface.plugs['curvePrecisionShaded'].set_value(10)
            # this.follicle_surface.plugs['overrideDisplayType'].set_value(2)
            this.follicle_surface.plugs['overrideEnabled'].set_value(1)
            this.follicle_surface.assign_shading_group(this.get_root().shaders[this.side].shading_group)

        if not this.surface_data or not this.create_spline_on_surface:
            up_vector_transform = this.create_child(
                Transform,
                segment_name='UpperUpVector'
            )
            up_vector_transform.create_child(
                Locator
            )
            this.upper_up_vector_transform = up_vector_transform
            if this.upper_up_vector_position:
                this.upper_up_vector_transform.set_matrix(Matrix(this.upper_up_vector_position))
            else:
                this.upper_up_vector_position = list(this.upper_up_vector_transform.get_matrix())

            #adding second upvector
            up_vector_transform = this.create_child(
                Transform,
                segment_name='LowerUpVector'
            )
            up_vector_transform.create_child(
                Locator
            )
            this.lower_up_vector_transform = up_vector_transform
            if this.lower_up_vector_position:
                this.lower_up_vector_transform.set_matrix(Matrix(this.lower_up_vector_position))
            else:
                this.lower_up_vector_position = list(this.lower_up_vector_transform.get_matrix())

        start_handle, start_joint = spb.create_guide_handle(
            this,
            **upper_handle_data[0]
        )
        end_handle, end_joint = spb.create_guide_handle(
            this,
            **upper_handle_data[-1]
        )
        size_multiply.plugs['outputX'].connect_to(start_handle.plugs['size'])
        size_multiply.plugs['outputX'].connect_to(end_handle.plugs['size'])

        upper_handles = []
        upper_joints = []
        for handle_data in upper_handle_data[1:-1]:
            handle, joint = spb.create_guide_handle(
                this,
                **handle_data
            )
            size_multiply.plugs['outputX'].connect_to(handle.plugs['size'])
            upper_handles.append(handle)
            upper_joints.append(joint)

        lower_handles = []
        lower_joints = []
        for handle_data in lower_handle_data[1:-1]:
            handle, joint = spb.create_guide_handle(
                this,
                **handle_data
            )
            size_multiply.plugs['outputX'].connect_to(handle.plugs['size'])
            lower_handles.append(handle)
            lower_joints.append(joint)

        all_handles = [start_handle]
        all_handles.extend(merge_lists(upper_handles, lower_handles))
        all_handles.append(end_handle)
        this.base_handles = list(all_handles)

        all_joints = [start_joint]
        all_joints.extend(merge_lists(upper_joints, lower_joints))
        all_joints.append(end_joint)
        this.joints = all_joints
        upper_spline_group = this.create_child(
            Transform,
            segment_name='Spline',
            differentiation_name='Upper'
        )
        driver_joints = [start_joint]
        driver_joints.extend(upper_joints)
        driver_joints.append(end_joint)
        this.up_vector_transform = this.upper_up_vector_transform
        upper_spline, upper_spline_handles, upper_spline_joints, upper_roll_joints = spb.create_spline(
            this,
            upper_spline_group,
            driver_joints
        )
        this.upper_main_curve = upper_spline
        this.upper_spline_handles = upper_spline_handles


        lower_spline_group = this.create_child(
            Transform,
            segment_name='Spline',
            differentiation_name='Lower'
        )

        driver_joints = [start_joint]
        driver_joints.extend(lower_joints)
        driver_joints.append(end_joint)

        this.up_vector_transform = this.lower_up_vector_transform
        lower_spline, lower_spline_handles, lower_spline_joints, lower_roll_joints = spb.create_spline(
            this,
            lower_spline_group,
            driver_joints
        )
        this.lower_main_curve = lower_spline
        this.lower_spline_handles = lower_spline_handles

        all_spline_joints = upper_spline_joints + lower_spline_joints
        all_spline_handles = upper_spline_handles + lower_spline_handles

        all_handles.extend(all_spline_handles)

        for handle in all_spline_handles:

            # handle.plugs['overrideRGBColors'].set_value(True)
            # handle.plugs['overrideColorRGB'].set_value([0.1, 0.1, 0.1])
            handle.plugs.set_locked(
                # translate=True,
                rotate=True,
                scale=True
            )
        for joint in all_spline_joints:

            joint.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
            )

        # Backward compatible "Slide" values
        joint_parameters = kwargs.pop('joint_parameters', None)
        # if not joint_parameters:
        #     print 'NO JOINT PARMS FOUND: %s' % this
        # elif not len(all_spline_handles) == len(joint_parameters):
        #     print 'param count mismatch ', len(all_spline_handles), len(joint_parameters), this
        #

        if joint_parameters and len(all_spline_handles) == len(joint_parameters):
            upper_joint_parameters = joint_parameters[:len(joint_parameters) / 2]
            lower_joint_parameters = joint_parameters[len(joint_parameters) / 2:]
            for i in range(len(upper_joint_parameters)):
                slide_value = 1.0 / (len(upper_joint_parameters)-1) * i + (upper_joint_parameters[i] * 0.1)
                upper_spline_handles[i].plugs['Slide'].set_value(slide_value)
            for i in range(len(lower_joint_parameters)):
                slide_value = 1.0 / (len(lower_joint_parameters)-1) * i + (lower_joint_parameters[i] * 0.1)
                lower_spline_handles[i].plugs['Slide'].set_value(slide_value)

        this.spline_joints = all_spline_joints
        this.spline_handles = all_spline_handles
        this.set_handles(all_handles)

        return this

    def get_blueprint(self):
        blueprint = super(DoubleSurfaceSplineUpvectorsGuide, self).get_blueprint()
        blueprint.update(dict(
            handle_positions=self.get_handle_positions(),
            handle_vertices=self.get_vertex_data(),
            secondary_parameters=[x.plugs['Slide'].get_value() for x in self.spline_handles],
            secondary_translations=[x.plugs['translate'].get_value() for x in self.spline_handles],
            upper_up_vector_position=list(self.upper_up_vector_transform.get_translation()) if self.upper_up_vector_transform else None,
            lower_up_vector_position=list(self.lower_up_vector_transform.get_translation()) if self.lower_up_vector_transform else None,
            surface_data=self.follicle_surface.get_surface_data() if self.follicle_surface else self.surface_data
        ))
        return blueprint

    def get_handle_data(self):
        handle_data = []
        if not self.base_handles:
            raise Exception('No Base Handles Found')
        for i, handle in enumerate(self.base_handles):
            handle = self.base_handles[i]
            handle_data.append(
                dict(
                    klass=handle.__class__.__name__,
                    module=handle.__module__,
                    vertices=[(x.mesh.get_selection_string(), x.index) for x in handle.vertices],
                    matrix=list(self.joints[i].get_matrix()),
                    root_name=handle.root_name,
                    segment_name=handle.segment_name,
                    differentiation_name=handle.differentiation_name,
                    size=handle.size,
                    side=handle.side
                )
            )
        return handle_data

    def get_toggle_blueprint(self):
        blueprint = super(DoubleSurfaceSplineUpvectorsGuide, self).get_toggle_blueprint()
        blueprint['handle_data'] = self.get_handle_data()
        blueprint['secondary_parameters'] = [x.plugs['Slide'].get_value() for x in self.spline_handles]
        blueprint['secondary_translations'] = [x.plugs['translate'].get_value() for x in self.spline_handles]
        blueprint['upper_up_vector_position'] = list(self.upper_up_vector_transform.get_translation()) if self.upper_up_vector_transform else None
        blueprint['lower_up_vector_position'] = list(self.lower_up_vector_transform.get_translation()) if self.lower_up_vector_transform else None
        blueprint['surface_data'] = self.follicle_surface.get_surface_data() if self.follicle_surface else self.surface_data

        return blueprint

    def get_mirror_blueprint(self):
        sides = dict(left='right', right='left')
        handles = self.handles
        if not all(self.side == x.side for x in handles):
            raise Exception('Non uniform handle sides not supported in mirror blueprint')
        blueprint = super(DoubleSurfaceSplineUpvectorsGuide, self).get_mirror_blueprint()
        handle_data = []
        for handle in self.handles:
            handle_matrix = list(handle.get_matrix())
            handle_matrix[12] = handle_matrix[12]*-1
            handle_properties = dict(
                klass=handle.__class__.__name__,
                module=handle.__module__,
                root_name=handle.root_name,
                size=handle.plugs['size'].get_value(1.0),
                side=sides[handle.side],
                index=handle.index,
                handle_matrix=handle_matrix
            )
            mirror_vertices = []
            for vertex in handle.vertices:
                position = list(vertex.get_translation())
                position[0] = position[0] * -1
                mirror_index = self.controller.get_closest_vertex_index(
                    vertex.mesh,
                    position,
                )
                mirror_vertex = vertex.mesh.get_vertex(mirror_index)
                mirror_vertices.append(mirror_vertex)
            handle_properties['vertices'] = [(x.mesh.get_selection_string(), x.index) for x in mirror_vertices]
            handle_data.append(handle_properties)
        blueprint['handle_data'] = handle_data
        blueprint['handle_data'] = handle_data

        return blueprint

    def set_vertex_data(self, *args, **kwargs):
        super(DoubleSurfaceSplineUpvectorsGuide, self).set_vertex_data(*args, **kwargs)
        self.consolidate_slide_values()

    def consolidate_slide_values(self):
        for handle in self.upper_spline_handles:
            position = list(handle.get_translation())
            closest_parameter = self.controller.scene.get_closest_curve_parameter(
                self.upper_main_curve.m_object,
                list(handle.get_translation())
            )
            upper_spans = self.upper_main_curve.plugs['spans'].get_value()
            if upper_spans == 0:
                raise Exception('The upper_main_curve for %s had zero spans' % self)
            handle.plugs['Slide'].set_value(closest_parameter / upper_spans)
            self.controller.scene.xform(handle, ws=True, t=position)

        for handle in self.lower_spline_handles:
            position = list(handle.get_translation())
            closest_parameter = self.controller.scene.get_closest_curve_parameter(
                self.lower_main_curve.m_object,
                list(handle.get_translation())
            )
            lower_spans = self.lower_main_curve.plugs['spans'].get_value()
            if lower_spans == 0:
                raise Exception('The lower_main_curve curve for %s had zero spans' % self)
            handle.plugs['Slide'].set_value(closest_parameter / lower_spans)
            self.controller.scene.xform(handle, ws=True, t=position)




class DoubleSurfaceSplineUpvectors(Part):

    surface_data = DataProperty(
        name='surface_data'
    )
    create_gimbal = DataProperty(
        name='create_gimbal'
    )
    use_fit_curve = DataProperty(
        name='use_fit_curve',
        default_value=False
    )
    fit_curve = ObjectProperty(
        name='fit_curve'
    )
    base_curve = ObjectProperty(
        name='base_curve'
    )
    follicle_surface = ObjectProperty(
        name='follicle_surface'
    )
    handle_data = DataProperty(
        name='handle_data'
    )
    joint_count = DataProperty(
        name='joint_count'
    )
    main_curve = ObjectProperty(
        name='spline_curve'
    )
    upper_main_curve = ObjectProperty(
        name='upper_main_curve'
    )
    lower_main_curve = ObjectProperty(
        name='lower_main_curve'
    )
    ribbon_surface = ObjectProperty(
        name='ribbon_surface'
    )
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )
    spline_handles = ObjectListProperty(
        name='spline_handles'
    )
    secondary_parameters = DataProperty(
        name='secondary_parameters'
    )
    secondary_translations = DataProperty(
        name='secondary_translations'
    )
    create_shards = DataProperty(
        name='create_shards',
        default_value=False
    )
    upper_joints = ObjectListProperty(
        name='upper_joints'
    )
    lower_joints = ObjectListProperty(
        name='lower_joints'
    )
    start_joint = ObjectProperty(
        name='start_joint'
    )
    end_joint = ObjectProperty(
        name='end_joint'
    )

    upper_bind_joints = ObjectListProperty(
        name='upper_bind_joints'
    )
    lower_bind_joints = ObjectListProperty(
        name='lower_bind_joints'
    )
    start_bind_joint = ObjectProperty(
        name='start_bind_joint'
    )
    end_bind_joint = ObjectProperty(
        name='end_bind_joint'
    )

    up_vector_position = DataProperty(
        name='up_vector_position'
    )
    up_vector_transform = ObjectProperty(
        name='up_vector_transform'
    )
    upper_up_vector_position = DataProperty(
        name='upper_up_vector_position'
    )
    upper_up_vector_transform = ObjectProperty(
        name='upper_up_vector_transform'
    )
    lower_up_vector_position = DataProperty(
        name='lower_up_vector_position'
    )
    lower_up_vector_transform = ObjectProperty(
        name='lower_up_vector_transform'
    )
    create_spline_on_surface = DataProperty(
        name='create_spline_on_surface',
        default_value=False
    )
    create_roll_joints = DataProperty(
        name='create_roll_joints',
        default_value=False
    )
    base_handles = ObjectListProperty(
        name='base_handles'
    )
    start_handle = ObjectProperty(
        name='start_handle'
    )
    end_handle = ObjectProperty(
        name='end_handle'
    )
    upper_handles = ObjectListProperty(
        name='upper_handles'
    )
    lower_handles = ObjectListProperty(
        name='lower_handles'
    )
    upper_spline_handles = ObjectListProperty(
        name='upper_spline_handles'
    )
    lower_spline_handles = ObjectListProperty(
        name='lower_spline_handles'
    )
    def __init__(self, **kwargs):
        super(DoubleSurfaceSplineUpvectors, self).__init__(**kwargs)
        self.disconnected_joints = True
        self.joint_chain = False

    @classmethod
    def create(cls, controller, **kwargs):
        handle_data = kwargs.pop('handle_data', None)
        if not handle_data:
            raise Exception('You must provide the handle_data keyword to create a %s' % cls.__name__)
        this = super(DoubleSurfaceSplineUpvectors, cls).create(controller, **kwargs)

        #  Chunk out data into upper and lower
        upper_handle_data = [handle_data[0]]
        lower_handle_data = [handle_data[0]]
        for up_data, down_data in chunks(handle_data[1:-1], 2):
            upper_handle_data.append(up_data)
            lower_handle_data.append(down_data)
        upper_handle_data.append(handle_data[-1])
        lower_handle_data.append(handle_data[-1])

        if this.surface_data:
            positions, knots_u, knots_v, degree_u, degree_v, form_u, form_v = this.surface_data
            surface_transform = this.create_child(
                Transform,
                segment_name='Surface'
            )
            this.follicle_surface = surface_transform.create_child(
                NurbsSurface,
                positions=positions,
                knots_u=knots_u,
                knots_v=knots_v,
                degree_u=degree_u,
                degree_v=degree_v,
                form_u=form_u,
                form_v=form_v
            )
            this.follicle_surface.plugs['v'].set_value(False)
        if not this.surface_data or not this.create_spline_on_surface:

            upper_up_vector_transform = this.create_child(
                Transform,
                segment_name='UpperUpVector'
            )
            upper_up_vector_transform.create_child(
                Locator
            )
            this.upper_up_vector_transform = upper_up_vector_transform
            if this.upper_up_vector_position:
                this.upper_up_vector_transform.set_matrix(Matrix(this.upper_up_vector_position))
            else:
                this.upper_up_vector_position = this.upper_up_vector_transform.get_matrix()

            #lower upvector
            lower_up_vector_transform = this.create_child(
                Transform,
                segment_name='LowerUpVector'
            )
            lower_up_vector_transform.create_child(
                Locator
            )
            this.lower_up_vector_transform = lower_up_vector_transform
            if this.lower_up_vector_position:
                this.lower_up_vector_transform.set_matrix(Matrix(this.lower_up_vector_position))
            else:
                this.lower_up_vector_position = this.lower_up_vector_transform.get_matrix()

        start_handle, start_joint = spb.create_handle(this, **upper_handle_data[0])
        end_handle, end_joint = spb.create_handle(this, **upper_handle_data[-1])
        upper_handles = []
        upper_joints = []
        for data in upper_handle_data[1:-1]:
            handle, joint = spb.create_handle(this, **data)
            upper_handles.append(handle)
            upper_joints.append(joint)

        lower_handles = []
        lower_joints = []
        for data in lower_handle_data[1:-1]:
            handle, joint = spb.create_handle(this, **data)
            lower_handles.append(handle)
            lower_joints.append(joint)

        all_handles = [start_handle]
        all_handles.extend(merge_lists(upper_handles, lower_handles))
        all_handles.append(end_handle)

        for handle in all_handles:
            this.get_root().add_plugs(
                handle.plugs['tx'],
                handle.plugs['ty'],
                handle.plugs['tz']
            )

        this.base_handles = list(all_handles)
        this.handles = list(all_handles)

        all_joints = [start_joint]
        all_joints.extend(merge_lists(upper_joints, lower_joints))
        all_joints.append(end_joint)
        this.start_joint = start_joint
        this.end_joint = end_joint
        this.upper_joints = upper_joints
        this.lower_joints = lower_joints
        this.start_handle = start_handle
        this.end_handle = end_handle
        this.upper_handles = upper_handles
        this.lower_handles = lower_handles
        this.joints = all_joints

        return this

    def create_deformation_rig(self, **kwargs):
        # super(DoubleSurfaceSpline, self).create_deformation_rig(**kwargs)

        root = self.get_root()

        def create_deform_joints(*part_joints):
            deform_joints = []
            for j, part_joint in enumerate(part_joints):
                deform_joint = part_joint.create_child(
                    Joint,
                    parent=root.deform_group,
                    functionality_name='Bind',
                )
                deform_joint.plugs['radius'].set_value(part_joint.size)
                deform_joint.zero_rotation()
                deform_joint.plugs.set_values(
                    overrideEnabled=True,
                    overrideRGBColors=True,
                    overrideColorRGB=env.colors['bindJoints'],
                    radius=part_joint.plugs['radius'].get_value(),
                    type=part_joint.plugs['type'].get_value(),
                    side=part_joint.plugs['side'].get_value(),
                    drawStyle=part_joint.plugs['drawStyle'].get_value(2)
                )
                part_joint.plugs['rotateOrder'].connect_to(deform_joint.plugs['rotateOrder'])
                part_joint.plugs['inverseScale'].connect_to(deform_joint.plugs['inverseScale'])
                part_joint.plugs['jointOrient'].connect_to(deform_joint.plugs['jointOrient'])
                part_joint.plugs['translate'].connect_to(deform_joint.plugs['translate'])
                part_joint.plugs['rotate'].connect_to(deform_joint.plugs['rotate'])
                part_joint.plugs['scale'].connect_to(deform_joint.plugs['scale'])
                part_joint.plugs['drawStyle'].set_value(2)

                if self.joint_chain:
                    joint_parent = deform_joint
                deform_joints.append(deform_joint)
            return deform_joints

        start_bind_joint, end_bind_joint = create_deform_joints(self.start_joint, self.end_joint)
        upper_bind_joints = create_deform_joints(*self.upper_joints)
        lower_bind_joints = create_deform_joints(*self.lower_joints)
        all_bind_joints = [start_bind_joint, end_bind_joint]
        all_bind_joints.extend(upper_bind_joints)
        all_bind_joints.extend(lower_bind_joints)

        self.deform_joints = all_bind_joints
        self.base_deform_joints = all_bind_joints

        for deform_joint in self.deform_joints:
            deform_joint.plugs['v'].set_value(False)

        upper_spline_parent_group = self.create_child(
            Transform,
            segment_name='Spline',
            differentiation_name='Upper'
        )
        upper_spline_drivers = [self.start_joint]
        upper_spline_drivers.extend(self.upper_joints)
        upper_spline_drivers.append(self.end_joint)

        self.up_vector_transform = self.upper_up_vector_transform
        upper_spline, upper_spline_handles, upper_spline_joints, upper_toll_joints = spb.create_spline(
            self,
            upper_spline_parent_group,
            upper_spline_drivers
        )

        self.upper_main_curve = upper_spline

        lower_spline_parent_group = self.create_child(
            Transform,
            segment_name='Spline',
            differentiation_name='Lower'
        )
        lower_spline_drivers = [self.start_joint]
        lower_spline_drivers.extend(self.lower_joints)
        lower_spline_drivers.append(self.end_joint)

        self.up_vector_transform = self.lower_up_vector_transform
        lower_spline, lower_spline_handles, lower_spline_joints, lower_roll_joints = spb.create_spline(
            self,
            lower_spline_parent_group,
            lower_spline_drivers
        )
        self.lower_main_curve = lower_spline

        all_spline_joints = upper_spline_joints + lower_spline_joints
        all_spline_handles = upper_spline_handles + lower_spline_handles
        all_handles = list(self.handles)
        all_handles.extend(all_spline_handles)
        self.set_handles(all_handles)
        self.secondary_handles = all_spline_handles
        self.deform_joints.extend(self.spline_joints)
        self.spline_joints = all_spline_joints
        self.spline_handles = all_spline_handles
        self.upper_spline_handles = upper_spline_handles
        self.lower_spline_handles = lower_spline_handles

        for up_joint in upper_spline_joints:
            up_joint.plugs['type'].set_value(18)
            up_joint.plugs['otherType'].set_value('upper_spline')

        for lower_joint in lower_spline_joints:
            lower_joint.plugs['type'].set_value(18)
            lower_joint.plugs['otherType'].set_value('lower_spline')

        for j in self.upper_joints:
            j.plugs['type'].set_value(18)
            j.plugs['otherType'].set_value('upper')

        for j in self.lower_joints:
            j.plugs['type'].set_value(18)
            j.plugs['otherType'].set_value('lower')

        for handle in all_spline_handles:
            root.add_plugs(
                handle.plugs['tx'],
                handle.plugs['ty'],
                handle.plugs['tz']
            )

        # Backward compatible "Slide" values
        joint_parameters = kwargs.pop('joint_parameters', None)
        # if not joint_parameters:
        #     print 'NO JOINT PARMS FOUND: %s' % self
        # elif not len(all_spline_handles) == len(joint_parameters):
        #     print 'param count mismatch ', len(all_spline_handles), len(joint_parameters), self

        if joint_parameters and len(all_spline_handles) == len(joint_parameters):
            upper_joint_parameters = joint_parameters[:len(joint_parameters) / 2]
            lower_joint_parameters = joint_parameters[len(joint_parameters) / 2:]
            for i in range(len(upper_joint_parameters)):
                slide_value = 1.0 / (len(upper_joint_parameters)-1) * i + (upper_joint_parameters[i] * 0.1)
                upper_spline_handles[i].plugs['Slide'].set_value(slide_value)
            for i in range(len(lower_joint_parameters)):
                slide_value = 1.0 / (len(lower_joint_parameters)-1) * i + (lower_joint_parameters[i] * 0.1)
                lower_spline_handles[i].plugs['Slide'].set_value(slide_value)

        if self.secondary_parameters and len(all_spline_handles) == len(self.secondary_parameters):
            for i in range(len(all_spline_handles)):
                all_spline_handles[i].plugs['Slide'].set_value(self.secondary_parameters[i])
                all_spline_handles[i].plugs['Slide'].set_locked(True)

        if self.secondary_translations and len(all_spline_handles) == len(self.secondary_translations):
            for i in range(len(all_spline_handles)):
                all_spline_handles[i].groups[-2].plugs['translate'].set_value(self.secondary_translations[i])

    def get_toggle_blueprint(self):
        blueprint = super(DoubleSurfaceSplineUpvectors, self).get_toggle_blueprint()
        blueprint['handle_data'] = self.get_handle_data()
        return blueprint

    def get_blueprint(self):
        blueprint = super(DoubleSurfaceSplineUpvectors, self).get_blueprint()
        blueprint['handle_data'] = self.get_handle_data()
        blueprint['upper_up_vector_position'] = list(self.upper_up_vector_transform.get_translation()) if self.upper_up_vector_transform else None
        blueprint['lower_up_vector_position'] = list(self.lower_up_vector_transform.get_translation()) if self.lower_up_vector_transform else None

        return blueprint

    def get_handle_data(self):
        handle_data = []
        if not self.base_handles:
            raise Exception('No Base Handles Found')
        for i, handle in enumerate(self.base_handles):
            handle = self.base_handles[i]
            handle_data.append(
                dict(
                    klass=handle.__class__.__name__,
                    module=handle.__module__,
                    vertices=[(x.mesh.get_selection_string(), x.index) for x in handle.vertices],
                    matrix=list(self.matrices[i]),
                    root_name=handle.root_name,
                    segment_name=handle.segment_name,
                    differentiation_name=handle.differentiation_name,
                    size=handle.size,
                    side=handle.side
                )
            )
        return handle_data


    def consolidate_slide_values(self):
        for handle in self.upper_spline_handles:
            position = list(handle.get_translation())
            closest_parameter = self.controller.scene.get_closest_curve_parameter(
                self.upper_main_curve.m_object,
                list(handle.get_translation())
            )
            upper_spans = self.upper_main_curve.plugs['spans'].get_value()
            if upper_spans == 0:
                raise Exception('The upper_main_curve for %s had zero spans' % self)
            handle.plugs['Slide'].set_value(closest_parameter / upper_spans)
            self.controller.scene.xform(handle.groups[2], ws=True, t=position)
            handle.groups[3].plugs['translate'].set_value([0.0, 0.0, 0.0])
            handle.plugs['translate'].set_value([0.0, 0.0, 0.0])

        for handle in self.lower_spline_handles:
            position = list(handle.get_translation())
            closest_parameter = self.controller.scene.get_closest_curve_parameter(
                self.lower_main_curve.m_object,
                list(handle.get_translation())
            )
            lower_spans = self.lower_main_curve.plugs['spans'].get_value()
            if lower_spans == 0:
                raise Exception('The lower_main_curve curve for %s had zero spans' % self)
            handle.plugs['Slide'].set_value(closest_parameter / lower_spans)
            self.controller.scene.xform(handle.groups[2], ws=True, t=position)
            handle.groups[3].plugs['translate'].set_value([0.0, 0.0, 0.0])
            handle.plugs['translate'].set_value([0.0, 0.0, 0.0])

def is_even(number):
    if (number % 2) == 0:
        return True
    return False


def create_handle_data(count, side, root_name, segment_name, size):
    if count < 2:
        raise Exception('Count must be at-least 2')

    data = []
    if side in ['left', 'right']:
        for x in range(count):
            if x == 0:
                handle_segment_name = 'InCorner'
            elif x == count - 1:
                handle_segment_name = 'OutCorner'
            else:
                handle_segment_name = '%s%s' % (segment_name, rig_factory.index_dictionary[x - 1].title())
            data.append(dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side=side,
                matrix=Matrix([(size*2) * x, 0.0, 0.0]) if side == 'left' else Matrix([(size*-2) * x, 0.0, 0.0])
            ))
    elif side == 'center':
        for x in range(count):
            if x == 0:
                handle_segment_name = 'Start'
            elif x == count-1:
                handle_segment_name = 'End'
            else:
                handle_segment_name = '%s%s' % (segment_name, rig_factory.index_dictionary[x - 1].title())
            data.append(dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side=side,
                matrix=Matrix([0.0, (size*2) * x, 0.0])
            ))
    elif side is None:
        even_count = is_even(count)
        side_count = count / 2 if even_count else (count - 1) / 2
        for x in range(side_count):
            if x == side_count-1:
                handle_segment_name = 'Corner'
            else:
                handle_segment_name = '%s%s' % (segment_name, rig_factory.index_dictionary[x].title())
            position = [(size * -2) * (x + 1), 0.0, 0.0]
            if x == 0 and even_count:
                position = [(size * -1) * (x + 1), 0.0, 0.0]
            data.insert(0, dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side='right',
                matrix=Matrix(position)
            ))

        if not even_count:
            data.append(dict(
                root_name=root_name,
                segment_name='%s%s' % (segment_name, rig_factory.index_dictionary[0].title()),
                size=size,
                side='center',
                matrix=Matrix([0.0, 0.0, 0.0])
            ))
        for x in range(side_count):
            position = [(size * 2) * (x + 1), 0.0, 0.0]
            if x == side_count-1:
                handle_segment_name = 'Corner'
            else:
                handle_segment_name = '%s%s' % (segment_name, rig_factory.index_dictionary[x].title())
            data.append(dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side='left',
                matrix=Matrix(position)
            ))

    return data


def chunks(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i:i + n]


def merge_lists(list_1, list_2):
    merged_list = []
    for a, b in zip(list_1, list_2):
        merged_list.append(a)
        merged_list.append(b)
    return merged_list
