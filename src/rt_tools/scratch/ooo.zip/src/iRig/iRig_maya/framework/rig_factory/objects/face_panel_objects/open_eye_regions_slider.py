from rig_factory.objects.face_panel_objects.base_slider import BaseSlider, BaseSliderGuide
from rig_math.matrix import Matrix
import rig_factory.utilities.face_panel_utillities as utl
from rig_factory.objects.base_objects.properties import ObjectProperty
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.joint import Joint
import copy


class OpenEyeRegionsSliderGuide(BaseSliderGuide):
    default_settings = dict(
        differentiation_name='Panel',
        root_name='Eye',
        side='left',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(OpenEyeRegionsSliderGuide, self).__init__(**kwargs)
        self.toggle_class = OpenEyeRegionsSlider.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(BaseSliderGuide, cls).create(controller, **kwargs)
        joints = []
        for handle_name in ('Lid', 'Blink'):
            handle = this.create_handle(
                segment_name=handle_name
            )
            handle.mesh.assign_shading_group(this.get_root().shaders[this.side].shading_group)
            joint = handle.create_child(
                Joint
            )
            controller.create_parent_constraint(handle, joint)
            joint.plugs['drawStyle'].set_value(2)
            joints.append(joint)
        this.joints = joints
        return this


class OpenEyeRegionsSlider(BaseSlider):
    default_settings = dict(
        differentiation_name='Panel',
        root_name='Eye',
        side='left',
        size=1.0
    )
    up_handle = ObjectProperty(
        name='up_handle'
    )

    down_handle = ObjectProperty(
        name='down_handle'
    )

    blink_handle = ObjectProperty(
        name='blink_handle'
    )

    def __init__(self, **kwargs):
        super(OpenEyeRegionsSlider, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(OpenEyeRegionsSlider, cls).create(controller, **kwargs)
        side = this.side
        size = this.size
        if len(this.matrices) == 1:
            eye_matrix = this.matrices[0]
            blink_matrix = this.matrices[0]
        else:
            eye_matrix, blink_matrix = this.matrices

        root = this.get_root()

        #  Up Handle
        up_handle = this.create_handle(
            segment_name='Up',
            shape='square_smooth_rot90',
            size=size,
            matrix=eye_matrix * Matrix(0.0, size, 0.0)
        )
        utl.set_attr_limit(up_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(up_handle, 'TransY', -2.0, 2.0)
        utl.set_attr_limit(up_handle, 'TransZ', 0.0, 0.0)
        up_handle.multiply_shape_matrix(Matrix(scale=[4.0, 1.0, 1.0]))

        #  down Handle
        down_handle = this.create_handle(
            segment_name='Down',
            shape='square_smooth_rot90',
            size=size,
            matrix=eye_matrix * Matrix(0.0, -1.0 * size, 0.0)
        )
        utl.set_attr_limit(down_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(down_handle, 'TransY', -2.0, 2.0)
        utl.set_attr_limit(down_handle, 'TransZ', 0.0, 0.0)
        down_handle.multiply_shape_matrix(Matrix(scale=[4.0, -1.0, 1.0]))

        # Up In Handle
        up_in_handle = this.create_handle(
            segment_name='UpIn',
            shape='teardrop',
            size=size * 1.75,
            matrix=eye_matrix * Matrix(-1.1 * size, size * 1.50, 0.0),
            parent=up_handle,
            axis='y'
        )
        utl.set_attr_limit(up_in_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(up_in_handle, 'TransY', -2.0, 2.0)
        utl.set_attr_limit(up_in_handle, 'TransZ', 0.0, 0.0)
        utl.set_attr_limit(up_in_handle, 'RotZ', -90.0, 90.0)
        up_in_handle.create_plug(
            'LashRoll',
            k=True,
            at='float',
            min=-1.0,
            max=1.0
        )

        # Down In Handle
        down_in_handle = this.create_handle(
            segment_name='DownIn',
            shape='teardrop',
            size=size * 1.75,
            matrix=eye_matrix * Matrix(-1.1 * size, size * -1.50, 0.0),
            parent=down_handle,
            axis='y'
        )
        utl.set_attr_limit(down_in_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(down_in_handle, 'TransY', -2.0, 2.0)
        utl.set_attr_limit(down_in_handle, 'TransZ', 0.0, 0.0)
        utl.set_attr_limit(down_in_handle, 'RotZ', -90.0, 90.0)
        down_in_handle.multiply_shape_matrix(Matrix(scale=[1.0, -1.0, 1.0]))
        down_in_handle.create_plug(
            'LashRoll',
            k=True,
            at='float',
            min=-1.0,
            max=1.0
        )

        # Up Mid Handle
        up_mid_handle = this.create_handle(
            segment_name='UpMid',
            shape='teardrop',
            size=size * 1.75,
            matrix=eye_matrix * Matrix(0.0, size * 1.50, 0.0),
            parent=up_handle,
            axis='y'
        )
        utl.set_attr_limit(up_mid_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(up_mid_handle, 'TransY', -2.0, 2.0)
        utl.set_attr_limit(up_mid_handle, 'TransZ', 0.0, 0.0)
        utl.set_attr_limit(up_mid_handle, 'RotZ', -90.0, 90.0)
        up_mid_handle.create_plug(
            'LashRoll',
            k=True,
            at='float',
            min=-1.0,
            max=1.0
        )

        # Down Mid Handle
        down_mid_handle = this.create_handle(
            segment_name='DownMid',
            shape='teardrop',
            size=size * 1.75,
            matrix=eye_matrix * Matrix(0.0, size * -1.50, 0.0),
            parent=down_handle,
            axis='y'
        )
        utl.set_attr_limit(down_mid_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(down_mid_handle, 'TransY', -2.0, 2.0)
        utl.set_attr_limit(down_mid_handle, 'TransZ', 0.0, 0.0)
        utl.set_attr_limit(down_mid_handle, 'RotZ', -90.0, 90.0)
        down_mid_handle.multiply_shape_matrix(Matrix(scale=[1.0, -1.0, 1.0]))
        down_mid_handle.create_plug(
            'LashRoll',
            k=True,
            at='float',
            min=-1.0,
            max=1.0
        )

        # Up Out Handle
        up_out_handle = this.create_handle(
            segment_name='UpOut',
            shape='teardrop',
            size=size * 1.75,
            matrix=eye_matrix * Matrix(size * 1.1, size * 1.50, 0.0),
            parent=up_handle,
            axis='y'
        )
        utl.set_attr_limit(up_out_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(up_out_handle, 'TransY', -2.0, 2.0)
        utl.set_attr_limit(up_out_handle, 'TransZ', 0.0, 0.0)
        utl.set_attr_limit(up_out_handle, 'RotZ', -90.0, 90.0)
        up_out_handle.create_plug(
            'LashRoll',
            k=True,
            at='float',
            min=-1.0,
            max=1.0
        )

        # Down Out Handle
        down_out_handle = this.create_handle(
            segment_name='DownOut',
            shape='teardrop',
            size=size * 1.75,
            matrix=eye_matrix * Matrix(size * 1.1, size * -1.50, 0.0),
            parent=down_handle,
            axis='y'
        )
        utl.set_attr_limit(down_out_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(down_out_handle, 'TransY', -2.0, 2.0)
        utl.set_attr_limit(down_out_handle, 'TransZ', 0.0, 0.0)
        utl.set_attr_limit(down_out_handle, 'RotZ', -90.0, 90.0)
        down_out_handle.multiply_shape_matrix(Matrix(scale=[1.0, -1.0, 1.0]))
        down_out_handle.create_plug(
            'LashRoll',
            k=True,
            at='float',
            min=-1.0,
            max=1.0
        )

        # Rotate entire right eyelid controls
        if side == 'right':
            up_handle.groups[0].plugs['rotateY'].set_value(180.0)
            down_handle.groups[0].plugs['rotateY'].set_value(180.0)

        position_transform = this.create_child(
            Transform,
            matrix=blink_matrix,
            segment_name='BlinkPosition',
        )
        outline_curve_wide = position_transform.create_child(
            NurbsCurve,
            segment_name='OutlineWide',
            degree=1,
            positions=[
                [0.0, 0.0, 0.0],
                [0.0, size, 0.0],
                [size * -1.0, size, 0.0],
                [size * -1.0, size * -1.0, 0.0],
                [0.0, size * -1.0, 0.0],
                [0.0, 0.0, 0.0],
                [size * -1.0, 0.0, 0.0]
            ]
        )

        outline_curve_wide.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )

        blink_handle = this.create_handle(
            segment_name='Blink',
            shape='star_four',
            axis='z',
            size=size,
            side=side,
            matrix=blink_matrix * Matrix(-size, 0.0, 0.0),
            parent=position_transform
        )
        utl.set_attr_limit(
            blink_handle,
            'TransY',
            size * -1.0,
            size
        )
        utl.set_attr_limit(
            blink_handle,
            'TransX',
            0.0,
            size * 1.0
        )
        utl.set_attr_limit(
            blink_handle,
            'TransZ',
            0.0,
            0.0
        )

        setup_lid_drivers(this, blink_handle, up_handle, down_handle, 'Lid')
        setup_lid_region_drivers(this, up_in_handle, down_in_handle, 'LidIn')
        setup_lid_region_drivers(this, up_mid_handle, down_mid_handle, 'LidMid')
        setup_lid_region_drivers(this, up_out_handle, down_out_handle, 'LidOut')

        joint = this.create_child(
            Joint,
            parent=this.joint_group,
            segment_name='A'
        )

        root.add_plugs(
            up_handle.plugs['tx'],
            up_handle.plugs['ty'],
            up_handle.plugs['rz'],
            up_in_handle.plugs['LashRoll'],
            up_mid_handle.plugs['LashRoll'],
            up_out_handle.plugs['LashRoll'],
            up_in_handle.plugs['tx'],
            up_in_handle.plugs['ty'],
            up_in_handle.plugs['rz'],
            down_handle.plugs['tx'],
            down_handle.plugs['ty'],
            down_handle.plugs['rz'],
            down_in_handle.plugs['LashRoll'],
            down_mid_handle.plugs['LashRoll'],
            down_out_handle.plugs['LashRoll'],
            down_in_handle.plugs['tx'],
            down_in_handle.plugs['ty'],
            down_in_handle.plugs['rz'],
            up_mid_handle.plugs['tx'],
            up_mid_handle.plugs['ty'],
            up_mid_handle.plugs['rz'],
            down_mid_handle.plugs['tx'],
            down_mid_handle.plugs['ty'],
            down_mid_handle.plugs['rz'],
            up_out_handle.plugs['tx'],
            up_out_handle.plugs['ty'],
            up_out_handle.plugs['rz'],
            down_out_handle.plugs['tx'],
            down_out_handle.plugs['ty'],
            down_out_handle.plugs['rz'],
            blink_handle.plugs['tx'],
            blink_handle.plugs['ty'],
            blink_handle.plugs['rz']
        )

        #  Properties
        this.joints.append(joint)
        this.blink_handle = blink_handle

        return this


def setup_lid_drivers(part, blink_handle, up_handle, down_handle, name):
    size = part.size

    up_lid_blink_driver_plug = part.create_plug(
        'Up%sVerticalDriver' % name,
        k=True,
        at='double'
    )

    down_lid_blink_driver_plug = part.create_plug(
        'Down%sVerticalDriver' % name,
        k=True,
        at='double'
    )

    up_horizontal_driver = part.create_plug(
        'Up%sHorizontalDriver' % name,
        k=True,
        at='double',
        min=-1.0,
        max=1.0
    )

    down_horizontal_driver = part.create_plug(
        'Down%sHorizontalDriver' % name,
        k=True,
        at='double',
        min=-1.0,
        max=1.0
    )

    up_rotation_driver = part.create_plug(
        'Up%sRotationDriver' % name,
        k=True,
        at='double',
        min=-90.0,
        max=90.0
    )

    down_rotation_driver = part.create_plug(
        'Down%sRotationDriver' % name,
        k=True,
        at='double',
        min=-90.0,
        max=90.0
    )

    blink_remap_x = blink_handle.plugs['tx'].remap(
        (size * -2.0, -2.0),
        (0.0, 0.0),
        (size * 2.0, 2.0)
    )
    blink_remap_y = blink_handle.plugs['ty'].remap(
        (size * -2.0, -2.0),
        (0.0, 0.0),
        (size * 2.0, 2.0)
    )

    up_lid_remap_x = up_handle.plugs['tx'].remap(
        (size * -2.0, -2.0),
        (0.0, 0.0),
        (size * 2.0, 2.0)
    )
    up_lid_remap_y = up_handle.plugs['ty'].remap(
        (size * -2.0, -2.0),
        (0.0, 0.0),
        (size * 2.0, 2.0)
    )
    up_lid_remap_rz = up_handle.plugs['rz'].remap(
        (size * -90.0, -90.0),
        (0.0, 0.0),
        (size * 90.0, 90.0)
    )
    down_lid_remap_x = down_handle.plugs['tx'].remap(
        (size * -2.0, -2.0),
        (0.0, 0.0),
        (size * 2.0, 2.0)
    )
    down_lid_remap_y = down_handle.plugs['ty'].remap(
        (size * -2.0, -2.0),
        (0.0, 0.0),
        (size * 2.0, 2.0)
    )
    down_lid_remap_rz = down_handle.plugs['rz'].remap(
        (size * -90.0, -90.0),
        (0.0, 0.0),
        (size * 90.0, 90.0)
    )

    blink_up_remap = blink_remap_y.remap(
        (-1.0, -1.0),
        (0.0, -0.75),
        (1.0, 0.0),
    )
    blink_down_remap = blink_remap_y.remap(
        (-1.0, 0.0),
        (0.0, 0.25),
        (1.0, 1.0),
    )

    blink_reverse = blink_remap_x.reverse()

    blink_up_remap.multiply(blink_remap_x) \
        .add(up_lid_remap_y.multiply(blink_reverse)) \
        .blend_weighted() \
        .connect_to(up_lid_blink_driver_plug)

    blink_down_remap.multiply(blink_remap_x) \
        .add(down_lid_remap_y.multiply(blink_reverse)) \
        .blend_weighted() \
        .connect_to(down_lid_blink_driver_plug)

    lid_x_reverse = blink_remap_x.reverse()
    up_lid_remap_x.multiply(lid_x_reverse).blend_weighted().connect_to(up_horizontal_driver)
    up_lid_remap_rz.multiply(lid_x_reverse).blend_weighted().connect_to(up_rotation_driver)
    down_lid_remap_x.multiply(lid_x_reverse).blend_weighted().connect_to(down_horizontal_driver)
    down_lid_remap_rz.multiply(lid_x_reverse).blend_weighted().connect_to(down_rotation_driver)


def setup_lid_region_drivers(part, up_handle, down_handle, name):
    size = part.size

    up_lid_blink_driver_plug = part.create_plug(
        'Up%sVerticalDriver' % name,
        k=True,
        at='double'
    )

    down_lid_blink_driver_plug = part.create_plug(
        'Down%sVerticalDriver' % name,
        k=True,
        at='double'
    )

    up_horizontal_driver = part.create_plug(
        'Up%sHorizontalDriver' % name,
        k=True,
        at='double',
        min=-1.0,
        max=1.0
    )

    down_horizontal_driver = part.create_plug(
        'Down%sHorizontalDriver' % name,
        k=True,
        at='double',
        min=-1.0,
        max=1.0
    )

    up_lid_remap_x = up_handle.plugs['tx'].remap(
        (size * -2.0, -2.0),
        (0.0, 0.0),
        (size * 2.0, 2.0)
    )
    up_lid_remap_y = up_handle.plugs['ty'].remap(
        (size * -2.0, -2.0),
        (0.0, 0.0),
        (size * 2.0, 2.0)
    )
    down_lid_remap_x = down_handle.plugs['tx'].remap(
        (size * -2.0, -2.0),
        (0.0, 0.0),
        (size * 2.0, 2.0)
    )
    down_lid_remap_y = down_handle.plugs['ty'].remap(
        (size * -2.0, -2.0),
        (0.0, 0.0),
        (size * 2.0, 2.0)
    )

    up_lid_remap_y.blend_weighted().connect_to(up_lid_blink_driver_plug)
    down_lid_remap_y.blend_weighted().connect_to(down_lid_blink_driver_plug)

    up_lid_remap_x.blend_weighted().connect_to(up_horizontal_driver)
    down_lid_remap_x.blend_weighted().connect_to(down_horizontal_driver)
