from rig_factory.objects.biped_objects.biped_main import BipedMainGuide, BipedMain
from rig_factory.objects.biped_objects.biped_spine import BipedSpineGuide, BipedSpine
from rig_factory.objects.biped_objects.biped_arm import BipedArmGuide, BipedArm
from rig_factory.objects.biped_objects.biped_leg import BipedLegGuide, BipedLeg
from rig_factory.objects.biped_objects.biped_neck import BipedNeckGuide, BipedNeck
from rig_factory.objects.rig_objects.reverse_pole_vector import ReversePoleVector
from rig_factory.objects.node_objects.joint import Joint


"""
This module is currently unused, but we should keep it around for if motionCapture/human IK is requested.
"""


def create_human_ik(self, finger_animation=False):
    if self.character_node:
        raise Exception('Human IK character node already exists')

    self.solve_t_pose()
    self.controller.load_plugin('mayaHIK')
    self.character_node = self.create_child(
        'DependNode',
        node_type='HIKCharacterNode',
        root_name='%s_mocap_in' % self.root_name
    )
    controller = self.controller
    joint_chunks = []
    all_parts = self.get_parts()
    all_mocap_joints = []
    for part in all_parts:
        mocap_joints = create_mocap_joints(
            part,
            name='mocap'
        )
        joint_chunks.append(mocap_joints)
        all_mocap_joints.extend(mocap_joints)
        if isinstance(part, BipedSpine):
            mocap_joints[0].plugs['Character'].connect_to(self.character_node.plugs['Hips'])
            mocap_joints[1].plugs['Character'].connect_to(self.character_node.plugs['Spine'])
            mocap_joints[2].plugs['Character'].connect_to(self.character_node.plugs['Spine1'])
            mocap_joints[3].plugs['Character'].connect_to(self.character_node.plugs['Spine2'])
            spine_fk_handles = self.spine.fk_spine.handles[0:-1]
            fk_hip_handle = self.spine.fk_spine.handles[-1]
            ik_hip_handle = self.spine.ik_spine.handles[0]
            ik_chest_handle = self.spine.ik_spine.handles[1]
            cog_handle = part.cog_handle

            for i in range(len(spine_fk_handles)):
                controller.create_orient_constraint(
                    mocap_joints[i+1],
                    spine_fk_handles[i]
                )
            controller.create_orient_constraint(
                mocap_joints[0],
                fk_hip_handle,
                mo=True
            )
            controller.create_parent_constraint(
                mocap_joints[0],
                ik_hip_handle,
                mo=True
            )
            controller.create_parent_constraint(
                mocap_joints[-2],
                ik_chest_handle,
                mo=True
            )
            controller.create_parent_constraint(
                mocap_joints[1],
                cog_handle,
                mo=True
            )
        elif isinstance(part, BipedNeck):
            mocap_joints[0].plugs['Character'].connect_to(self.character_node.plugs['Neck'])
            mocap_joints[1].plugs['Character'].connect_to(self.character_node.plugs['Neck1'])
            mocap_joints[2].plugs['Character'].connect_to(self.character_node.plugs['Neck2'])
            mocap_joints[3].plugs['Character'].connect_to(self.character_node.plugs['Head'])
            neck_fk_handles = self.neck.fk_neck.handles
            ik_head_handle = self.neck.ik_neck.handles[0]

            for i in range(len(neck_fk_handles[1:-1])):
                controller.create_orient_constraint(
                    mocap_joints[i+1],
                    neck_fk_handles[i]
                )
            controller.create_orient_constraint(
                mocap_joints[-1],
                neck_fk_handles[-1]
            )
            controller.create_parent_constraint(
                mocap_joints[-1],
                ik_head_handle
            )
        elif isinstance(part, BipedArm):
            if part.side == 'left':
                mocap_joints[0].plugs['Character'].connect_to(self.character_node.plugs['LeftShoulder'])
                mocap_joints[1].plugs['Character'].connect_to(self.character_node.plugs['LeftArm'])
                mocap_joints[2].plugs['Character'].connect_to(self.character_node.plugs['LeftForeArm'])
                mocap_joints[3].plugs['Character'].connect_to(self.character_node.plugs['LeftHand'])
            if part.side == 'right':
                mocap_joints[0].plugs['Character'].connect_to(self.character_node.plugs['RightShoulder'])
                mocap_joints[1].plugs['Character'].connect_to(self.character_node.plugs['RightArm'])
                mocap_joints[2].plugs['Character'].connect_to(self.character_node.plugs['RightForeArm'])
                mocap_joints[3].plugs['Character'].connect_to(self.character_node.plugs['RightHand'])
            controller.create_parent_constraint(
                mocap_joints[0],
                part.ik_arm.clavicle_handle
            )
            part.create_child(
                ReversePoleVector,
                mocap_joints[1], mocap_joints[2], mocap_joints[3],
                part.ik_arm.elbow_handle,
                root_name='%s_reverse_pole' % part.root_name
            )
            controller.create_parent_constraint(
                mocap_joints[3],
                part.ik_arm.wrist_handle,
            )

            for i, fk_handle in enumerate(part.fk_arm.handles):
                controller.create_orient_constraint(
                    mocap_joints[i],
                    fk_handle
                )
        elif isinstance(part, BipedLeg):
            if part.side == 'left':
                mocap_joints[1].plugs['Character'].connect_to(self.character_node.plugs['LeftUpLeg'])
                mocap_joints[2].plugs['Character'].connect_to(self.character_node.plugs['LeftLeg'])
                mocap_joints[3].plugs['Character'].connect_to(self.character_node.plugs['LeftFoot'])
                mocap_joints[4].plugs['Character'].connect_to(self.character_node.plugs['LeftToeBase'])
            if part.side == 'right':
                mocap_joints[1].plugs['Character'].connect_to(self.character_node.plugs['RightUpLeg'])
                mocap_joints[2].plugs['Character'].connect_to(self.character_node.plugs['RightLeg'])
                mocap_joints[3].plugs['Character'].connect_to(self.character_node.plugs['RightFoot'])
                mocap_joints[4].plugs['Character'].connect_to(self.character_node.plugs['RightToeBase'])
            controller.create_parent_constraint(
                mocap_joints[3],
                part.ik_leg.ankle_handle,
                mo=True
            )
            for i, fk_handle in enumerate(part.fk_leg.handles):
                controller.create_orient_constraint(
                    mocap_joints[i+1],
                    fk_handle
                )
            part.create_child(
                ReversePoleVector,
                mocap_joints[1], mocap_joints[2], mocap_joints[3],
                part.ik_leg.knee_handle,
                root_name='%s_reverse_pole' % part.root_name
            )
            controller.create_orient_constraint(
                mocap_joints[4],
                part.ik_leg.toe_handle,
                mo=False
            )
        elif isinstance(part, BipedFinger):
            if finger_animation:
                for i, handle in enumerate(part.handles):
                    controller.create_orient_constraint(
                        mocap_joints[i],
                        handle
                    )
        elif isinstance(part, BipedMain):
            mocap_joints[0].plugs['Character'].connect_to(self.character_node.plugs['Reference'])
            controller.create_parent_constraint(
                mocap_joints[0],
                part.handles[1],
                mo=False
            )
        else:
            print('Warning ! The Part "%s" is not registered within the HumanIk system' % part)
    parent_indices = self.get_parent_joint_indices()
    for i, joint_chunk in enumerate(joint_chunks):
        parent_index = parent_indices[i]
        if len(joint_chunk) > 0:
            root_joint = joint_chunk[0]
            if parent_index is not None:
                root_joint.set_parent(all_mocap_joints[parent_index])
            else:
                root_joint.set_parent(self.utilities_group)
    self.mocap_joints = all_mocap_joints
    return all_mocap_joints
#
def import_skeletal_animation(self, path):

    """


    Remove cmds so it works with mock




    """
    temp_namespace = 'skeletal_animation'
    self.controller.scene.file(
        path,
        r=True,
        namespace=temp_namespace
    )
    self.create_human_ik()
    import maya.mel as mel
    import maya.cmds as mc
    character_nodes = mc.ls('%s:*' % temp_namespace, type='HIKCharacterNode')
    if character_nodes:
        mel.eval('mayaHIKsetCharacterInput( "%s", "%s" );' % (self.character_node, character_nodes[0]))

    mc.select(self.get_handles())
    mc.playbackOptions(min=0, max=250)
    mc.bakeResults(
        t=(0.0, 250.0),
        simulation=True,
        sampleBy=1,
        oversamplingRate=1,
        disableImplicitControl=True,
        preserveOutsideKeys=True,
        sparseAnimCurveBake=False,
        removeBakedAttributeFromLayer=False,
        bakeOnOverrideLayer=False,
        minimizeRotation=True,
        controlPoints=False,
        shape=False
    )

    mc.filterCurve(self.keyable_plugs, f='euler')
    mc.filterCurve(self.keyable_plugs, f='butterworth')
    mc.file(path, ur=True)




def create_mocap_joints(part, name='base'):
    controller = part.controller
    mocap_joints = []
    part_joints = part.joints
    joint_parent = None
    for j, part_joint in enumerate(part_joints):
        new_joint = controller.create_object(
            Joint,
            parent=joint_parent,
            root_name='%s_%s' % (part_joint.root_name, name),
            index=part_joint.index,
            side=part_joint.side,
            size=part_joint.size*0.2,
            matrix=part_joint.get_matrix()
        )
        new_joint.plugs.set_values(
            overrideEnabled=True,
            overrideRGBColors=True,
            overrideColorRGB=[0.6, 0.7, 1.0]
        )
        new_joint.zero_rotation()
        new_joint.plugs['type'].set_value(part_joint.plugs['type'].get_value())
        new_joint.plugs['side'].set_value(part_joint.plugs['side'].get_value())
        new_joint.create_plug('Character', at='message')
        mocap_joints.append(new_joint)
        joint_parent = new_joint
    return mocap_joints
