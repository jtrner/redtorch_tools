from rig_factory.objects.deformer_objects.nonlinear import NonLinear


class Flare(NonLinear):

    handle_type = 'deformFlare'
    deformer_type = 'flare'
    suffix = 'Flare'

    def __init__(self, **kwargs):
        super(Flare, self).__init__(**kwargs)

