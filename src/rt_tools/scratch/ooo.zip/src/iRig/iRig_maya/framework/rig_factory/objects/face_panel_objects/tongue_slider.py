from rig_factory.objects.face_panel_objects.base_slider import BaseSlider, BaseSliderGuide
from rig_factory.objects.rig_objects.curve_handle import CurveHandle
from rig_factory.objects.rig_objects.text_curve import TextCurve
from rig_math.matrix import Matrix
from rig_factory.utilities import face_panel_utillities as utl


class TongueSliderGuide(BaseSliderGuide):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Tongue',
        side='center',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(TongueSliderGuide, self).__init__(**kwargs)
        self.toggle_class = TongueSlider.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(TongueSliderGuide, cls).create(controller, **kwargs)
        return this


class TongueSlider(BaseSlider):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Tongue',
        side='center',
        size=1.0
    )
    def __init__(self, **kwargs):
        super(TongueSlider, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(TongueSlider, cls).create(controller, **kwargs)
        size = this.size
        side = this.side
        matrices = this.matrices

        limits_curve = this.create_child(
            CurveHandle,
            segment_name='Square',
            shape='square',
            size=size,
            side=side,
            matrix=matrices[0]
        )
        matrix = Matrix(scale=[2.0, 1.0, 2.0])
        limits_curve.plugs['shapeMatrix'].set_value(matrix)
        limits_curve.plugs['rotateX'].set_value(90)
        utl.set_color_index(limits_curve, 1)  # black
        limits_curve.plugs['overrideDisplayType'].set_value(2)

        tongue_handle = this.create_handle(
            segment_name='Main',
            shape='diamond',
            size=size*0.5,
            side=side,
            matrix=matrices[0]
        )
        controller.scene.transformLimits(
            tongue_handle,
            etx=(1, 1),
            tx=(-1.0, 1.0),
            ety=(1, 1),
            ty=(-1.0, 1.0)
        )
        multiply_plug = tongue_handle.create_plug(
            'Multiply',
            at='double',
            dv=0.0,
            keyable=True,
            min=1.0,
            max=5.0
        )

        up_down_handle = this.create_handle(
            segment_name='UpDown',
            shape='diamond',
            size=size*0.25,
            side=side,
            matrix=matrices[0] * Matrix(-1.0, 0.0, 0.0)
        )
        controller.scene.transformLimits(
            up_down_handle,
            ety=(1, 1),
            ty=(-1.0, 1.0)
        )

        in_out_handle = this.create_handle(
            segment_name='InOut',
            shape='diamond',
            size=size*0.25,
            side=side,
            matrix=matrices[0] * Matrix(0.0, -1.0, 0.0)
        )
        controller.scene.transformLimits(
            in_out_handle,
            etx=(1, 1),
            tx=(-1.0, 1.0)
        )

        setup_tongue_movement_drivers(this, tongue_handle, multiply_plug)
        setup_tongue_up_down_drivers(this, up_down_handle, multiply_plug)
        setup_tongue_in_out_drivers(this, in_out_handle, multiply_plug)

        root = this.get_root()
        root.add_plugs(
            [
                tongue_handle.plugs['tx'],
                tongue_handle.plugs['ty'],
                tongue_handle.plugs['Multiply'],
                up_down_handle.plugs['ty'],
                in_out_handle.plugs['tx']
            ]
        )

        # Text
        handle_text = this.create_child(
            TextCurve,
            segment_name='Text',
            text_input='Tongue',
            matrix=matrices[0] * Matrix(0.0, 1.5, 0.0)
        )
        handle_text.set_size(0.75)
        utl.set_color_index(handle_text, 1)  # black
        handle_text.plugs['overrideDisplayType'].set_value(2)

        return this


def setup_tongue_movement_drivers(part, handle, multiply_plug):
    size = part.size

    up_down_driver_plug = part.create_plug(
        'TongueUpDownDriver',
        k=True,
        at='double'
    )

    left_right_driver_plug = part.create_plug(
        'TongueLeftRightDriver',
        k=True,
        at='double'
    )

    handle.plugs['ty'].multiply(multiply_plug).blend_weighted().connect_to(up_down_driver_plug)
    handle.plugs['tx'].multiply(multiply_plug).blend_weighted().connect_to(left_right_driver_plug)


def setup_tongue_up_down_drivers(part, handle, multiply_plug):

    size = part.size

    vertical_driver_plug = part.create_plug(
        'TongueVerticalDriver',
        k=True,
        at='double'
    )

    handle.plugs['ty'].multiply(multiply_plug).blend_weighted().connect_to(vertical_driver_plug)


def setup_tongue_in_out_drivers(part, handle, multiply_plug):

    size = part.size

    vertical_driver_plug = part.create_plug(
        'TongueInOutDriver',
        k=True,
        at='double'
    )

    handle.plugs['tx'].multiply(multiply_plug).blend_weighted().connect_to(vertical_driver_plug)


