import os
import sys
import glob


def load_rigging_environment(project, entity, dev_mode=False):

    import shotgun
    sg = shotgun.connect()

    project_data = sg.find(
        "Project",
        [["sg_code", "is", project]],
        ["sg_code"]
    )

    if not project_data:
        raise Exception('No Project called : "%s"' % project)

    asset_data = sg.find(
        "Asset",
        [["code", "is", entity], ["project.Project.sg_code", "is", project]],
        ["code", "sg_asset_type"]
    )

    if not asset_data:
        raise Exception('The asset "%s" was not found in the project "%s"' % (entity, project))

    task_id = sg.find_one(
        "Task",
        [
            ["entity.Asset.code", "is", entity],
            ["project.Project.sg_code", "is", project],
            ["content", "is", "Rigging"]
        ],
        ["id"]
    )["id"]

    user_data = sg.find(
        "HumanUser",
        [["login", "is", os.environ['USERNAME']]],
        []
    )

    os.environ['PIPE_DEV_MODE'] = 'TRUE' if dev_mode else 'FALSE'
    os.environ['SERVER_BASE'] = 'Y:\\'
    os.environ['TT_PROJCODE'] = project_data[0]['sg_code']
    os.environ['TT_ENTNAME'] = asset_data[0]['code']
    os.environ['TT_ASSTYPE'] = asset_data[0]['sg_asset_type']
    os.environ['TT_STEPCODE'] = 'rig'
    os.environ['TT_PACKAGE'] = 'Maya'
    os.environ['TT_ENTTYPE'] = 'Asset'
    os.environ['TT_ENTID'] = str(asset_data[0]['id'])
    os.environ['TT_USER'] = os.environ['USERNAME']
    os.environ['TT_TASKID'] = str(task_id)
    os.environ['TT_USERID'] = str(user_data[0]['id'])
    os.environ['TT_PROJID'] = str(project_data[0]['id'])
    os.environ['MAYA_PLUG_IN_PATH'] = '' \
                                      'C:/pipeline_modules/maya/gpuCache/1.0.0/2019;' \
                                      'Z:/pipeline/pixar/RenderManStudio-19.0-maya2015/plug-ins;' \
                                      'Z:/pipeline/config/EAV/custom/plugins;' \
                                      'C:/Users/' + os.environ['TT_USER'] + '/Documents/maya/2019/plug-ins;' \
                                                                            'C:/Users/' + os.environ[
                                          'TT_USER'] + '/Documents/maya/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/bin/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/ATF/plug-ins;' \
                                                       'C:/pipeline_modules/maya/AnimSchoolPicker/1.0/2019/plug-ins;' \
                                                       'C:/pipeline_modules/maya/IconTools/1.1/2019/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Bifrost/Maya2019/bifrost/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/MASH/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/fbx/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/camd/plug-ins;' \
                                                       'C:/solidangle/mtoadeploy/2019/plug-ins;' \
                                                       'C:/Allegorithmic/SubstanceMaya/2019/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Bifrost/Maya2019/vnn/plug-ins;' \
                                                       'C:/pipeline_modules/maya/ornatrix/2.5.3.24029/2019;' \
                                                       'C:/pipeline_modules/maya/assetInfo/1.2/20XX/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/fbx/plug-ins;' \
                                                       'C:/pipeline_modules/maya/python_icon/1.0/20XX/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/camd/plug-ins;' \
                                                       'C:/pipeline_modules/solidangle/mtoa/3.3.0.1/2019/plug-ins;' \
                                                       'C:/pipeline_modules/maya/ngSkinTools/1.7.9/plug-ins/2019;' \
                                                       'C:/pipeline_modules/maya/pyIconTools/1.0/20XX/plug-ins;' \
                                                       'C:/pipeline_modules/maya/shard_matrix/1.0/20XX/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/xgen/plug-ins' \
                                                       ''


def load_mock_rigging_environment(project, entity, dev_mode=False):

    os.environ['PIPE_DEV_MODE'] = 'TRUE' if dev_mode else 'FALSE'
    os.environ['SERVER_BASE'] = 'Y:\\'
    os.environ['TT_PROJCODE'] = project
    os.environ['TT_ENTNAME'] = entity
    os.environ['TT_ASSTYPE'] = 'Character'
    os.environ['TT_STEPCODE'] = 'rig'
    os.environ['TT_PACKAGE'] = 'Maya'
    os.environ['TT_ENTTYPE'] = 'Asset'
    os.environ['TT_ENTID'] = ''
    os.environ['TT_USER'] = os.environ['USERNAME']
    os.environ['TT_TASKID'] = ''
    os.environ['TT_USERID'] = ''
    os.environ['TT_PROJID'] = ''
    os.environ['MAYA_PLUG_IN_PATH'] = '' \
                                      'C:/pipeline_modules/maya/gpuCache/1.0.0/2019;' \
                                      'Z:/pipeline/pixar/RenderManStudio-19.0-maya2015/plug-ins;' \
                                      'Z:/pipeline/config/EAV/custom/plugins;' \
                                      'C:/Users/' + os.environ['TT_USER'] + '/Documents/maya/2019/plug-ins;' \
                                                                            'C:/Users/' + os.environ[
                                          'TT_USER'] + '/Documents/maya/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/bin/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/ATF/plug-ins;' \
                                                       'C:/pipeline_modules/maya/AnimSchoolPicker/1.0/2019/plug-ins;' \
                                                       'C:/pipeline_modules/maya/IconTools/1.1/2019/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Bifrost/Maya2019/bifrost/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/MASH/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/fbx/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/camd/plug-ins;' \
                                                       'C:/solidangle/mtoadeploy/2019/plug-ins;' \
                                                       'C:/Allegorithmic/SubstanceMaya/2019/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Bifrost/Maya2019/vnn/plug-ins;' \
                                                       'C:/pipeline_modules/maya/ornatrix/2.5.3.24029/2019;' \
                                                       'C:/pipeline_modules/maya/assetInfo/1.2/20XX/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/fbx/plug-ins;' \
                                                       'C:/pipeline_modules/maya/python_icon/1.0/20XX/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/camd/plug-ins;' \
                                                       'C:/pipeline_modules/solidangle/mtoa/3.3.0.1/2019/plug-ins;' \
                                                       'C:/pipeline_modules/maya/ngSkinTools/1.7.9/plug-ins/2019;' \
                                                       'C:/pipeline_modules/maya/pyIconTools/1.0/20XX/plug-ins;' \
                                                       'C:/pipeline_modules/maya/shard_matrix/1.0/20XX/plug-ins;' \
                                                       'C:/Program Files/Autodesk/Maya2019/plug-ins/xgen/plug-ins' \
                                                       ''

def load_system_paths(project, dev_mode=True):

    user = os.environ['USERNAME']
    if dev_mode:
        framework_location = 'D:/pipeline/%s/dev/git_repo/irig/src/iRig/iRig_maya/framework' % user
    else:
        irig_location = 'G:/Rigging/.rigging/iRig'
        irig_version_locations = [x.replace('\\', '/') for x in glob.glob('%s/iRig_*.*.*' % irig_location) if os.path.isdir(x)]
        latest_irig_location = sorted(irig_version_locations, key=os.path.getmtime)[-1]
        framework_location = '%s/src/iRig/iRig_maya/framework' % latest_irig_location  # for framework
    if not os.path.exists(framework_location):
        raise Exception('framework path not found: %s' % framework_location)
    if framework_location in sys.path:
        sys.path.remove(framework_location)
    sys.path.insert(0, framework_location)
    if dev_mode:
        git_location = 'D:/pipeline/%s/dev/git_repo' % os.environ['USERNAME']
        pipe_base = '%s/pipeline_monolith' % git_location
        os.environ['PIPE_BASE'] = pipe_base
        system_paths = [
            '%s/python' % pipe_base,
            '%s/py_utilities' % pipe_base,  # for file_tools
            '%s/python/control_tower/v0002' % pipe_base, # for fileTools
            '%s/maya/scripts' % pipe_base  # for maya scripts
        ]
    else:
        pipe_base = 'G:/Pipeline/pipeline'
        os.environ['PIPE_BASE'] = pipe_base
        system_paths = [
            '%s/python' % pipe_base,
            '%s/py_utilities' % pipe_base,  # for file_tools
            '%s/python/control_tower/v0002' % pipe_base,  # for fileTools
            '%s/maya/scripts' % pipe_base  # for maya scripts
        ]
    for system_path in system_paths:
        if not os.path.exists(system_path):
            print 'WARNING: A local copy of a system path not found: %s' % system_path
        if system_path not in sys.path:
            sys.path.insert(0, system_path)

    sys.path.append('G:/Rigging/Shows/%s' % project)
    sys.path.append('G:/Rigging/Shows/%s/%s_scripts' % (project, project.lower()))


def load_rigging_plugins(dev_mode = False):
    import maya.cmds as mc

    user = os.environ['USERNAME']
    if dev_mode:
        framework_location = 'D:/pipeline/%s/dev/git_repo/irig/src/iRig/iRig_maya/framework' % user
    else:

        irig_location = 'G:/Rigging/.rigging/iRig'
        irig_version_locations = [x.replace('\\', '/') for x in glob.glob('%s/iRig_*.*.*' % irig_location) if os.path.isdir(x)]
        latest_irig_location = sorted(irig_version_locations, key=os.path.getmtime)[-1]
        framework_location = '%s/src/iRig/iRig_maya/framework' % latest_irig_location  # for framework


    mc.loadPlugin('C:/pipeline_modules/maya/assetInfo/1.1/20XX/plug-ins/assetInfo.py')
    mc.loadPlugin('%s/maya_tools/shard_matrix.py' % framework_location)
    mc.loadPlugin('lookdevKit')


