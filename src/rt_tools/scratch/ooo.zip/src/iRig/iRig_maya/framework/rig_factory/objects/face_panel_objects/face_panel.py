from rig_factory.objects.part_objects.part_array import PartArray, PartArrayGuide


class FacePanelGuide(PartArrayGuide):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Face',
        side='center',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(FacePanelGuide, self).__init__(**kwargs)
        self.toggle_class = FacePanel.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['differentiation_name'] = 'Panel'
        this = super(FacePanelGuide, cls).create(controller, **kwargs)
        return this

    def create_members(self):

        main_panel = self.create_part(
            'FacePanelMainGuide',
            root_name='Main',
            side='center'
        )
        main_panel.handles[0].plugs['translate'].set_value([0.5, 0.0, 0.0])
        main_joint = main_panel.joints[0]

        waggle_brow = self.create_part(
            'BrowWaggleSliderGuide',
            root_name='BrowWaggle',
            side='center'
        )
        waggle_brow.handles[0].plugs['translate'].set_value([-2.75, 6.25, 0.0])
        waggle_brow.set_parent_joint(main_joint)

        # LEFT side #################################################################
        left_brow = self.create_part(
            'BrowSliderGuide',
            root_name='Brow',
            side='left'
        )
        left_brow.handles[0].plugs['translate'].set_value([1.75, 7.0, 0.0])
        left_brow.set_parent_joint(main_joint)

        right_brow = self.create_part(
            'BrowSliderGuide',
            root_name='Brow',
            side='right'
        )
        right_brow.handles[0].plugs['translate'].set_value([-7.25, 7.0, 0.0])
        right_brow.set_parent_joint(main_joint)

        left_eye = self.create_part(
            'OpenEyeRegionsSliderGuide',
            root_name='Eye',
            side='left'
        )
        left_eye.handles[0].plugs['translate'].set_value([1.75, 3.0, 0.0])
        left_eye.handles[1].plugs['translate'].set_value([-1.25, 3.0, 0.0])
        left_eye.set_parent_joint(main_joint)

        right_eye = self.create_part(
            'OpenEyeRegionsSliderGuide',
            root_name='Eye',
            side='right'
        )
        right_eye.handles[0].plugs['translate'].set_value([-7.25, 3.0, 0.0])
        right_eye.handles[1].plugs['translate'].set_value([-3.25, 3.0, 0.0])
        right_eye.set_parent_joint(main_joint)
        nose = self.create_part(
            'NoseSliderGuide',
            root_name='Nose',
            side='center'
        )
        nose.handles[0].plugs['translate'].set_value([-2.75, -1.0, 0.0])
        nose.set_parent_joint(main_joint)

        left_cheek = self.create_part(
            'CheekSliderGuide',
            root_name='Cheek',
            side='left'
        )
        left_cheek.handles[0].plugs['translate'].set_value([2.75, -2.0, 0.0])
        left_cheek.set_parent_joint(main_joint)

        right_cheek = self.create_part(
            'CheekSliderGuide',
            root_name='Cheek',
            side='right'
        )
        right_cheek.handles[0].plugs['translate'].set_value([-8.25, -2.0, 0.0])
        right_cheek.set_parent_joint(main_joint)

        mouth = self.create_part(
            'MouthSliderGuide',
            root_name='Mouth',
            side='center'
        )
        mouth.handles[0].plugs['translate'].set_value([-2.75, -5.5, 0.0])
        mouth.set_parent_joint(main_joint)

        # RIGHT side #################################################################
        jaw_overbite = self.create_part(
            'JawOverbiteSliderGuide',
            root_name='Overbite',
            side='center'
        )
        jaw_overbite.handles[0].plugs['translate'].set_value([6.75, 6.0, 0.0])
        jaw_overbite.set_parent_joint(main_joint)

        lip_curl_slider = self.create_part(
            'LipCurlSliderGuide',
            root_name='LipCurl',
            side='center'
        )
        lip_curl_slider.handles[0].plugs['translate'].set_value([6.75, 1.0, 0.0])
        lip_curl_slider.set_parent_joint(main_joint)

        tongue = self.create_part(
            'TongueSliderGuide',
            root_name='Tongue',
            side='center'
        )
        tongue.handles[0].plugs['translate'].set_value([6.75, -3.5, 0.0])
        tongue.set_parent_joint(main_joint)

        teeth = self.create_part(
            'TeethSliderGuide',
            root_name='Teeth',
            side='center'
        )
        teeth.handles[0].plugs['translate'].set_value([6.75, -7.5, 0.0])
        teeth.set_parent_joint(main_joint)


class FacePanel(PartArray):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Face',
        side='center',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(FacePanel, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['differentiation_name'] = 'Panel'
        this = super(FacePanel, cls).create(controller, **kwargs)
        return this

    def post_create(self, **blueprint):
        pass
