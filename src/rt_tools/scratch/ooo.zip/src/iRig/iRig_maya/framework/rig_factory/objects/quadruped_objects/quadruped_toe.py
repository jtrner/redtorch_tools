import rig_factory
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.part_objects.chain_guide import ChainGuide
from rig_factory.objects.node_objects.joint import Joint
from rig_math.matrix import Matrix
import rig_factory.positions as pos
from rig_factory.objects.base_objects.properties import DataProperty
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.rig_objects.grouped_handle import WorldHandle


class QuadrupedToeGuide(ChainGuide):
    default_settings = dict(
        root_name='Toe',
        count=5,
        size=1.0,
        side='left'
    )

    def __init__(self, **kwargs):
        super(QuadrupedToeGuide, self).__init__(**kwargs)
        self.toggle_class = QuadrupedToe.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['up_vector_indices'] = [0]
        segment_names = []
        count = kwargs.get('count', cls.default_settings['count'])
        for i in range(count):
            if i == 0:
                segment_names.append('Meta')
            else:
                segment_names.append(rig_factory.index_dictionary[i - 1].title())
        kwargs['segment_names'] = segment_names
        this = super(QuadrupedToeGuide, cls).create(controller, **kwargs)
        this.set_handle_positions(pos.QUADRUPED_POSITIONS)
        return this


class QuadrupedToe(Part):
    segment_names = DataProperty(
        name='segment_names',
        default_value=[]
    )

    def __init__(self, **kwargs):
        super(QuadrupedToe, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(QuadrupedToe, cls).create(controller, **kwargs)
        matrices = this.matrices
        size = this.size
        side = this.side
        joints = []
        root = this.get_root()
        joint_parent = this.joint_group
        handle_parent = this
        base_matrix = matrices[0]

        for x, matrix in enumerate(matrices):
            if x == 0:
                segment_name = 'Meta'
            else:
                segment_name = rig_factory.index_dictionary[x - 1].title()
            joint = this.create_child(
                Joint,
                segment_name=segment_name,
                matrix=matrix,
                parent=joint_parent
            )
            joint_parent = joint
            joint.zero_rotation()
            joint.plugs.set_values(
                overrideEnabled=1,
                overrideDisplayType=2
            )
            joints.append(joint)
            if x != len(matrices) - 1:
                handle = this.create_handle(
                    handle_type=WorldHandle,
                    size=size * 1.5,
                    matrix=matrix,
                    side=side,
                    shape='circle',
                    segment_name=segment_name,
                    parent=handle_parent,
                    rotation_order='xyz',
                    group_count=5,
                    create_gimbal=False
                )
                controller.create_parent_constraint(
                    handle,
                    joint
                )


                handle.plugs['scale'].connect_to(joint.plugs['scale'])
                root.add_plugs(
                    [
                        handle.plugs['tx'],
                        handle.plugs['ty'],
                        handle.plugs['tz'],
                        handle.plugs['rx'],
                        handle.plugs['ry'],
                        handle.plugs['rz'],
                        handle.plugs['sx'],
                        handle.plugs['sy'],
                        handle.plugs['sz']
                    ]
                )
                handle_parent = handle


        joints[0].plugs['type'].set_value(1)
        for joint in joints[1:]:
            joint.plugs['type'].set_value(6)
        this.joints = joints
        return this
