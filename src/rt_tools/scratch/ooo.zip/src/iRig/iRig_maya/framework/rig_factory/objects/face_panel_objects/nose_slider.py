from rig_factory.objects.face_panel_objects.base_slider import BaseSlider, BaseSliderGuide
from rig_math.matrix import Matrix
from rig_factory.utilities import face_panel_utillities as utl


class NoseSliderGuide(BaseSliderGuide):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Nose',
        side='center',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(NoseSliderGuide, self).__init__(**kwargs)
        self.toggle_class = NoseSlider.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(NoseSliderGuide, cls).create(controller, **kwargs)
        return this


class NoseSlider(BaseSlider):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Nose',
        side='center',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(NoseSlider, self).__init__(**kwargs)


    @classmethod
    def create(cls, controller, **kwargs):
        this = super(NoseSlider, cls).create(controller, **kwargs)
        size = this.size
        side = this.side
        matrices = this.matrices

        nose_handle = this.create_handle(
            segment_name='Main',
            shape='face_nose',
            size=size,
            side=side,
            matrix=matrices[0]
        )
        matrix = Matrix(scale=[2.0, 1.25, 2.5])
        nose_handle.plugs['shapeMatrix'].set_value(matrix)
        utl.set_attr_limit(nose_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(nose_handle, 'TransY', -1.0, 1.0)
        utl.set_attr_limit(nose_handle, 'RotZ', -45.0, 45.0)

        root = this.get_root()
        root.add_plugs(
            [

                nose_handle.plugs['tx'],
                nose_handle.plugs['ty'],
                nose_handle.plugs['rz']
            ]
        )

        for handle_side in ['left', 'right']:
            side_mult = 1.0 if handle_side == 'left' else -1.0
            nostril_template = this.create_handle(
                segment_name='Outline',
                shape='face_nostril_rot45',
                size=size,
                side=handle_side,
                parent=nose_handle,
                matrix=matrices[0] * Matrix(0.75*side_mult, -0.75, 0.0)
            )
            matrix = Matrix(scale=[0.6*side_mult, 0.6*side_mult, 1.0])
            nostril_template.set_shape_matrix(matrix)
            nostril_template.groups[-1].plugs['template'].set_value(True)


            nostril_handle = this.create_handle(
                segment_name='Nostril',
                shape='face_nostril_rot45',
                size=size,
                side=handle_side,
                parent=nose_handle,
                matrix=matrices[0] * Matrix(0.75*side_mult, -0.75, 0.0)
            )
            matrix = Matrix(scale=[0.45*side_mult, 0.45*side_mult, 1.0])
            nostril_handle.set_shape_matrix(matrix)
            utl.set_attr_limit(nostril_handle, 'TransX', 0.0, 1.0)
            utl.set_attr_limit(nostril_handle, 'TransY', -1.0, 1.0)
            if handle_side == 'right':
                nostril_handle.groups[0].plugs['ry'].set_value(180)
                nostril_template.groups[0].plugs['ry'].set_value(180)

            root.add_plugs(
                [

                    nostril_handle.plugs['tx'],
                    nostril_handle.plugs['ty'],
                ]
            )


        return this
