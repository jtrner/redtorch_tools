import maya.OpenMaya as om


def get_shrinkwrap_data(m_object):
    # Get geometry, weights, plug values from wire deformer

    return dict()


def create_shrinkwrap(data):
    # should return m_object of wrap deformer

    return om.MObject()
