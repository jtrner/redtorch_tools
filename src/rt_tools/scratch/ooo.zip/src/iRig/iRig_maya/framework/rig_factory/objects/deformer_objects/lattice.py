
from typing import *
from rig_factory.objects.deformer_objects.deformer import Deformer
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.dag_node import DagNode
from rig_factory.objects.node_objects.object_set import ObjectSet
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.base_objects.properties import ObjectProperty


__all__ = (
    'Lattice',
)


class Lattice(Transform):

    # Public properties for accessing child framework objects.
    ffd = ObjectProperty(
        name='ffd'
    )
    lattice_transform = ObjectProperty(
        name='lattice'
    )
    lattice_shape = ObjectProperty(
        name='lattice_shape'
    )
    lattice_base_transform = ObjectProperty(
        name='base_lattice'
    )
    base_lattice_shape = ObjectProperty(
        name='base_lattice_shape'
    )

    # Defines a custom suffix for this framework object.
    suffix = 'Lat'

    @classmethod
    def create(cls, *args, **kwargs):
        # type: (Any, Any) -> Lattice
        """
        Main entry point that starts the creation of the framework
        Lattice in scene.
        :return:
            Instantiated framework Lattice object.
        """
        this = super(Lattice, cls).create(*args, **kwargs)

        # Creates lattice deformer node structure.
        # Gets m_objects for all created nodes.
        (
            m_ffd,
            m_lattice,
            m_base_lattice,
            m_lattice_shape,
            m_base_lattice_shape,
            m_object_set
        ) = this.controller.scene.create_lattice()

        # Creates framework objects to contain the m_objects.
        this.ffd = this.create_child(
            Deformer,
            node_type='ffd',
            segment_name='Ffd',
            m_object=m_ffd
        )
        this.ffd.deformer_set = this.create_child(
            ObjectSet,
            segment_name='ObjectSet',
            m_object=m_object_set
        )
        this.lattice_transform = lattice = this.create_child(
            Transform,
            segment_name='Lattice',
            m_object=m_lattice
        )
        this.lattice_shape = this.create_child(
            DagNode,
            node_type='lattice',
            segment_name='LatticeShape',
            parent=lattice,
            m_object=m_lattice_shape
        )
        this.lattice_base_transform = base_lattice = this.create_child(
            Transform,
            segment_name='BaseLattice',
            m_object=m_base_lattice
        )
        this.base_lattice_shape = this.create_child(
            DagNode,
            node_type='baseLattice',
            segment_name='BaseLatticeShape',
            parent=base_lattice,
            m_object=m_base_lattice_shape
        )

        # Sets default ffd settings.
        this.ffd.plugs['outsideLattice'].set_value(1)

        return this

    def get_weights(self):
        # type: () -> List
        """
        :return:
            The Lattice objects deformer weight data.
        """
        return self.controller.get_deformer_weights(self.ffd)

    def set_weights(self, weights):
        # type: (List) -> None
        """
        Sets the Lattice objects deformer weight data.
        :param weights:
            Weight data which will replace the Lattice objects
            current deformer weights.
        """
        self.controller.set_deformer_weights(self.ffd, weights)

    def add_geometry(self, geometry):
        # type: (Iterable) -> None
        """
        Adds given geometries as objects to be deformed by the Lattice
        object.
        :param geometry:
             Iterable of geometries to add to the Lattice objects
             deformer set.
        """
        member_names = {x.name for x in self.ffd.deformer_set.members}
        new_geometry = [x for x in geometry if x.name not in member_names]
        self.ffd.deformer_set.members.extend(new_geometry)
        self.controller.add_deformer_geometry(self.ffd, new_geometry)

    def remove_geometry(self, geometries):
        # type: (List) -> None
        """
        Removes given geometries from the Lattice objects deformer set.
        :param geometries:
            List of geometries to be removed from the Lattice objects
            deformer set.
        """
        geometry_names = {x.name for x in geometries}
        valid_members = [
            member for member in self.ffd.deformer_set.members
            if member.name not in geometry_names
        ]
        self.ffd.deformer_set.members = valid_members
        self.controller.remove_deformer_geometry(self, geometries)
