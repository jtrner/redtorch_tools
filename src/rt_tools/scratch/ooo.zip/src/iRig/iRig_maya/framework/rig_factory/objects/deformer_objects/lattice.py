from rig_factory.objects.deformer_objects.deformer import Deformer
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.dag_node import DagNode
from rig_factory.objects.node_objects.object_set import ObjectSet
from rig_factory.objects.base_objects.properties import ObjectProperty
from rig_factory.utilities.decorators import flatten_args

class Lattice(Transform):

    ffd = ObjectProperty(
        name='ffd'
    )
    lattice_transform = ObjectProperty(
        name='lattice'
    )
    lattice_shape = ObjectProperty(
        name='lattice_shape'
    )
    lattice_base_transform = ObjectProperty(
        name='base_lattice'
    )
    base_lattice_shape = ObjectProperty(
        name='base_lattice_shape'
    )

    suffix = 'Lat'

    @classmethod
    def create(cls, *args, **kwargs):
        geometry = kwargs.pop('geometry', [])
        this = super(Lattice, cls).create(*args, **kwargs)
        if geometry:
            this.add_geometry(geometry)
        return this

    def create_in_scene(self):
        super(Lattice, self).create_in_scene()
        (
            m_ffd,
            m_lattice,
            m_base_lattice,
            m_lattice_shape,
            m_base_lattice_shape,
            m_object_set
        ) = self.controller.scene.create_lattice()

        self.ffd = self.create_child(
            Deformer,
            node_type='ffd',
            segment_name='Ffd',
            m_object=m_ffd
        )
        self.ffd.deformer_set = self.create_child(
            ObjectSet,
            segment_name='ObjectSet',
            m_object=m_object_set
        )
        self.lattice_transform = lattice = self.create_child(
            Transform,
            segment_name='Lattice',
            m_object=m_lattice
        )
        self.lattice_shape = self.create_child(
            DagNode,
            node_type='lattice',
            segment_name='LatticeShape',
            parent=lattice,
            m_object=m_lattice_shape
        )
        self.lattice_base_transform = base_lattice = self.create_child(
            Transform,
            segment_name='BaseLattice',
            m_object=m_base_lattice
        )
        self.base_lattice_shape = self.create_child(
            DagNode,
            node_type='baseLattice',
            segment_name='BaseLatticeShape',
            parent=base_lattice,
            m_object=m_base_lattice_shape
        )
        self.ffd.plugs['outsideLattice'].set_value(1)

    def get_weights(self):
        return self.ffd.get_weights()

    def set_weights(self, weights):
        self.ffd.set_weights(weights)

    @flatten_args
    def add_geometry(self, *geometry):
        self.ffd.add_geometry(geometry)

    @flatten_args
    def remove_geometry(self, *geometry):
        self.ffd.remove_geometry(geometry)
