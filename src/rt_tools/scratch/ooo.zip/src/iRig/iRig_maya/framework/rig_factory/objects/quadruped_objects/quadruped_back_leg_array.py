import copy
from rig_factory.objects.base_objects.properties import DataProperty
from rig_factory.objects.part_objects.part_array import PartArrayGuide, PartArray
from rig_factory.objects.quadruped_objects.quadruped_bendy_back_leg import QuadrupedBendyBackLegGuide, QuadrupedBendyBackLeg
from rig_factory.objects.quadruped_objects.quadruped_foot import QuadrupedFootGuide, QuadrupedFoot
import rig_factory.positions as pos


class QuadrupedBackLegArrayGuide(PartArrayGuide):
    default_settings = {
        'root_name': 'Back',
        'size': 10.0,
        'side': 'left'
    }

    create_sdks = DataProperty(
        name='create_sdks',
        default_value=True
    )


    def __init__(self, **kwargs):
        super(QuadrupedBackLegArrayGuide, self).__init__(**kwargs)
        self.toggle_class = QuadrupedBackLegArray.__name__

    def create_members(self):
        super(QuadrupedBackLegArrayGuide, self).create_members()

        self.create_part(
            QuadrupedBendyBackLegGuide,
            side=self.side,
            size=self.size,
            root_name=self.root_name + 'Leg'
        )
        foot_part = self.create_part(
            QuadrupedFootGuide,
            side=self.side,
            size=self.size * 0.333,
            root_name=self.root_name + 'Foot'
        )
        foot_part.create_members()
        self.set_handle_positions(copy.copy(pos.QUADRUPED_POSITIONS))


class QuadrupedBackLegArray(PartArray):


    # unused
    create_sdks = DataProperty(
        name='create_sdks',
        default_value=True
    )