import rig_factory.utilities.selection_utilities as sut
from rig_factory.objects.part_objects.base_container import BaseContainer
from rig_factory.objects.part_objects.base_part import BasePart
from rig_factory.objects.face_objects.face_handle_array import FaceHandleArrayGuide
from rig_factory.objects.part_objects.surface_spline import SurfaceSplineGuide
from rig_factory.objects.part_objects.double_surface_spline import DoubleSurfaceSplineGuide
from rig_factory.objects.part_objects.part_array import PartArrayGuide
from rig_factory.objects.face_objects.projection_eye import ProjectionEye
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.part_objects.part_group import PartGroup


def add_visibility_tags(controller, tag):
    selected_parts = sut.get_selected_parts(
        controller,
        types=(
            Part,
            PartGroup,
            PartGroup
        )
    )
    if not selected_parts:
        controller.raise_warning(
            'There doesn\'t seem to be any Parts selected.'
        )
        return
    for part in selected_parts:
        part.vis_layer = tag


def create_single_part(controller, part_type, **kwargs):
    """
    This may be causing garbage collection errors when it fails..
    Need to find a way to make sure nodes dont exist before creating a part.
    """
    owner = kwargs.pop('owner', None)

    if owner:
        part = owner.create_part(part_type, **kwargs)
    else:
        part = controller.root.create_part(part_type, **kwargs)
    if isinstance(part, PartArrayGuide):
        part.create_members()
    for joint in part.joints:
        joint.parent_part = part
    part.post_create(**kwargs)
    controller.dg_dirty()
    return part


def add_visibility_tags(controller, tag):
    selected_parts = sut.get_selected_parts(
        controller,
        types=(
            Part,
            PartGroup
        )
    )
    handles = []
    for part in selected_parts:
        handles.extend(part.get_handles())
    handles.extend(sut.get_selected_handles(controller))
    if not handles:
        controller.raise_warning(
            'There doesn\'t seem to be any Parts or Handles selected.'
        )
        return
    for handle in handles:
        if tag != handle.visibility_tag:
            handle.visibility_tag = tag
            print '"{0}" tag added to "{1}".'.format(tag, handle)
        else:
            print '"{0}" seems to be tagged to "{1}" already.'.format(tag, handle)


def assign_mesh(controller):
    selected_parts = sut.get_selected_parts(
        controller,
        types=(
            ProjectionEye
        )
    )
    if not selected_parts:
        controller.raise_warning(
            'There doesn\'t seem to be any ProjectionEyes selected.'
        )
        return
    elif len(selected_parts) > 1:
        controller.raise_warning(
            'There are more than one ProjectionEye parts selected. Please select only 1.'
        )
        return
    selection_list = controller.scene.ls(sl=True)
    if not selection_list:
        controller.raise_warning('Nothing is selected')
        return
    last_selected_item = selection_list[-1]

    if last_selected_item in controller.named_objects:
        last_selected_node = controller.named_objects[last_selected_item]
        if isinstance(last_selected_node, (BaseContainer, BasePart)):
            controller.raise_warning(
                'Last item in selection "%s" is a Part. it should be a mesh' % last_selected_item
            )
            return
    mesh_objects = controller.scene.get_mesh_objects(last_selected_item)
    surface_object_names = [controller.scene.get_selection_string(x) for x in mesh_objects]
    if len(mesh_objects) > 1:
        controller.raise_warning(
            'Last item in selection list contained more than one mesh object: %s' % '\n'.join(surface_object_names)
        )
        return
    elif len(mesh_objects) < 1:
        controller.raise_warning(
            'No mesh objects were found in the last selected item : %s' % last_selected_item
        )
        return
    mesh_name = surface_object_names[-1]

    for part in selected_parts:
        part.add_geometry_names(mesh_name)

    controller.raise_warning('Success!: Set Surface data for : %s' % selected_parts)


def remove_nurbs_surface_assignments(controller):
        selected_parts = sut.get_selected_parts(
            controller,
            types=(
                BaseContainer,
                FaceHandleArrayGuide,
                SurfaceSplineGuide,
                DoubleSurfaceSplineGuide
            ),
            recursive=True
        )
        if not selected_parts:
            controller.raise_warning(
                'There doesn\'t seem to be any face handle arrays selected.'
            )
            return

        for part in selected_parts:
            if hasattr(part, 'surface_data'):
                part.surface_data = None
                if hasattr(part, 'follicle_surface'):
                    if part.follicle_surface:
                        controller.schedule_objects_for_deletion(part.follicle_surface)

        controller.delete_scheduled_objects()
        return selected_parts

def assign_nurbs_surface(controller):
    selected_parts = sut.get_selected_parts(
        controller,
        types=(
            BaseContainer,
            FaceHandleArrayGuide,
            SurfaceSplineGuide,
            DoubleSurfaceSplineGuide
        ),
        recursive=True
    )
    if not selected_parts:
        controller.raise_warning(
            'There doesn\'t seem to be any face handle arrays selected.'
        )
        return
    selection_list = controller.scene.ls(sl=True)
    if not selection_list:
        controller.raise_warning('Nothing is selected')
        return
    last_selected_item = selection_list[-1]

    if last_selected_item in controller.named_objects:
        last_selected_node = controller.named_objects[last_selected_item]
        if isinstance(last_selected_node, (BaseContainer, BasePart)):
            controller.raise_warning(
                'Last item in selection "%s" is a Part. it should be a surface' % last_selected_item
            )
            return
    surface_objects = controller.scene.get_nurbs_surface_objects(last_selected_item)
    surface_object_names = [controller.scene.get_selection_string(x) for x in surface_objects]
    if len(surface_objects) > 1:
        controller.raise_warning(
            'Last item in selection list contained more than one surface object: %s' % '\n'.join(surface_object_names)
        )
        return
    elif len(surface_objects) < 1:
        controller.raise_warning(
            'No surface objects were found in the last selected item : %s' % last_selected_item
        )
        return
    surface_name = controller.scene.get_dag_path(surface_objects[-1]).fullPathName()
    data = controller.scene.get_surface_data(surface_name)

    for part in selected_parts:
        if hasattr(part, 'surface_data'):
            part.surface_data = data
            if hasattr(part, 'follicle_surface'):
                if part.follicle_surface:
                    controller.scene.connectAttr(
                        '%s.worldSpace[0]' % surface_name,
                        '%s.create' % part.follicle_surface.name
                    )
                    part.follicle_surface.update()
                    controller.scene.disconnectAttr(
                        '%s.worldSpace[0]' % surface_name,
                        '%s.create' % part.follicle_surface.name
                    )

    return surface_name, selected_parts


def assign_closest_vertices_to_selected_parts(controller):
    selected_parts = sut.get_selected_parts(controller)
    selection_list = controller.scene.ls(sl=True)
    if not selection_list:
        controller.raise_warning('Nothing is selected')
        return
    last_selected_item = selection_list[-1]
    if last_selected_item not in controller.named_objects:
        controller.raise_warning(
            'Last item in selection "%s" is not registered with the controller' % last_selected_item
        )
        return
    last_selected_node = controller.named_objects[last_selected_item]
    if isinstance(last_selected_node, (BaseContainer, BasePart)):
        controller.raise_warning(
            'Last item in selection "%s" is a Part. it should be a mesh' % last_selected_item
        )
        return
    mesh_objects = controller.scene.get_mesh_objects(last_selected_item)
    mesh_object_names = [controller.scene.get_selection_string(x) for x in mesh_objects]
    if len(mesh_objects) > 1:
        controller.raise_warning(
            'Last item in selection list contained more than one mesh object: %s' % '\n'.join(mesh_object_names)
        )
        return
    elif len(mesh_objects) < 1:
        controller.raise_warning(
            'No mesh objects were found in the last selected item : %s' % last_selected_item
        )
        return
    if not mesh_object_names[0] in controller.named_objects:
        controller.raise_warning(
            'Selected mesh "%s" is not registered with the controller' % mesh_object_names[0]
        )
        return
    for part in selected_parts:
        assign_closest_vertices(part, mesh_object_names[0])

def assign_closest_vertices(part, mesh_name):
    print part, mesh_name, ' <<<-------'
    controller = part.controller
    if mesh_name in controller.named_objects:
        mesh = controller.named_objects[mesh_name]
        for handle in part.get_handles():
            # try:
            index = controller.get_closest_vertex_index(
                mesh,
                handle.get_matrix().get_translation()
            )
            handle.snap_to_vertices([mesh.get_vertex(index)])
            del handle
            # except Exception as e:
            #     del handle
            #     raise e
    else:
        raise Exception('Invalid mesh: %s ' % mesh_name)

def snap_selected_parts_to_selected_mesh(controller):
    """
    This is a user facing selection based function and so must have a lot of checks
    """
    selection_list = controller.scene.ls(sl=True)
    if not selection_list:
        controller.raise_warning('Nothing is selected')
        return
    last_selected_item = selection_list[-1]

    if last_selected_item in controller.named_objects:
        if isinstance(controller.named_objects[last_selected_item], (BaseContainer, BasePart)):
            controller.raise_warning(
                'Last item in selection "%s" is a Part. it should be a mesh' % last_selected_item
            )
            return

    mesh_m_objects = controller.scene.get_mesh_objects(last_selected_item)
    mesh_object_names = [controller.scene.get_selection_string(x) for x in mesh_m_objects]
    if len(mesh_m_objects) > 1:
        controller.raise_warning(
            'Last item in selection list contained more than one mesh object: %s' % '\n'.join(
                mesh_object_names
            )
        )
        return

    elif len(mesh_m_objects) < 1:
        controller.raise_warning(
            'No mesh objects were found in the last selected item : %s' % mesh_m_objects
        )
        return

    mesh_name = mesh_object_names[0]

    similar_mesh = controller.find_similar_mesh(mesh_name)
    if not similar_mesh:
        controller.raise_warning(
            'Invalid mesh: %s' % mesh_name
        )
        return

    handles = sut.get_selected_part_handles(
        controller,
        include_selected_handles=True
    )

    if not handles:
        controller.raise_warning(
            'No handles found in selection'
        )
        return

    vertexless_handles = []
    for handle in handles:
        if handle.vertices:
            vertex_strings = []
            for x in handle.vertices:
                # if x.mesh == similar_mesh:
                vertex_strings.append('%s.vtx[%s]' % (mesh_name, x.index))
            if vertex_strings:
                position = controller.scene.get_bounding_box_center(*vertex_strings)
                controller.xform(handle, t=position, ws=True)
        else:
            vertexless_handles.append(handle)
    vertexless_handles = list(set(vertexless_handles))
    vertexless_handle_names = [vertexless_handles[x].name for x in range(len(vertexless_handles)) if x < 10]
    if vertexless_handles:
        controller.raise_warning(
            'Warning: some handles did not have vertex assignments and could not be snapped.\n%s' % '\n'.join(
                vertexless_handle_names
            )
        )


def snap_part_to_mesh(part, mesh_name):
    controller = part.controller
    similar_mesh = controller.find_similar_mesh(mesh_name)
    if not similar_mesh:
        raise Exception('Invalid mesh: %s' % mesh_name)
    for handle in part.get_handles(part):
        if handle.vertices:
            vertex_strings = []
            for x in handle.vertices:
                if x.mesh == similar_mesh:
                    vertex_strings.append('%s.vtx[%s]' % (mesh_name, x.index))
            if vertex_strings:
                position = controller.scene.get_bounding_box_center(*vertex_strings)
                controller.xform(handle, t=position, ws=True)
        else:
            print 'Handle "%s" had no vertices ' % handle


def snap_part_to_selected_mesh(part):
    controller = part.controller
    mesh_names = controller.get_selected_mesh_names()
    for mesh_name in mesh_names:
        snap_part_to_mesh(part, mesh_name)
