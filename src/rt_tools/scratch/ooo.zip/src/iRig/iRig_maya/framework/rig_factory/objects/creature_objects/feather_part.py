from rig_factory.objects.deformer_objects.bend import Bend
from rig_factory.objects.deformer_objects.twist import Twist
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.part_objects.chain_guide import ChainGuide
from rig_math.matrix import Matrix


class FeatherPartGuide(ChainGuide):
    default_settings = dict(
        root_name='Feather',
        differentiation_name='Primary',
        size=1.0,
        side='center',
    )

    create_gimbal = DataProperty(
        name='create_gimbal',
        default_value=False
    )

    def __init__(self, **kwargs):
        super(FeatherPartGuide, self).__init__(**kwargs)
        self.toggle_class = FeatherPart.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['count'] = 2
        this = super(FeatherPartGuide, cls).create(controller, **kwargs)
        return this


class FeatherPart(Part):
    _weights = DataProperty(  # Structure: [twist, bendX, bendY]
        name='_weights'
    )
    _geometry_names = DataProperty(
        name='_geometry_names',
        default_value=[]
    )
    geometries = ObjectListProperty(
        name='geometries'
    )
    twist = ObjectProperty(
        name='twist'
    )
    bend_x = ObjectProperty(
        name='bendX'
    )
    bend_z = ObjectProperty(
        name='bendY'
    )
    create_gimbal = DataProperty(
        name='create_gimbal',
        default_value=False
    )
    deform_slide_group = ObjectProperty(
        name='deform_slide_group'
    )
    slide_value = DataProperty(
        name='slide_value',
        default_value=0.0
    )

    @classmethod
    def create(cls, *args, **kwargs):
        this = super(FeatherPart, cls).create(*args, **kwargs)
        joint_1 = this.create_child(
            Joint,
            segment_name='Base',
            matrix=this.matrices[0],
            parent=this.joint_group
        )
        joint_2 = joint_1.create_child(
            Joint,
            segment_name='Tip',
            matrix=this.matrices[1]
        )


        joint_1.zero_rotation()
        joint_2.zero_rotation()
        joint_1.plugs['type'].set_value(18)
        joint_1.plugs['otherType'].set_value('feather')
        joint_2.plugs['type'].set_value(18)
        joint_2.plugs['otherType'].set_value('feather')

        handle = this.create_handle(
            segment_name='Settings',
            shape='marker',
            axis='z',
            matrix=this.matrices[0]
        )

        length = (joint_2.get_translation() - joint_1.get_translation()).mag()
        handle.set_shape_matrix(Matrix([0.0,  (length * -1.1) if this.side=='right' else (length * 1.1), 0.0]))
        if this.side == 'right':
            handle.multiply_shape_matrix(Matrix(scale=[1.0, -1.0, 1.0]))
        this.controller.create_parent_constraint(handle, joint_1)
        this.joints = [joint_1, joint_2]

        bend_x_plug = handle.create_plug(
            'BendX',
            at='double',
            keyable=True
        )
        bend_z_plug = handle.create_plug(
            'BendZ',
            at='double',
            keyable=True
        )
        twist_plug = handle.create_plug(
            'Twist',
            at='double',
            keyable=True
        )
        handle.create_plug(
            'BendXInput',
            at='double',
            keyable=False
        )
        handle.create_plug(
            'BendZInput',
            at='double',
            keyable=False
        )
        handle.create_plug(
            'TwistInput',
            at='double',
            keyable=False
        )
        handle.create_plug(
            'BendXOutput',
            at='double',
            keyable=False
        )
        handle.create_plug(
            'BendZOutput',
            at='double',
            keyable=False
        )
        handle.create_plug(
            'TwistOutput',
            at='double',
            keyable=False
        )
        bend_x_add = this.create_child(
            DependNode,
            node_type='addDoubleLinear',
            segment_name='BendX'
        )
        bend_z_add = this.create_child(
            DependNode,
            node_type='addDoubleLinear',
            segment_name='BendZ'
        )
        twist_add = this.create_child(
            DependNode,
            node_type='addDoubleLinear',
            segment_name='Twist'
        )
        slide_plug = handle.create_plug(
            'Slide',
            at='double',
            keyable=True,
            min=-1.0,
            max=1.0,
            dv=this.slide_value
        )
        #Adding 3 extra attributes to the driver null: twist, bend x , bend z

        drv_null = handle.groups[-2]
        drv_bendx_plug = drv_null.create_plug(
            'BendX',
            at='double',
            keyable=True,
            dv=0
        )
        drv_bendz_plug = drv_null.create_plug(
            'BendZ',
            at='double',
            keyable=True,
            dv=0
        )
        drv_twist_plug = drv_null.create_plug(
            'Twist',
            at='double',
            keyable=True,
            dv=0
        )
        root = this.get_root()

        root.add_plugs(
            drv_bendx_plug,
            drv_bendz_plug,
            drv_twist_plug
        )
        handle.plugs['BendX'].connect_to(bend_x_add.plugs['input1'])
        handle.plugs['BendXInput'].connect_to(bend_x_add.plugs['input2'])
        bend_x_add.plugs['output'].connect_to(handle.plugs['BendXOutput'])
        handle.plugs['BendZ'].connect_to(bend_z_add.plugs['input1'])
        handle.plugs['BendZInput'].connect_to(bend_z_add.plugs['input2'])
        bend_z_add.plugs['output'].connect_to(handle.plugs['BendZOutput'])
        handle.plugs['Twist'].connect_to(twist_add.plugs['input1'])
        handle.plugs['TwistInput'].connect_to(twist_add.plugs['input2'])
        twist_add.plugs['output'].connect_to(handle.plugs['TwistOutput'])

        root = this.get_root()

        root.add_plugs(
            slide_plug,
            bend_x_plug,
            bend_z_plug,
            twist_plug,
            handle.plugs['rx'],
            handle.plugs['ry'],
            handle.plugs['rz'],
        )
        return this

    def create_deformation_rig(self, **kwargs):

        super(FeatherPart, self).create_deformation_rig(**kwargs)
        root = self.get_root()
        if self._geometry_names:
            self.add_geometries([
                root.geometry[geometry_name]
                for geometry_name in self._geometry_names
                if geometry_name in root.geometry
            ])
        if self._weights:
            weights_twist, weights_bendX, weights_bendY = self._weights
            if self.twist:
                self.twist.deformer.set_weights(weights_twist)
            if self.bend_x:
                self.bend_x.deformer.set_weights(weights_bendX)
            if self.bend_z:
                self.bend_z.deformer.set_weights(weights_bendY)

    def create_deformers(self, geometries):
        for geometry in geometries:
            if geometry in self.geometries:
                raise Exception('The geometry "%s" has already been added to %s' % (geometry, self))



        deform_slide_group = self.deform_joints[0].create_child(
            Transform,
            segment_name='DeformSlide'
        )
        slide_divide = deform_slide_group.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='Slide'
        )
        length = (self.joints[1].get_translation() - self.joints[0].get_translation()).mag()
        self.handles[0].plugs['Slide'].connect_to(slide_divide.plugs['input1X'])
        slide_divide.plugs['input2X'].set_value(length * -1.0 if self.side == 'right' else length)
        slide_divide.plugs['outputX'].connect_to(deform_slide_group.plugs['ty'])


        vector_1 = self.matrices[0].get_translation()
        vector_2 = self.matrices[1].get_translation()
        length = (vector_2 - vector_1).magnitude()
        self.twist = deform_slide_group.create_child(
            Twist,
            geometry=geometries,
            segment_name='Twist'
        )
        self.bend_x = deform_slide_group.create_child(
            Bend,
            geometry=geometries,
            segment_name='BendX'
        )
        self.bend_z = deform_slide_group.create_child(
            Bend,
            geometry=geometries,
            segment_name='BendZ'
        )
        bend_position = [
            0.0,
            length * -0.25 if self.side == 'right' else length * 0.25,
            0.0
        ]
        twist_position = [
            0.0,
            length * -0.75 if self.side == 'right' else length * 0.75,
            0.0
        ]
        bend_scale = [length*0.75, length*0.75, length*0.75]
        twist_scale = [length*0.25, length*0.25, length*0.25]
        bend_matrix = Matrix(bend_position, scale=bend_scale)
        twist_matrix = Matrix(twist_position, scale=twist_scale)
        self.twist.handle_shape.plugs['handleWidth'].set_value(1.0)
        self.bend_x.set_matrix(bend_matrix, world_space=False)
        self.bend_z.set_matrix(bend_matrix, world_space=False)
        self.twist.set_matrix(twist_matrix, world_space=False)
        self.bend_z.plugs['ry'].set_value(90.0)
        bend_x_driver = self.handles[0].plugs['BendXOutput']
        bend_z_driver = self.handles[0].plugs['BendZOutput']
        twist_driver = self.handles[0].plugs['TwistOutput']
        if self.side == 'right':
            bend_twist_multiply = self.create_child(
                DependNode,
                node_type='multiplyDivide',
                segment_name='BendTwist'
            )
            self.handles[0].plugs['BendXOutput'].connect_to(bend_twist_multiply.plugs['input1X'])
            self.handles[0].plugs['BendZOutput'].connect_to(bend_twist_multiply.plugs['input1Y'])
            self.handles[0].plugs['TwistOutput'].connect_to(bend_twist_multiply.plugs['input1Z'])
            bend_twist_multiply.plugs['input2X'].set_value(-1.0)
            bend_twist_multiply.plugs['input2Y'].set_value(-1.0)
            bend_twist_multiply.plugs['input2Z'].set_value(1.0)
            bend_x_driver = bend_twist_multiply.plugs['outputX']
            bend_z_driver = bend_twist_multiply.plugs['outputY']
            twist_driver = bend_twist_multiply.plugs['outputZ']

        #adding the bend offset nulls with the bends from the handle:
        drv_null = self.handles[0].groups[-2]
        bend_x_drv_plug = drv_null.plugs['BendX']
        bend_z_drv_plug = drv_null.plugs['BendZ']
        bend_x_offset = bend_x_drv_plug.add(self.handles[0].plugs['BendXOutput'])
        bend_z_offset = bend_z_drv_plug.add(self.handles[0].plugs['BendZOutput'])
        twist_offset = drv_null.plugs['Twist'].add(self.handles[0].plugs['TwistOutput'])

        #Making sure 'right' side null is mirrored:
        if self.side == 'right':
            null_twist_multiply = self.create_child(
                DependNode,
                node_type='multiplyDivide',
                segment_name='BendTwistNull'
            )
            bend_x_offset.connect_to(null_twist_multiply.plugs['input1X'])
            bend_z_offset.connect_to(null_twist_multiply.plugs['input1Y'])
            twist_offset.connect_to(null_twist_multiply.plugs['input1Z'])
            null_twist_multiply.plugs['input2X'].set_value(-1.0)
            null_twist_multiply.plugs['input2Y'].set_value(-1.0)
            null_twist_multiply.plugs['input2Z'].set_value(1.0)
            r_bend_x_offset = null_twist_multiply.plugs['outputX']
            r_bend_z_offset = null_twist_multiply.plugs['outputY']
            r_twist_offset = null_twist_multiply.plugs['outputZ']
            r_bend_x_offset.connect_to(self.bend_x.deformer.plugs['curvature'])
            r_bend_z_offset.connect_to(self.bend_z.deformer.plugs['curvature'])
            self.bend_x.deformer.plugs['highBound'].set_value(0.0)
            self.bend_z.deformer.plugs['highBound'].set_value(0.0)
            r_twist_offset.connect_to(self.twist.deformer.plugs['startAngle'])

        else:
            bend_x_offset.connect_to(self.bend_x.deformer.plugs['curvature'])
            bend_z_offset.connect_to(self.bend_z.deformer.plugs['curvature'])
            twist_offset.connect_to(self.twist.deformer.plugs['endAngle'])
            self.bend_x.deformer.plugs['lowBound'].set_value(0.0)
            self.bend_z.deformer.plugs['lowBound'].set_value(0.0)

        self.twist.plugs['v'].set_value(False)
        self.bend_x.plugs['v'].set_value(False)
        self.bend_z.plugs['v'].set_value(False)
        self.geometries.extend(geometries)

    def get_weights(self):
        if self.geometries:
            return [
                self.twist.deformer.get_weights(),
                self.bend_x.deformer.get_weights(),
                self.bend_z.deformer.get_weights()
            ]

    def get_blueprint(self):
        blueprint = super(FeatherPart, self).get_blueprint()
        blueprint['_geometry_names'] = [x.name for x in self.geometries]
        blueprint['_weights'] = self.get_weights()
        blueprint['slide_value'] = self.handles[0].plugs['Slide'].get_value()

        return blueprint

    def get_toggle_blueprint(self):
        blueprint = super(FeatherPart, self).get_toggle_blueprint()
        blueprint['rig_data']['_geometry_names'] = [x.name for x in self.geometries]
        blueprint['rig_data']['_weights'] = self.get_weights()
        blueprint['rig_data']['slide_value'] = self.handles[0].plugs['Slide'].get_value()
        return blueprint

    def add_selected_geometries(self):
        self.add_geometries(get_selected_mesh_objects(self.controller))

    def add_geometries(self, geometries):
        for geometry in geometries:
            if geometry in self.geometries:
                raise Exception('The geometry "%s" has already been added to %s' % (geometry, self))

        for geometry in geometries:
            if not self.controller.scene.find_skin_cluster(geometry.m_object):
                self.controller.scene.skinCluster(
                    geometry,
                    self.deform_joints[0],
                    bindMethod=0,
                    tsb=True
                )

        if geometries:
            if not self.geometries:
                self.create_deformers(geometries)
            else:
                self.twist.add_geometry(geometries)
                self.bend_x.add_geometry(geometries)
                self.bend_z.add_geometry(geometries)

    def clear_geometry(self):
        for geometry in self.geometries:
            self.controller.scene.skinCluster(geometry, edit=True, unbind=True)
        self.controller.schedule_objects_for_deletion(
            self.twist,
            self.bend_x,
            self.bend_z,
        )
        self.controller.delete_scheduled_objects()
        self.geometries = []

    def finalize(self):
        super(FeatherPart, self).finalize()
        if self.twist:
            self.twist.plugs['v'].set_value(False)
        if self.bend_x:
            self.bend_x.plugs['v'].set_value(False)
        if self.bend_z:
            self.bend_z.plugs['v'].set_value(False)


def get_selected_mesh_objects(c):
    return [c.named_objects[x] for x in c.scene.get_selected_mesh_names() if x in c.named_objects]

