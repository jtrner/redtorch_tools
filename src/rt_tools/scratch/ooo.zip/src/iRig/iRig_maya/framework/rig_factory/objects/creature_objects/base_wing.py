from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty
from rig_factory.objects.part_objects.part_array import PartArrayGuide, PartArray
from rig_factory.objects.part_objects.fk_chain import FkChainGuide, FkChain
from rig_factory.objects.creature_objects.feather_part import FeatherPart
from rig_factory.objects.biped_objects.biped_arm_bendy import BipedArmBendyGuide, BipedArmBendy
from rig_factory.objects.biped_objects.biped_arm import BipedArmGuide, BipedArm
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.locator import Locator

import rig_math.vector as vec
from rig_math.matrix import Matrix
import rig_factory.environment as env
import rig_factory


class BaseWingGuide(PartArrayGuide):
    default_settings = {
        'root_name': 'Wing',
        'size': 1.0,
        'side': 'left',
        'primary_digit_count': 5,
        'secondary_digit_count': 5,
        'tertiary_digit_count': 5,
        'digit_segment_count': 3,
        'use_bendy_arm': False
    }

    primary_digit_count = DataProperty(
        name='primary_digit_count'
    )
    secondary_digit_count = DataProperty(
        name='secondary_digit_count'
    )
    tertiary_digit_count = DataProperty(
        name='tertiary_digit_count'
    )
    primary_length = DataProperty(
        name='primary_length',
        default_value=13.0
    )
    secondary_length = DataProperty(
        name='secondary_length',
        default_value=10.0
    )

    tertiary_length = DataProperty(
        name='tertiary_length',
        default_value=8.0
    )

    digit_segment_count = DataProperty(
        name='digit_segment_count',
        default_value=3
    )

    use_bendy_arm = DataProperty(
        name='use_bendy_arm',
        default_value=False
    )

    digit_class = FkChainGuide

    def __init__(self, **kwargs):
        super(BaseWingGuide, self).__init__(**kwargs)
        self.toggle_class = BaseWing.__name__

    def create_members(self):
        if self.side not in ['left', 'right']:
            raise Exception('Invalid side "%s"' % self.side)
        limb_chain = self.create_part(
            BipedArmBendyGuide if self.use_bendy_arm else BipedArmGuide,
            root_name='%sLimb' % self.root_name,
            size=self.size*2,
            side=self.side,
            count=5,
            create_bendy_hand=True
        )
        for i in range(self.primary_digit_count):
            digit = self.create_part(
                self.digit_class,
                root_name='%sDigit%s' % (self.root_name, rig_factory.index_dictionary[i].capitalize()),
                differentiation_name='Primary',
                size=self.size*0.25,
                side=self.side,
                count=self.digit_segment_count
            )
            digit.set_parent_joint(limb_chain.joints[3])
        for i in range(self.secondary_digit_count):
            digit = self.create_part(
                self.digit_class,
                root_name='%sDigit%s' % (self.root_name, rig_factory.index_dictionary[i].capitalize()),
                differentiation_name='Secondary',
                size=self.size*0.25,
                side=self.side,
                count=self.digit_segment_count
            )
            digit.set_parent_joint(limb_chain.joints[2])
        for i in range(self.tertiary_digit_count):
            digit = self.create_part(
                self.digit_class,
                root_name='%sDigit%s' % (self.root_name, rig_factory.index_dictionary[i].capitalize()),
                differentiation_name='Tertiary',
                size=self.size*0.25,
                side=self.side,
                count=self.digit_segment_count
            )
            digit.set_parent_joint(limb_chain.joints[1])
        sm = -1.0 if self.side == 'right' else 1.0
        limb_chain.base_handles[0].plugs['translate'].set_value([1.0*self.size*sm, 0.0, 0.0])
        limb_chain.base_handles[1].plugs['translate'].set_value([6.0*self.size*sm, 0.0, 0.0])
        limb_chain.base_handles[2].plugs['translate'].set_value([16.0*self.size*sm, 0.0, -5.0*self.size])
        limb_chain.base_handles[3].plugs['translate'].set_value([26.0*self.size*sm, 0.0, 0.0])
        limb_chain.base_handles[4].plugs['translate'].set_value([30.0*self.size*sm, 0.0,  -1.0*self.size])
        limb_chain.up_handles[0].plugs['translate'].set_value([0.0, 0.0,  -20.0*self.size])
        self.calculate_positions()

    def calculate_positions(self):
        limb_chain = self.find_first_part(BipedArmGuide)
        if not limb_chain:
            self.controller.raise_warning(
                'Limb not found.'
            )
            return
        if len(limb_chain.joints) != 5:
            self.controller.raise_warning(
                'Wing Limb had %s joints. unable to calculate digit positions' % len(limb_chain.joints)
            )
            return
        if self.digit_segment_count < 2:
            self.controller.raise_warning(
                'digit_segment_count is less than 2. Unable to calculate spacing.'
            )
            return

        primary_digits = self.find_parts(
            self.digit_class,
            differentiation_name='Primary',
            sorted=True
        )
        secondary_digits = self.find_parts(
            self.digit_class,
            differentiation_name='Secondary',
            sorted=True
        )
        tertiary_digits = self.find_parts(
            self.digit_class,
            differentiation_name='Tertiary',
            sorted=True
        )

        digit_lengths = [self.tertiary_length, self.tertiary_length, self.secondary_length, self.primary_length]
        for d, digits in enumerate([tertiary_digits, secondary_digits, primary_digits]):
            if digits:
                side_multiply = -1.0 if digits[0].side == 'right' else 1.0
                digit_count = len(digits)
                joint_1 = limb_chain.joints[d]
                joint_2 = limb_chain.joints[d+1]
                joint_3 = limb_chain.joints[d+2]
                vector_1 = vec.Vector(joint_1.get_matrix().data[2][0:3]) * -1.0
                vector_2 = vec.Vector(joint_2.get_matrix().data[2][0:3]) * -1.0
                vector_3 = vec.Vector(joint_3.get_matrix().data[2][0:3]) * -1.0
                start_vector = (vector_1 + vector_2).normalize() * side_multiply
                if d == 2:
                    end_vector = (joint_3.get_translation() - joint_2.get_translation()).normalize()
                else:
                    end_vector = (vector_2 + vector_3).normalize() * side_multiply
                for i, digit in enumerate(digits):
                    percentage = 0.0 if digit_count == 1 else 1.0 / (digit_count -1) * i
                    digit_vector = (end_vector * percentage) + (start_vector * (1.0 - percentage))
                    digit_position = (joint_3.get_translation() * percentage) + (joint_2.get_translation() * (1.0 - percentage))
                    digit_length = (digit_lengths[d+1] * percentage) + (digit_lengths[d] * (1.0-percentage))
                    current_aim_position = digit_position + (digit_vector * (digit_length*self.size))
                    current_up_position = digit_position + vec.Vector([0.0, self.size * 4.0, 0.0])
                    base_handles = digit.base_handles
                    up_handle = digit.up_handles[0]
                    base_handles[0].plugs['translate'].set_value(digit_position)
                    base_handles[-1].plugs['translate'].set_value(current_aim_position)
                    set_even_spacing(base_handles)
                    up_handle.plugs['translate'].set_value(current_up_position)


class BaseWing(PartArray):

    aim_handles = ObjectListProperty(
        name='aim_handles'
    )
    digit_class = FkChain

    def finish_create(self, **kwargs):
        limb_part = self.find_first_part(BipedArm, BipedArmBendy)
        if isinstance(limb_part, BipedArmBendy) and len(limb_part.limb_segments) != 3:
            self.controller.raise_warning(
                'WARNING: BipedArmBendy does not have three bendy segments. Please set "create_bendy_hand" to True'
            )
        primary_digits = sorted(self.find_parts(self.digit_class, differentiation_name='Primary'), key=lambda x: x.name)
        secondary_digits = sorted(self.find_parts(self.digit_class, differentiation_name='Secondary'), key=lambda x: x.name)
        tertiary_digits = sorted(self.find_parts(self.digit_class, differentiation_name='Tertiary'), key=lambda x: x.name)
        clavicle_joint = limb_part.joints[0]
        shoulder_joint = limb_part.joints[1]
        forearm_joint = limb_part.joints[2]
        wrist_joint = limb_part.joints[3]
        wrist_tip_joint = limb_part.joints[4]
        arm_joints = [clavicle_joint, shoulder_joint, forearm_joint, wrist_joint, wrist_tip_joint]
        root = self.get_root()
        aim_handles = []
        position_getters = []
        tertiary_vector = tertiary_digits[0].joints[-1].get_translation() - tertiary_digits[0].joints[0].get_translation()
        secondary_vector = secondary_digits[0].joints[-1].get_translation() - secondary_digits[0].joints[0].get_translation()
        primary_vector = primary_digits[0].joints[-1].get_translation() - primary_digits[0].joints[0].get_translation()
        primary_tip_vector = primary_digits[-1].joints[-1].get_translation() - primary_digits[-1].joints[0].get_translation()
        digit_groups = [tertiary_digits, secondary_digits, primary_digits, None]
        digit_vectors = [tertiary_vector, secondary_vector, primary_vector, primary_tip_vector]

        bend_x_remap = self.create_child(
            DependNode,
            node_type='remapValue',
            segment_name='BendX',
        )

        bend_z_remap = self.create_child(
            DependNode,
            node_type='remapValue',
            segment_name='BendZ',
        )

        twist_remap = self.create_child(
            DependNode,
            node_type='remapValue',
            segment_name='Twist',
        )

        bend_x_remap_nodes = []
        bend_z_remap_nodes = []
        twist_remap_nodes = []
        up_transforms = []

        for i in range(len(arm_joints)-1):
            digits = digit_groups[i]
            joint = arm_joints[i]
            next_joint = arm_joints[i + 1]
            next_joint_position = next_joint.get_translation()
            aim_transform = self.create_child(
                Transform,
                segment_name='%sAim' % next_joint.segment_name,
                matrix=Matrix(next_joint_position + (digit_vectors[i]*2.0))
            )
            joint_constraint = self.controller.create_parent_constraint(
                joint, next_joint,
                aim_transform,
                mo=True
            )
            angle_transform = self.create_child(
                Transform,
                segment_name='%sAngle' % joint.segment_name,
                matrix=Matrix(next_joint_position),
                parent=next_joint
            )

            up_transform = joint.create_child(
                Transform,
                segment_name='%sUpGetter' % joint.segment_name,
                matrix=joint.get_matrix()
            )
            up_transforms.append(up_transform)
            orient_constraint = self.controller.create_orient_constraint(
                joint,
                next_joint,
                up_transform,
                mo=False
            )
            orient_constraint.plugs['interpType'].set_value(2)
            self.controller.create_aim_constraint(
                aim_transform,
                angle_transform,
                aimVector=env.side_aim_vectors[self.side],
                upVector=env.side_up_vectors[self.side],
                worldUpObject=up_transform,
                worldUpType='objectrotation',
                worldUpVector=[1.0, 0.0, 0.0] if self.side == 'right' else [-1.0, 0.0, 0.0],
                mo=False
            )
            handle_positon = angle_transform.get_matrix()
            if self.side == 'right':
                handle_positon.flip_y()
            handle_positon.set_translation(next_joint_position + (digit_vectors[i]*1.1))
            aim_handle = self.create_handle(
                shape='marker',
                axis='z',
                segment_name='%sAim' % joint.segment_name,
                matrix=handle_positon,
                parent=angle_transform,
                size=self.size*2.5
            )
            if self.side not in 'right':
                aim_handle.multiply_shape_matrix(Matrix(scale=[1.0, 1.0, -1.0]))
            rotation_blending_plug = aim_handle.create_plug(
                'RotationBlending',
                at='double',
                dv=0.5,
                min=0.0,
                max=1.0,
                k=True
            )
            blending_reverse = joint.create_child(
                DependNode,
                node_type='reverse'
            )
            rotation_blending_plug.connect_to(blending_reverse.plugs['inputX'])
            blending_reverse.plugs['outputX'].connect_to(joint_constraint.get_weight_plug(joint))
            rotation_blending_plug.connect_to(joint_constraint.get_weight_plug(next_joint))
            root.add_plugs(
                aim_handle.plugs['tx'],
                aim_handle.plugs['ty'],
                aim_handle.plugs['tz']
            )
            bend_x_plug = aim_handle.create_plug(
                'BendX',
                at='double',
                keyable=True
            )
            bend_z_plug = aim_handle.create_plug(
                'BendZ',
                at='double',
                keyable=True
            )
            twist_plug = aim_handle.create_plug(
                'Twist',
                at='double',
                keyable=True
            )
            root.add_plugs(
                bend_x_plug,
                bend_z_plug,
                twist_plug,
                rotation_blending_plug
            )
            # Adding 3 extra attributes to the driver null: twist, bend x , bend z:

            aim_drv_null = aim_handle.groups[-2]
            aim_drv_bendx_plug = aim_drv_null.create_plug(
                'BendX',
                at='double',
                keyable=True,
                dv=0
            )
            aim_drv_bendz_plug = aim_drv_null.create_plug(
                'BendZ',
                at='double',
                keyable=True,
                dv=0
            )
            aim_drv_twist_plug = aim_drv_null.create_plug(
                'Twist',
                at='double',
                keyable=True,
                dv=0
            )

            root.add_plugs(
                aim_drv_bendx_plug,
                aim_drv_bendz_plug,
                aim_drv_twist_plug
            )

            aim_handles.append(aim_handle)

            if digits is None or len(digits) < 2:
                getter = aim_handle.create_child(
                    Transform,
                    segment_name='%sGetter' % aim_handle.segment_name,
                    parent=self
                )
                self.controller.create_point_constraint(
                    aim_handle,
                    getter,
                    mo=False
                )
                position_getters.append((getter, getter))
            else:
                start_handle = self.create_handle(
                    shape='circle',
                    axis='z',
                    segment_name='%sStartAim' % joint.segment_name,
                    matrix=handle_positon,
                    parent=aim_handle,
                    size=self.size,
                    create_gimbal=False
                )
                start_handle.multiply_shape_matrix(Matrix([self.size * -1.0 if self.side=='right' else self.size, self.size, 0.0]))
                end_handle = self.create_handle(
                    shape='circle',
                    axis='z',
                    segment_name='%sEndAim' % joint.segment_name,
                    matrix=handle_positon,
                    parent=aim_handle,
                    size=self.size,
                    create_gimbal=False
                )
                root.add_plugs(
                    start_handle.plugs['tx'],
                    start_handle.plugs['ty'],
                    start_handle.plugs['tz'],
                    end_handle.plugs['tx'],
                    end_handle.plugs['ty'],
                    end_handle.plugs['tz'],
                )
                end_handle.multiply_shape_matrix(Matrix([self.size if self.side == 'right' else self.size * -1.0, self.size, 0.0]))
                start_getter = start_handle.create_child(
                    Transform,
                    segment_name='%sGetter' % start_handle.segment_name,
                    parent=self
                )
                end_getter = end_handle.create_child(
                    Transform,
                    segment_name='%sGetter' % end_handle.segment_name,
                    parent=self
                )
                self.controller.create_point_constraint(
                    start_handle,
                    start_getter,
                    mo=False
                )
                self.controller.create_point_constraint(
                    end_handle,
                    end_getter,
                    mo=False
                )
                position_getters.append((start_getter, end_getter))

            #Adding an addDoubleLinear in between the control and the remap node to add offset nulls:
            aim_drv_null = aim_handle.groups[-2]
            aim_bend_x_drv_plug = aim_drv_null.plugs['BendX']
            aim_bend_z_drv_plug = aim_drv_null.plugs['BendZ']
            aim_twist_drv_plug = aim_drv_null.plugs['Twist']
            aim_bendx_add = aim_bend_x_drv_plug.add(bend_x_plug)
            aim_bendz_add = aim_bend_z_drv_plug.add(bend_z_plug)
            aim_twist_add= aim_twist_drv_plug.add(twist_plug)

            #Connecting remap nodes to out addDoubleLinear instead:
            in_value = 1.0/(len(arm_joints)-2) * i
            bend_x_remap.plugs['value'].element(i).child(0).set_value(in_value)
            aim_bendx_add.connect_to(bend_x_remap.plugs['value'].element(i).child(1))
            bend_x_remap.plugs['value'].element(i).child(2).set_value(2)
            bend_z_remap.plugs['value'].element(i).child(0).set_value(in_value)
            aim_bendz_add.connect_to(bend_z_remap.plugs['value'].element(i).child(1))
            bend_z_remap.plugs['value'].element(i).child(2).set_value(2)
            twist_remap.plugs['value'].element(i).child(0).set_value(in_value)
            aim_twist_add.connect_to(twist_remap.plugs['value'].element(i).child(1))
            twist_remap.plugs['value'].element(i).child(2).set_value(2)
            bend_x_remap_nodes.append(bend_x_remap)
            bend_z_remap_nodes.append(bend_z_remap)
            twist_remap_nodes.append(twist_remap)

        limb_locators = []
        for limb_joint in limb_part.joints:
            locator = limb_joint.create_child(
                Locator,
                segment_name='%sBendyGetter' % limb_joint.segment_name
            )
            locator.plugs['visibility'].set_value(False)
            limb_locators.append(locator)
        all_digits = digit_groups[0] + digit_groups[1] + digit_groups[2]
        ad = 0
        for d in range(3):

            start_getter = position_getters[d][1]
            end_getter = position_getters[d+1][0]
            fist_tip_position = digit_groups[d][0].joints[-1].get_translation()
            last_tip_position = digit_groups[d][-1].joints[-1].get_translation()
            tip_span_vector = (last_tip_position - fist_tip_position)
            tip_span_length = tip_span_vector.mag()

            limb_joint_1 = limb_part.joints[d + 1]
            limb_joint_2 = limb_part.joints[d + 2]

            joint_position_1 = limb_joint_1.get_translation()
            joint_position_2 = limb_joint_2.get_translation()

            if isinstance(limb_part, BipedArmBendy) and len(limb_part.limb_segments) > d:
                segment_curve = limb_part.limb_segments[d].nurbs_curve
            else:
                limb_locator_1 = limb_locators[d + 1]
                limb_locator_2 = limb_locators[d + 2]
                segment_curve_transform = self.create_child(
                    Transform,
                    segment_name='BendyCurve%s' % rig_factory.index_dictionary[d]
                )
                segment_curve = segment_curve_transform.create_child(
                    NurbsCurve,
                    degree=1,
                    positions=[
                        joint_position_1,
                        joint_position_2
                    ]
                )
                segment_curve_transform.plugs['inheritsTransform'].set_value(False)
                segment_curve_transform.plugs['visibility'].set_value(False)
                limb_locator_1.plugs['worldPosition'].element(0).connect_to(
                    segment_curve.plugs['controlPoints'].element(0))
                limb_locator_2.plugs['worldPosition'].element(0).connect_to(
                    segment_curve.plugs['controlPoints'].element(1))

            for i, digit in enumerate(digit_groups[d]):

                digit_start_position = digit.joints[0].get_translation()
                digit_second_position = digit.joints[1].get_translation()
                end_position = digit.joints[-1].get_translation()
                second_to_end_position = digit.joints[-2].get_translation()
                closest_point_on_bone = vec.find_closest_point_on_line(
                    digit_start_position,
                    joint_position_1,
                    joint_position_2
                )
                bone_vector = joint_position_2 - joint_position_1
                bone_segment_vector = closest_point_on_bone - joint_position_1
                if bone_vector.mag() == 0.0:
                    raise Exception('Bone has zero length.')
                if bone_vector.mag() == 0.0:
                    raise Exception('Bone has zero length.')
                segment_length = bone_segment_vector.mag()
                percent_down_bone = 0.0 if segment_length == 0.0 else segment_length / bone_vector.mag()

                edge_point = vec.find_closest_point_on_line(
                    digit.joints[-1].get_translation(),
                    fist_tip_position,
                    last_tip_position
                )
                closest_point_on_digit = vec.find_closest_point_on_line(
                    edge_point,
                    digit.joints[0].get_translation(),
                    digit.joints[-1].get_translation()
                )
                edge_point = vec.find_closest_point_on_line(
                    closest_point_on_digit,
                    fist_tip_position,
                    last_tip_position
                )
                closest_point_on_digit = vec.find_closest_point_on_line(
                    edge_point,
                    digit.joints[0].get_translation(),
                    digit.joints[-1].get_translation()
                )

                segment_span_length = (closest_point_on_digit - fist_tip_position).mag()
                if segment_span_length == 0.0 or tip_span_length == 0.0:
                    percentage_down_edge = 0.0
                else:
                    percentage_down_edge = segment_span_length / tip_span_length

                handle_position = digit.joints[0].get_matrix()
                handle_position.set_translation(end_position + ((end_position - second_to_end_position).normalize() * self.size))
                rotation_blending_plug = digit.create_plug(
                    'RotationBlending',
                    attributeType='double',
                    min=0.0,
                    max=1.0,
                    dv=0.0,
                    keyable=True
                )
                mantain_offset_plug = digit.create_plug(
                    'MaintainOffset',
                    attributeType='double',
                    min=0.0,
                    max=1.0,
                    dv=1.0,
                    keyable=True
                )
                rotation_blending_plug.set_value(percentage_down_edge)
                aim_object = digit.create_child(
                    Transform,
                    segment_name='AimObject',
                    parent=self
                )

                blend_colors = aim_object.create_child(
                    DependNode,
                    node_type='blendColors',
                )
                end_getter.plugs['translate'].connect_to(blend_colors.plugs['color1'])
                start_getter.plugs['translate'].connect_to(blend_colors.plugs['color2'])
                blend_colors.plugs['output'].connect_to(aim_object.plugs['translate'])
                rotation_blending_plug.connect_to(blend_colors.plugs['blender'])
                aim_constraint = self.controller.create_aim_constraint(
                    aim_object,
                    digit.handles[0].groups[0],
                    aimVector=env.side_aim_vectors[self.side],
                    upVector=env.side_up_vectors[self.side],
                    worldUpObject=up_transforms[d],
                    worldUpType='objectrotation',
                    worldUpVector=[1.0, 0.0, 0.0] if self.side == 'right' else [-1.0, 0.0, 0.0],
                    mo=True
                )
                pair_blend = digit.create_child(
                    DependNode,
                    node_type='pairBlend',
                    segment_name='OrientBlend%s' % digit.segment_name
                )
                point_on_curve_info = digit.create_child(
                    DependNode,
                    node_type='pointOnCurveInfo',
                    segment_name='%sBendy' % digit.segment_name
                )
                translate_getter_transform = digit.create_child(
                    Transform,
                    segment_name='%sBendyGetter' % digit.segment_name
                )
                translate_getter_transform.plugs['inheritsTransform'].set_value(False)

                segment_curve.plugs['worldSpace'].element(0).connect_to(point_on_curve_info.plugs['inputCurve'])
                point_on_curve_info.plugs['turnOnPercentage'].set_value(True)
                point_on_curve_info.plugs['parameter'].set_value(percentage_down_edge)
                point_on_curve_info.plugs['result'].child(0).connect_to(translate_getter_transform.plugs['translate'])
                self.controller.create_point_constraint(
                    translate_getter_transform,
                    digit.handles[0].groups[0],
                    mo=True
                )
                pair_blend.plugs['inRotate1'].set_value([0.0, 0.0, 0.0])
                pair_blend.plugs['inRotate2'].set_value(aim_constraint.plugs['offset'].get_value())
                pair_blend.plugs['outRotate'].connect_to(aim_constraint.plugs['offset'])
                pair_blend.plugs['rotInterpolation'].set_value(1)
                mantain_offset_plug.connect_to(pair_blend.plugs['weight'])
                if isinstance(digit, FeatherPart):
                    feather_bend_x_remap = self.create_child(
                        DependNode,
                        node_type='remapValue',
                        segment_name='FeatherBendX%s' % rig_factory.index_dictionary[ad],
                    )
                    feather_bend_z_remap = self.create_child(
                        DependNode,
                        node_type='remapValue',
                        segment_name='FeatherBendZ%s' % rig_factory.index_dictionary[ad],
                    )
                    feather_twist_remap = self.create_child(
                        DependNode,
                        node_type='remapValue',
                        segment_name='FeatherTwist%s' % rig_factory.index_dictionary[ad],
                    )

                    fraction = 1.0 / (len(all_digits)-1) * ad
                    feather_bend_x_remap.plugs['inputValue'].set_value(fraction)
                    feather_bend_z_remap.plugs['inputValue'].set_value(fraction)
                    feather_twist_remap.plugs['inputValue'].set_value(fraction)

                    feather_bend_x_remap.plugs['outValue'].connect_to(digit.handles[0].plugs['BendXInput'])
                    feather_bend_z_remap.plugs['outValue'].connect_to(digit.handles[0].plugs['BendZInput'])
                    feather_twist_remap.plugs['outValue'].connect_to(digit.handles[0].plugs['TwistInput'])

                    for e in range(4):
                        for c in range(3):
                            bx = feather_bend_x_remap.plugs['value'].element(e).child(c)
                            bend_x_remap_nodes[d].plugs['value'].element(e).child(c).connect_to(bx)
                            bz = feather_bend_z_remap.plugs['value'].element(e).child(c)
                            bend_z_remap_nodes[d].plugs['value'].element(e).child(c).connect_to(bz)
                            tz = feather_twist_remap.plugs['value'].element(e).child(c)
                            twist_remap_nodes[d].plugs['value'].element(e).child(c).connect_to(tz)
                ad += 1

        self.aim_handles = aim_handles

        #reorder FK wrist handle
        limb_part.fk_handles[-1].plugs['rotateOrder'].set_value(5)


def set_even_spacing(transforms):
    if len(transforms) < 2:
        raise Exception('Not enough handles to space evenly')
    position_1 = transforms[0].get_translation()
    position_2 = transforms[-1].get_translation()
    center_handles = transforms[1:-1]
    for i in range(len(center_handles)):
        fraction = 1.0 / (len(center_handles)+1) * (i+1)
        center_handles[i].set_matrix(Matrix((position_1*(1.0-fraction))+(position_2*fraction)))
