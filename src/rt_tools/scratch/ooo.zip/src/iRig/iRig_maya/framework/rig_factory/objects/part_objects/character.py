from rig_factory.objects.part_objects.container import Container, ContainerGuide


class CharacterGuide(ContainerGuide):

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['root_name'] = None
        return super(CharacterGuide, cls).create(controller, **kwargs)

    def __init__(self, **kwargs):
        super(CharacterGuide, self).__init__(**kwargs)
        self.toggle_class = Character.__name__

    def post_create(self, **kwargs):
        super(CharacterGuide, self).post_create(**kwargs)


class Character(Container):

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['root_name'] = None
        return super(Character, cls).create(controller, **kwargs)

    def post_create(self, **kwargs):
        super(Character, self).post_create(**kwargs)
