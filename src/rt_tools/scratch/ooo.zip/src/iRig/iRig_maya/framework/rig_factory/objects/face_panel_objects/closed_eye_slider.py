
from rig_factory.objects.face_panel_objects.base_slider import BaseSlider, BaseSliderGuide
from rig_math.matrix import Matrix
import rig_factory.utilities.face_panel_utillities as utl
from rig_factory.objects.base_objects.properties import ObjectProperty
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.joint import Joint
import copy


class ClosedEyeSliderGuide(BaseSliderGuide):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Eye',
        side='left',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(ClosedEyeSliderGuide, self).__init__(**kwargs)
        self.toggle_class = ClosedEyeSlider.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(BaseSliderGuide, cls).create(controller, **kwargs)
        joints = []
        for handle_name in ('Lid', 'Blink'):
            handle = this.create_handle(
                segment_name=handle_name
            )
            handle.mesh.assign_shading_group(this.get_root().shaders[this.side].shading_group)
            joint = handle.create_child(
                Joint
            )
            controller.create_parent_constraint(handle, joint)
            joint.plugs['drawStyle'].set_value(2)
            joints.append(joint)
        this.joints = joints
        return this


class ClosedEyeSlider(BaseSlider):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Eye',
        side='left',
        size=1.0
    )
    up_handle = ObjectProperty(
        name='up_handle'
    )

    down_handle = ObjectProperty(
        name='up_handle'
    )

    blink_handle = ObjectProperty(
        name='blink_handle'
    )

    def __init__(self, **kwargs):
        super(ClosedEyeSlider, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(ClosedEyeSlider, cls).create(controller, **kwargs)
        side = this.side
        size = this.size
        if len(this.matrices) == 1:
            eye_matrix, blink_matrix = [
                this.matrices[0],
                copy.copy(this.matrices[0])
            ]
        else:
            eye_matrix, blink_matrix = this.matrices

        #  Nodes

        up_handle = this.create_handle(
            segment_name='Up',
            shape='circle_half_smooth',
            size=size * 2,
            matrix=eye_matrix * Matrix(0.0, size, 0.0)
        )
        # utl.set_attr_limit(up_handle, 'TransY', size * -1.25, size * 0.25)
        # utl.set_attr_limit(up_handle, 'TransX', size * -1.0, size)
        utl.set_attr_limit(up_handle, 'TransZ', 0.0, 0.0)
        if side == 'right':
            up_handle.groups[-1].plugs['rotateY'].set_value(180.0)

        down_handle = this.create_handle(
            segment_name='Down',
            shape='circle_half_smooth',
            size=size * 2,
            matrix=eye_matrix * Matrix(0.0, -1.0 * size, 0.0)
        )
        # utl.set_attr_limit(down_handle, 'TransY', size * -0.25, size * 1.25)
        # utl.set_attr_limit(down_handle, 'TransX', size * -1.0, size)
        utl.set_attr_limit(down_handle, 'TransZ', 0.0, 0.0)
        down_handle.multiply_shape_matrix(Matrix(scale=[1.0, -1.0, 1.0]))
        if side == 'right':
            down_handle.groups[-1].plugs['rotateY'].set_value(180.0)
        position_transform = this.create_child(
            Transform,
            matrix=blink_matrix,
            segment_name='BlinkPosition',
        )
        outline_curve_wide = position_transform.create_child(
            NurbsCurve,
            segment_name='OutlineWide',
            degree=1,
            positions=[
                [0.0, size, 0.0],
                [size * -1.0, size, 0.0],
                [size * -1.0, size * -1.0, 0.0],
                [0.0, size * -1.0, 0.0],
                [0.0, size, 0.0]
            ]
        )
        x_curve = position_transform.create_child(
            NurbsCurve,
            segment_name='X',
            degree=1,
            positions=[
                [size * -1.0, 0.0, 0.0],
                [0.0, 0.0, 0.0]
            ]
        )

        x_curve.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )

        outline_curve_wide.plugs.set_values(
            overrideDisplayType=1,
            overrideEnabled=True
        )

        blink_handle = this.create_handle(
            segment_name='Blink',
            shape='star_four',
            axis='z',
            size=size,
            side=side,
            matrix=blink_matrix,
            parent=position_transform
        )
        utl.set_attr_limit(
            blink_handle,
            'TransY',
            size * -1.0,
            size
        )
        utl.set_attr_limit(
            blink_handle,
            'TransX',
            size * -1.0,
            0.0
        )
        utl.set_attr_limit(
            blink_handle,
            'TransZ',
            0.0,
            0.0
        )


        up_lid_blink_driver_plug = this.create_plug(
            'up_lid_blink_driver',
            k=True,
            at='double'
        )

        down_lid_blink_driver_plug = this.create_plug(
            'down_lid_blink_driver',
            k=True,
            at='double'
        )

        up_horizontal_driver = this.create_plug(
            'up_horizontal_driver',
            k=True,
            at='double',
            min=-1.0,
            max=1.0
        )

        down_horizontal_driver = this.create_plug(
            'down_horizontal_driver',
            k=True,
            at='double',
            min=-1.0,
            max=1.0
        )
        #
        # up_locator = position_transform.create_child(
        #     Transform,
        #     root_name='%s_up_locator' % root_name
        # )
        # up_locator_shape = up_locator.create_child(Locator)
        # up_locator_shape.plugs.set_values(
        #     localScale=[size*0.5, size*0.5, size*0.5]
        # )
        # down_locator = position_transform.create_child(
        #     Transform,
        #     root_name='%s_down_locator' % root_name
        # )
        # down_locator_shape = down_locator.create_child(Locator)
        # down_locator_shape.plugs.set_values(
        #     localScale=[size*0.5, size*0.5, size*0.5]
        # )
        # up_lid_blink_driver_plug.connect_to(up_locator.plugs['ty'])
        # down_lid_blink_driver_plug.connect_to(down_locator.plugs['ty'])
        #
        # up_locator.plugs.set_values(
        #     overrideDisplayType=1,
        #     overrideEnabled=True
        # )
        #
        # down_locator.plugs.set_values(
        #     overrideDisplayType=1,
        #     overrideEnabled=True
        # )

        blink_remap_x = blink_handle.plugs['tx'].remap(
            (0.0, 0.0),
            (size*-1, 1.0)
        )
        blink_remap_reverse_x = blink_handle.plugs['tx'].remap(
            (0.0, 1.0),
            (size*-1, 0.0)
        )

        blink_remap_y = blink_handle.plugs['ty'].remap(
            (size * -2.0, -2.0),
            (0.0, 0.0),
            (size*2.0, 2.0)
        )
        up_lid_remap_x = up_handle.plugs['tx'].remap(
            (size * -2.0, -2.0),
            (0.0, 0.0),
            (size*2.0, 2.0)
        )
        up_lid_remap_y = up_handle.plugs['ty'].remap(
            (size * -2.0, -2.0),
            (0.0, 0.0),
            (size*2.0, 2.0)
        )
        down_lid_remap_x = down_handle.plugs['tx'].remap(
            (size * -2.0, -2.0),
            (0.0, 0.0),
            (size*2.0, 2.0)
        )
        down_lid_remap_y = down_handle.plugs['ty'].remap(
            (size * -2.0, -2.0),
            (0.0, 0.0),
            (size*2.0, 2.0)
        )

        lid_up_wide_remap_x = blink_handle.plugs['tx'].remap(
            (size*-1, 0.0),
            ((size*-1.25), 0.25)
        )
        lid_up_wide_remap_y = blink_handle.plugs['ty'].remap(
            (size*-1, 0.0),
            (0.0, 1.0)
        )

        up_wide_plug = lid_up_wide_remap_x.multiply(lid_up_wide_remap_y)

        lid_down_wide_remap_x = blink_handle.plugs['tx'].remap(
            (size*-1, 0.0),
            ((size*-1.25), -0.25)
        )
        lid_down_wide_remap_y = blink_handle.plugs['ty'].remap(
            (size, 0.0),
            (0.0, 1.0)
        )

        down_wide_plug = lid_down_wide_remap_x.multiply(lid_down_wide_remap_y)

        lid_line_multiply = blink_remap_y.multiply(blink_remap_reverse_x)
        lid_line_multiply\
            .add(blink_remap_x)\
            .add(up_lid_remap_y.multiply(blink_remap_x))\
            .add(up_wide_plug) \
            .clamp(-1.25, 1.25) \
            .blend_weighted() \
            .connect_to(up_lid_blink_driver_plug)

        lid_line_multiply\
            .add(blink_remap_x.multiply(-1.0))\
            .add(down_lid_remap_y.multiply(blink_remap_x))\
            .add(down_wide_plug) \
            .clamp(-1.25, 1.25) \
            .blend_weighted()\
            .connect_to(down_lid_blink_driver_plug)

        up_lid_remap_x.blend_weighted().connect_to(up_horizontal_driver)
        down_lid_remap_x.blend_weighted().connect_to(down_horizontal_driver)

        joint = this.create_child(
            Joint,
            parent=this.joint_group,
            segment_name='A'
        )

        root = this.get_root()
        root.add_plugs(
            blink_handle.plugs['tx'],
            blink_handle.plugs['ty'],
            blink_handle.plugs['rz'],
            up_handle.plugs['tx'],
            up_handle.plugs['ty'],
            up_handle.plugs['rz'],
            down_handle.plugs['tx'],
            down_handle.plugs['ty'],
            down_handle.plugs['rz'],
        )

        #  Properties

        this.joints.append(joint)
        this.up_handle = up_handle
        this.down_handle = down_handle
        this.blink_handle = blink_handle

        return this

    def finalize(self):
        super(ClosedEyeSlider, self).finalize()
        self.blink_handle.plugs['tx'].set_value(self.size*-1)
