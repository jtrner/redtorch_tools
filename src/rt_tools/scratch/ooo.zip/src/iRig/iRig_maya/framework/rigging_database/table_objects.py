import uuid
import json
import datetime
import sqlalchemy
from sqlalchemy import Column, ForeignKey, Integer, String, Boolean, Text, DateTime, Sequence
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.types import TypeDecorator
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.postgresql import JSON, JSONB


Base = declarative_base()

class JosnDataType(TypeDecorator):

    impl = Text(256)

    def process_bind_param(self, value, dialect):
        if value is not None:
            value = json.dumps(value)

        return value


def initialize_object(self, *args, **kwargs):
    if not kwargs and args and isinstance(args[0], dict):
        kwargs = args[0]
    for key in kwargs:
        if hasattr(self, key):
            setattr(self, key, kwargs[key])
        else:
            raise Exception('The Table "%s" does not habe the key "%s"' % (self, key))


class ProjectRoot(object):
    projects = []


class User(Base):

    __tablename__ = 'user'
    name = Column(String(100), primary_key=True, nullable=False)

    def __init__(self, *args, **kwargs):
        super(User, self).__init__()
        initialize_object(self, *args, **kwargs)


class Project(Base):

    __tablename__ = 'project'
    # project_root = None  # this is needed for the tree model
    # id = Column(Integer, primary_key=True)
    name = Column(String(100), primary_key=True, nullable=False)
    # use_oldest_part_versions = Column(Boolean(), default=False)
    # sg_code = Column(String(100), nullable=True)
    data = Column(JSON)
    # created = Column(DateTime, default=datetime.datetime.now)
    # entities = sqlalchemy.orm.relationship(
    #     'Entity',
    #     backref=sqlalchemy.orm.backref(
    #         "project",
    #         remote_side='Project.id'
    #     )
    # )

    def __init__(self, *args, **kwargs):
        super(Project, self).__init__()
        initialize_object(self, *args, **kwargs)

    # def __repr__(self):
    #     return "Project(id=%s, name=%s)" % (
    #                 self.id,
    #                 self.name
    #             )
#
#
# class Entity(Base):
#
#     __tablename__ = 'entity'
#
#     id = Column(Integer, primary_key=True)
#     code = Column(String(100), nullable=False)
#     sg_asset_type = Column(String(100), nullable=True)
#     created = Column(DateTime, default=datetime.datetime.now())
#     project_id = Column(
#         Integer,
#         ForeignKey('project.id')
#     )
#
#     def __init__(self, *args, **kwargs):
#         super(Entity, self).__init__()
#         initialize_object(self, *args, **kwargs)
#
#     def __repr__(self):
#         return "Entity(id=%s, name=%s)" % (
#                     self.id,
#                     self.code
#                 )
