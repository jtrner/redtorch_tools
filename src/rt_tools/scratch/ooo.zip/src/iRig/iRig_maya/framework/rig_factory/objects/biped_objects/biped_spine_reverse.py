import copy
import rig_factory
from rig_factory.objects.base_objects.properties import ObjectProperty, ObjectListProperty, DataProperty
from rig_factory.objects.biped_objects.biped_spine_fk import BipedSpineFk
from rig_factory.objects.biped_objects.biped_spine_ik import BipedSpineIk
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.part_objects.spline_chain_guide import SplineChainGuide
from rig_factory.objects.rig_objects.curve_handle import CurveHandle
from rig_factory.objects.rig_objects.grouped_handle import CogHandle, GroupedHandle
from rig_factory.objects.rig_objects.grouped_handle import LocalHandle, WorldHandle

from rig_factory.objects.node_objects.dag_node import DagNode
from rig_math.matrix import Matrix
import rig_factory.environment as env
import rig_factory.utilities.node_utilities.ik_handle_utilities as iks
import rig_factory.positions as pos


class BipedReverseSpineGuide(SplineChainGuide):
    default_settings = dict(
        root_name='Spine',
        size=15.0,
        side='center',
        joint_count=9,
        count=5,
        squash=0.0,
        reverse=True,
        rename_cog=True
    )

    squash = DataProperty(
        name='squash',
    )

    reverse = DataProperty(
        name='reverse',
        default_value=True,
    )

    cog_handle = ObjectProperty(
        name='cog_handle',
    )
    rename_cog = DataProperty(
        name='rename_cog',
        default_value=True,
    )

    def __init__(self, **kwargs):
        super(BipedReverseSpineGuide, self).__init__(**kwargs)
        self.toggle_class = BipedReverseSpine.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs.setdefault('root_name', 'Spine')
        segment_names = []
        count = kwargs.get('count', cls.default_settings['count'])
        for i in range(count):
            if i == 0:
                segment_names.append('Hip')
            elif i == count - 2:
                segment_names.append('Chest')
            elif i == count - 1:
                segment_names.append('ChestEnd')
            else:
                segment_names.append(rig_factory.index_dictionary[i - 1].title())
        kwargs['segment_names'] = segment_names
        this = super(BipedReverseSpineGuide, cls).create(controller, **kwargs)
        root = this.get_root()
        size_plug = this.plugs['size']
        side = kwargs.get('side', 'center')
        shader = root.shaders[side].shading_group

        hip_joint = this.create_child(
            Joint,
            segment_name='SplineHip',
            matrix=this.joints[0].get_matrix()
        )
        hip_joint.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
        )
        this.controller.create_point_constraint(
            this.joints[0],
            hip_joint,
            mo=False
        )

        position = this.spline_joints[1].get_matrix().get_translation()
        cog_handle = this.create_handle(
            segment_name='Cog',
            matrix=position,
        )
        size_plug.connect_to(cog_handle.plugs['size'])
        cog_handle.mesh.assign_shading_group(shader)
        this.cog_handle = cog_handle

        this.spline_joints[0].set_parent(hip_joint)
        this.spline_joints.insert(0, hip_joint)
        this.set_handle_positions(pos.BIPED_POSITIONS)

        return this

    def get_toggle_blueprint(self):
        blueprint = super(BipedReverseSpineGuide, self).get_toggle_blueprint()
        blueprint['cog_matrix'] = list(self.cog_handle.get_matrix())
        return blueprint


class BipedReverseSpine(Part):
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )

    cog_handle = ObjectProperty(
        name='cog_handle'
    )

    settings_handle = ObjectProperty(
        name='settings_handle'
    )
    upper_ik_match_joint = ObjectProperty(
        name='upper_ik_match_joint'
    )
    lower_ik_match_joint = ObjectProperty(
        name='lower_ik_match_joint'
    )
    upper_fk_match_joint = ObjectProperty(
        name='upper_fk_match_joint'
    )
    hip_fk_match_joint = ObjectProperty(
        name='hip_fk_match_joint'
    )
    fk_match_transforms = ObjectListProperty(
        name='fk_match_transforms'
    )
    squash = DataProperty(
        name='squash',
        default_value=1.0,
    )

    reverse = DataProperty(
        name='reverse',
        default_value=False,
    )
    rename_cog = DataProperty(
        name='rename_cog',
        default_value=True,
    )
    lower_torso_handle = ObjectProperty(
        name='lower_torso_handle'
    )
    upper_torso_handle = ObjectProperty(
        name='upper_torso_handle'
    )
    center_handles = ObjectListProperty(
        name='center_handles'
    )
    hip_handle = ObjectProperty(
        name='hip_handle'
    )
    joint_matrices = []

    def __init__(self, **kwargs):
        super(BipedReverseSpine, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(BipedReverseSpine, cls).create(controller, **kwargs)
        size = this.size
        matrices = this.matrices
        cog_matrix = Matrix(kwargs.get('cog_matrix', matrices[1]))
        if not matrices:
            raise Exception('you must provide matrices to create a spine %s' % matrices)
        cog_handle = this.create_handle(
            handle_type=CogHandle,
            segment_name='Cog',
            shape='cog_arrows',
            line_width=3,
            matrix=cog_matrix.get_translation(),
            size=size * 3.0,
            rotation_order='xzy'
        )

        # Fk Spine
        this.differentiation_name = 'Fk'

        fk_group = this.create_child(
            Transform,
            segment_name='SubPart',
            matrix=Matrix()
        )
        controller.create_parent_constraint(
            cog_handle.gimbal_handle,
            fk_group,
            mo=True
        )

        this.top_group = fk_group
        BipedSpineFk.build_rig(this)
        fk_joints = list(this.joints)
        fk_handles = list(this.handles)
        this.handles = []
        this.top_group = this

        # Ik Spine
        this.differentiation_name = 'Ik'
        ik_group = this.create_child(
            Transform,
            segment_name='SubPart',
            matrix=Matrix()
        )
        controller.create_parent_constraint(
            cog_handle.gimbal_handle,
            ik_group,
            mo=True
        )

        this.top_group = ik_group
        BipedSpineIk.build_rig(this)
        ik_joints = list(this.joints)
        ik_handles = list(this.handles)

        this.handles = fk_handles
        this.handles.extend(ik_handles)  # reorder handles
        this.differentiation_name = None
        this.top_group = this

        joints = []
        joint_parent = this.joint_group
        for i in range(len(matrices)):
            if i == 0:
                segment_name = 'Hip'
            elif i == len(matrices) - 2:
                segment_name = 'Chest'
            elif i == len(matrices) - 1:
                segment_name = 'ChestEnd'
            else:
                segment_name = rig_factory.index_dictionary[i - 1].title()
            joint = this.create_child(
                Joint,
                parent=joint_parent,
                matrix=matrices[i],
                segment_name=segment_name
            )
            joint_parent = joint
            joint.zero_rotation()
            joints.append(joint)

        settings_handle = this.create_handle(
            handle_type=GroupedHandle,
            segment_name='Settings',
            shape='gear_simple',
            size=size * 0.5,
            group_count=1,
            parent=cog_handle.gimbal_handle
        )
        settings_handle.groups[0].plugs.set_values(
            rz=-90,
            tz=-1.5 * size
        )
        settings_handle.plugs.set_values(
            overrideEnabled=True,
            overrideRGBColors=True,
            overrideColorRGB=env.colors['highlight']
        )
        ik_plug = settings_handle.create_plug(
            'ikSwitch',
            at='double',
            k=True,
            dv=0.0,
            min=0.0,
            max=1.0
        )
        for i, joint in enumerate(joints):
            index_character = rig_factory.index_dictionary[i].title(),
            pair_blend = this.create_child(
                DependNode,
                node_type='pairBlend',
                segment_name='%sBlend' % index_character,
                index=i
            )
            joint.plugs['overrideEnabled'].set_value(True)
            joint.plugs['overrideDisplayType'].set_value(2)
            ik_joints[i].plugs['translate'].connect_to(pair_blend.plugs['inTranslate2'])
            ik_joints[i].plugs['rotate'].connect_to(pair_blend.plugs['inRotate2'])
            fk_joints[i].plugs['translate'].connect_to(pair_blend.plugs['inTranslate1'])
            fk_joints[i].plugs['rotate'].connect_to(pair_blend.plugs['inRotate1'])
            pair_blend.plugs['outTranslate'].connect_to(joint.plugs['translate'])
            pair_blend.plugs['outRotate'].connect_to(joint.plugs['rotate'])
            pair_blend.plugs['rotInterpolation'].set_value(1)
            ik_plug.connect_to(pair_blend.plugs['weight'])
            joint.plugs['rotateOrder'].connect_to(fk_joints[i].plugs['rotateOrder'])
            joint.plugs['rotateOrder'].connect_to(ik_joints[i].plugs['rotateOrder'])

        fk_match_transforms = []
        for i, fk_handle in enumerate(fk_handles):
            index_character = rig_factory.index_dictionary[i].title(),
            fk_match_transform = ik_joints[i].create_child(
                Transform,
                parent=ik_joints[i],
                matrix=fk_handle.get_matrix(),
                segment_name='%sFkMatch' % index_character
            )
            fk_match_transform.create_child(Locator)
            fk_match_transforms.append(fk_match_transform)

        ik_plug.connect_to(ik_group.plugs['visibility'])

        visibility_reverse = this.create_child(
            DependNode,
            segment_name='Visibility',
            node_type='reverse'
        )
        ik_plug.connect_to(visibility_reverse.plugs['inputX'])


        if this.reverse:
            rev_plug = settings_handle.create_plug(
                'Reverse',
                at='double',
                k=True,
                dv=0.0,
                min=0.0,
                max=1.0
            )


            # rev fk spine

            this.differentiation_name = 'FkRev'
            revFk_group = this.create_child(
                Transform,
                segment_name='SubPart',
                matrix=Matrix()
            )
            controller.create_parent_constraint(
                cog_handle.gimbal_handle,
                revFk_group,
                mo=True
            )
            this.top_group = revFk_group
            handle_parent = this
            rev_FkhandleArray = []
            revJointList = fk_joints[::-1]

            for i, fk_handle in enumerate(reversed(fk_handles[1::])):

                rev_Fkhandle = this.create_handle(
                    handle_type=LocalHandle,
                    segment_name='%s' % fk_handle.segment_name,
                    shape='star_four',
                    line_width=3,
                    matrix=fk_handle.get_matrix(),
                    size=size * 3,
                    parent=handle_parent,
                    rotation_order='xzy',
                )
                rev_Fkhandle.plugs.set_values(
                    overrideEnabled=True,
                    overrideRGBColors=True,
                    overrideColorRGB=env.secondary_colors['reverseSpine']
                )
                rev_Fkhandle.gimbal_handle.plugs.set_values(
                    overrideEnabled=True,
                    overrideRGBColors=True,
                    overrideColorRGB=env.secondary_colors['reverseSpine']
                )
                shape_matrix = Matrix()
                # repositioning handle shapes
                if fk_handle.segment_name != 'Hip':
                    shape_matrix.set_translation([0, size * 0.2, 0])
                    shape_matrix.set_scale([size * 3, size * 3, size * 3])
                    rev_Fkhandle.set_shape_matrix(shape_matrix)

                handle_parent = rev_Fkhandle.gimbal_handle
                '''
                creating parent constraint connect from reverse fk spine handle to joints from FK spine
                driving weights on parent constraint using reverse attribute
                '''
                controller.accepts_duplicate_names = True
                parConst = controller.create_parent_constraint(
                    rev_Fkhandle.gimbal_handle,
                    revJointList[i + 1],
                    mo=True)

                default_Fkreverse = this.create_child(
                    DependNode,
                    segment_name='{}_DefaultFkControl_rev'.format(rev_Fkhandle),
                    node_type='reverse'
                )

                defplugName = str(fk_handle.gimbal_handle) + 'W0'
                plugName = str(rev_Fkhandle.gimbal_handle) + 'W1'
                rev_plug.connect_to(parConst.plugs[plugName])
                rev_plug.connect_to(default_Fkreverse.plugs['inputX'])
                default_Fkreverse.plugs['outputX'].connect_to(parConst.plugs[defplugName])

                rev_FkhandleArray.append(rev_Fkhandle)

            this.differentiation_name = None
            this.top_group = this

            # # rev ik spine
            this.differentiation_name = 'IkRev'
            revIk_group = this.create_child(
                Transform,
                segment_name='SubPart',
                matrix=Matrix()
            )
            controller.create_parent_constraint(
                cog_handle.gimbal_handle,
                revIk_group,
                mo=True
            )
            this.top_group = revIk_group
            handle_parent = this
            rev_IkhandleArray = []
            revIkJointList = ik_joints[-2::-1]
            # swapping ikHandle list order as midIK control is getting created before chestIK
            ik_handles[1], ik_handles[2] = ik_handles[2], ik_handles[1]
            rev_ikHandles = ik_handles[::-1]

            for i, ik_handle in enumerate(rev_ikHandles):

                if ik_handle == rev_ikHandles[0] or ik_handle == rev_ikHandles[-1]:
                    if ik_handle == rev_ikHandles[-1]:
                        handle_parent = rev_IkhandleArray[0].gimbal_handle
                    rev_Ikhandle = this.create_handle(
                        handle_type=LocalHandle,
                        segment_name='%s' % ik_handle.segment_name,
                        shape='star_four',
                        line_width=3,
                        matrix=ik_handle.get_matrix(),
                        size=size * 3,
                        parent=handle_parent,
                        rotation_order='xzy',
                    )
                else:
                    rev_Ikhandle = this.create_handle(
                        handle_type=LocalHandle,
                        segment_name='%s' % ik_handle.segment_name,
                        shape='circle',
                        line_width=3,
                        matrix=ik_handle.get_matrix(),
                        size=size,
                        parent=handle_parent,
                        rotation_order='xzy',
                    )
                rev_Ikhandle.plugs.set_values(
                    overrideEnabled=True,
                    overrideRGBColors=True,
                    overrideColorRGB=env.secondary_colors['reverseSpine']
                )
                rev_Ikhandle.gimbal_handle.plugs.set_values(
                    overrideEnabled=True,
                    overrideRGBColors=True,
                    overrideColorRGB=env.secondary_colors['reverseSpine']
                )

                rev_IkhandleArray.append(rev_Ikhandle)

            center_revIkHandles = rev_IkhandleArray[1:-1]
            center_revIkJoints = revIkJointList[1:-1]
            center_IkHandles = ik_handles[1:-1]
            lower_torso_revhandle, upper_torso_revhandle = rev_IkhandleArray[-1], rev_IkhandleArray[0]

            controller.accepts_duplicate_names = True
            for revIkJoint, rev_handle, ik_handle in zip([revIkJointList[0], revIkJointList[-1]],
                                                         [upper_torso_revhandle, lower_torso_revhandle],
                                                         [ik_handles[-1], ik_handles[0]]):
                parConst = controller.create_parent_constraint(
                    rev_handle.gimbal_handle,
                    revIkJoint,
                    mo=True)
                default_Ikreverse = this.create_child(
                    DependNode,
                    segment_name='{}_DefaultIkControl_rev'.format(rev_handle),
                    node_type='reverse'
                )

                defplugName = str(ik_handle.gimbal_handle) + 'W0'
                plugName = str(rev_handle.gimbal_handle) + 'W1'
                rev_plug.connect_to(parConst.plugs[plugName])

                rev_plug.connect_to(default_Ikreverse.plugs['inputX'])
                default_Ikreverse.plugs['outputX'].connect_to(parConst.plugs[defplugName])

            ikRev_lower_aim_transform = this.create_child(
                Transform,
                segment_name='LowerAimRev'
            )
            controller.create_point_constraint(
                lower_torso_revhandle.gimbal_handle,
                ikRev_lower_aim_transform,
                mo=True
            )
            controller.create_aim_constraint(
                upper_torso_revhandle.gimbal_handle,
                ikRev_lower_aim_transform,
                aimVector=env.aim_vector,
                upVector=env.up_vector,
                worldUpObject=lower_torso_revhandle.gimbal_handle,
                worldUpType='objectrotation',
                worldUpVector=[0.0, 0.0, -1.0]
            )
            sub_handle_count = len(center_revIkHandles)

            for i, center_handle in enumerate(center_revIkHandles):
                matrix = center_handle.get_matrix()
                ikRev_lower_aim_transform.plugs['rotate'].connect_to(center_handle.groups[0].plugs['rotate'])
                constraint = controller.create_point_constraint(
                    lower_torso_revhandle.gimbal_handle,
                    upper_torso_revhandle.gimbal_handle,
                    center_handle.groups[0],
                    mo=True
                )
                value = 1.0 / (sub_handle_count + 1) * (i + 1)
                constraint.plugs['%sW0' % lower_torso_revhandle.gimbal_handle.name].set_value(1.0 - value)
                constraint.plugs['%sW1' % upper_torso_revhandle.gimbal_handle.name].set_value(value)
                center_handle.groups[1].set_matrix(matrix)

                parConst = controller.create_parent_constraint(
                    center_handle.gimbal_handle,
                    center_revIkJoints[i],
                    mo=True
                )

                defCenterplugName = str(center_IkHandles[i].gimbal_handle) + 'W0'
                centerPlugName = str(center_handle.gimbal_handle) + 'W1'
                rev_plug.connect_to(parConst.plugs[centerPlugName])

                default_Ikreverse.plugs['outputX'].connect_to(parConst.plugs[defCenterplugName])

                # controller.accepts_duplicate_names = True
                aimConst = controller.create_aim_constraint(
                    center_handle,
                    center_revIkJoints[i - 1],
                    mo=True,
                    aimVector=env.aim_vector,
                    upVector=env.up_vector,
                    worldUpObject=revIkJointList[-1],
                    worldUpType='objectrotation',
                    worldUpVector=[0.0, 0.0, -1.0]
                )

                defAimplugName = str(center_IkHandles[i]) + 'W0'
                aimPlugName = str(center_handle) + 'W1'

                rev_plug.connect_to(aimConst.plugs[aimPlugName])

                default_Ikreverse.plugs['outputX'].connect_to(aimConst.plugs[defAimplugName])

            this.differentiation_name = None
            this.top_group = this

            # create utility nodes for reverse spine visibility connections

            visibility_Fkreverse = this.create_child(
                DependNode,
                segment_name='FkRevVisibility',
                node_type='reverse'
            )

            visibility_FkSpineMD = this.create_child(
                DependNode,
                segment_name='FkSpineVisibility',
                node_type='multiplyDivide'
            )

            visibility_FkRevMD = this.create_child(
                DependNode,
                segment_name='FkRevVisibility',
                node_type='multiplyDivide'
            )

            visibility_IkRevMD = this.create_child(
                DependNode,
                segment_name='IkRevVisibility',
                node_type='multiplyDivide'
            )

            visibility_IkControlMD = this.create_child(
                DependNode,
                segment_name='IkControlVisibility',
                node_type='multiplyDivide'
            )
            # changing vis connection for fk_group if reverse build is present
            rev_plug.connect_to(visibility_Fkreverse.plugs['inputX'])
            visibility_Fkreverse.plugs['outputX'].connect_to(visibility_FkSpineMD.plugs['input1X'])
            visibility_reverse.plugs['outputX'].connect_to(visibility_FkSpineMD.plugs['input2X'])
            visibility_FkSpineMD.plugs['outputX'].connect_to(fk_group.plugs['visibility'])

            # making connection network for Fk reverse spine group visibility
            rev_plug.connect_to(visibility_FkRevMD.plugs['input1X'])
            visibility_reverse.plugs['outputX'].connect_to(visibility_FkRevMD.plugs['input2X'])
            visibility_FkRevMD.plugs['outputX'].connect_to(revFk_group.plugs['visibility'])

            # making connection network for Ik reverse spine group visibility
            rev_plug.connect_to(visibility_IkRevMD.plugs['input1X'])
            ik_plug.connect_to(visibility_IkRevMD.plugs['input2X'])
            visibility_IkRevMD.plugs['outputX'].connect_to(revIk_group.plugs['visibility'])

            ik_plug.connect_to(visibility_IkControlMD.plugs['input1X'])
            visibility_Fkreverse.plugs['outputX'].connect_to(visibility_IkControlMD.plugs['input2X'])
            for i, ik_handle in enumerate(ik_handles):
                visibility_IkControlMD.plugs['input2X'].connect_to(ik_handle.groups[0].plugs['visibility'])

        else:
            # Temporary solution to fix ikSwitch from connecting to spine top group
            visibility_reverse.plugs['outputX'].connect_to(fk_group.plugs['visibility'])

        this.lower_ik_match_joint = fk_joints[0].create_child(
            Transform,
            segment_name='LowerIkMatch',
            matrix=this.lower_torso_handle.get_matrix()
        )
        this.upper_ik_match_joint = fk_joints[-2].create_child(
            Transform,
            segment_name='UpperIkMatch',
            matrix=this.upper_torso_handle.get_matrix()
        )
        this.hip_fk_match_joint = ik_joints[0].create_child(
            Transform,
            segment_name='HipFkMatch',
            matrix=this.hip_handle.get_matrix()
        )
        joints[0].plugs['type'].set_value(2)
        for joint in joints[1:]:
            joint.plugs['type'].set_value(6)
        root = this.get_root()
        for handle in (rev_FkhandleArray + rev_IkhandleArray):
            root.add_plugs(
                [
                    handle.plugs['tx'],
                    handle.plugs['ty'],
                    handle.plugs['tz'],
                    handle.plugs['rx'],
                    handle.plugs['ry'],
                    handle.plugs['rz'],
                    handle.plugs['rotateOrder']
                ]
            )
        root.add_plugs(
            [
                cog_handle.plugs['tx'],
                cog_handle.plugs['ty'],
                cog_handle.plugs['tz'],
                cog_handle.plugs['rx'],
                cog_handle.plugs['ry'],
                cog_handle.plugs['rz'],
                cog_handle.plugs['rotateOrder'],
                ik_plug,
                rev_plug
            ]
        )

        squash = this.squash

        settings_handle.create_plug(
            'squash',
            attributeType='float',
            keyable=True,
            defaultValue=squash,
        )
        settings_handle.create_plug(
            'squashMin',
            attributeType='float',
            keyable=True,
            defaultValue=0.1,
        )
        settings_handle.create_plug(
            'squashMax',
            attributeType='float',
            keyable=True,
            defaultValue=5,
        )
        root.add_plugs(
            [
                settings_handle.plugs['squash'],
                settings_handle.plugs['squashMin'],
                settings_handle.plugs['squashMax'],
            ],
        )

        # this.secondary_handles.extend(ik_spine.secondary_handles)
        # this.secondary_handles.extend(fk_spine.secondary_handles)

        this.joints = joints
        this.settings_handle = settings_handle
        # handles = [settings_handle, cog_handle]
        # handles.extend(ik_spine.handles)
        # handles.extend(fk_spine.handles)
        this.cog_handle = cog_handle
        # this.set_handles(handles)
        #
        # """
        # Temporary renaming until lighting pipe gets updated
        # """
        # if this.rename_cog:
        #     for i in range(len(cog_handle.curves)):
        #         if i > 0:
        #             shape_name = '%sShape%s' % (cog_handle, i)
        #         else:
        #             shape_name = '%sShape' % cog_handle
        #         controller.set_name(
        #             cog_handle.curves[i],
        #             shape_name
        #         )
        #     for i in range(len(cog_handle.base_curves)):
        #         if i > 0:
        #             shape_name = '%sBaseShape%s' % (cog_handle, i)
        #         else:
        #             shape_name = '%sBaseShape' % cog_handle
        #         controller.set_name(
        #             cog_handle.base_curves[i],
        #             shape_name
        #         )
        #     for i in range(len(cog_handle.gimbal_handle.curves)):
        #         if i > 0:
        #             shape_name = '%sShape%s' % (cog_handle.gimbal_handle, i)
        #         else:
        #             shape_name = '%sShape' % cog_handle.gimbal_handle
        #         controller.set_name(
        #             cog_handle.gimbal_handle.curves[i],
        #             shape_name
        #         )
        #     for i in range(len(cog_handle.gimbal_handle.base_curves)):
        #         if i > 0:
        #             shape_name = '%sBaseShape%s' % (cog_handle.gimbal_handle, i)
        #         else:
        #             shape_name = '%sBaseShape' % cog_handle.gimbal_handle
        #         controller.set_name(
        #             cog_handle.gimbal_handle.base_curves[i],
        #             shape_name
        #         )
        #
        #     controller.set_name(
        #         cog_handle,
        #         'COG_Ctrl'
        #     )
        #     controller.set_name(
        #         cog_handle.gimbal_handle,
        #         'COG_gimbal_Ctrl'
        #     )
        this.fk_match_transforms = fk_match_transforms
        return this

    def create_deformation_rig(self, **kwargs):
        super(BipedReverseSpine, self).create_deformation_rig(**kwargs)

        joint_matrices = self.joint_matrices
        root_name = self.root_name
        deform_joints = self.deform_joints
        root = self.get_root()
        controller = self.controller
        curve_degree = 3
        curve_locators = []
        spline_joints = []
        settings_handle = self.settings_handle

        for deform_joint in deform_joints:
            blend_locator = deform_joint.create_child(
                Locator
            )
            blend_locator.plugs['v'].set_value(0)
            curve_locators.append(blend_locator)

        for deform_joint in deform_joints[1:-1]:
            deform_joint.plugs['drawStyle'].set_value(2)

        positions = [[0.0, 0.0, 0.0]] * len(curve_locators)

        segment_name = '%sSpline' % self.segment_name

        nurbs_curve_transform = self.create_child(
            Transform,
            segment_name=segment_name
        )
        nurbs_curve = nurbs_curve_transform.create_child(
            NurbsCurve,
            degree=curve_degree,
            positions=positions
        )
        curve_info = nurbs_curve_transform.create_child(
            DependNode,
            node_type='curveInfo'
        )

        scale_divide = nurbs_curve_transform.create_child(
            DependNode,
            node_type='multiplyDivide'
        )
        scale_divide.plugs['operation'].set_value(2)
        curve_info.plugs['arcLength'].connect_to(scale_divide.plugs['input1X'])
        curve_info.plugs['arcLength'].connect_to(scale_divide.plugs['input1Y'])
        curve_info.plugs['arcLength'].connect_to(scale_divide.plugs['input1Z'])
        self.scale_multiply_transform.plugs['scale'].connect_to(scale_divide.plugs['input2'])
        length_divide = self.create_child(
            DependNode,
            segment_name='%sLengthDivide' % segment_name,
            node_type='multiplyDivide'
        )
        scale_divide.plugs['output'].connect_to(length_divide.plugs['input1'])
        nurbs_curve_transform.plugs['visibility'].set_value(False)
        nurbs_curve_transform.plugs['inheritsTransform'].set_value(False)
        nurbs_curve.plugs['worldSpace'].element(0).connect_to(curve_info.plugs['inputCurve'])
        length_divide.plugs['operation'].set_value(2)
        length_divide.plugs['input2Y'].set_value(len(joint_matrices) - 1)
        for i, blend_locator in enumerate(curve_locators):
            blend_locator.plugs['worldPosition'].element(0).connect_to(
                nurbs_curve.plugs['controlPoints'].element(i)
            )
        spline_joint_parent = deform_joints[0]
        rebuild_curve = nurbs_curve.create_child(
            DependNode,
            node_type='rebuildCurve'
        )
        rebuild_curve.plugs.set_values(
            keepRange=0,
            keepControlPoints=1,
        )
        nurbs_curve.plugs['worldSpace'].element(0).connect_to(
            rebuild_curve.plugs['inputCurve'],
        )
        nurbs_curve.plugs['degree'].connect_to(
            rebuild_curve.plugs['degree'],
        )
        arc_length_dimension_parameter = 1.0 / (len(joint_matrices) - 1)
        previous_spline_joint = None
        previous_arc_length_dimension = None
        for i, matrix in enumerate(joint_matrices):
            spline_segment_name = 'Secondary%s' % rig_factory.index_dictionary[i].title()
            spline_joint = spline_joint_parent.create_child(
                Joint,
                segment_name=spline_segment_name,
                functionality_name='Bind',
                index=i,
                matrix=matrix
            )
            if previous_spline_joint:
                previous_spline_joint.plugs['scale'].connect_to(
                    spline_joint.plugs['inverseScale'],
                )
            spline_joint.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.colors['bindJoints'],
                overrideDisplayType=0
            )
            root.add_plugs(
                [
                    spline_joint.plugs['rx'],
                    spline_joint.plugs['ry'],
                    spline_joint.plugs['rz']
                ],
                keyable=False
            )
            spline_joint.zero_rotation()
            spline_joints.append(spline_joint)
            spline_joint_parent = spline_joint

            if i > 0:
                length_divide.plugs['outputY'].connect_to(
                    spline_joint.plugs['t{0}'.format(env.aim_vector_axis)],
                )

            if i not in {0, len(joint_matrices) - 1}:
                arc_length_segment_name = (
                        'Secondary%s' % rig_factory.index_dictionary[i].title()
                )
                arc_length_dimension = spline_joint.create_child(
                    DagNode,
                    segment_name=arc_length_segment_name,
                    node_type='arcLengthDimension',
                    parent=self.utility_group
                )
                arc_length_dimension.plugs.set_values(
                    uParamValue=arc_length_dimension_parameter * i,
                    visibility=False,
                )
                rebuild_curve.plugs['outputCurve'].connect_to(
                    arc_length_dimension.plugs['nurbsGeometry'],
                )
                plus_minus_average = spline_joint.create_child(
                    DependNode,
                    node_type='plusMinusAverage',
                )
                plus_minus_average.plugs['operation'].set_value(2)
                arc_length_dimension.plugs['arcLength'].connect_to(
                    plus_minus_average.plugs['input1D'].element(0),
                )
                if previous_arc_length_dimension:
                    previous_arc_length_dimension.plugs['arcLength'].connect_to(
                        plus_minus_average.plugs['input1D'].element(1),
                    )
                multiply_divide = spline_joint.create_child(
                    DependNode,
                    node_type='multiplyDivide',
                )
                multiply_divide.plugs['operation'].set_value(2)
                multiply_divide.plugs['input1X'].set_value(
                    plus_minus_average.plugs['output1D'].get_value(),
                )
                plus_minus_average.plugs['output1D'].connect_to(
                    multiply_divide.plugs['input2X'],
                )

                inverse_scale = spline_joint.create_child(
                    DependNode,
                    node_type='multiplyDivide',
                    segment_name='%sInverse' % spline_segment_name,
                )
                inverse_scale.plugs['operation'].set_value(1)
                multiply_divide.plugs['outputX'].connect_to(
                    inverse_scale.plugs['input1X'],
                )
                self.scale_multiply_transform.plugs['scaleX'].connect_to(
                    inverse_scale.plugs['input2X'],
                )

                blend_colors = spline_joint.create_child(
                    DependNode,
                    node_type='blendColors',
                )
                blend_colors.plugs['color2R'].set_value(1)
                inverse_scale.plugs['outputX'].connect_to(
                    blend_colors.plugs['color1R'],
                )
                settings_handle.plugs['squash'].connect_to(
                    blend_colors.plugs['blender'],
                )

                clamp = spline_joint.create_child(
                    DependNode,
                    node_type='clamp',
                )
                blend_colors.plugs['outputR'].connect_to(
                    clamp.plugs['inputR'],
                )
                settings_handle.plugs['squashMin'].connect_to(
                    clamp.plugs['minR'],
                )
                settings_handle.plugs['squashMax'].connect_to(
                    clamp.plugs['maxR'],
                )
                clamp.plugs['outputR'].connect_to(
                    spline_joint.plugs['scaleX'],
                )
                clamp.plugs['outputR'].connect_to(
                    spline_joint.plugs['scaleZ'],
                )

                previous_arc_length_dimension = arc_length_dimension

            previous_spline_joint = spline_joint

        spline_ik_handle = iks.create_spline_ik(
            spline_joints[0],
            spline_joints[-1],
            nurbs_curve,
            world_up_object=deform_joints[0],
            world_up_object_2=deform_joints[-1],
            up_vector=[0.0, 0.0, -1.0],
            up_vector_2=[0.0, 0.0, -1.0],
            world_up_type=4,
        )
        spline_ik_handle.plugs['visibility'].set_value(False)
        self.spline_joints = spline_joints
        self.deform_joints.extend(spline_joints)

    def get_blueprint(self):
        blueprint = super(BipedReverseSpine, self).get_blueprint()
        blueprint['joint_matrices'] = [list(x) for x in self.joint_matrices]
        blueprint['squash'] = self.settings_handle.plugs['squash'].get_value()
        blueprint['cog_matrix'] = list(self.cog_handle.get_matrix())
        return blueprint

    def toggle_ik(self):
        value = self.settings_handle.plugs['ik_switch'].get_value()
        if value > 0.5:
            self.match_to_fk()
        else:
            self.match_to_ik()

    def match_to_fk(self):
        self.settings_handle.plugs['ik_switch'].set_value(0.0)
        positions = [x.get_matrix() for x in self.fk_match_transforms]
        self.fk_spine.hip_handle.set_matrix(self.hip_fk_match_joint.get_matrix())
        fk_handles = self.fk_spine.handles[1:]
        for i, fk_handle in enumerate(fk_handles):
            fk_handle.set_matrix(positions[i + 1])

    def match_to_ik(self):
        self.settings_handle.plugs['ik_switch'].set_value(1.0)
        positions = [x.get_matrix() for x in self.fk_spine.joints]
        self.ik_spine.lower_torso_handle.set_matrix(self.lower_ik_match_joint.get_matrix())
        self.ik_spine.upper_torso_handle.set_matrix(self.upper_ik_match_joint.get_matrix())
        self.ik_spine.center_handles[0].set_matrix(positions[2])
