from rig_factory.objects.base_objects.properties import ObjectListProperty, ObjectProperty, DataProperty
from rig_factory.objects.node_objects.dag_node import DagNode
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_factory.objects.deformer_objects.sine import Sine
from rig_math.matrix import Matrix
from rig_factory.utilities.decorators import flatten_args

# Plugs from the deformer node
plug_names = ['amplitude', 'dropoff', 'highBound', 'lowBound', 'offset', 'wavelength']


class SinePartGuide(PartGuide):

    default_settings = dict(
        root_name='Sine'
    )

    plug_values = DataProperty(
        name='plug_values',
        default_value=dict()
    )

    deformer_matrix = DataProperty(
        name='deformer_matrix'
    )

    def __init__(self, **kwargs):
        super(SinePartGuide, self).__init__(**kwargs)
        self.toggle_class = SinePart.__name__
        self.joint_chain = False

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(SinePartGuide, cls).create(controller, **kwargs)
        handle = this.create_handle()

        # Create deformer handle under the handle that was just created
        deformer_handle = handle.create_child(
            DagNode,
            node_type='deformSine',
            suffix='Dhd'
        )

        # Check if previous matrix information exists, if so, use that to position the handle
        if this.deformer_matrix:
            handle.set_matrix(Matrix(this.deformer_matrix))
        handle.mesh.assign_shading_group(this.get_root().shaders[this.side].shading_group)

        # Create plugs on the handle, then plug into the deformer node plugs
        for attribute_name in plug_names:
            property_plug = handle.create_plug(
                attribute_name,
                at='double',
                k=True,
                dv=deformer_handle.plugs[attribute_name].get_value())
            property_plug.connect_to(deformer_handle.plugs[attribute_name])

            # Find the values from blueprint based on the attribute names and set
            if this.plug_values and attribute_name in this.plug_values:
                property_plug.set_value(this.plug_values[attribute_name])
        return this

    # Get data from rig state
    def get_toggle_blueprint(self):
        blueprint = super(SinePartGuide, self).get_toggle_blueprint()
        blueprint['plug_values'] = dict((x, self.handles[0].plugs[x].get_value()) for x in plug_names)
        blueprint['deformer_matrix'] = list(self.handles[0].get_matrix())
        return blueprint

    # Get data from blueprint
    def get_blueprint(self):
        blueprint = super(SinePartGuide, self).get_blueprint()
        blueprint['plug_values'] = dict((x, self.handles[0].plugs[x].get_value()) for x in plug_names)
        blueprint['deformer_matrix'] = list(self.handles[0].get_matrix())
        return blueprint


class SinePart(Part):

    plug_values = DataProperty(
        name='plug_values',
        default_value=dict()
    )

    sine = ObjectProperty(
        name='sine'
    )
    geometry = ObjectListProperty(
        name='geometry'
    )
    geometry_names = DataProperty(
        name='geometry_names'
    )
    deformer_matrix = DataProperty(
        name='deformer_matrix'
    )

    def __init__(self, **kwargs):
        super(SinePart, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(SinePart, cls).create(controller, **kwargs)
        named_objects = controller.named_objects

        # Check if this.geometry_names is valid, if so, create a list of geometry objects for adding to deformer
        if this.geometry_names:
            this.geometry = [named_objects[x] for x in this.geometry_names if x in named_objects]
        return this

    @flatten_args
    def add_geometry(self, *geometry):
        geometry = list(geometry)
        for x in geometry:
            if x in self.geometry:
                raise Exception('%s is already added to %s' % (x, self))
        if geometry and not self.sine:
            self.geometry = geometry
            self.create_nonlinear_deformers()
        else:
            self.sine.add_geometry(geometry)
            self.geometry.extend(geometry)

    @flatten_args
    def remove_geometry(self, *geometry):
        geometry = list(geometry)
        for x in geometry:
            if x not in self.geometry:
                raise Exception('%s does not exist in %s' % (x, self))
        if geometry and self.geometry:
            if len(geometry) >= len(self.geometry):
                self.controller.schedule_objects_for_deletion(self.sine)
                self.controller.delete_scheduled_objects()
            else:
                self.sine.remove_geometry(geometry)
            for x in geometry:
                self.geometry.remove(x)

    def create_nonlinear_deformers(self, **kwargs):
        super(SinePart, self).create_nonlinear_deformers(**kwargs)
        """
        This gets called during blueprint execution
        """
        if self.sine:
            raise Exception('ERROR: create_nonlinear_deformers() can only be called once')

        # If self.geometry is valid(Not empty), create the Sine deformer and add the geometry
        if self.geometry:
            sine = self.create_child(
                Sine,
                geometry=self.geometry
            )

            # Assign the matrix of the Sine deformer based on self.deformer_matrix
            sine.set_matrix(Matrix(self.deformer_matrix))

            # Set values for the plugs
            if self.plug_values:
                for plug_name in self.plug_values:
                    sine.deformer.plugs[plug_name].set_value(self.plug_values[plug_name])
            self.sine = sine

    # Get data from guide state
    def get_toggle_blueprint(self):
        blueprint = super(SinePart, self).get_toggle_blueprint()
        if self.sine:
            blueprint['plug_values'] = dict((x, self.sine.deformer.plugs[x].get_value()) for x in plug_names)
            blueprint['rig_data']['geometry_names'] = [x.name for x in self.geometry]
        return blueprint

    # Get data from blueprint
    def get_blueprint(self):
        blueprint = super(SinePart, self).get_blueprint()
        if self.sine:
            blueprint['plug_values'] = dict((x, self.sine.deformer.plugs[x].get_value()) for x in plug_names)
            blueprint['geometry_names'] = [x.name for x in self.geometry]
        return blueprint
