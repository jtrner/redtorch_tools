from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
from rigging_widgets.face_builder.models.plug_model import PlugModel
from rig_factory.objects.sdk_objects.sdk_network import SDKNetwork


class PlugsWidget(QFrame):

    done_signal = Signal()

    def __init__(self, *args, **kwargs):
        super(PlugsWidget, self).__init__(*args, **kwargs)
        font = QFont('', 12, True)
        font.setWeight(100)
        self.vertical_layout = QVBoxLayout(self)
        self.horizontal_layout = QHBoxLayout()
        self.button_layout = QHBoxLayout()
        self.label = QLabel('Plugs', self)
        self.done_button = QPushButton('Done', self)
        self.add_button = QPushButton('Add Selected', self)
        self.plug_view = PlugsView(self)
        self.horizontal_layout.addWidget(self.label)
        self.horizontal_layout.addStretch()
        self.horizontal_layout.addWidget(self.add_button)
        self.vertical_layout.addLayout(self.horizontal_layout)
        self.vertical_layout.addWidget(self.plug_view)
        self.vertical_layout.addLayout(self.button_layout)
        self.button_layout.addStretch()
        self.button_layout.addWidget(self.done_button)
        self.label.setFont(font)
        self.done_button.pressed.connect(self.done_signal.emit)
        self.add_button.pressed.connect(self.add_selected)

        self.controller = None

    def set_controller(self, controller):
        self.plug_view.set_controller(controller)
        self.controller = controller

    def reset(self, *args):
        model = self.plug_view.model()
        model.modelAboutToBeReset.emit()
        model.modelReset.emit()
        model.plugs = [x.name for x in self.controller.face_network.sdk_network.driven_plugs]
        model.modelReset.emit()

    def add_selected(self):
        face_network = self.controller.face_network
        if not face_network:
            self.raise_error(Exception('No Face Network Found'))
        if not face_network.sdk_network:
            face_network.sdk_network = face_network.create_child(
                SDKNetwork
            )
        selected_plugs = self.controller.get_selected_plug_strings()
        if selected_plugs:
            self.add_driven_plugs(selected_plugs)
        else:
            message_box = QMessageBox(self)
            message_box.setText('No plugs selected.')
            message_box.exec_()

    def add_driven_plugs(self, plug_names):
        face_network = self.controller.face_network
        sdk_network = face_network.sdk_network
        if not sdk_network:
            face_network.sdk_network = face_network.create_child(
                SDKNetwork
            )
        existing_plug_names = [x.name for x in face_network.sdk_network.driven_plugs]
        non_existant_plugs = []
        skipped_plugs = []
        new_driven_plugs = []
        for plug_name in plug_names:
            if plug_name in existing_plug_names:
                skipped_plugs.append(plug_name)
            else:
                node_name, attribute_name = plug_name.split('.')
                if node_name not in self.controller.named_objects:
                    self.raise_warning('The node "%s" does not exist in the controller' % node_name)
                node = self.controller.named_objects[node_name]
                if node.plugs.exists(attribute_name):
                    new_driven_plugs.append(node.plugs[attribute_name])
                else:
                    non_existant_plugs.append(plug_name)
        face_network.sdk_network.add_driven_plugs(new_driven_plugs)
        self.reset()

        for x in non_existant_plugs:
            print 'Skipping non-existant driven plug: %s' % x
        for x in skipped_plugs:
            print 'Skipping existing driven plug: %s' % x

        if new_driven_plugs:
            shortened_plug_names = [new_driven_plugs[i].name for i in range(len(new_driven_plugs)) if i < 11]
            if len(shortened_plug_names) > 10:
                shortened_plug_names.append('etc...')
            self.raise_warning('Added Plugs: \n\n%s' % '\n'.join(shortened_plug_names))
        if skipped_plugs:
            self.raise_warning('Plugs already added.\n See script editor for details')

        for x in self.controller.face_network.sdk_network.driven_plugs:
            if not x.relationships['blend_node']:
                self.raise_error(Exception('No Blend Node %s' % x))


    def show_message(self, message):
            print message
            message_box = QMessageBox(self)
            message_box.setWindowTitle('Info')
            message_box.setText(message)
            message_box.exec_()

    def raise_warning(self, message):
        QMessageBox.warning(
            self,
            'Message',
            message
        )

    def raise_error(self, exception):
        QMessageBox.critical(
            self,
            'Critical Error',
            exception.message
        )
        raise exception


class PlugsView(QListView):
    def __init__(self, *args, **kwargs):
        super(PlugsView, self).__init__(*args, **kwargs)
        self.setModel(PlugModel())
        self.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.setStyleSheet('border: 0px; background-color: rgb(68 ,68 ,68); padding: 0px 4px 0px 4px;')
        self.controller = None

    def set_controller(self, controller):
        self.model().set_controller(controller)
        self.controller = controller
