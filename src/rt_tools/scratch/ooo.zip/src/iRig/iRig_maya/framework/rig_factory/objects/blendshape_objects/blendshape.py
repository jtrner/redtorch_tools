from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.base_objects.properties import DataProperty, ObjectProperty, ObjectListProperty
from rig_factory.objects.base_objects.base_node import BaseNode
import rig_factory


class Blendshape(DependNode):

    parallel = DataProperty(
        name='parallel',
        default_value=False
    )
    base_geometry = ObjectListProperty(
        name='base_geometry'
    )
    blendshape_groups = ObjectListProperty(
        name='blendshape_groups'
    )

    suffix = 'Blnd'

    @classmethod
    def create(cls, controller, *base_geometry, **kwargs):
        if len(base_geometry) < 1:
            raise Exception('You must provide geometry as args to create a %s' % cls.__name__)
        kwargs['base_geometry'] = list(base_geometry)
        return super(Blendshape, cls).create(controller, **kwargs)

    def __init__(self, **kwargs):
        super(Blendshape, self).__init__(**kwargs)
        self.node_type = 'blendShape'

    def add_base_geometry(self, *geometry):
        self.controller.add_blendshape_base_geometry(self, *geometry)

    def create_group(self, *targets, **kwargs):
        kwargs['index'] = self.get_next_weight_index()

        kwargs.setdefault(
            'parent',
            self
        )
        blendshape_group = self.create_child(
            BlendshapeGroup,
            **kwargs
        )
        # self.start_ownership_signal.emit(
        #     blendshape_group,
        #     self
        # )
        blendshape_group.blendshape = self
        self.blendshape_groups.append(blendshape_group)
        # self.end_ownership_signal.emit(
        #     blendshape_group,
        #     self
        # )
        for i, target in enumerate(targets):
            weight = 1.0 / len(targets) * (i + 1)
            blendshape_group.create_inbetween(
                target,
                weight=weight
            )
        return blendshape_group

    def get_blueprint(self):
        blueprint = dict(
            klass=self.__class__.__name__,
            module=self.__module__,
            root_name=self.root_name,
            side=self.side,
            size=self.size,
            index=self.index,
            base_geometry=[x.get_selection_string() for x in self.base_geometry]
        )
        return blueprint

    def create_in_scene(self):
        self.m_object = self.controller.scene.create_blendshape(
            *list(self.base_geometry),
            parallel=self.parallel,
            name=self.name
        )

    def get_target_index_list(self, mesh):
        return self.controller.scene.get_blendshape_target_index_list(self.m_object, mesh.m_object)

    def get_weight_index_list(self):
        return self.controller.scene.get_blendshape_weight_index_list(self.m_object)

    def get_next_weight_index(self):
        weight_indices = [x.index for x in self.blendshape_groups]
        current_index = 0
        while True:
            if current_index not in weight_indices:
                return current_index
            current_index += 1

    def get_next_avaliable_weight_index(self):
        """
        This seems to be getting the wrong index..  in some edge cases.
        maybe depreciate
        """
        weight_indices = self.get_weight_index_list()
        current_index = 0
        while True:
            if current_index not in weight_indices:
                return current_index
            current_index += 1

    def get_next_avaliable_target_index(self):
        weight_indices = self.get_target_index_list()
        current_index = 0
        while True:
            if current_index not in weight_indices:
                return current_index
            current_index += 1

    def teardown(self):
        self.controller.schedule_objects_for_deletion(self.blendshape_groups)
        super(Blendshape, self).teardown()


class BlendshapeGroup(BaseNode):

    blendshape = ObjectProperty(
        name='blendshape'
    )
    blendshape_inbetweens = ObjectListProperty(
        name='blendshape_inbetweens'
    )
    tangent_space = DataProperty(
        name='tangent_space',
        default_value=False
    )
    suffix = 'Bsg'

    @classmethod
    def create(cls, *args, **kwargs):
        return super(BlendshapeGroup, cls).create(*args, **kwargs)

    def __init__(self, **kwargs):
        super(BlendshapeGroup, self).__init__(**kwargs)

    def create_inbetween(self, *targets, **kwargs):
        kwargs.setdefault('side', self.side)
        blendshape = self.blendshape
        base_geometry = blendshape.base_geometry
        kwargs.setdefault('weight', 1.0)

        if targets and len(targets) != len(base_geometry):
            raise Exception('target shape mismatch')
        kwargs.setdefault('index', len(self.blendshape_inbetweens))
        kwargs.setdefault('root_name', self.root_name)
        kwargs.setdefault('segment_name', '%s_%s' % (
            self.segment_name,
            rig_factory.index_dictionary[self.index].title(),
        ))
        kwargs.setdefault('side', self.side)
        kwargs.setdefault('parent', self)
        kwargs.setdefault('tangent_space', self.tangent_space)

        this = self.create_child(
            BlendshapeInbetween,
            **kwargs
        )
        # self.start_ownership_signal.emit(this, self)
        this.blendshape_group = self
        self.blendshape_inbetweens.append(this)
        # self.end_ownership_signal.emit(this, self)
        # self.create_blendshape_geometry(this, *targets)
        for target in targets:
            this.create_blendshape_target(
                target,
            )
        return this

    def disconnnect_targets(self):
        self.controller.scene.clear_blendshape_group_targets(
            self.blendshape.m_object,
            self.index
        )

    def connect_targets(self):
        raise NotImplementedError('Connect targets does not work with tangent space blendshapes')
        # for blendshape_inbetween in self.blendshape_inbetweens:
        #     for target_shape in blendshape_inbetween.target_shapes:
        #         target_shape.connect()

    def get_blueprint(self):
        blueprint = dict(
            klass=self.__class__.__name__,
            module=self.__module__,
            root_name=self.root_name,
            side=self.side,
            size=self.size,
            index=self.index,
        )
        return blueprint

    def get_weight_plug(self):
        weight_plug = self.blendshape.plugs['weight'].element(self.index)
        return weight_plug

    def isolate(self):
        for blendshape_group in self.blendshape.blendshape_groups:
            if blendshape_group != self:
                blendshape_group.get_weight_plug().set_value(0.0)

    def teardown(self):
        self.controller.schedule_objects_for_deletion(self.blendshape_inbetweens)

        super(BlendshapeGroup, self).teardown()


class BlendshapeInbetween(BaseNode):

    mesh_group = ObjectProperty(
        name='mesh_group'
    )
    blendshape_group = ObjectProperty(
        name='blendshape_group'
    )
    target_shapes = ObjectListProperty(
        name='target_shapes'
    )
    weight = DataProperty(
        name='weight'
    )
    tangent_space = DataProperty(
        name='tangent_space',
        default_value=False
    )

    suffix = 'Bsi'

    def __init__(self, **kwargs):
        super(BlendshapeInbetween, self).__init__(**kwargs)

    def create_blendshape_target(self, target_geometry, **kwargs):
        kwargs.setdefault('side', self.side)
        kwargs.setdefault('parent', self)
        kwargs.setdefault('index', len(self.target_shapes))
        kwargs.setdefault('segment_name', '%s_%s_%s' % (
            self.segment_name,
            rig_factory.index_dictionary[self.index].title(),
            rig_factory.index_dictionary[len(self.target_shapes)]
        ))
        kwargs.setdefault('root_name', self.root_name)
        kwargs.setdefault('side', self.side)
        kwargs.setdefault('tangent_space', self.tangent_space)

        target_shape = self.create_child(
            BlendshapeTarget,
            **kwargs
        )
        target_shape.blendshape_inbetween = self
        self.target_shapes.append(target_shape)
        target_shape.target_geometry = target_geometry
        if target_shape.target_geometry and self.weight:
            target_shape.connect()
        return target_shape

    def get_blueprint(self):
        blueprint = dict(
            klass=self.__class__.__name__,
            module=self.__module__,
            root_name=self.root_name,
            side=self.side,
            size=self.size,
            index=self.index,
            target_shapes=[x.target_geometry.get_selection_string() for x in self.target_shapes]
        )
        return blueprint

    def teardown(self):
        self.controller.schedule_objects_for_deletion(self.target_shapes)
        super(BlendshapeInbetween, self).teardown()


class BlendshapeTarget(BaseNode):

    blendshape_inbetween = ObjectProperty(
        name='blendshape_inbetween'
    )
    target_geometry = ObjectProperty(
        name='target_geometry'
    )
    tangent_space = DataProperty(
        name='tangent_space',
        default_value=False
    )
    suffix = 'Bst'

    def __init__(self, **kwargs):
        super(BlendshapeTarget, self).__init__(**kwargs)

    def disconnect(self):
        target_geometry = self.target_geometry
        if target_geometry:
            blendshape_inbetween = self.blendshape_inbetween
            blendshape_group = blendshape_inbetween.blendshape_group
            blendshape = blendshape_group.blendshape
            shape_index = blendshape_inbetween.target_shapes.index(self)
            base_geometry = blendshape.base_geometry[shape_index]
            self.controller.scene.remove_blendshape_target(
                blendshape.m_object,
                base_geometry.m_object,
                blendshape_group.index,
                target_geometry.m_object,
                blendshape_inbetween.weight
            )

    def connect(self):
        target_geometry = self.target_geometry
        blendshape_inbetween = self.blendshape_inbetween
        blendshape_group = blendshape_inbetween.blendshape_group
        blendshape = blendshape_group.blendshape
        shape_index = blendshape_inbetween.target_shapes.index(self)
        base_geometry = blendshape.base_geometry[shape_index]
        base_geometry.plugs['visibility'].set_value(True)

        self.controller.scene.create_blendshape_target(
            blendshape.m_object,
            base_geometry.m_object,
            blendshape_group.index,
            target_geometry.m_object,
            blendshape_inbetween.weight,
            tangent_space=self.tangent_space
        )



    def teardown(self):
        target_geometry = self.target_geometry
        if target_geometry:
            blendshape_inbetween = self.blendshape_inbetween
            blendshape_group = blendshape_inbetween.blendshape_group
            blendshape = blendshape_group.blendshape
            base_geometry = blendshape.base_geometry[self.index]
            self.controller.scene.remove_blendshape_target(
                blendshape.m_object,
                base_geometry.m_object,
                blendshape_group.index,
                target_geometry.m_object,
                blendshape_inbetween.weight
            )
        super(BlendshapeTarget, self).teardown()