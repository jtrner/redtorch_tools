from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.rig_objects.cone import Cone
from rig_factory.objects.rig_objects.line import Line
from rig_factory.objects.node_objects.nurbs_surface import NurbsSurface
from rig_factory.objects.node_objects.dag_node import DagNode
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_factory.objects.rig_objects.grouped_handle import LocalHandle

import rig_factory.environment as env


class SuspensionBankGuide(PartGuide):
    default_settings = dict(
        root_name='SuspensionBank',
        size=5.0,
        wheel_amount=4,
        shape='cube',
        create_gimbal=False
    )

    shape = DataProperty(
        name='shape'
    )

    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    wheel_amount = DataProperty(
        name='wheel_amount'
    )

    def __init__(self, **kwargs):
        super(SuspensionBankGuide, self).__init__(**kwargs)
        self.toggle_class = SuspensionBank.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        """
        Use rig_objects.handle_guide.CubeHandleGuide
        """
        handle_positions = kwargs.get('handle_positions', dict())
        kwargs.setdefault('side', 'center')
        this = super(SuspensionBankGuide, cls).create(controller, **kwargs)
        wheel_amount = kwargs.get('wheel_amount', cls.default_settings['wheel_amount'])
        side = 'center'
        size = this.size

        # Create nodes
        # Create wheels

        if this.wheel_amount == 2:
            left_sus_bank_jnt = this.create_child(
                Joint,
                segment_name='Sus_Bank',
                side='left'
            )

            right_sus_bank_jnt = this.create_child(
                Joint,
                segment_name='Sus_Bank',
                side='right'
            )

            left_sus_bank_guide = this.create_handle(
                segment_name='Sus_Bank',
                side='left'
            )

            right_sus_bank_guide = this.create_handle(
                segment_name='Sus_Bank',
                side='right'
            )

            left_sus_bank_pos = handle_positions.get(left_sus_bank_guide.name, [20.0, 0.0, 0.0])
            left_sus_bank_guide.plugs['translate'].set_value(left_sus_bank_pos)

            right_sus_bank_pos = handle_positions.get(right_sus_bank_guide.name, [-20.0, 0.0, 0.0])
            right_sus_bank_guide.plugs['translate'].set_value(right_sus_bank_pos)

            controller.create_point_constraint(
                left_sus_bank_guide,
                left_sus_bank_jnt
            )

            controller.create_point_constraint(
                right_sus_bank_guide,
                right_sus_bank_jnt
            )

            # create everything else

            distance_node = this.create_child(
                DependNode,
                node_type='distanceBetween',
            )

            multiply = this.create_child(
                DependNode,
                node_type='multiplyDivide',
                segment_name='ItemSize'
            )

            # Attributes

            size_plug = this.plugs['size']
            size_plug.connect_to(multiply.plugs['input1X'])
            multiply.plugs['input2X'].set_value(1)

            multiply.plugs['outputX'].connect_to(left_sus_bank_guide.plugs['size'])
            multiply.plugs['outputX'].connect_to(right_sus_bank_guide.plugs['size'])

            for joint in [left_sus_bank_jnt, right_sus_bank_jnt]:
                joint.plugs.set_values(
                    overrideEnabled=True,
                    overrideDisplayType=2,
                    radius=size * 1.5
                )

            left_sus_bank_guide.plugs['radius'].set_value(size * 0.5)
            right_sus_bank_guide.plugs['radius'].set_value(size * 0.5)

            # Shaders
            root = this.get_root()
            left_sus_bank_guide.mesh.assign_shading_group(root.shaders['left'].shading_group)
            right_sus_bank_guide.mesh.assign_shading_group(root.shaders['right'].shading_group)

            root = this.get_root()
            if root:
                root.add_plugs(
                    [
                        left_sus_bank_guide.plugs['tx'],
                        left_sus_bank_guide.plugs['ty'],
                        left_sus_bank_guide.plugs['tz'],
                        right_sus_bank_guide.plugs['tx'],
                        right_sus_bank_guide.plugs['ty'],
                        right_sus_bank_guide.plugs['tz']
                    ]
                )
            this.base_handles = [left_sus_bank_guide,
                                 right_sus_bank_guide
                                 ]
            this.joints = [left_sus_bank_jnt,
                           right_sus_bank_jnt
                           ]
            return this

        elif this.wheel_amount == 4:

            left_fr_sus_bank_jnt = this.create_child(
                Joint,
                segment_name='Fr_Sus_Bank',
                side='left'
            )

            left_bk_sus_bank_jnt = this.create_child(
                Joint,
                segment_name='Bk_Sus_Bank',
                side='left'
            )

            right_fr_sus_bank_jnt = this.create_child(
                Joint,
                segment_name='Fr_Sus_Bank',
                side='right'
            )

            right_bk_sus_bank_jnt = this.create_child(
                Joint,
                segment_name='Bk_Sus_Bank',
                side='right'
            )

            left_fr_sus_bank_guide = this.create_handle(
                segment_name='Fr_Sus_Bank',
                side='left'
            )

            left_bk_sus_bank_guide = this.create_handle(
                segment_name='Bk_Sus_Bank',
                side='left'
            )

            right_fr_sus_bank_guide = this.create_handle(
                segment_name='Fr_Sus_Bank',
                side='right'
            )

            right_bk_sus_bank_guide = this.create_handle(
                segment_name='Bk_Sus_Bank',
                side='right'
            )

            left_fr_sus_bank_pos = handle_positions.get(left_fr_sus_bank_guide.name, [20.0, 0.0, 20.0])
            left_fr_sus_bank_guide.plugs['translate'].set_value(left_fr_sus_bank_pos)

            left_bk_sus_bank_pos = handle_positions.get(left_bk_sus_bank_guide.name, [20.0, 0.0, -20.0])
            left_bk_sus_bank_guide.plugs['translate'].set_value(left_bk_sus_bank_pos)

            right_fr_sus_bank_pos = handle_positions.get(right_fr_sus_bank_guide.name, [-20.0, 0.0, 20.0])
            right_fr_sus_bank_guide.plugs['translate'].set_value(right_fr_sus_bank_pos)

            right_bk_sus_bank_pos = handle_positions.get(right_bk_sus_bank_guide.name, [-20.0, 0.0, -20.0])
            right_bk_sus_bank_guide.plugs['translate'].set_value(right_bk_sus_bank_pos)

            controller.create_point_constraint(
                left_fr_sus_bank_guide,
                left_fr_sus_bank_jnt
            )

            controller.create_point_constraint(
                left_bk_sus_bank_guide,
                left_bk_sus_bank_jnt
            )

            controller.create_point_constraint(
                right_fr_sus_bank_guide,
                right_fr_sus_bank_jnt
            )

            controller.create_point_constraint(
                right_bk_sus_bank_guide,
                right_bk_sus_bank_jnt
            )

            # create everything else

            distance_node = this.create_child(
                DependNode,
                node_type='distanceBetween',
            )

            multiply = this.create_child(
                DependNode,
                node_type='multiplyDivide',
                segment_name='ItemSize'
            )

            # Attributes

            size_plug = this.plugs['size']
            size_plug.connect_to(multiply.plugs['input1X'])
            multiply.plugs['input2X'].set_value(1)

            multiply.plugs['outputX'].connect_to(left_fr_sus_bank_guide.plugs['size'])
            multiply.plugs['outputX'].connect_to(left_bk_sus_bank_guide.plugs['size'])
            multiply.plugs['outputX'].connect_to(right_fr_sus_bank_guide.plugs['size'])
            multiply.plugs['outputX'].connect_to(right_bk_sus_bank_guide.plugs['size'])

            for joint in [left_fr_sus_bank_jnt, left_bk_sus_bank_jnt, right_fr_sus_bank_jnt, right_bk_sus_bank_jnt]:
                joint.plugs.set_values(
                    overrideEnabled=True,
                    overrideDisplayType=2,
                    radius=size * 1.5
                )

            left_fr_sus_bank_guide.plugs['radius'].set_value(size * 0.5)
            left_bk_sus_bank_guide.plugs['radius'].set_value(size * 0.5)
            right_fr_sus_bank_guide.plugs['radius'].set_value(size * 0.5)
            right_bk_sus_bank_guide.plugs['radius'].set_value(size * 0.5)

            # Shaders
            root = this.get_root()
            left_fr_sus_bank_guide.mesh.assign_shading_group(root.shaders['left'].shading_group)
            left_bk_sus_bank_guide.mesh.assign_shading_group(root.shaders['left'].shading_group)
            right_fr_sus_bank_guide.mesh.assign_shading_group(root.shaders['right'].shading_group)
            right_bk_sus_bank_guide.mesh.assign_shading_group(root.shaders['right'].shading_group)

            root = this.get_root()
            if root:
                root.add_plugs(
                    [
                        left_fr_sus_bank_guide.plugs['tx'],
                        left_fr_sus_bank_guide.plugs['ty'],
                        left_fr_sus_bank_guide.plugs['tz'],
                        left_bk_sus_bank_guide.plugs['tx'],
                        left_bk_sus_bank_guide.plugs['ty'],
                        left_bk_sus_bank_guide.plugs['tz'],
                        right_fr_sus_bank_guide.plugs['tx'],
                        right_fr_sus_bank_guide.plugs['ty'],
                        right_fr_sus_bank_guide.plugs['tz'],
                        right_bk_sus_bank_guide.plugs['tx'],
                        right_bk_sus_bank_guide.plugs['ty'],
                        right_bk_sus_bank_guide.plugs['tz']
                    ]
                )
            this.base_handles = [left_fr_sus_bank_guide,
                                 left_bk_sus_bank_guide,
                                 right_fr_sus_bank_guide,
                                 right_bk_sus_bank_guide
                                 ]
            this.joints = [left_fr_sus_bank_jnt,
                           left_bk_sus_bank_jnt,
                           right_fr_sus_bank_jnt,
                           right_bk_sus_bank_jnt
                           ]
            return this

        else:
            print ("uh oh spaghettios you messed up it only takes 2 or 4 babyyyy")





class SuspensionBank(Part):
    deformers = ObjectListProperty(
        name='deformers'
    )

    geometry = ObjectListProperty(
        name='geometry'
    )

    shape = DataProperty(
        name='shape'
    )

    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    wheel_amount = DataProperty(
        name='wheel_amount'
    )

    def __init__(self, **kwargs):
        super(SuspensionBank, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(SuspensionBank, cls).create(controller, **kwargs)
        size = this.size
        matrices = this.matrices

        top_transform = this.create_child(
            Transform,
            side='center',
            segment_name='Master'
        )
        if this.wheel_amount == 2:

            left_sus_bank_handle_jnt = this.create_child(
                Joint,
                index=0,
                side='left',
                segment_name='Sus_Bank',
                matrix=matrices[0],
                parent=this.joint_group
            )

            right_sus_bank_handle_jnt = this.create_child(
                Joint,
                index=0,
                side='right',
                segment_name='Sus_Bank',
                matrix=matrices[1],
                parent=this.joint_group
            )

            average_axle_pos = (left_sus_bank_handle_jnt.get_translation() + right_sus_bank_handle_jnt.get_translation()) / 2

            sus_main_bank_handle = this.create_handle(
                handle_type=GroupedHandle,
                shape='cube',
                side='center',
                segment_name='Sus_Bank',
                size=size,
                matrix=average_axle_pos,
                create_gimbal=this.create_gimbal,
                parent=top_transform
            )

            left_sus_bank_handle = this.create_handle(
                handle_type=GroupedHandle,
                shape='arrow_vertical',
                side='left',
                segment_name='Sus_Bank',
                size=size,
                matrix=matrices[0],
                create_gimbal=this.create_gimbal,
                parent=sus_main_bank_handle
            )

            right_sus_bank_handle = this.create_handle(
                handle_type=GroupedHandle,
                shape='arrow_vertical',
                side='right',
                segment_name='Sus_Bank',
                size=size,
                matrix=matrices[1],
                create_gimbal=this.create_gimbal,
                parent=sus_main_bank_handle
            )

            for joint_handle in [left_sus_bank_handle_jnt, right_sus_bank_handle_jnt]:
                joint_handle.zero_rotation()
                joint_handle.plugs.set_values(
                    overrideEnabled=True,
                    overrideDisplayType=2,
                )

            #########################################################################################
            # create constraints

            controller.create_parent_constraint(
                left_sus_bank_handle,
                left_sus_bank_handle_jnt
            )

            controller.create_scale_constraint(
                left_sus_bank_handle,
                left_sus_bank_handle_jnt
            )

            controller.create_parent_constraint(
                right_sus_bank_handle,
                right_sus_bank_handle_jnt
            )

            controller.create_scale_constraint(
                right_sus_bank_handle,
                right_sus_bank_handle_jnt
            )


            #########################################################################################
            root = this.get_root()
            if root:
                root.add_plugs(
                    [
                        left_sus_bank_handle.plugs['tx'],
                        left_sus_bank_handle.plugs['ty'],
                        left_sus_bank_handle.plugs['tz'],
                        right_sus_bank_handle.plugs['tx'],
                        right_sus_bank_handle.plugs['ty'],
                        right_sus_bank_handle.plugs['tz']
                    ]
                )
            this.joint_chain = False
            this.joints = [left_sus_bank_handle_jnt,
                           right_sus_bank_handle_jnt,
                           ]
            return this



        elif this.wheel_amount == 4:

            left_fr_sus_bank_handle_jnt = this.create_child(
                Joint,
                index=0,
                side='left',
                segment_name='Fr_Sus_Bank',
                matrix=matrices[0],
                parent=this.joint_group
            )

            left_bk_sus_bank_handle_jnt = this.create_child(
                Joint,
                index=0,
                side='left',
                segment_name='Bk_Sus_Bank',
                matrix=matrices[1],
                parent=this.joint_group
            )

            right_fr_sus_bank_handle_jnt = this.create_child(
                Joint,
                index=0,
                side='right',
                segment_name='Fr_Sus_Bank',
                matrix=matrices[2],
                parent=this.joint_group
            )

            right_bk_sus_bank_handle_jnt = this.create_child(
                Joint,
                index=0,
                side='right',
                segment_name='Bk_Sus_Bank',
                matrix=matrices[3],
                parent=this.joint_group
            )

            fr_average_axle_pos = (left_fr_sus_bank_handle_jnt.get_translation() + right_fr_sus_bank_handle_jnt.get_translation()) / 2
            bk_average_axle_pos = (left_bk_sus_bank_handle_jnt.get_translation() + right_bk_sus_bank_handle_jnt.get_translation()) / 2

            fr_sus_main_bank_handle = this.create_handle(
                handle_type=GroupedHandle,
                shape='cube',
                side='center',
                segment_name='Fr_Sus_Bank',
                size=size,
                matrix=fr_average_axle_pos,
                create_gimbal=this.create_gimbal,
                parent=top_transform
            )

            bk_sus_main_bank_handle = this.create_handle(
                handle_type=GroupedHandle,
                shape='cube',
                side='center',
                segment_name='Bk_Sus_Bank',
                size=size,
                matrix=bk_average_axle_pos,
                create_gimbal=this.create_gimbal,
                parent=top_transform
            )

            left_fr_sus_bank_handle = this.create_handle(
                handle_type=GroupedHandle,
                shape='arrow_vertical',
                side='left',
                segment_name='Fr_Sus_Bank',
                size=size,
                matrix=matrices[0],
                create_gimbal=this.create_gimbal,
                parent=fr_sus_main_bank_handle
            )

            left_bk_sus_bank_handle = this.create_handle(
                handle_type=GroupedHandle,
                shape='arrow_vertical',
                side='left',
                segment_name='Bk_Sus_Bank',
                size=size,
                matrix=matrices[1],
                create_gimbal=this.create_gimbal,
                parent=bk_sus_main_bank_handle
            )

            right_fr_sus_bank_handle = this.create_handle(
                handle_type=GroupedHandle,
                shape='arrow_vertical',
                side='right',
                segment_name='Fr_Sus_Bank',
                size=size,
                matrix=matrices[2],
                create_gimbal=this.create_gimbal,
                parent=fr_sus_main_bank_handle
            )

            right_bk_sus_bank_handle = this.create_handle(
                handle_type=GroupedHandle,
                shape='arrow_vertical',
                side='right',
                segment_name='Bk_Sus_Bank',
                size=size,
                matrix=matrices[3],
                create_gimbal=this.create_gimbal,
                parent=bk_sus_main_bank_handle
            )

            for joint_handle in [left_fr_sus_bank_handle_jnt, left_bk_sus_bank_handle_jnt,
                                 right_fr_sus_bank_handle_jnt, right_bk_sus_bank_handle_jnt]:
                joint_handle.zero_rotation()
                joint_handle.plugs.set_values(
                    overrideEnabled=True,
                    overrideDisplayType=2,
                )

            #########################################################################################
            # make the surface

            left_fr_pos = left_fr_sus_bank_handle_jnt.get_translation()
            left_bk_pos = left_bk_sus_bank_handle_jnt.get_translation()
            right_fr_pos = right_fr_sus_bank_handle_jnt.get_translation()
            right_bk_pos = right_bk_sus_bank_handle_jnt.get_translation()

            surface_transform = this.create_child(
                Transform,
                segment_name='Surface',
                parent=this.utility_group
            )

            surface_shape = surface_transform.create_child(
                NurbsSurface,
            )

            cvs = [
                left_fr_pos,
                right_fr_pos,
                left_bk_pos,
                right_bk_pos
            ]

            knots_u = [0.0, 1.0]
            knots_v = [0.0, 1.0]
            degree_u = 1
            degree_v = 1
            spans_u = 1
            spans_v = 1

            surface_shape.set_surface_data(cvs, knots_u, knots_v, degree_u, degree_v, spans_u, spans_v)

            surface_fol_transform = this.create_child(
                Transform,
                segment_name='Follicle',
                parent=this.utility_group
            )

            surface_fol_shape = surface_fol_transform.create_child(
                DagNode,
                node_type='follicle',
            )

            surface_shape.plugs['local'].connect_to(surface_fol_shape.plugs['inputSurface'])
            surface_shape.plugs['worldMatrix'].element(0).connect_to(surface_fol_shape.plugs['inputWorldMatrix'])
            surface_fol_shape.plugs['parameterU'].set_value(0.5)
            surface_fol_shape.plugs['parameterV'].set_value(0.5)
            surface_fol_shape.plugs['outRotate'].connect_to(surface_fol_transform.plugs['rotate'])
            surface_fol_shape.plugs['outTranslate'].connect_to(surface_fol_transform.plugs['translate'])
            left_fr_sus_bank_handle_jnt.plugs['translate'].connect_to(surface_shape.plugs['controlPoints'].element(0))
            left_bk_sus_bank_handle_jnt.plugs['translate'].connect_to(surface_shape.plugs['controlPoints'].element(2))
            right_fr_sus_bank_handle_jnt.plugs['translate'].connect_to(surface_shape.plugs['controlPoints'].element(1))
            right_bk_sus_bank_handle_jnt.plugs['translate'].connect_to(surface_shape.plugs['controlPoints'].element(3))


            #########################################################################################
            # create constraints

            controller.create_parent_constraint(
                left_fr_sus_bank_handle,
                left_fr_sus_bank_handle_jnt
            )

            controller.create_scale_constraint(
                left_fr_sus_bank_handle,
                left_fr_sus_bank_handle_jnt
            )

            controller.create_parent_constraint(
                left_bk_sus_bank_handle,
                left_bk_sus_bank_handle_jnt
            )

            controller.create_scale_constraint(
                left_bk_sus_bank_handle,
                left_bk_sus_bank_handle_jnt
            )

            controller.create_parent_constraint(
                right_fr_sus_bank_handle,
                right_fr_sus_bank_handle_jnt
            )

            controller.create_scale_constraint(
                right_fr_sus_bank_handle,
                right_fr_sus_bank_handle_jnt
            )

            controller.create_parent_constraint(
                right_bk_sus_bank_handle,
                right_bk_sus_bank_handle_jnt
            )

            controller.create_scale_constraint(
                right_bk_sus_bank_handle,
                right_bk_sus_bank_handle_jnt
            )

            #########################################################################################
            root = this.get_root()
            if root:
                root.add_plugs(
                    [
                        left_fr_sus_bank_handle.plugs['tx'],
                        left_fr_sus_bank_handle.plugs['ty'],
                        left_fr_sus_bank_handle.plugs['tz'],
                        left_bk_sus_bank_handle.plugs['tx'],
                        left_bk_sus_bank_handle.plugs['ty'],
                        left_bk_sus_bank_handle.plugs['tz'],
                        right_fr_sus_bank_handle.plugs['tx'],
                        right_fr_sus_bank_handle.plugs['ty'],
                        right_fr_sus_bank_handle.plugs['tz'],
                        right_bk_sus_bank_handle.plugs['tx'],
                        right_bk_sus_bank_handle.plugs['ty'],
                        right_bk_sus_bank_handle.plugs['tz']
                    ]
                )
            this.joint_chain = False
            this.joints = [left_fr_sus_bank_handle_jnt,
                           left_bk_sus_bank_handle_jnt,
                           right_fr_sus_bank_handle_jnt,
                           right_bk_sus_bank_handle_jnt
                           ]
            return this