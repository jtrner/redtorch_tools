from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.node_objects.nurbs_surface import NurbsSurface
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.joint import Joint
import rig_factory.utilities.spline_builders as spb
import rig_factory
import rig_factory.environment as env
import rig_factory.utilities.joint_volume_utiilities as jvu
from rig_math.matrix import Matrix


class ArrayMixin(object):

    def __init__(self, **kwargs):
        super(ArrayMixin, self).__init__(**kwargs)

    def get_control_points(self):
        return self.controller.get_control_points(self)

    def snap_to_mesh(self, mesh):
        self.controller.snap_to_mesh(self, mesh)

    def create_points(self, *vertices, **kwargs):
        return self.controller.create_points(self, *vertices, **kwargs)

    def create_point(self, **kwargs):
        return self.controller.create_point(self, **kwargs)


class DoubleSurfaceSplineGuide(PartGuide, ArrayMixin):

    surface_data = DataProperty(
        name='surface_data'
    )
    locators = ObjectListProperty(
        name='locators'
    )
    count = DataProperty(
        name='count'
    )
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )
    spline_handles = ObjectListProperty(
        name='spline_handles'
    )
    joint_count = DataProperty(
        name='joint_count',
        default_value=19
    )
    use_fit_curve = DataProperty(
        name='use_fit_curve'
    )
    create_gimbal = DataProperty(
        name='create_gimbal'
    )
    threshold = DataProperty(
        name='threshold',
        default_value=0.01
    )
    secondary_parameters = DataProperty(
        name='secondary_parameters'
    )
    secondary_translations = DataProperty(
        name='secondary_translations'
    )
    up_vector_position = DataProperty(
        name='up_vector_position'
    )
    follicle_surface = ObjectProperty(
        name='follicle_surface'
    )
    up_vector_transform = ObjectProperty(
        name='up_vector_transform'
    )

    ribbon_surface = ObjectProperty(
        name='ribbon_surface'
    )
    create_shards = DataProperty(
        name='create_shards'
    )
    create_spline_on_surface = DataProperty(
        name='create_spline_on_surface'
    )
    create_roll_joints = DataProperty(
        name='create_roll_joints'
    )
    create_scale_joints = DataProperty(
        name='create_scale_joints'
    )
    create_auto_volume = DataProperty(
        name='create_auto_volume'
    )
    create_twist_joints = DataProperty(
        name='create_twist_joints'
    )
    upper_spline_handles = ObjectListProperty(
        name='upper_spline_handles'
    )
    lower_spline_handles = ObjectListProperty(
        name='lower_spline_handles'
    )
    upper_main_curve = ObjectProperty(
        name='upper_main_curve'
    )
    lower_main_curve = ObjectProperty(
        name='lower_main_curve'
    )

    default_settings = dict(
        root_name='Spline',
        count=5,
        size=3.0,
        mirror=False,
        side=None,
        threshold=0.01,
        create_gimbal=False,
        use_fit_curve=False,
        joint_count=9,
        create_shards=False,
        create_spline_on_surface=False,
        create_roll_joints=False,
        create_scale_joints=False,
        create_auto_volume=False,
        create_twist_joints=False
    )

    def __init__(self, **kwargs):
        super(DoubleSurfaceSplineGuide, self).__init__(**kwargs)
        self.toggle_class = DoubleSurfaceSpline.__name__

    @classmethod
    def create(cls, controller, **kwargs):

        this = super(DoubleSurfaceSplineGuide, cls).create(controller, **kwargs)
        count = this.count
        side = this.side
        size = this.size
        size_multiply = this.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='Size'
        )
        size_plug = this.plugs['size']
        size_plug.connect_to(size_multiply.plugs['input1X'])
        size_plug.connect_to(size_multiply.plugs['input1Y'])
        size_multiply.plugs['input2X'].set_value(0.5)
        size_multiply.plugs['input2Y'].set_value(0.5)

        upper_handle_data = create_handle_data(
            count,
            side,
            this.root_name,
            'Upper',
            size
        )

        lower_handle_data = create_handle_data(
            count,
            side,
            this.root_name,
            'Lower',
            size
        )

        if this.surface_data:
            positions, knots_u, knots_v, degree_u, degree_v, form_u, form_v = this.surface_data
            follicle_surface_transform = this.create_child(
                Transform,
                segment_name='Slide'
            )
            this.follicle_surface = follicle_surface_transform.create_child(
                NurbsSurface,
                positions=positions,
                knots_u=knots_u,
                knots_v=knots_v,
                degree_u=degree_u,
                degree_v=degree_v,
                form_u=form_u,
                form_v=form_v
            )
            this.follicle_surface.plugs['curvePrecisionShaded'].set_value(10)
            # this.follicle_surface.plugs['overrideDisplayType'].set_value(2)
            this.follicle_surface.plugs['overrideEnabled'].set_value(1)
            this.follicle_surface.assign_shading_group(this.get_root().shaders[this.side].shading_group)

        if not this.surface_data or not this.create_spline_on_surface:
            up_vector_transform = this.create_child(
                Transform,
                segment_name='UpVector'
            )
            up_vector_transform.create_child(
                Locator
            )
            this.up_vector_transform = up_vector_transform
            if this.up_vector_position:
                this.up_vector_transform.set_matrix(Matrix(this.up_vector_position))
            else:
                this.up_vector_position = list(this.up_vector_transform.get_matrix())

        start_handle, start_joint = spb.create_guide_handle(
            this,
            **upper_handle_data[0]
        )
        end_handle, end_joint = spb.create_guide_handle(
            this,
            **upper_handle_data[-1]
        )



        size_multiply.plugs['outputX'].connect_to(start_handle.plugs['size'])
        size_multiply.plugs['outputX'].connect_to(end_handle.plugs['size'])

        upper_handles = []
        upper_joints = []

        for handle_data in upper_handle_data[1:-1]:
            handle, joint = spb.create_guide_handle(
                this,
                **handle_data
            )
            size_multiply.plugs['outputX'].connect_to(handle.plugs['size'])
            upper_handles.append(handle)
            upper_joints.append(joint)

        lower_handles = []
        lower_joints = []
        for handle_data in lower_handle_data[1:-1]:
            handle, joint = spb.create_guide_handle(
                this,
                **handle_data
            )
            size_multiply.plugs['outputX'].connect_to(handle.plugs['size'])
            lower_handles.append(handle)
            lower_joints.append(joint)

        all_handles = [start_handle]
        all_handles.extend(merge_lists(upper_handles, lower_handles))
        all_handles.append(end_handle)
        this.base_handles = list(all_handles)

        all_joints = [start_joint]
        all_joints.extend(merge_lists(upper_joints, lower_joints))
        all_joints.append(end_joint)
        this.joints = all_joints
        upper_spline_group = this.create_child(
            Transform,
            segment_name='Spline',
            differentiation_name='Upper'
        )
        driver_joints = [start_joint]
        driver_joints.extend(upper_joints)
        driver_joints.append(end_joint)

        for handle in all_handles:
            handle_positions = kwargs.get('handle_positions', dict())
            if handle.name in handle_positions:
                handle.plugs['translate'].set_value(handle_positions[handle.name])

        upper_spline, upper_spline_handles, upper_spline_joints, upper_roll_joints = spb.create_spline(
            this,
            upper_spline_group,
            driver_joints
        )

        this.upper_main_curve = upper_spline
        this.upper_spline_handles = upper_spline_handles
        lower_spline_group = this.create_child(
            Transform,
            segment_name='Spline',
            differentiation_name='Lower'
        )
        driver_joints = [start_joint]
        driver_joints.extend(lower_joints)
        driver_joints.append(end_joint)

        lower_spline, lower_spline_handles, lower_spline_joints, lower_roll_joints = spb.create_spline(
            this,
            lower_spline_group,
            driver_joints
        )
        this.lower_main_curve = lower_spline
        this.lower_spline_handles = lower_spline_handles

        all_spline_joints = upper_spline_joints + lower_spline_joints
        all_spline_handles = upper_spline_handles + lower_spline_handles

        all_handles.extend(all_spline_handles)

        for handle in all_spline_handles:

            # handle.plugs['overrideRGBColors'].set_value(True)
            # handle.plugs['overrideColorRGB'].set_value([0.1, 0.1, 0.1])
            handle.plugs.set_locked(
                # translate=True,
                rotate=True,
                scale=True
            )
        for joint in all_spline_joints:

            joint.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
            )

        # Backward compatible "Slide" values
        joint_parameters = kwargs.pop('joint_parameters', None)
        # if not joint_parameters:
        #     print 'NO JOINT PARMS FOUND: %s' % this
        # elif not len(all_spline_handles) == len(joint_parameters):
        #     print 'param count mismatch ', len(all_spline_handles), len(joint_parameters), this
        #

        if joint_parameters and len(all_spline_handles) == len(joint_parameters):
            upper_joint_parameters = joint_parameters[:len(joint_parameters) / 2]
            lower_joint_parameters = joint_parameters[len(joint_parameters) / 2:]
            for i in range(len(upper_joint_parameters)):
                slide_value = 1.0 / (len(upper_joint_parameters)-1) * i + (upper_joint_parameters[i] * 0.1)
                upper_spline_handles[i].plugs['Slide'].set_value(slide_value)
            for i in range(len(lower_joint_parameters)):
                slide_value = 1.0 / (len(lower_joint_parameters)-1) * i + (lower_joint_parameters[i] * 0.1)
                lower_spline_handles[i].plugs['Slide'].set_value(slide_value)

        this.spline_joints = all_spline_joints
        this.spline_handles = all_spline_handles
        this.set_handles(all_handles)

        this.consolidate_slide_values()

        return this

    def get_handle_positions(self):
        return dict((x.name, x.plugs['translate'].get_value()) for x in self.base_handles)

    def get_index_handle_positions(self):
        return [self.controller.xform(x, q=True, t=True, ws=True)for x in self.base_handles]

    def get_blueprint(self):
        blueprint = super(DoubleSurfaceSplineGuide, self).get_blueprint()
        blueprint.update(dict(
            handle_positions=self.get_handle_positions(),
            handle_vertices=self.get_vertex_data(),
            secondary_parameters=[x.plugs['Slide'].get_value() for x in self.spline_handles],
            secondary_translations=[x.plugs['translate'].get_value() for x in self.spline_handles],
            up_vector_position=list(self.up_vector_transform.get_translation()) if self.up_vector_transform else None,
            surface_data=self.follicle_surface.get_surface_data() if self.follicle_surface else self.surface_data
        ))
        return blueprint

    def get_handle_data(self):
        handle_data = []
        if not self.base_handles:
            raise Exception('No Base Handles Found')
        for i, handle in enumerate(self.base_handles):
            handle = self.base_handles[i]
            handle_data.append(
                dict(
                    klass=handle.__class__.__name__,
                    module=handle.__module__,
                    vertices=[(x.mesh.get_selection_string(), x.index) for x in handle.vertices],
                    matrix=list(self.joints[i].get_matrix()),
                    root_name=handle.root_name,
                    segment_name=handle.segment_name,
                    differentiation_name=handle.differentiation_name,
                    size=handle.size,
                    side=handle.side
                )
            )
        return handle_data

    def get_toggle_blueprint(self):
        blueprint = super(DoubleSurfaceSplineGuide, self).get_toggle_blueprint()
        blueprint['handle_data'] = self.get_handle_data()
        blueprint['secondary_parameters'] = [x.plugs['Slide'].get_value() for x in self.spline_handles]
        blueprint['secondary_translations'] = [x.plugs['translate'].get_value() for x in self.spline_handles]
        blueprint['up_vector_position'] = list(self.up_vector_transform.get_translation()) if self.up_vector_transform else None
        blueprint['surface_data'] = self.follicle_surface.get_surface_data() if self.follicle_surface else self.surface_data

        return blueprint

    def get_mirror_blueprint(self):
        sides = dict(left='right', right='left')
        handles = self.handles
        if not all(self.side == x.side for x in handles):
            raise Exception('Non uniform handle sides not supported in mirror blueprint')
        blueprint = super(DoubleSurfaceSplineGuide, self).get_mirror_blueprint()
        handle_data = []
        for handle in self.handles:
            handle_matrix = list(handle.get_matrix())
            handle_matrix[12] = handle_matrix[12]*-1
            handle_properties = dict(
                klass=handle.__class__.__name__,
                module=handle.__module__,
                root_name=handle.root_name,
                size=handle.plugs['size'].get_value(1.0),
                side=sides[handle.side],
                index=handle.index,
                handle_matrix=handle_matrix
            )
            mirror_vertices = []
            for vertex in handle.vertices:
                position = list(vertex.get_translation())
                position[0] = position[0] * -1
                mirror_index = self.controller.get_closest_vertex_index(
                    vertex.mesh,
                    position,
                )
                mirror_vertex = vertex.mesh.get_vertex(mirror_index)
                mirror_vertices.append(mirror_vertex)
            handle_properties['vertices'] = [(x.mesh.get_selection_string(), x.index) for x in mirror_vertices]
            handle_data.append(handle_properties)
        blueprint['handle_data'] = handle_data
        blueprint['handle_data'] = handle_data

        return blueprint

    def set_vertex_data(self, *args, **kwargs):
        super(DoubleSurfaceSplineGuide, self).set_vertex_data(*args, **kwargs)

    def consolidate_slide_values(self):
        for handle in self.upper_spline_handles:
            position = list(handle.get_translation())
            print type(self.upper_main_curve), self.upper_main_curve.name, self.controller.scene.nodeType(self.upper_main_curve.name)
            closest_parameter = self.controller.scene.get_closest_curve_parameter(
                self.upper_main_curve.m_object,
                list(handle.get_translation())
            )
            upper_spans = self.upper_main_curve.plugs['spans'].get_value()
            if upper_spans == 0:
                raise Exception('The upper_main_curve for %s had zero spans' % self)
            handle.plugs['Slide'].set_value(closest_parameter / upper_spans)
            self.controller.scene.xform(handle, ws=True, t=position)

        for handle in self.lower_spline_handles:
            position = list(handle.get_translation())
            closest_parameter = self.controller.scene.get_closest_curve_parameter(
                self.lower_main_curve.m_object,
                list(handle.get_translation())
            )
            lower_spans = self.lower_main_curve.plugs['spans'].get_value()
            if lower_spans == 0:
                raise Exception('The lower_main_curve curve for %s had zero spans' % self)
            handle.plugs['Slide'].set_value(closest_parameter / lower_spans)
            self.controller.scene.xform(handle, ws=True, t=position)


class DoubleSurfaceSpline(Part):

    surface_data = DataProperty(
        name='surface_data'
    )
    create_gimbal = DataProperty(
        name='create_gimbal'
    )
    use_fit_curve = DataProperty(
        name='use_fit_curve'
    )
    fit_curve = ObjectProperty(
        name='fit_curve'
    )
    base_curve = ObjectProperty(
        name='base_curve'
    )
    follicle_surface = ObjectProperty(
        name='follicle_surface'
    )
    handle_data = DataProperty(
        name='handle_data'
    )
    joint_count = DataProperty(
        name='joint_count'
    )
    upper_main_curve = ObjectProperty(
        name='upper_main_curve'
    )
    lower_main_curve = ObjectProperty(
        name='lower_main_curve'
    )
    ribbon_surface = ObjectProperty(
        name='ribbon_surface'
    )
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )
    spline_handles = ObjectListProperty(
        name='spline_handles'
    )
    secondary_parameters = DataProperty(
        name='secondary_parameters'
    )
    secondary_translations = DataProperty(
        name='secondary_translations'
    )
    create_shards = DataProperty(
        name='create_shards',
        default_value=False
    )
    upper_joints = ObjectListProperty(
        name='upper_joints'
    )
    lower_joints = ObjectListProperty(
        name='lower_joints'
    )
    start_joint = ObjectProperty(
        name='start_joint'
    )
    end_joint = ObjectProperty(
        name='end_joint'
    )

    upper_bind_joints = ObjectListProperty(
        name='upper_bind_joints'
    )
    lower_bind_joints = ObjectListProperty(
        name='lower_bind_joints'
    )
    start_bind_joint = ObjectProperty(
        name='start_bind_joint'
    )
    end_bind_joint = ObjectProperty(
        name='end_bind_joint'
    )

    up_vector_position = DataProperty(
        name='up_vector_position'
    )
    up_vector_transform = ObjectProperty(
        name='up_vector_transform'
    )
    create_spline_on_surface = DataProperty(
        name='create_spline_on_surface'
    )
    create_roll_joints = DataProperty(
        name='create_roll_joints'
    )
    create_scale_joints = DataProperty(
        name='create_scale_joints'
    )
    create_auto_volume = DataProperty(
        name='create_auto_volume'
    )
    create_twist_joints = DataProperty(
        name='create_twist_joints'
    )
    base_handles = ObjectListProperty(
        name='base_handles'
    )
    start_handle = ObjectProperty(
        name='start_handle'
    )
    end_handle = ObjectProperty(
        name='end_handle'
    )
    upper_handles = ObjectListProperty(
        name='upper_handles'
    )
    lower_handles = ObjectListProperty(
        name='lower_handles'
    )
    upper_spline_handles = ObjectListProperty(
        name='upper_spline_handles'
    )
    lower_spline_handles = ObjectListProperty(
        name='lower_spline_handles'
    )
    def __init__(self, **kwargs):
        super(DoubleSurfaceSpline, self).__init__(**kwargs)
        self.disconnected_joints = True
        self.joint_chain = False

    @classmethod
    def create(cls, controller, **kwargs):
        handle_data = kwargs.pop('handle_data', None)
        if not handle_data:
            raise Exception('You must provide the handle_data keyword to create a %s' % cls.__name__)
        this = super(DoubleSurfaceSpline, cls).create(controller, **kwargs)

        #  Chunk out data into upper and lower
        upper_handle_data = [handle_data[0]]
        lower_handle_data = [handle_data[0]]
        for up_data, down_data in chunks(handle_data[1:-1], 2):
            upper_handle_data.append(up_data)
            lower_handle_data.append(down_data)
        upper_handle_data.append(handle_data[-1])
        lower_handle_data.append(handle_data[-1])

        if this.surface_data:
            positions, knots_u, knots_v, degree_u, degree_v, form_u, form_v = this.surface_data
            surface_transform = this.create_child(
                Transform,
                segment_name='Surface'
            )
            this.follicle_surface = surface_transform.create_child(
                NurbsSurface,
                positions=positions,
                knots_u=knots_u,
                knots_v=knots_v,
                degree_u=degree_u,
                degree_v=degree_v,
                form_u=form_u,
                form_v=form_v
            )
            this.follicle_surface.plugs['v'].set_value(False)
        if not this.surface_data or not this.create_spline_on_surface:

            up_vector_transform = this.create_child(
                Transform,
                segment_name='UpVector'
            )
            up_vector_transform.create_child(
                Locator
            )
            this.up_vector_transform = up_vector_transform
            if this.up_vector_position:
                this.up_vector_transform.set_matrix(Matrix(this.up_vector_position))
            else:
                this.up_vector_position = this.up_vector_transform.get_matrix()
        start_handle, start_joint = spb.create_handle(this, **upper_handle_data[0])
        end_handle, end_joint = spb.create_handle(this, **upper_handle_data[-1])
        upper_handles = []
        upper_joints = []
        for data in upper_handle_data[1:-1]:
            handle, joint = spb.create_handle(this, **data)
            upper_handles.append(handle)
            upper_joints.append(joint)

        lower_handles = []
        lower_joints = []
        for data in lower_handle_data[1:-1]:
            handle, joint = spb.create_handle(this, **data)
            lower_handles.append(handle)
            lower_joints.append(joint)

        all_handles = [start_handle]
        all_handles.extend(merge_lists(upper_handles, lower_handles))
        all_handles.append(end_handle)

        for handle in all_handles:
            this.get_root().add_plugs(
                handle.plugs['tx'],
                handle.plugs['ty'],
                handle.plugs['tz']
            )

        this.base_handles = list(all_handles)
        this.handles = list(all_handles)

        all_joints = [start_joint]
        all_joints.extend(merge_lists(upper_joints, lower_joints))
        all_joints.append(end_joint)
        this.start_joint = start_joint
        this.end_joint = end_joint
        this.upper_joints = upper_joints
        this.lower_joints = lower_joints
        this.start_handle = start_handle
        this.end_handle = end_handle
        this.upper_handles = upper_handles
        this.lower_handles = lower_handles
        this.joints = all_joints

        return this

    def create_deformation_rig(self, **kwargs):
        # super(DoubleSurfaceSpline, self).create_deformation_rig(**kwargs)

        root = self.get_root()

        def create_deform_joints(*part_joints):
            deform_joints = []
            for j, part_joint in enumerate(part_joints):
                deform_joint = part_joint.create_child(
                    Joint,
                    parent=root.deform_group,
                    functionality_name='Bind',
                )
                deform_joint.plugs['radius'].set_value(part_joint.size)
                deform_joint.zero_rotation()
                deform_joint.plugs.set_values(
                    overrideEnabled=True,
                    overrideRGBColors=True,
                    overrideColorRGB=env.colors['bindJoints'],
                    radius=part_joint.plugs['radius'].get_value(),
                    type=part_joint.plugs['type'].get_value(),
                    side=part_joint.plugs['side'].get_value(),
                    drawStyle=part_joint.plugs['drawStyle'].get_value(2)
                )
                part_joint.plugs['rotateOrder'].connect_to(deform_joint.plugs['rotateOrder'])
                part_joint.plugs['inverseScale'].connect_to(deform_joint.plugs['inverseScale'])
                part_joint.plugs['jointOrient'].connect_to(deform_joint.plugs['jointOrient'])
                part_joint.plugs['translate'].connect_to(deform_joint.plugs['translate'])
                part_joint.plugs['rotate'].connect_to(deform_joint.plugs['rotate'])
                part_joint.plugs['scale'].connect_to(deform_joint.plugs['scale'])
                part_joint.plugs['drawStyle'].set_value(2)

                if self.joint_chain:
                    joint_parent = deform_joint
                deform_joints.append(deform_joint)
            return deform_joints

        start_bind_joint, end_bind_joint = create_deform_joints(self.start_joint, self.end_joint)
        upper_bind_joints = create_deform_joints(*self.upper_joints)
        lower_bind_joints = create_deform_joints(*self.lower_joints)
        all_bind_joints = [start_bind_joint, end_bind_joint]
        all_bind_joints.extend(upper_bind_joints)
        all_bind_joints.extend(lower_bind_joints)

        self.deform_joints = all_bind_joints
        self.base_deform_joints = all_bind_joints

        for deform_joint in self.deform_joints:
            deform_joint.plugs['v'].set_value(False)

        upper_spline_parent_group = self.create_child(
            Transform,
            segment_name='Spline',
            differentiation_name='Upper'
        )
        upper_spline_drivers = [self.start_joint]
        upper_spline_drivers.extend(self.upper_joints)
        upper_spline_drivers.append(self.end_joint)

        upper_spline, upper_spline_handles, upper_spline_joints, upper_roll_joints = spb.create_spline(
            self,
            upper_spline_parent_group,
            upper_spline_drivers
        )

        self.upper_main_curve = upper_spline

        lower_spline_parent_group = self.create_child(
            Transform,
            segment_name='Spline',
            differentiation_name='Lower'
        )
        lower_spline_drivers = [self.start_joint]
        lower_spline_drivers.extend(self.lower_joints)
        lower_spline_drivers.append(self.end_joint)
        lower_spline, lower_spline_handles, lower_spline_joints, lower_roll_joints = spb.create_spline(
            self,
            lower_spline_parent_group,
            lower_spline_drivers
        )
        self.lower_main_curve = lower_spline

        all_spline_joints = upper_spline_joints + lower_spline_joints
        all_spline_handles = upper_spline_handles + lower_spline_handles
        all_handles = list(self.handles)
        all_handles.extend(all_spline_handles)
        self.set_handles(all_handles)
        self.secondary_handles = all_spline_handles
        self.deform_joints.extend(self.spline_joints)
        self.spline_joints = all_spline_joints
        self.spline_handles = all_spline_handles
        self.upper_spline_handles = upper_spline_handles
        self.lower_spline_handles = lower_spline_handles

        for up_joint in upper_spline_joints:
            up_joint.plugs['type'].set_value(18)
            up_joint.plugs['otherType'].set_value('upper_spline')

        for lower_joint in lower_spline_joints:
            lower_joint.plugs['type'].set_value(18)
            lower_joint.plugs['otherType'].set_value('lower_spline')

        for j in self.upper_joints:
            j.plugs['type'].set_value(18)
            j.plugs['otherType'].set_value('upper')

        for j in self.lower_joints:
            j.plugs['type'].set_value(18)
            j.plugs['otherType'].set_value('lower')

        for handle in all_spline_handles:
            root.add_plugs(
                handle.plugs['tx'],
                handle.plugs['ty'],
                handle.plugs['tz']
            )

        # Backward compatible "Slide" values
        joint_parameters = kwargs.pop('joint_parameters', None)
        # if not joint_parameters:
        #     print 'NO JOINT PARMS FOUND: %s' % self
        # elif not len(all_spline_handles) == len(joint_parameters):
        #     print 'param count mismatch ', len(all_spline_handles), len(joint_parameters), self

        if joint_parameters and len(all_spline_handles) == len(joint_parameters):
            upper_joint_parameters = joint_parameters[:len(joint_parameters) / 2]
            lower_joint_parameters = joint_parameters[len(joint_parameters) / 2:]
            for i in range(len(upper_joint_parameters)):
                slide_value = 1.0 / (len(upper_joint_parameters)-1) * i + (upper_joint_parameters[i] * 0.1)
                upper_spline_handles[i].plugs['Slide'].set_value(slide_value)
            for i in range(len(lower_joint_parameters)):
                slide_value = 1.0 / (len(lower_joint_parameters)-1) * i + (lower_joint_parameters[i] * 0.1)
                lower_spline_handles[i].plugs['Slide'].set_value(slide_value)

        if self.secondary_parameters and len(all_spline_handles) == len(self.secondary_parameters):
            for i in range(len(all_spline_handles)):
                all_spline_handles[i].plugs['Slide'].set_value(self.secondary_parameters[i])

        if self.secondary_translations and len(all_spline_handles) == len(self.secondary_translations):
            for i in range(len(all_spline_handles)):
                all_spline_handles[i].groups[-2].plugs['translate'].set_value(self.secondary_translations[i])

        self.consolidate_slide_values()

        for i in range(len(all_spline_handles)):
            all_spline_handles[i].plugs['Slide'].set_locked(True)

        get_closest = self.controller.scene.get_closest_curve_parameter
        upper_parameters = [get_closest(upper_spline.m_object, list(x.get_translation())) for x in upper_spline_handles]
        upper_volume_plugs = None
        upper_auto_volume_plugs = None
        upper_twist_plugs = None

        for i, base_handle in enumerate(upper_spline_drivers):
            segment_character = rig_factory.index_dictionary[i].upper()
            paremeter_plug = base_handle.create_plug(
                'parameter_driver',
                at='double',
                dv=0.0
            )
            tweak_getter = base_handle.create_child(
                Locator,
                segment_name='%sTweakGetter%s' % (base_handle.segment_name, segment_character)
            )
            nearest_point_on_curve = tweak_getter.create_child(
                DependNode,
                node_type='nearestPointOnCurve'
            )
            tweak_getter.plugs['visibility'].set_value(False)
            upper_spline.plugs['worldSpace'].element(0).connect_to(nearest_point_on_curve.plugs['inputCurve'])
            tweak_getter.plugs['worldPosition'].element(0).connect_to(nearest_point_on_curve.plugs['inPosition'])
            nearest_point_on_curve.plugs['parameter'].connect_to(paremeter_plug)

        if upper_parameters and self.create_twist_joints:
            twist_drivers = []
            upper_driver_handles = [self.start_handle]
            upper_driver_handles.extend(self.upper_handles)
            upper_driver_handles.append(self.end_handle)
            for spline_driver in upper_driver_handles:
                twist_drivers.append(spline_driver.create_plug(
                    'UpperTwist',
                    at='double',
                    keyable=True
                ))
            root.add_plugs(twist_drivers)

            upper_twist_plugs = jvu.generate_distribution_plugs(
                upper_spline,
                upper_parameters,
                twist_drivers,
                'Twist'
            )

        if upper_parameters and self.create_scale_joints:
            volume_drivers = [x.plugs['scaleZ'] for x in upper_spline_drivers]
            root.add_plugs(volume_drivers)
            upper_volume_plugs = jvu.generate_distribution_plugs(
                upper_spline,
                upper_parameters,
                volume_drivers,
                'Volume',
                subtract_value=1.0
            )
        if upper_parameters and self.create_auto_volume:
            upper_auto_volume_plugs = jvu.generate_volume_plugs(
                upper_spline,
                upper_parameters,
            )
            upper_auto_volume_plug = self.create_plug(
                'UpperAutoVolume',
                at='double',
                dv=1.0,
                k=True,
                min=0.0,
                max=10.0
            )
            upper_min_auto_volume_plug = self.create_plug(
                'UpperMinAutoVolume',
                at='double',
                dv=-2.0,
                k=True
            )
            upper_max_auto_volume_plug = self.create_plug(
                'UpperMaxAutoVolume',
                at='double',
                dv=2.0,
                k=True
            )
            upper_auto_volume_plug.connect_to(upper_spline.plugs['AutoVolume'])
            upper_min_auto_volume_plug.connect_to(upper_spline.plugs['MinAutoVolume'])
            upper_max_auto_volume_plug.connect_to(upper_spline.plugs['MaxAutoVolume'])
            root.add_plugs(
                upper_auto_volume_plug
            )
        for i in range(len(upper_spline_handles)):
            index_character = rig_factory.index_dictionary[i].upper()
            volume_add = self.create_child(
                DependNode,
                segment_name='AddVolume%s' % index_character,
                node_type='plusMinusAverage'
            )
            if upper_volume_plugs:
                upper_volume_plugs[i].connect_to(volume_add.plugs['input2D'].element(0).child(0))
                upper_volume_plugs[i].connect_to(volume_add.plugs['input2D'].element(0).child(1))
            if upper_auto_volume_plugs:
                upper_auto_volume_plugs[i][0].connect_to(volume_add.plugs['input2D'].element(1).child(0))
                upper_auto_volume_plugs[i][1].connect_to(volume_add.plugs['input2D'].element(1).child(1))
            if upper_twist_plugs:
                upper_twist_plugs[i].connect_to(upper_spline_handles[i].groups[-1].plugs['rotateZ'])
            volume_add.plugs['input2D'].element(2).child(0).set_value(1.0)
            volume_add.plugs['input2D'].element(2).child(1).set_value(1.0)

            volume_add.plugs['output2D'].child(0).connect_to(upper_spline_handles[i].groups[-1].plugs['sx'])
            volume_add.plugs['output2D'].child(1).connect_to(upper_spline_handles[i].groups[-1].plugs['sz'])


        for i, base_handle in enumerate(lower_spline_drivers[1:-1]):
            segment_character = rig_factory.index_dictionary[i].upper()
            paremeter_plug = base_handle.create_plug(
                'parameter_driver',
                at='double',
                dv=0.0
            )
            tweak_getter = base_handle.create_child(
                Locator,
                segment_name='%sTweakGetter%s' % (base_handle.segment_name, segment_character)
            )
            nearest_point_on_curve = base_handle.create_child(
                DependNode,
                node_type='nearestPointOnCurve'
            )
            tweak_getter.plugs['visibility'].set_value(False)
            lower_spline.plugs['worldSpace'].element(0).connect_to(nearest_point_on_curve.plugs['inputCurve'])
            tweak_getter.plugs['worldPosition'].element(0).connect_to(nearest_point_on_curve.plugs['inPosition'])
            nearest_point_on_curve.plugs['parameter'].connect_to(paremeter_plug)

        lower_parameters = [get_closest(lower_spline.m_object, list(x.get_translation())) for x in lower_spline_handles]

        lower_volume_plugs = None
        lower_auto_volume_plugs = None
        lower_twist_plugs = None

        if lower_parameters and self.create_twist_joints:
            twist_drivers = []
            lower_driver_handles = [self.start_handle]
            lower_driver_handles.extend(self.lower_handles)
            lower_driver_handles.append(self.end_handle)
            for spline_driver in lower_driver_handles:
                twist_drivers.append(spline_driver.create_plug(
                    'LowerTwist',
                    at='double',
                    keyable=True
                ))
            root.add_plugs(twist_drivers)

            lower_twist_plugs = jvu.generate_distribution_plugs(
                lower_spline,
                lower_parameters,
                twist_drivers,
                'Twist'
            )

        if lower_parameters and self.create_scale_joints:
            volume_drivers = [x.plugs['scaleZ'] for x in lower_spline_drivers]
            root.add_plugs(volume_drivers)
            lower_volume_plugs = jvu.generate_distribution_plugs(
                lower_spline,
                lower_parameters,
                volume_drivers,
                'Volume',
                subtract_value=1.0
            )
        if lower_parameters and self.create_auto_volume:
            lower_auto_volume_plugs = jvu.generate_volume_plugs(
                lower_spline,
                lower_parameters,
            )
            lower_auto_volume_plug = self.create_plug(
                'LowerAutoVolume',
                at='double',
                dv=1.0,
                k=True,
                min=0.0,
                max=10.0
            )
            lower_min_auto_volume_plug = self.create_plug(
                'LowerMinAutoVolume',
                at='double',
                dv=-2.0,
                k=True
            )
            lower_max_auto_volume_plug = self.create_plug(
                'LowerMaxAutoVolume',
                at='double',
                dv=2.0,
                k=True
            )
            lower_auto_volume_plug.connect_to(lower_spline.plugs['AutoVolume'])
            lower_min_auto_volume_plug.connect_to(lower_spline.plugs['MinAutoVolume'])
            lower_max_auto_volume_plug.connect_to(lower_spline.plugs['MaxAutoVolume'])
            root.add_plugs(
                lower_auto_volume_plug
            )

        for i in range(len(lower_spline_handles)):
            index_character = rig_factory.index_dictionary[i].lower()
            volume_add = self.create_child(
                DependNode,
                segment_name='AddVolume%s' % index_character,
                node_type='plusMinusAverage'
            )
            if lower_volume_plugs:
                lower_volume_plugs[i].connect_to(volume_add.plugs['input2D'].element(0).child(0))
                lower_volume_plugs[i].connect_to(volume_add.plugs['input2D'].element(0).child(1))
            if lower_auto_volume_plugs:
                lower_auto_volume_plugs[i][0].connect_to(volume_add.plugs['input2D'].element(1).child(0))
                lower_auto_volume_plugs[i][1].connect_to(volume_add.plugs['input2D'].element(1).child(1))

            if lower_twist_plugs:
                lower_twist_plugs[i].connect_to(lower_spline_handles[i].groups[-1].plugs['rotateZ'])
            volume_add.plugs['input2D'].element(2).child(0).set_value(1.0)
            volume_add.plugs['input2D'].element(2).child(1).set_value(1.0)

            volume_add.plugs['output2D'].child(0).connect_to(lower_spline_handles[i].groups[-1].plugs['sx'])
            volume_add.plugs['output2D'].child(1).connect_to(lower_spline_handles[i].groups[-1].plugs['sz'])


    def consolidate_slide_values(self):
        for handle in self.upper_spline_handles:
            position = list(handle.get_translation())
            closest_parameter = self.controller.scene.get_closest_curve_parameter(
                self.upper_main_curve.m_object,
                list(handle.get_translation())
            )
            upper_spans = self.upper_main_curve.plugs['spans'].get_value()
            if upper_spans == 0:
                raise Exception('The upper_main_curve for %s had zero spans' % self)
            handle.plugs['Slide'].set_value(closest_parameter / upper_spans)
            self.controller.scene.xform(handle.groups[2], ws=True, t=position)
            handle.groups[3].plugs['translate'].set_value([0.0, 0.0, 0.0])
            handle.plugs['translate'].set_value([0.0, 0.0, 0.0])

        for handle in self.lower_spline_handles:
            position = list(handle.get_translation())
            closest_parameter = self.controller.scene.get_closest_curve_parameter(
                self.lower_main_curve.m_object,
                list(handle.get_translation())
            )
            lower_spans = self.lower_main_curve.plugs['spans'].get_value()
            if lower_spans == 0:
                raise Exception('The lower_main_curve curve for %s had zero spans' % self)
            handle.plugs['Slide'].set_value(closest_parameter / lower_spans)
            self.controller.scene.xform(handle.groups[2], ws=True, t=position)
            handle.groups[3].plugs['translate'].set_value([0.0, 0.0, 0.0])
            handle.plugs['translate'].set_value([0.0, 0.0, 0.0])

    def get_toggle_blueprint(self):
        blueprint = super(DoubleSurfaceSpline, self).get_toggle_blueprint()
        blueprint['handle_data'] = self.get_handle_data()
        return blueprint

    def get_blueprint(self):
        blueprint = super(DoubleSurfaceSpline, self).get_blueprint()
        blueprint['handle_data'] = self.get_handle_data()
        blueprint['up_vector_position'] = list(self.up_vector_transform.get_translation()) if self.up_vector_transform else None

        return blueprint

    def get_handle_data(self):
        handle_data = []
        if not self.base_handles:
            raise Exception('No Base Handles Found')
        for i, handle in enumerate(self.base_handles):
            handle = self.base_handles[i]
            handle_data.append(
                dict(
                    klass=handle.__class__.__name__,
                    module=handle.__module__,
                    vertices=[(x.mesh.get_selection_string(), x.index) for x in handle.vertices],
                    matrix=list(self.matrices[i]),
                    root_name=handle.root_name,
                    segment_name=handle.segment_name,
                    differentiation_name=handle.differentiation_name,
                    size=handle.size,
                    side=handle.side
                )
            )
        return handle_data

def is_even(number):
    if (number % 2) == 0:
        return True
    return False


def create_handle_data(count, side, root_name, segment_name, size):
    if count < 2:
        raise Exception('Count must be at-least 2')
    if size < 0.001:
        raise Exception('size is to small to generate handle data')
    data = []
    if side in ['left', 'right']:
        for x in range(count):
            if x == 0:
                handle_segment_name = 'InCorner'
            elif x == count - 1:
                handle_segment_name = 'OutCorner'
            else:
                handle_segment_name = '%s%s' % (segment_name, rig_factory.index_dictionary[x - 1].title())
            data.append(dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side=side,
                matrix=Matrix([(size*2) * x, 0.0, 0.0]) if side == 'left' else Matrix([(size*-2) * x, 0.0, 0.0])
            ))
    elif side == 'center':
        for x in range(count):
            if x == 0:
                handle_segment_name = 'Start'
            elif x == count-1:
                handle_segment_name = 'End'
            else:
                handle_segment_name = '%s%s' % (segment_name, rig_factory.index_dictionary[x - 1].title())
            data.append(dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side=side,
                matrix=Matrix([0.0, (size*2) * x, 0.0])
            ))
    elif side is None:
        even_count = is_even(count)
        side_count = count / 2 if even_count else (count - 1) / 2
        for x in range(side_count):
            if x == side_count-1:
                handle_segment_name = 'Corner'
            else:
                handle_segment_name = '%s%s' % (segment_name, rig_factory.index_dictionary[x].title())
            position = [(size * -2) * (x + 1), 0.0, 0.0]
            if x == 0 and even_count:
                position = [(size * -1) * (x + 1), 0.0, 0.0]
            data.insert(0, dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side='right',
                matrix=Matrix(position)
            ))

        if not even_count:
            data.append(dict(
                root_name=root_name,
                segment_name='%s%s' % (segment_name, rig_factory.index_dictionary[0].title()),
                size=size,
                side='center',
                matrix=Matrix([0.0, 0.0, 0.0])
            ))
        for x in range(side_count):
            position = [(size * 2) * (x + 1), 0.0, 0.0]
            if x == side_count-1:
                handle_segment_name = 'Corner'
            else:
                handle_segment_name = '%s%s' % (segment_name, rig_factory.index_dictionary[x].title())
            data.append(dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side='left',
                matrix=Matrix(position)
            ))

    return data


def chunks(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i:i + n]


def merge_lists(list_1, list_2):
    merged_list = []
    for a, b in zip(list_1, list_2):
        merged_list.append(a)
        merged_list.append(b)
    return merged_list
