"""
Usage:
Open Command Shell and run these:
cd 'c:\Program Files\Autodesk\Maya2019\bin'
mayapy G:/Rigging/Users/ehsanm/code_share/batch_rig_build.py
"""
import sys
import os
import multiprocessing
import copy


DEV_MODE = True
UPDATE_GEOMETRY = True
BUILD_FACE = True
BUILD_FROM_WORK = False
SAVE = False
PUBLISH = False
MOCK_PUBLISH = True
COMMENT = 'mock publish lid test'
SCRIPT_PATH = None
RUN_IN_PARALLEL = True
PROJECT = 'RBGB'
ENTITIES = [
    'Allie',
    'Boomer',
    'Gimme_Pig',
    'Hopper',
    'Shelly',
    'Winger'
]

if DEV_MODE:
    sys.path.insert(0, 'D:/pipeline/%s/dev/git_repo/irig/src/iRig/iRig_maya/framework' % os.environ['USERNAME'])

import batch_tasks.environment_worker as wkr


def callback(result):
    print 'Finished !', result


if __name__ == "__main__":

    options = dict(
        mock_publish=MOCK_PUBLISH,
        publish=PUBLISH,
        build_work=BUILD_FROM_WORK,
        build_face=BUILD_FACE,
        update_geometry=UPDATE_GEOMETRY,
        dev_mode=DEV_MODE,
        comment=COMMENT,
        script_path=SCRIPT_PATH,
        save=SAVE,
        standalone=True
    )

    if RUN_IN_PARALLEL:
        p = multiprocessing.Pool(len(ENTITIES))
        result = p.map_async(
            wkr.do_task,
            [[PROJECT, x, options] for x in ENTITIES],
            callback=callback
            )
        result.get()
    else:
        for entity in ENTITIES:
            wkr.do_task([PROJECT, entity, dict(options)])

