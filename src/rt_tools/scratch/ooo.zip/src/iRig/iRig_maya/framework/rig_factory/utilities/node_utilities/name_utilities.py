import rig_factory

DEFAULT_SEGMENT_NAME = 'root'


def create_name_string(**kwargs):
    """
    This function names all objects in the framework
    @param kwargs: Data used to construct name
    @return: str
    """
    allow_underscores = kwargs.get('allow_underscores', False)
    name = kwargs.get('name', None)
    if name:
        return name
    root_name = kwargs.get('root_name', None)
    if root_name is not None:
        if not allow_underscores and '_' in root_name:
            raise Exception('Invalid character in root_name : "%s"' % root_name)
        if len(root_name) == 0:
            raise Exception('Empty string "" is not a valid root name')
        if not root_name[0].isupper():
            raise Exception('root_name "%s" must be CamelCase' % root_name)
    functionality_name = kwargs.get('functionality_name', None)
    differentiation_name = kwargs.get('differentiation_name', None)
    side = kwargs.get('side', None)
    segment_name = kwargs.get('segment_name', None)
    suffix = kwargs.get('suffix', None)

    if side in rig_factory.settings_data['side_prefixes']:
        if root_name is not None:
            name = '%s_%s' % (rig_factory.settings_data['side_prefixes'][side], root_name)
        else:
            name = rig_factory.settings_data['side_prefixes'][side]
    elif root_name is not None:
        name = root_name

    if isinstance(segment_name, basestring):
        if not segment_name[0].isupper():
            raise Exception('segment_name "%s" must be CamelCase' % segment_name)
        if name:
            name = '%s_%s' % (name, segment_name)
        else:
            name = segment_name
    else:
        raise Exception('Invalid segment_name type: "%s"' % type(segment_name))
    if differentiation_name is not None:
        if not differentiation_name[0].isupper():
            raise Exception('differentiation_name "%s" must be CamelCase' % differentiation_name)
        if '_' in differentiation_name:
            raise Exception('Invalid character in differentiation_name : "%s"' % differentiation_name)
        name = '%s_%s' % (name, differentiation_name)
    if functionality_name is not None:
        if not functionality_name[0].isupper():
            raise Exception('functionality_name "%s" must be CamelCase' % functionality_name)
        if '_' in functionality_name:
            raise Exception('Invalid character in functionality_name : "%s"' % functionality_name)
        name = '%s_%s' % (name, functionality_name)
    if suffix:
        if not suffix.istitle():
            raise Exception('Invalid character in suffix : "%s"' % suffix)
        name = '%s_%s' % (name, suffix)
    return name