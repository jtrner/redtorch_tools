"""
Part version of the `Projection` object.
Supports:
- One texture for projection.
- Parenting to other objects (but not to self).
- Menu items for:
    ~ Assigning projection to selection.
    ~ Un-assigning projection to selection.
    ~ Updating guide matrix in rig state.

Automatically stores the file path for the projected texture; users are
required to set the connected `file` node manually.
"""

from warnings import warn
from collections import OrderedDict
from rig_factory.objects.part_objects.part import PartGuide, Part
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.rig_objects.projection import Projection
from rig_factory.objects.base_objects.properties import (
    DataProperty, ObjectProperty
)
from rig_math.matrix import Matrix


class ProjectionPartGuide(PartGuide):

    _place_3d_texture_matrix = DataProperty(
        name='_place_3d_texture_matrix'
    )

    default_settings = OrderedDict((
        ('root_name', 'ProjectionPart'),
        ('side', 'center'),
        ('size', 1.0),
    ))

    projection = ObjectProperty(
        name='projection'
    )

    def __init__(self, **kwargs):
        super(ProjectionPartGuide, self).__init__(**kwargs)
        self.toggle_class = ProjectionPart.__name__

    @classmethod
    def create(cls, *args, **kwargs):
        this = super(ProjectionPartGuide, cls).create(*args, **kwargs)

        this.projection = projection = this.create_child(
            Projection,
            root_name=this.root_name + '_projection'
        )
        projection.place_3d_texture.set_matrix(
            Matrix(this._place_3d_texture_matrix or (0, 0, 0))
        )

        return this

    def get_toggle_blueprint(self):
        self._place_3d_texture_matrix = list(
            self.projection.place_3d_texture.get_matrix()
        )
        return super(ProjectionPartGuide, self).get_toggle_blueprint()

    def get_blueprint(self):
        self._place_3d_texture_matrix = list(
            self.projection.place_3d_texture.get_matrix()
        )
        return super(ProjectionPartGuide, self).get_blueprint()


class ProjectionPart(Part):

    _place_3d_texture_matrix = DataProperty(
        name='_place_3d_texture_matrix'
    )
    _geometries = DataProperty(
        name='_geometries'
    )
    _projection_file_path = DataProperty(
        name='_projection_file_path'
    )

    place_2d_texture = ObjectProperty(
        name='place_2d_texture'
    )
    file_node = ObjectProperty(
        name='file_node'
    )
    projection = ObjectProperty(
        name='projection'
    )

    @classmethod
    def create(cls, *args, **kwargs):
        this = super(ProjectionPart, cls).create(*args, **kwargs)

        # place_2d_texture node.

        this.place_2d_texture = place_2d_texture = this.create_child(
            DependNode,
            node_type='place2dTexture',
            root_name=this.root_name + '_place2dTexture'
        )

        # file node.

        this.file_node = file_node = this.create_child(
            DependNode,
            node_type='file',
            root_name=this.root_name + '_file'
        )
        file_node.plugs['fileTextureName'].set_value(
            this._projection_file_path or ''
        )
        connections = (
            ('wrapU',           'wrapU'),
            ('rotateFrame',     'rotateFrame'),
            ('mirrorU',         'mirrorU'),
            ('vertexUvThree',   'vertexUvThree'),
            ('repeatUV',        'repeatUV'),
            ('vertexUvTwo',     'vertexUvTwo'),
            ('noiseUV',         'noiseUV'),
            ('outUV',           'uvCoord'),
            ('vertexCameraOne', 'vertexCameraOne'),
            ('stagger',         'stagger'),
            ('mirrorV',         'mirrorV'),
            ('translateFrame',  'translateFrame'),
            ('vertexUvOne',     'vertexUvOne'),
            ('rotateUV',        'rotateUV'),
            ('wrapV',           'wrapV'),
            ('offset',          'offset'),
            ('outUvFilterSize', 'uvFilterSize'),
            ('coverage',        'coverage'),
        )
        for s, d in connections:
            place_2d_texture.plugs[s].connect_to(file_node.plugs[d])

        # projection object.

        this.projection = projection = this.create_child(
            Projection,
            root_name=this.root_name + '_projection'
        )
        projection.place_3d_texture.set_matrix(
            Matrix(this._place_3d_texture_matrix or (0, 0, 0))
        )
        file_node.plugs['outColor'].connect_to(
            projection.projection.plugs['image']
        )
        if this._place_3d_texture_matrix:
            projection.place_3d_texture.set_matrix(
                Matrix(this._place_3d_texture_matrix)
            )
        if this._geometries:
            projection.shader.add_geometries([
                this.get_root().geometry[x] for x in this._geometries
                if x in this.get_root().geometry
            ])

        return this

    def get_toggle_blueprint(self):
        blueprint = super(ProjectionPart, self).get_toggle_blueprint()
        blueprint['_place_3d_texture_matrix'] = self._place_3d_texture_matrix
        blueprint['rig_data']['_projection_file_path'] = (
            self.file_node.plugs['fileTextureName'].get_value()
        )
        blueprint['rig_data']['_geometries'] = [
            x.get_selection_string()
            for x in self.projection.shader.geometries
        ]
        return blueprint

    def get_blueprint(self):
        blueprint = super(ProjectionPart, self).get_blueprint()
        blueprint['_place_3d_texture_matrix'] = self._place_3d_texture_matrix
        blueprint['_projection_file_path'] = (
            self.file_node.plugs['fileTextureName'].get_value()
        )
        blueprint['_geometries'] = [
            x.get_selection_string()
            for x in self.projection.shader.geometries
        ]
        return blueprint

    def add_selected_geometries(self):
        # type: () -> None
        """
        Assigns the projection's shader to all geometries in the
        current selection.
        """
        selection = [
            self.controller.named_objects[x]
            for x in self.controller.get_selected_mesh_names()
        ]
        self.projection.shader.add_geometries(selection)
        warn('add_selected_geometries: Added items %s' % selection)

    def remove_selected_geometries(self):
        # type: () -> None
        """
        Un-assigns the projection's shader from all geometries in the
        current selection.
        """
        selection = [
            self.controller.named_objects[x]
            for x in self.controller.get_selected_mesh_names()
        ]
        self.projection.shader.remove_geometries(selection)
        warn('add_selected_geometries: Removed items %s' % selection)

    def save_projection_matrix(self):
        # type: () -> None
        """
        Updates the projection's matrix in the guide blueprint to match
        the current projection matrix in rig state.
        """
        self._place_3d_texture_matrix = matrix = list(
            self.projection.place_3d_texture.get_matrix()
        )
        warn('add_selected_geometries: Saved guide matrix %s' % matrix)
