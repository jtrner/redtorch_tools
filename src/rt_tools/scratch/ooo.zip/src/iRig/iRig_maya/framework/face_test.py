import rig_factory.build.utilities.controller_utilities as cut
from rig_factory.objects.face_network_objects.face_network import FaceNetwork
from rig_factory.objects.part_objects.surface_spline import SurfaceSpline
from rig_factory.objects.part_objects.container import Container
from rig_math.matrix import Matrix

controller = cut.initialize_development_controller(
    'RCL',
    'Paxton_Sandbox',
    standalone=True
)

root = controller.create_object(
    Container,
    root_name='Body'
)

controller.set_root(root)

root.create_part(
    SurfaceSpline,
    matrices=[
        Matrix(),
        Matrix(),
        Matrix(),
        Matrix()
    ],
    root_name='Lip'
)


handles = root.get_handles()

face_network = controller.create_object(
    FaceNetwork,
    root_name='Face'
)
controller.set_face_network(face_network)

face_network.add_selected_handles(
    handles[0],
    attributes=['tx']
)

mouth_vertical = face_network.create_group(
    segment_name='MouthVertical',
    driver_plug=controller.root.plugs['ty']
)
handles[0].plugs['tx'].set_value(1.0)
mouth_vertical.create_face_target(driver_value=1.0)
# handles[0].plugs['tx'].set_value(0.0)
# mouth_vertical.create_face_target(driver_value=2.0)

print len(mouth_vertical.sdk_group.animation_curves.values()), 'Curves created'

key_frames = []
for driver_plug in mouth_vertical.sdk_group.animation_curves:
    for x in mouth_vertical.sdk_group.animation_curves[driver_plug].keyframes:
        key_frames.append(x)

print len(key_frames), 'Keys created'
