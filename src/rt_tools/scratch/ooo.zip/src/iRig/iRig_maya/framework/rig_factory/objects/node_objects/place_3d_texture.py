from rig_factory.objects.node_objects.transform import Transform


class Place3dTexture(Transform):
    """
    Represents a maya `place3dTexture` node.
    """

    def __init__(self, **kwargs):
        super(Place3dTexture, self).__init__(**kwargs)
        self.node_type = 'place3dTexture'