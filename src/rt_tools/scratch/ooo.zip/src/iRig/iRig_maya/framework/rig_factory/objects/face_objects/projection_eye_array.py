from rig_factory.objects.face_objects.eye_array import EyeArrayGuide, EyeArray


class ProjectionEyeArrayGuide(EyeArrayGuide):

    member_type = 'ProjectionEyeGuide'

    def __init__(self, **kwargs):
        super(ProjectionEyeArrayGuide, self).__init__(**kwargs)
        self.toggle_class = ProjectionEyeArray.__name__


class ProjectionEyeArray(EyeArray):
    pass
