from rig_factory.objects.base_objects.properties import ObjectProperty
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.rig_objects.grouped_handle import GimbalHandle, GroupedHandle
from rig_math.matrix import Matrix
import rig_factory.environment as env
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.part_objects.part import PartGuide
from rig_factory.objects.rig_objects.spline_array import SplineArray
from rig_factory.objects.rig_objects.capsule import Capsule
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve

import rig_factory


class TeethGuide(PartGuide):

    capsules = ObjectListProperty(
        name='capsules'
    )
    locators = ObjectListProperty(
        name='locators'
    )
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )

    base_joints = ObjectListProperty(
        name='base_joints'
    )
    joint_count = DataProperty(
        name='joint_count',
        default_value=9
    )
    count = DataProperty(
        name='count',
        default_value=5
    )
    default_settings = {
        'root_name': 'Teeth',
        'size': 1.0,
        'joint_count': 33
    }

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['side'] = None
        this = super(TeethGuide, cls).create(controller, **kwargs)
        root = this.get_root()
        size_plug = this.plugs['size']
        size = this.size
        root_name = this.root_name
        joint_count = this.joint_count
        count = this.count
        length_multiply_plug = this.create_plug(
            'LengthMultiply',
            at='double',
            min=0.0,
            max=1.0,
            dv=1.0,
            k=False
        )
        handles_data = create_handle_data(count, None, root_name, '', size)
        joints_data = create_handle_data(joint_count, None, root_name, 'Spline', size)
        spline_joints = []
        for handle_data in handles_data:
            handle = this.create_handle(
                **handle_data
            )
            handle.mesh.assign_shading_group(root.shaders[handle_data['side']].shading_group)

        curve_degree = 1 if this.count < 3 else 2
        positions = [x.get_translation() for x in this.handles]

        nurbs_curve_transform = this.create_child(
            Transform,
            root_name='%sCurve' % root_name,
        )
        nurbs_curve = nurbs_curve_transform.create_child(
            NurbsCurve,
            degree=curve_degree,
            root_name='%sCurveNcv' % root_name,
            positions=positions
        )
        nurbs_curve.plugs['v'].set_value(False)
        curve_info = nurbs_curve.create_child(
            DependNode,
            node_type='curveInfo'
        )
        nurbs_curve.plugs['worldSpace'].element(0).connect_to(curve_info.plugs['inputCurve'])

        segment_parameter = 1.0 / (joint_count - 1)

        for i, joint_data in enumerate(joints_data):
            index_character = rig_factory.index_dictionary[i].capitalize()

            spline_joint = this.create_child(
                Joint,
                **joint_data
            )

            spline_joint.plugs.set_values(
                overrideRGBColors=True,
                overrideColorRGB=env.secondary_colors['bindJoints'],
                overrideEnabled=True,
                type=18,
                otherType='spline'
            )

            point_on_curve_info = spline_joint.create_child(
                DependNode,
                node_type='pointOnCurveInfo'
            )
            parameter_multiply_node = spline_joint.create_child(
                DependNode,
                segment_name='Parameter%s' % index_character,
                node_type='multiplyDivide'
            )
            slide_plug = spline_joint.create_plug(
                'Slide',
                at='float',
                min=(segment_parameter * i * -1.0) * 10,
                max=(1.0 - (segment_parameter * i)) * 10,
                dv=0.0,
                keyable=True
            )

            nurbs_curve.plugs['worldSpace'].element(0).connect_to(point_on_curve_info.plugs['inputCurve'])

            point_on_curve_info.plugs['turnOnPercentage'].set_value(True)

            slide_multiply_node = spline_joint.create_child(
                DependNode,
                segment_name='SecondarySlide%s' % index_character,
                node_type='multiplyDivide'
            )
            slide_multiply_node.plugs['operation'].set_value(2)
            slide_multiply_node.plugs['input2X'].set_value(10.0)
            slide_plug.connect_to(slide_multiply_node.plugs['input1X'])
            add_parameter_node = spline_joint.create_child(
                DependNode,
                node_type='addDoubleLinear',
            )
            add_parameter_node.plugs['input1'].set_value(segment_parameter * i)
            slide_multiply_node.plugs['outputX'].connect_to(add_parameter_node.plugs['input2'])
            add_parameter_node.plugs['output'].connect_to(parameter_multiply_node.plugs['input2X'])
            parameter_multiply_node.plugs['outputX'].connect_to(point_on_curve_info.plugs['parameter'])
            length_multiply_plug.connect_to(parameter_multiply_node.plugs['input1X'])
            point_on_curve_info.plugs['result'].child(0).connect_to(spline_joint.plugs['translate'])
            mesh = spline_joint.create_child(
                Mesh
            )
            poly_cylinder = spline_joint.create_child(
                'DependNode',
                node_type='polyCylinder',
            )
            multiply = spline_joint.create_child(
                'DependNode',
                node_type='multiplyDivide',
            )

            mesh.plugs['overrideEnabled'].set_value(True)
            mesh.plugs['overrideDisplayType'].set_value(2)
            poly_cylinder.plugs['roundCap'].set_value(False)
            poly_cylinder.plugs['subdivisionsCaps'].set_value(1)
            poly_cylinder.plugs['subdivisionsAxis'].set_value(8)
            poly_cylinder.plugs['axis'].set_value(env.aim_vector)
            poly_cylinder.plugs['output'].connect_to(mesh.plugs['inMesh'])

            size_plug.connect_to(multiply.plugs['input1X'])
            multiply.plugs['input2X'].set_value(0.25)
            multiply.plugs['outputX'].connect_to(poly_cylinder.plugs['radius'])
            mesh.assign_shading_group(root.shaders[joint_data['side']].shading_group)

            spline_joints.append(spline_joint)

        this.spline_joints = spline_joints
        return this

    def __init__(self, **kwargs):
        super(TeethGuide, self).__init__(**kwargs)
        self.toggle_class = Teeth.__name__

    def get_toggle_blueprint(self):
        blueprint = super(TeethGuide, self).get_toggle_blueprint()
        position_1 = self.handles[0].get_matrix().get_translation()
        position_2 = self.handles[1].get_matrix().get_translation()
        blueprint.update(
            joint_matrices=[list(x.get_matrix()) for x in self.joints],
            matrices=[list(x.get_matrix()) for x in self.base_joints],
            up_vector=(position_2 - position_1).normalize().data
        )
        return blueprint


class Teeth(Part):

    add_root = DataProperty(
        name='add_root'
    )
    fk_mode = DataProperty(
        name='fk_mode'
    )
    sub_levels = DataProperty(
        name='sub_levels'
    )

    up_vector = DataProperty(
        name='up_vector'
    )
    settings_handle = ObjectProperty(
        name='settings_handle'
    )
    joint_matrices = DataProperty(
        name='joint_matrices'
    )

    spline_joints = ObjectListProperty(
        name='spline_joints'
    )
    @classmethod
    def create(cls, controller, **kwargs):
        matrices = kwargs.get('matrices', [])
        if len(matrices) < 4:
            raise Exception('You must provide atleast 4 matrices to create a %s' % cls.__name__)
        this = super(Teeth, cls).create(controller, **kwargs)
        root = this.get_root()
        matrices = this.matrices
        joint_count = len(this.joint_matrices)
        root_name = this.root_name
        side = this.side
        size = this.size
        up_vector = this.up_vector
        joints = []
        spline_joints = []
        segment_handles = []
        sub_segment_handles = []
        for i, matrix in enumerate(matrices):
            joint = this.joint_group.create_child(
                Joint,
                index=i,
                matrix=matrix,
                root_name='%sBase' % root_name,
                segment_name=rig_factory.index_dictionary[i].title()
            )
            joint.zero_rotation()
            joints.append(joint)
            joint.plugs['drawStyle'].set_value(2)

        settings_matrix = joints[0].get_matrix()
        settings_handle = this.create_handle(
            shape='gear',
            root_name=this.root_name,
            segment_name='Settings',
            matrix=settings_matrix,
            parent=joints[0]

        )
        settings_handle.groups[0].plugs['tz'].set_value(size*5 if side == 'right' else size*-5)

        length_multiply_plug = settings_handle.create_plug(
            'length',
            at='double',
            min=0.0,
            max=1.0,
            dv=1.0,
            k=True
        )

        sub_controls_plug = settings_handle.create_plug(
            'sub_controls',
            at='double',
            min=0.0,
            max=1.0,
            dv=0.0,
            k=True
        )

        base_handle = this.create_handle(
            handle_type=GimbalHandle,
            matrix=matrices[1],
            shape='cube',
            root_name='%sBase' % root_name,
            segment_name=rig_factory.index_dictionary[i].title()
        )

        base_tip_handle = this.create_handle(
            handle_type=GroupedHandle,
            matrix=matrices[0],
            shape='diamond',
            root_name='%sBaseSubTip' % root_name,
            size=size*0.33333,
            parent=base_handle.gimbal_handle,
            segment_name=rig_factory.index_dictionary[i].title()
        )

        base_sub_handle = this.create_handle(
            handle_type=GroupedHandle,
            matrix=matrices[1],
            shape='diamond',
            root_name='%sBaseSub' % root_name,
            size=size*0.33333,
            parent=base_handle.gimbal_handle,
            segment_name=rig_factory.index_dictionary[i].title()
        )

        sub_segment_handles.extend([base_tip_handle, base_sub_handle])


        #sub_controls_plug.connect_to(base_tip_handle.plugs['visibility'])
        #sub_controls_plug.connect_to(base_sub_handle.plugs['visibility'])


        distance = (base_handle.get_translation() - base_tip_handle.get_translation()).mag()
        base_shape_matrix = Matrix(0.0, distance*0.5 if side=='right' else distance*-0.5, 0.0)
        base_shape_matrix.set_scale([size, distance, size])
        base_handle.set_shape_matrix(base_shape_matrix)

        controller.create_parent_constraint(
            base_sub_handle,
            joints[1],
            mo=True
        )
        controller.create_parent_constraint(
            base_tip_handle,
            joints[0],
            mo=True
        )

        segment_handle_parent = this
        if this.fk_mode:
            segment_handle_parent = base_handle

        for h, matrix in enumerate(matrices[2:-2]):
            segment_handle = this.create_handle(
                handle_type=GimbalHandle,
                matrix=matrix,
                shape='cube',
                root_name='%sSegment' % root_name,
                index=h,
                parent=segment_handle_parent
            )

            sub_segment_handle = this.create_handle(
                handle_type=GroupedHandle,
                matrix=matrix,
                shape='diamond',
                root_name='%sSubSegment' % root_name,
                size=size * 0.33333,
                parent=segment_handle.gimbal_handle,
                index=h

            )
            controller.create_parent_constraint(
                sub_segment_handle,
                joints[h+2],
                mo=False
            )

            #sub_controls_plug.connect_to(sub_segment_handle.plugs['visibility'])
            segment_handles.append(segment_handle)
            sub_segment_handles.append(sub_segment_handle)
            if this.fk_mode:
                segment_handle_parent = segment_handle


        end_handle = this.create_handle(
            handle_type=GimbalHandle,
            matrix=matrices[-2],
            shape='cube',
            root_name='%sEnd' % root_name,
            parent=segment_handle_parent
        )

        end_tip_handle = this.create_handle(
            handle_type=GroupedHandle,
            matrix=matrices[-1],
            shape='diamond',
            root_name='%sEndSubTip' % root_name,
            size=size * 0.3333,
            parent=end_handle.gimbal_handle
        )
        end_sub_handle = this.create_handle(
            handle_type=GroupedHandle,
            matrix=matrices[-2],
            shape='diamond',
            root_name='%sEndSub' % root_name,
            size=size * 0.33333,
            parent=end_handle.gimbal_handle
        )

        controller.create_parent_constraint(
            end_sub_handle,
            joints[-2],
            mo=True
        )
        controller.create_parent_constraint(
            end_tip_handle,
            joints[-1],
            mo=True
        )
        end_handle.stretch_shape(end_tip_handle.get_matrix())
        #sub_controls_plug.connect_to(end_tip_handle.plugs['visibility'])
        #sub_controls_plug.connect_to(end_sub_handle.plugs['visibility'])
        sub_segment_handles.extend([end_tip_handle, end_sub_handle])

        spline_array = this.create_child(
            SplineArray,
            up_vector=up_vector,
            positions=[list(x.get_translation()) for x in matrices],
            joint_chain=False,
            count=joint_count,
            handle_shape='square',
            handle_color=env.secondary_colors[side],
            extruded_ribbon=True,
            root_name='%sSpline' % root_name,
            side=side
        )

        length_multiply_plug.connect_to(spline_array.plugs['length_multiply'])
        spline_array.ribbon.plugs['inheritsTransform'].set_value(False)
        controller.scene.skinCluster(
            joints,
            spline_array.ribbon.nurbs_surface,
            toSelectedBones=True,
            maximumInfluences=1,
            bindMethod=0,
        )

        joint_parent = this.joint_group
        for transform in spline_array.transforms:
            i = spline_array.transforms.index(transform)
            joint = joint_parent.create_child(
                Joint,
                index=transform.index,
                matrix=transform.get_matrix(),
                segment_name=rig_factory.index_dictionary[i].title()
            )
            joint.zero_rotation()
            spline_joints.append(joint)
            joint_parent = joint
            controller.create_parent_constraint(
                transform,
                joint
            )

        root.add_plugs(
            [
                base_handle.plugs['tx'],
                base_handle.plugs['ty'],
                base_handle.plugs['tz'],
                base_handle.plugs['rx'],
                base_handle.plugs['ry'],
                base_handle.plugs['rz'],
                base_handle.plugs['sx'],
                base_handle.plugs['sy'],
                base_handle.plugs['sz'],
                end_handle.plugs['tx'],
                end_handle.plugs['ty'],
                end_handle.plugs['tz'],
                end_handle.plugs['rx'],
                end_handle.plugs['ry'],
                end_handle.plugs['rz'],
                end_handle.plugs['sx'],
                end_handle.plugs['sy'],
                end_handle.plugs['sz'],
                length_multiply_plug,

            ]
        )
        for sub_handle in segment_handles:
            root.add_plugs(
                [
                    sub_handle.plugs['tx'],
                    sub_handle.plugs['ty'],
                    sub_handle.plugs['tz'],
                    sub_handle.plugs['rx'],
                    sub_handle.plugs['ry'],
                    sub_handle.plugs['rz'],
                    sub_handle.plugs['sx'],
                    sub_handle.plugs['sy'],
                    sub_handle.plugs['sz']
                ]
            )

        for h in sub_segment_handles:
            root.add_plugs(
                [
                    h.plugs['tx'],
                    h.plugs['ty'],
                    h.plugs['tz']
                ]
            )

        root.add_plugs(
            [sub_controls_plug],
            keyable=False
        )
        this.settings_handle = settings_handle
        #this.secondary_handles = sub_handles
        this.joints = spline_joints
        return this




def is_even(number):
    if (number % 2) == 0:
        return True
    return False


def create_handle_data(count, side, root_name, segment_name, size):
    # if count < 2:
    #     raise Exception('Count must be at-least 2')

    data = []
    if side in ['left', 'right']:
        for x in range(count):
            if x == 0:
                handle_segment_name = 'InCorner'
            elif x == count - 1:
                handle_segment_name = 'OutCorner'
            else:
                handle_segment_name = rig_factory.index_dictionary[x - 1].title()
            data.append(dict(
                root_name=root_name,
                segment_name='%s%s' % (segment_name, handle_segment_name),
                size=size,
                side=side,
                matrix=Matrix([(size*2) * x, 0.0, 0.0]) if side == 'left' else Matrix([(size*-2) * x, 0.0, 0.0])
            ))
    elif side == 'center':
        for x in range(count):
            if x == 0:
                handle_segment_name = 'Start'
            elif x == count-1:
                handle_segment_name = 'End'
            else:
                handle_segment_name = rig_factory.index_dictionary[x - 1].title()
            data.append(dict(
                root_name=root_name,
                segment_name='%s%s' % (segment_name, handle_segment_name),
                size=size,
                side=side,
                matrix=Matrix([0.0, (size*2) * x, 0.0])
            ))
    elif side is None:
        even_count = is_even(count)
        side_count = count / 2 if even_count else (count - 1) / 2
        for x in range(side_count):
            if x == side_count-1:
                handle_segment_name = 'Corner'
            else:
                handle_segment_name = rig_factory.index_dictionary[x].title()
            position = [(size * -2) * (x + 1), 0.0, 0.0]
            if x == 0 and even_count:
                position = [(size * -1) * (x + 1), 0.0, 0.0]
            data.insert(0, dict(
                root_name=root_name,
                segment_name='%s%s' % (segment_name, handle_segment_name),
                size=size,
                side='right',
                matrix=Matrix(position)
            ))

        if not even_count:
            data.append(dict(
                root_name=root_name,
                handle_segment_name = rig_factory.index_dictionary[0].title(),
                size=size,
                side='center',
                matrix=Matrix([0.0, 0.0, 0.0])
            ))
        for x in range(side_count):
            position = [(size * 2) * (x + 1), 0.0, 0.0]
            if x == side_count-1:
                handle_segment_name = 'Corner'
            else:
                handle_segment_name = rig_factory.index_dictionary[x].title()
            data.append(dict(
                root_name=root_name,
                segment_name='%s%s' % (segment_name, handle_segment_name),
                size=size,
                side='left',
                matrix=Matrix(position)
            ))

    return data


def chunks(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i:i + n]


def merge_lists(list_1, list_2):
    merged_list = []
    for a, b in zip(list_1, list_2):
        merged_list.append(a)
        merged_list.append(b)
    return merged_list
