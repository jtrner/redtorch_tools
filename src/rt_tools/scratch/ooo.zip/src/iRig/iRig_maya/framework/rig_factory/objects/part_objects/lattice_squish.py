
import copy
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.rig_objects.line import Line
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.base_objects.properties import DataProperty, ObjectProperty
from rig_factory.objects.deformer_objects.lattice import Lattice
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_math.matrix import Matrix
import rig_factory.environment as env
import rig_factory
from rig_factory.utilities.decorators import flatten_args


class LatticeSquishGuide(PartGuide):

    default_settings = {
        'root_name': 'Squish'
    }


    @classmethod
    def create(cls, controller, **kwargs):
        handle_positions = kwargs.get('handle_positions', dict())
        kwargs.setdefault('side', 'center')
        this = super(LatticeSquishGuide, cls).create(controller, **kwargs)
        side = this.side
        size = this.size

        # Create nodes

        joint_1 = this.create_child(
            Joint,
            segment_name='A',
        )
        joint_2 = joint_1.create_child(
            Joint,
            segment_name='B',
        )

        center_joint = this.create_child(
            Joint,
            segment_name='Center',
        )

        handle_1 = this.create_handle(
            segment_name='A',
        )
        handle_2 = this.create_handle(
            segment_name='B',
        )
        up_handle = this.create_handle(
            index=0,
            segment_name='A',
            functionality_name='UpVector'
        )
        locator_1 = joint_1.create_child(
            Locator
        )
        locator_2 = joint_2.create_child(
            Locator
        )
        up_locator = up_handle.create_child(
            Locator
        )

        line = this.create_child(
            Line
        )
        position_1 = handle_positions.get(handle_1.name, [0.0, 0.0, 0.0])
        position_2 = handle_positions.get(
            handle_2.name,
            [x * size * 3 for x in env.side_world_vectors[side]],
        )
        up_position = handle_positions.get(up_handle.name, [0.0, 0.0, size * -3])
        handle_1.plugs['translate'].set_value(position_1)
        handle_2.plugs['translate'].set_value(position_2)
        up_handle.plugs['translate'].set_value(up_position)
        cube_transform = this.create_child(
            Transform,
            segment_name='Cube'
        )
        cube_node = cube_transform.create_child(
            DependNode,
            node_type='polyCube',
        )
        distance_node = this.create_child(
            DependNode,
            node_type='distanceBetween',
        )
        cube_mesh = cube_transform.create_child(
            Mesh
        )
        multiply = this.create_child(
            DependNode,
            node_type='multiplyDivide',
        )

        # Constraints

        joint_1.zero_rotation()
        joint_2.zero_rotation()
        controller.create_aim_constraint(
            handle_2,
            joint_1,
            worldUpType='object',
            worldUpObject=up_handle,
            aimVector=env.aim_vector,
            upVector=env.up_vector
        )
        controller.create_aim_constraint(
            handle_1,
            joint_2,
            worldUpType='object',
            worldUpObject=up_handle,
            aimVector=[x*-1 for x in env.aim_vector],
            upVector=env.up_vector
        )
        controller.create_point_constraint(
            handle_1,
            joint_1
        )
        controller.create_point_constraint(
            handle_2,
            joint_2
        )
        controller.create_point_constraint(
            joint_1,
            joint_2,
            cube_transform
        )
        controller.create_parent_constraint(
            joint_1,
            joint_2,
            center_joint
        )
        controller.create_aim_constraint(
            handle_2,
            cube_transform,
            worldUpType='object',
            worldUpObject=up_handle,
            aimVector=env.aim_vector,
            upVector=env.up_vector
        )

        # Attributes

        size_plug = this.plugs['size']
        size_plug.connect_to(multiply.plugs['input1X'])
        multiply.plugs['input2X'].set_value(4.0)
        cube_node.plugs['output'].connect_to(cube_mesh.plugs['inMesh'])
        locator_1.plugs['worldPosition'].element(0).connect_to(distance_node.plugs['point1'])
        locator_2.plugs['worldPosition'].element(0).connect_to(distance_node.plugs['point2'])
        locator_1.plugs['worldPosition'].element(0).connect_to(line.curve.plugs['controlPoints'].element(0))
        up_locator.plugs['worldPosition'].element(0).connect_to(line.curve.plugs['controlPoints'].element(1))
        distance_node.plugs['distance'].connect_to(cube_node.plugs['height'])
        size_plug.connect_to(handle_1.plugs['size'])
        size_plug.connect_to(handle_2.plugs['size'])
        size_plug.connect_to(up_handle.plugs['size'])
        multiply.plugs['outputX'].connect_to(cube_node.plugs['depth'])
        multiply.plugs['outputX'].connect_to(cube_node.plugs['width'])
        locator_1.plugs['visibility'].set_value(False)
        locator_2.plugs['visibility'].set_value(False)
        up_locator.plugs['visibility'].set_value(False)
        cube_mesh.plugs['overrideEnabled'].set_value(True)
        cube_mesh.plugs['overrideDisplayType'].set_value(2)
        cube_transform.plugs['overrideEnabled'].set_value(True)
        cube_transform.plugs['overrideDisplayType'].set_value(2)
        joint_1.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
            radius=0.0
        )
        joint_2.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
            radius=0.0
        )
        center_joint.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
            radius=0.0
        )
        # Shaders

        root = this.get_root()
        handle_1.mesh.assign_shading_group(root.shaders[side].shading_group)
        handle_2.mesh.assign_shading_group(root.shaders[side].shading_group)
        up_handle.mesh.assign_shading_group(root.shaders[side].shading_group)
        cube_mesh.assign_shading_group(root.shaders[side].shading_group)
        this.joints = [joint_1, center_joint, joint_2]
        return this

    def __init__(self, **kwargs):
        super(LatticeSquishGuide, self).__init__(**kwargs)
        self.toggle_class = LatticeSquish.__name__

    def get_toggle_blueprint(self):
        blueprint = super(LatticeSquishGuide, self).get_toggle_blueprint()
        blueprint['matrices'] = [list(self.joints[0].get_matrix()), list(self.joints[-1].get_matrix())]
        return blueprint

    def get_blueprint(self):
        blueprint = super(LatticeSquishGuide, self).get_blueprint()
        return blueprint


class LatticeSquish(Part):

    lattice = ObjectProperty(
        name='lattice'
    )

    main_handle = ObjectProperty(
        name='main_handle'
    )

    _geometry_names = DataProperty(  # for internal use only. Don't assume this is up to date
        name='_geometry_names'
    )

    _lattice_weights = DataProperty(  # for internal use only. Don't assume this is up to date
        name='_lattice_weights'
    )

    _legacy_weights = DataProperty(  # Using this to catch legacy weights from SquishPart1.0 Delete when possible
        name='weights'
    )


    def __init__(self, **kwargs):
        super(LatticeSquish, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['joint_chain'] = True
        this = super(LatticeSquish, cls).create(controller, **kwargs)
        this._legacy_weights = kwargs.get('weights', None)
        root = this.get_root()
        size = this.size
        matrices = copy.deepcopy(this.matrices)
        main_handle_matrix = Matrix(matrices[-1])
        start_position = matrices[0].get_translation()
        end_position = matrices[1].get_translation()
        main_handle_matrix.set_translation(end_position + ((end_position-start_position)*0.5))
        start_position = matrices[0].get_translation()
        end_position = matrices[1].get_translation()
        middle_matrix = Matrix(matrices[0])
        middle_position = (start_position * 0.5) + (end_position * 0.5)
        middle_matrix.set_translation(middle_position)
        matrices.insert(1, middle_matrix)
        joint_parent = this.joint_group
        handle_parent = this
        joints = []
        handles = []
        for i in range(len(matrices)):
            index_character = rig_factory.index_dictionary[i].upper()
            joint = this.create_child(
                Joint,
                parent=joint_parent,
                segment_name=index_character,
                matrix=matrices[i]
            )
            joint.zero_rotation()
            handle = this.create_handle(
                shape='circle',
                matrix=matrices[i],
                segment_name=index_character,
                parent=handle_parent,
                size=size*4.0
            )
            controller.create_parent_constraint(
                handle,
                joint,
                mo=False
            )
            controller.create_scale_constraint(
                handle,
                joint,
            )

            root.add_plugs(
                handle.plugs['tx'],
                handle.plugs['ty'],
                handle.plugs['tz'],
                handle.plugs['rx'],
                handle.plugs['ry'],
                handle.plugs['rz'],
                handle.plugs['sx'],
                handle.plugs['sy'],
                handle.plugs['sz']
            )
            handle_parent = handle
            joint_parent = joint
            joints.append(joint)
            handles.append(handle)

        main_handle = this.create_handle(
            shape='arrow_vertical',
            size=size,
            matrix=main_handle_matrix,
            segment_name='Main'
        )
        handles.append(main_handle)

        this.main_handle = main_handle

        root.add_plugs(
            main_handle.plugs['tx'],
            main_handle.plugs['ty'],
            main_handle.plugs['tz'],
        )
        this.joints = joints
        return this

    def create_deformation_rig(self, **kwargs):

        super(LatticeSquish, self).create_deformation_rig(**kwargs)

        root = self.get_root()
        lattice_joints = []

        for i in range(len(self.deform_joints)):
            deform_joint = self.deform_joints[i]
            index_character = rig_factory.index_dictionary[i].upper()
            lattice_joint = self.create_child(
                Joint,
                segment_name='%sLattice' % index_character,
                parent=deform_joint
            )
            lattice_joint.zero_rotation()
            lattice_joint.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.colors['bindJoints'],
                radius=deform_joint.plugs['radius'].get_value(),
                type=deform_joint.plugs['type'].get_value(),
                side={'center': 0, 'left': 1, 'right': 2, None: 3}[deform_joint.side],
                drawStyle=deform_joint.plugs['drawStyle'].get_value(2)
            )
            lattice_joints.append(lattice_joint)
            self.controller.create_parent_constraint(
                deform_joint,
                lattice_joint,
                mo=False
            )

        size = self.size
        start_position = self.matrices[0].get_translation()
        end_position = self.matrices[1].get_translation()
        middle_position = (start_position * 0.5) + (end_position * 0.5)
        joint_distance = (end_position - start_position).mag()
        lattice_matrix = Matrix(self.matrices[0])
        lattice_matrix.set_translation(middle_position)
        self.lattice = self.create_child(
            Lattice,
            segment_name='Volume',
            matrix=lattice_matrix
        )
        root.geometry[self.lattice.lattice_shape.name] = self.lattice.lattice_shape
        length = (end_position - start_position).mag()
        self.lattice.plugs['sy'].set_value(length)
        self.lattice.plugs['sx'].set_value(size*4.0)
        self.lattice.plugs['sz'].set_value(size*4.0)
        self.lattice.lattice_shape.plugs['tDivisions'].set_value(3)
        # root.geometry[self.lattice.lattice_shape.name] = self.lattice.lattice_shape
        distance_between_node = self.create_child(
            DependNode,
            node_type='distanceBetween',
            segment_name='SubtractLength'
        )
        squash_start_locator = self.handles[0].create_child(Locator)
        squash_end_locator = self.main_handle.create_child(Locator)

        distance_normalize = self.create_child(
            DependNode,
            node_type='multDoubleLinear',
            segment_name='DistanceNormalize'
        )
        scale_divide = self.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='ScaleDivide'
        )
        scale_divide.plugs['operation'].set_value(2)

        self.scale_multiply_transform.plugs['scale'].connect_to(scale_divide.plugs['input2'])

        squash_start_locator.plugs['v'].set_value(False)
        squash_end_locator.plugs['v'].set_value(False)
        squash_start_locator.plugs['worldPosition'].element(0).connect_to(distance_between_node.plugs['point1'])
        squash_end_locator.plugs['worldPosition'].element(0).connect_to(distance_between_node.plugs['point2'])
        default_distance = distance_between_node.plugs['distance'].get_value()
        distance_between_node.plugs['distance'].connect_to(distance_normalize.plugs['input1'])
        distance_normalize.plugs['input2'].set_value(joint_distance / default_distance * 0.5)
        distance_normalize.plugs['output'].connect_to(scale_divide.plugs['input1X'])
        scale_divide.plugs['outputX'].connect_to(self.handles[1].groups[0].plugs['ty'])
        scale_divide.plugs['outputX'].connect_to(self.handles[2].groups[0].plugs['ty'])
        values = ((default_distance*0.5, 2.0), (default_distance, 1.0), (default_distance*2.0, 0.1))
        remap_plug = distance_between_node.plugs['distance'].remap(*values)
        remap_plug.connect_to(lattice_joints[1].plugs['sx'])
        remap_plug.connect_to(lattice_joints[1].plugs['sz'])

        up_object = self.create_child(
            Transform,
            segment_name='Up',
            matrix=self.deform_joints[1].get_matrix()
        )
        self.controller.create_aim_constraint(
            self.main_handle,
            self.handles[1].groups[0],
            aimVector=env.side_aim_vectors[self.side],
            upVector=env.side_up_vectors[self.side],
            worldUpVector=env.side_up_vectors[self.side],
            worldUpType='objectRotation',
            worldUpObject=up_object
        )
        self.lattice.plugs['inheritsTransform'].set_value(False)
        self.controller.create_parent_constraint(
            self,
            self.lattice.lattice_base_transform,
            mo=True
        )
        self.controller.scene.skinCluster(
            lattice_joints,
            self.lattice.lattice_shape,
            tsb=True
        )
        self.lattice.lattice_transform.plugs['translate'].set_locked(False)
        self.lattice.lattice_transform.plugs['rotate'].set_locked(False)
        self.lattice.lattice_transform.plugs['scale'].set_locked(False)
        self.lattice.lattice_transform.set_matrix(self.lattice.get_matrix())
        self.deform_joints.extend(lattice_joints)
        object_dict = self.controller.named_objects
        if self._geometry_names:
            self.lattice.ffd.add_geometry([object_dict[x] for x in self._geometry_names if x in object_dict])
        if self._lattice_weights:
            self.lattice.ffd.set_weights(self._lattice_weights)
        if self._legacy_weights:  # Remove this eventually
            self.controller.raise_warning('Found Legacy Squash weights. Attempting to apply them to the lattice')
            try:
                first_weights = self._legacy_weights[0]
                if isinstance(first_weights, dict):
                    geometry_names = first_weights.keys()
                    self.lattice.ffd.add_geometry([object_dict[x] for x in geometry_names if x in object_dict])
                    self.lattice.ffd.set_weights(first_weights)

            except Exception as e:
                import traceback
                traceback.print_exc()
                self.controller.raise_warning('Legacy Weights FAILED! See script editor for details')
            self._legacy_weights = None

    @flatten_args
    def add_geometry(self, *geometry):
        self.lattice.add_geometry(geometry)

    @flatten_args
    def remove_geometry(self, *geometry):
        self.lattice.remove_geometry(geometry)

    def get_toggle_blueprint(self):
        blueprint = super(LatticeSquish, self).get_toggle_blueprint()
        if self.lattice:
            blueprint['rig_data'].update(
                _geometry_names=[x.name for x in self.lattice.ffd.deformer_set.members],
                _lattice_weights=self.lattice.get_weights()
            )
        return blueprint

    def get_blueprint(self):
        blueprint = super(LatticeSquish, self).get_blueprint()
        if self.lattice:
            blueprint.update(
                _geometry_names=[x.name for x in self.lattice.ffd.deformer_set.members],
                _lattice_weights=self.lattice.get_weights()
            )
        return blueprint

    def finalize(self):
        super(LatticeSquish, self).finalize()
        self.lattice.plugs['v'].set_value(False)
