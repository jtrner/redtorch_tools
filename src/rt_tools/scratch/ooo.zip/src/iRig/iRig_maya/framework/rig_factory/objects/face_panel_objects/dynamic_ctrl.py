from rig_factory.objects.face_panel_objects.base_slider import BaseSlider, BaseSliderGuide
from rig_math.matrix import Matrix


class DynamicCtrlGuide(BaseSliderGuide):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Dynamic',
        side='center',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(DynamicCtrlGuide, self).__init__(**kwargs)
        self.toggle_class = DynamicCtrl.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(DynamicCtrlGuide, cls).create(controller, **kwargs)
        return this


class DynamicCtrl(BaseSlider):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Dynamic',
        side='center',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(DynamicCtrl, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(DynamicCtrl, cls).create(controller, **kwargs)
        size = this.size
        side = this.side
        handle = this.create_handle(
            segment_name='Main',
            shape='dynamic',
            size=size,
            side=side,
        )
        controller.create_matrix_parent_constraint(handle, this.joints[0])
        matrix = Matrix(scale=[2.5, 2.5, 2.5])
        handle.plugs['shapeMatrix'].set_value(matrix)

        root = this.get_root()

        root.add_plugs(
            [
                handle.plugs['tx'],
                handle.plugs['ty'],
                handle.plugs['rz'],
                handle.plugs['sx'],
                handle.plugs['sy'],
                handle.plugs['sz'],

            ]
        )

        return this
