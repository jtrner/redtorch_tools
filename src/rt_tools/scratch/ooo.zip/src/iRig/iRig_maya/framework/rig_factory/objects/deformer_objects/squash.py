from nonlinear import NonLinear


class Squash(NonLinear):

    handle_type = 'deformSquash'
    deformer_type = 'squash'

    def __init__(self, **kwargs):
        super(Squash, self).__init__(**kwargs)
