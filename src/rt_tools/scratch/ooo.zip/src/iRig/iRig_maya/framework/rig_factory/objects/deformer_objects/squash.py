from rig_factory.objects.deformer_objects.nonlinear import NonLinear


class Squash(NonLinear):

    handle_type = 'deformSquash'
    deformer_type = 'squash'
    suffix = 'Squash'

    def __init__(self, **kwargs):
        super(Squash, self).__init__(**kwargs)
