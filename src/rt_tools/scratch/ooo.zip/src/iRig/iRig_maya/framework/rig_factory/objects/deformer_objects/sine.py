from rig_factory.objects.deformer_objects.nonlinear import NonLinear


class Sine(NonLinear):

    handle_type = 'deformSine'
    deformer_type = 'sine'
    suffix = 'Sine'

    def __init__(self, **kwargs):
        super(Sine, self).__init__(**kwargs)
