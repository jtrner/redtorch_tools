import maya.OpenMaya as om
import maya_tools.utilities.decorators as dec


@dec.m_dag_path_arg
def get_closest_point(curve, position):
    curve_functions = om.MFnNurbsCurve(curve)
    u_util = om.MScriptUtil()
    u_util.createFromDouble(0)
    u_param = u_util.asDoublePtr()
    point = om.MPoint(*position)
    curve_functions.closestPoint(
        point,
        u_param,
        om.MSpace.kWorld
    )
    return om.MScriptUtil(u_param).asDouble()
