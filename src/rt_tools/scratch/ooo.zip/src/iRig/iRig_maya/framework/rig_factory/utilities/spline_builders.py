from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_factory.objects.rig_objects.surface_point import SurfacePoint
from rig_factory.objects.rig_objects.curve_handle import CurveHandle
from rig_math.matrix import Matrix
import rig_factory.environment as env
import rig_factory
import copy

shard_group_index = -3

def create_handle(owner, **data):
    root = owner.get_root()
    controller = owner.controller
    vertices = []
    data = copy.copy(data)
    vertex_data = data.pop('vertices', None)
    matrix = data.pop('matrix')
    segment_name = data.pop('segment_name')
    differentiation_name = data.pop('differentiation_name', None)
    side = data.pop('side')
    parent = data.get('parent', owner)
    size = data.get('size', owner.size)
    if vertex_data:
        for mesh_name, vertex_index in vertex_data:
            geometry = root.get_geometry(mesh_name)
            if not geometry:
                print('mesh not found "%s"' % mesh_name)
            else:
                vertex = geometry.get_vertex(vertex_index)
                vertices.append(vertex)
    surface_point = None
    if owner.follicle_surface:
        position = Matrix(matrix).get_translation()
        surface_point = owner.create_child(
            SurfacePoint,
            surface=owner.follicle_surface,
            matrix=matrix,
            segment_name=segment_name,
            differentiation_name=differentiation_name,
            side=side
        )
        u, v = controller.scene.get_closest_surface_uv(
            owner.follicle_surface.m_object,
            Matrix(matrix).get_translation().data
        )
        u = u / owner.follicle_surface.plugs['spansU'].get_value()
        v = v / owner.follicle_surface.plugs['spansV'].get_value()
        surface_point.follicle.plugs['parameterU'].set_value(u)
        surface_point.follicle.plugs['parameterV'].set_value(v)
        matrix = surface_point.get_matrix()
        matrix.set_translation(position)
        parent = surface_point
    handle = owner.create_handle(
        handle_type=GroupedHandle,
        create_gimbal=owner.create_gimbal,
        shape='pointer',
        axis='z',
        matrix=matrix,
        segment_name=segment_name,
        differentiation_name=differentiation_name,
        side=side,
        size=size,
        parent=parent
    )
    if owner.create_shards:
        shard_transform = handle.create_child(
            Transform,
            segment_name='%sShard' % segment_name,
            side=side,
            parent=root.utilities_group,
            matrix=matrix
        )
        shard_mesh = controller.create_shard_mesh(
            shard_transform
        )
        shard_matrix = shard_transform.create_child(
            DependNode,
            node_type='shardMatrix'
        )
        controller.connect_plug(
            shard_mesh.plugs['outMesh'],
            shard_matrix.plugs['inMesh']
        )
        controller.connect_plug(
            shard_matrix.plugs['translate'],
            handle.groups[shard_group_index].plugs['translate']
        )
        controller.connect_plug(
            shard_matrix.plugs['rotate'],
            handle.groups[shard_group_index].plugs['rotate']
        )
        handle.utility_nodes['shard_mesh'] = shard_mesh
        handle.utility_nodes['shard_transform'] = shard_transform
        handle.utility_nodes['shard_matrix'] = shard_matrix

    handle.mirror_plugs = ['translateX', 'rotateY', 'rotateZ', 'tx', 'ry', 'rz']
    # if handle.side == 'center':
    #     handle.mirror_plugs = ['translateX']
    if owner.follicle_surface:
        par_u_plug = handle.create_plug(
            'ParameterU',
            k=True,
            at='double'
        )
        par_v_plug = handle.create_plug(
            'ParameterV',
            k=True,
            at='double'
        )
        u, v = controller.scene.get_closest_surface_uv(
            owner.follicle_surface.m_object,
            list(handle.get_translation())
        )
        add_u = owner.create_child(
            DependNode,
            node_type='addDoubleLinear',
            segment_name='%sU' % segment_name,
            differentiation_name=differentiation_name,
            side=side
        )
        add_v = owner.create_child(
            DependNode,
            node_type='addDoubleLinear',
            segment_name='%sV' % segment_name,
            differentiation_name=differentiation_name,
            side=side
        )
        u = u / owner.follicle_surface.plugs['spansU'].get_value()
        v = v / owner.follicle_surface.plugs['spansV'].get_value()
        par_u_plug.connect_to(add_u.plugs['input1'])
        par_v_plug.connect_to(add_v.plugs['input1'])
        add_u.plugs['input2'].set_value(u)
        add_v.plugs['input2'].set_value(v)
        add_u.plugs['output'].connect_to(surface_point.follicle.plugs['parameterU'])
        add_v.plugs['output'].connect_to(surface_point.follicle.plugs['parameterV'])
        handle.utility_nodes['follicle_surface'] = owner.follicle_surface
        handle.handle_metadata['default_position'] = [u, v]
        handle.mirror_plugs = ['translateX', 'rotateY', 'rotateZ', 'ParameterU', 'tx', 'ry', 'rz']
    handle.vertices = vertices
    handle.owner = owner  # Why is this needed ?
    joint = handle.create_child(
        Joint,
        parent=owner.joint_group,
        matrix=handle.get_matrix()
    )
    controller.create_parent_constraint(
        handle,
        joint,
        mo=False
    )
    root.add_plugs(
        handle.plugs['tx'],
        handle.plugs['ty'],
        handle.plugs['tz'],
        handle.plugs['rx'],
        handle.plugs['ry'],
        handle.plugs['rz'],
        handle.plugs['sx'],
        handle.plugs['sy'],
        handle.plugs['sz']
    )
    joint.plugs['visibility'].set_value(False)
    joint.plugs['radius'].set_value(size)
    return handle, joint


def create_handles(owner, parent, handle_data):

    handles = []
    joints = []
    for i, data in enumerate(handle_data):
        data['parent'] = parent
        handle, joint = create_handle(owner, data)
        handles.append(handle)
        joints.append(joint)

    return handles, joints


def create_spline(owner, parent, driver_joints, joint_tag=None):

    positions = [x.get_translation() for x in driver_joints]
    base_curve_transform = parent.create_child(
        Transform,
        segment_name='BaseSpline'
    )
    base_curve = base_curve_transform.create_child(
        NurbsCurve,
        degree=1 if owner.use_fit_curve else 2,
        positions=positions
    )
    base_curve.plugs['visibility'].set_value(False)
    for i in range(len(driver_joints)):
        driver_joint = driver_joints[i]
        position_locator = driver_joints[i].create_child(
            'Locator',
            differentiation_name=parent.differentiation_name
        )
        position_locator.plugs['visibility'].set_value(False)
        if owner.follicle_surface and owner.create_spline_on_surface:
            closest_point_on_surface = parent.create_child(
                DependNode,
                node_type='closestPointOnSurface',
                segment_name='%sSurface' % driver_joint.segment_name,
                side=driver_joint.side
            )
            position_locator.plugs['worldPosition'].element(0).connect_to(
                closest_point_on_surface.plugs['inPosition']
            )
            owner.follicle_surface.plugs['worldSpace'].element(0).connect_to(
                closest_point_on_surface.plugs['inputSurface']
            )
            closest_point_on_surface.plugs['result'].child(0).connect_to(
                base_curve.plugs['controlPoints'].element(i)
            )
        else:
            driver_joint.plugs['translate'].connect_to(
                base_curve.plugs['controlPoints'].element(i)
            )
    if owner.use_fit_curve:
        nurbs_curve_transform = parent.create_child(
            Transform,
            segment_name='FitSpline'
        )
        nurbs_curve = nurbs_curve_transform.create_child(
            NurbsCurve
        )
        fit_b_spline_node = nurbs_curve.create_child(
            DependNode,
            node_type='fitBspline',
        )
        fit_b_spline_node.plugs.set_values(
            tolerance=0.001
        )
        nurbs_curve.plugs['visibility'].set_value(False)
        nurbs_curve_transform.plugs['inheritsTransform'].set_value(False)
        base_curve.plugs['worldSpace'].element(0).connect_to(fit_b_spline_node.plugs['inputCurve'])
        fit_b_spline_node.plugs['outputCurve'].connect_to(nurbs_curve.plugs['create'])
        # base_curve.plugs['intermediateObject'].set_value(True)
        nurbs_curve.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2
        )
        owner.main_curve = nurbs_curve
    else:
        base_curve.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2
        )
        owner.main_curve = base_curve
    roll_joints = []
    spline_joints = []
    spline_handles = []
    segment_parameter = 1.0 / (owner.joint_count - 1)
    side = owner.side
    root = owner.get_root()
    handle_data = create_handle_data(owner.joint_count, owner.side, owner.root_name, owner.size)
    for i in range(owner.joint_count):
        data = handle_data[i]
        index_character = rig_factory.index_dictionary[i].capitalize()
        data['segment_name'] = 'Secondary%s' % data['segment_name']

        spline_joint = parent.create_child(
            Joint,
            parent=root.deform_group,
            **data
        )
        spline_joint.plugs.set_locked(
            translate=False,
            rotate=False,
            scale=False
        )
        spline_handle = parent.create_child(
            GroupedHandle,
            create_gimbal=False,
            shape='triangle',
            axis='x',
            parent=parent,
            **data
        )
        spline_handle.groups[0].plugs['inheritsTransform'].set_value(False)
        spline_joint.zero_rotation()
        spline_joint.plugs.set_values(
            overrideRGBColors=True,
            overrideColorRGB=env.secondary_colors['bindJoints'],
            overrideEnabled=True,
            type=18,
            otherType='%sSpline' % parent.differentiation_name
        )

        point_on_curve_info = spline_joint.create_child(
            DependNode,
            node_type='pointOnCurveInfo',
            segment_name='Secondary%s' % index_character,
            side=side
        )

        slide_plug = spline_handle.create_plug(
            'Slide',
            at='float',
            min=0.0,
            max=1.0,
            dv=0.0
        )
        slide_plug.set_value(1.0/(owner.joint_count-1)*i)
        owner.main_curve.plugs['worldSpace'].element(0).connect_to(point_on_curve_info.plugs['inputCurve'])
        point_on_curve_info.plugs['turnOnPercentage'].set_value(True)
        slide_plug.connect_to(point_on_curve_info.plugs['parameter'])
        handle_size = owner.size * 0.4
        if owner.follicle_surface and owner.create_spline_on_surface:
            base_curve_transform.plugs['inheritsTransform'].set_value(False)
            shape_matrix = Matrix(0.0, 0.0, handle_size*-1)
            shape_matrix.set_scale([handle_size, handle_size, handle_size * 2])
            spline_handle.set_shape_matrix(shape_matrix)
            closest_point_on_surface = spline_joint.create_child(
                DependNode,
                node_type='closestPointOnSurface',
            )
            point_on_surface_info = spline_joint.create_child(
                DependNode,
                node_type='pointOnSurfaceInfo',
            )
            translation_transform = parent.create_child(
                Transform,
                segment_name='SurfaceTranslation%s' % index_character,
            )
            aim_transform = parent.create_child(
                Transform,
                segment_name='SplineAim%s' % index_character
            )
            orient_transform = parent.create_child(
                Transform,
                segment_name='SplineOrient%s' % index_character
            )
            up_transform = parent.create_child(
                Transform,
                segment_name='SplineUp%s' % index_character
            )
            orient_transform.plugs.set_values(
                inheritsTransform=False
            )
            aim_transform.plugs.set_values(
                inheritsTransform=False
            )
            translation_transform.plugs.set_values(
                inheritsTransform=False
            )
            up_transform.plugs.set_values(
                inheritsTransform=False
            )
            plus_minus_aim = spline_joint.create_child(
                DependNode,
                node_type='plusMinusAverage',
                segment_name='SplineAim%s' % index_character
            )
            plus_minus_up = spline_joint.create_child(
                DependNode,
                node_type='plusMinusAverage',
                segment_name='SplineUp%s' % index_character
            )
            curve_position_plug = point_on_curve_info.plugs['result'].child(0)
            surface_position_plug = point_on_surface_info.plugs['result'].child(0)
            curve_tangent_plug = point_on_curve_info.plugs['result'].child(4)
            surface_normal_plug = point_on_surface_info.plugs['result'].child(2)
            surface_position_plug.connect_to(plus_minus_up.plugs['input3D'].element(0))
            surface_normal_plug.connect_to(plus_minus_up.plugs['input3D'].element(1))
            plus_minus_up.plugs['output3D'].connect_to(up_transform.plugs['translate'])
            surface_position_plug.connect_to(plus_minus_aim.plugs['input3D'].element(0))
            curve_tangent_plug.connect_to(plus_minus_aim.plugs['input3D'].element(1))
            plus_minus_aim.plugs['output3D'].connect_to(aim_transform.plugs['translate'])
            point_on_curve_info.plugs['result'].child(0).connect_to(orient_transform.plugs['translate'])
            point_on_curve_info.plugs['result'].child(0).connect_to(closest_point_on_surface.plugs['inPosition'])
            owner.follicle_surface.plugs['worldSpace'].element(0).connect_to(
                closest_point_on_surface.plugs['inputSurface'])
            owner.follicle_surface.plugs['worldSpace'].element(0).connect_to(point_on_surface_info.plugs['inputSurface'])
            closest_point_on_surface.plugs['result'].child(1).connect_to(point_on_surface_info.plugs['parameterU'])
            closest_point_on_surface.plugs['result'].child(2).connect_to(point_on_surface_info.plugs['parameterV'])
            closest_point_on_surface.plugs['result'].child(0).connect_to(spline_handle.groups[0].plugs['translate'])
            if owner.side is None or owner.side in ['left', 'center']:
                aim_vector = [0.0, -1.0, 0.0]
                up_vector = [0.0, 0.0, 1.0]
            elif owner.side == 'right':
                aim_vector = [0.0, 1.0, 0.0]
                up_vector = [0.0, 0.0, 1.0]
            else:
                raise Exception('Side not supported')
            owner.controller.create_aim_constraint(
                aim_transform,
                orient_transform,
                worldUpType='object',
                worldUpObject=up_transform,
                aimVector=aim_vector,
                upVector=up_vector
            )
            orient_transform.plugs['rotate'].connect_to(spline_handle.groups[0].plugs['rotate'])
        elif owner.up_vector_transform:
            if owner.side is None or owner.side == 'center':
                aim_vector = [0.0, -1.0, 0.0]
                up_vector = [0.0, 0.0, -1.0]
            else:
                aim_vector = [1.0, 0.0, 0.0]
                up_vector = [0.0, 0.0, -1.0]
            point_on_curve_info.plugs['position'].connect_to(spline_handle.groups[0].plugs['translate'])
            owner.controller.create_tangent_constraint(
                owner.main_curve,
                spline_handle.groups[0],
                aimVector=aim_vector,
                upVector=up_vector,
                worldUpType='object',
                worldUpObject=owner.up_vector_transform.name
            )
        else:
            point_on_curve_info.plugs['position'].connect_to(spline_handle.groups[0].plugs['translate'])
        shape_matrix = Matrix(0.0, 0.0, handle_size)
        shape_matrix.set_scale([handle_size, handle_size, handle_size * -2])
        spline_handle.set_shape_matrix(shape_matrix)
        spline_joints.append(spline_joint)
        spline_handles.append(spline_handle)
        if owner.create_roll_joints:
            roll_data = copy.deepcopy(data)
            roll_segment_name = '%sRoll' % roll_data.pop('segment_name')
            position_getter = spline_joint.create_child(
                Transform,
                parent=parent,
                segment_name='%sGetter' % spline_joint.segment_name
            )
            roll_joint = parent.create_child(
                Joint,
                parent=root.deform_group,
                segment_name=roll_segment_name,
                **roll_data
            )
            roll_joint.zero_rotation()
            roll_joint.plugs.set_values(
                overrideRGBColors=True,
                overrideColorRGB=env.secondary_colors['bindJoints'],
                overrideEnabled=True
            )
            owner.controller.create_parent_constraint(spline_handle, position_getter, mo=False)
            position_getter.plugs['translate'].connect_to(roll_joint.plugs['translate'])
            position_getter.plugs['rotate'].connect_to(roll_joint.plugs['rotate'])
            roll_joint.plugs['type'].set_value(18)
            roll_joint.plugs['otherType'].set_value('%sRoll' % parent.differentiation_name)
            position_getter.plugs['translate'].connect_to(spline_joint.plugs['translate'])
            roll_joints.append(roll_joint)
        else:
            position_getter = spline_joint.create_child(
                Transform,
                parent=parent,
                segment_name='%sGetter' % spline_joint.segment_name
            )
            owner.controller.create_parent_constraint(spline_handle, position_getter)
            position_getter.plugs['translate'].connect_to(spline_joint.plugs['translate'])
        spline_handle.mirror_plugs = ['translateY', 'rotateX', 'rotateZ', 'ty', 'rx', 'rz']
        root.add_plugs(
            spline_handle.plugs['tx'],
            spline_handle.plugs['ty'],
            spline_handle.plugs['tz']
        )
    if roll_joints:
        differentiation_token = parent.differentiation_name if parent.differentiation_name else ''
        start_roll_plug = owner.create_plug(
            '%sStartRoll' % differentiation_token,
            at='float',
            keyable=True
        )
        mid_roll_plug = owner.create_plug(
            '%sMidRoll' % differentiation_token,
            at='float',
            keyable=True
        )
        end_roll_plug = owner.create_plug(
            '%sEndRoll' % differentiation_token,
            at='float',
            keyable=True
        )
        remap = parent.create_child(
            DependNode,
            node_type='remapValue',
            segment_name='Roll',
        )
        roll_multiplier = 10.0
        remap.plugs['value'].element(0).child(0).set_value(0.0)
        remap.plugs['value'].element(0).child(1).set_value(0.0*roll_multiplier)
        remap.plugs['value'].element(0).child(2).set_value(2)
        remap.plugs['value'].element(1).child(0).set_value(0.5)
        remap.plugs['value'].element(1).child(1).set_value(1.0*roll_multiplier)
        remap.plugs['value'].element(1).child(2).set_value(2)
        remap.plugs['value'].element(2).child(0).set_value(1.0)
        remap.plugs['value'].element(2).child(1).set_value(0.0*roll_multiplier)
        remap.plugs['value'].element(2).child(2).set_value(2)
        start_roll_plug.connect_to(remap.plugs['value'].element(0).child(1))
        mid_roll_plug.connect_to(remap.plugs['value'].element(1).child(1))
        end_roll_plug.connect_to(remap.plugs['value'].element(2).child(1))
        for i, roll_joint in enumerate(roll_joints):
            index_token = rig_factory.index_dictionary[i]
            roll_remap = parent.create_child(
                DependNode,
                segment_name='Roll%s' % index_token,
                node_type='remapValue'
            )
            roll_remap.plugs['inputValue'].set_value(1.0/(len(roll_joints)-1) * i)
            remap.plugs['value'].element(0).child(0).connect_to(roll_remap.plugs['value'].element(0).child(0))
            remap.plugs['value'].element(0).child(1).connect_to(roll_remap.plugs['value'].element(0).child(1))
            remap.plugs['value'].element(0).child(2).connect_to(roll_remap.plugs['value'].element(0).child(2))
            remap.plugs['value'].element(1).child(0).connect_to(roll_remap.plugs['value'].element(1).child(0))
            remap.plugs['value'].element(1).child(1).connect_to(roll_remap.plugs['value'].element(1).child(1))
            remap.plugs['value'].element(1).child(2).connect_to(roll_remap.plugs['value'].element(1).child(2))
            remap.plugs['value'].element(2).child(0).connect_to(roll_remap.plugs['value'].element(2).child(0))
            remap.plugs['value'].element(2).child(1).connect_to(roll_remap.plugs['value'].element(2).child(1))
            remap.plugs['value'].element(2).child(2).connect_to(roll_remap.plugs['value'].element(2).child(2))
            roll_remap.plugs['outValue'].connect_to(spline_handles[i].groups[1].plugs['rotateY'])

    return spline_handles, spline_joints


def create_guide_handles(owner, parent, handle_data):
    joints = []
    handles = []
    size_plug = owner.plugs['size']
    size_multiply = parent.create_child(
        DependNode,
        node_type='multiplyDivide',
        segment_name='Size'
    )
    size_plug.connect_to(size_multiply.plugs['input1X'])
    size_plug.connect_to(size_multiply.plugs['input1Y'])
    size_multiply.plugs['input2X'].set_value(1.0)
    size_multiply.plugs['input2Y'].set_value(1.0)

    for data in handle_data:
        handle, joint = create_guide_handle(owner, **data)
        size_multiply.plugs['outputX'].connect_to(handle.plugs['size'])
        joints.append(joint)
        handles.append(handle)

    return handles, joints


def create_guide_handle(owner, **data):
    root = owner.get_root()
    parent = data.get('parent', owner)
    vertices = []
    for mesh_name, index in data.pop('vertices', []):
        if mesh_name in root.geometry:
            vertices.append(root.geometry[mesh_name].get_vertex(index))
    data['root_name'] = owner.root_name

    handle = owner.create_handle(
        vertices=vertices,
        differentiation_name=parent.differentiation_name,
        **data
    )

    pointer_handle = handle.create_child(
        CurveHandle,
        shape='pointer',
        axis='z',
        suffix='Crv',
        size=data.pop('size', owner.size),
        **data
    )
    pointer_handle.plugs['overrideDisplayType'].set_value(1)

    if owner.up_vector_transform:
        owner.controller.create_aim_constraint(
            owner.up_vector_transform,
            pointer_handle,
            mo=False,
            aimVector=[0.0, 0.0, -1.0],
            upVector=[0.0, 1.0, 0.0],
            worldUpType='scene',
        )

    handle.vertices = vertices
    side = data['side']
    shader_side = side if side else 'center'
    shading_group = root.shaders[shader_side].shading_group
    handle.mesh.assign_shading_group(shading_group)
    joint = pointer_handle.create_child(
        Joint,
        parent=owner
    )
    owner.controller.create_parent_constraint(pointer_handle, joint)
    joint.plugs['drawStyle'].set_value(2)
    return handle, joint


def is_even(number):
    if (number % 2) == 0:
        return True
    return False


def create_handle_data(count, side, root_name, size):
    if count < 2:
        raise Exception('Count must be at-least 2')

    data = []
    if side == 'left':
        for x in range(count):
            data.append(dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[x].title(),
                size=size,
                side=side,
                matrix=Matrix([(size*2) * x, 0.0, 0.0])
            ))
    elif side == 'right':
        for x in range(count):
            data.append(dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[x].title(),
                size=size,
                side=side,
                matrix=Matrix([(size*-2) * x, 0.0, 0.0])
            ))
    elif side == 'center':
        for x in range(count):
            data.append(dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[x].title(),
                size=size,
                side=side,
                matrix=Matrix([0.0, (size*2) * x, 0.0])
            ))
    elif side is None:
        even_count = is_even(count)
        side_count = count / 2 if even_count else (count - 1) / 2
        for x in range(side_count):
            position = [(size * -2) * (x + 1), 0.0, 0.0]
            if x == 0 and even_count:
                position = [(size * -1) * (x + 1), 0.0, 0.0]
            data.insert(0, dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[x].title(),
                size=size,
                side='right',
                matrix=Matrix(position)
            ))
        if not even_count:
            data.append(dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[0].title(),
                size=size,
                side='center',
                matrix=Matrix([0.0, 0.0, 0.0])
            ))
        for x in range(side_count):
            position = [(size * 2) * (x + 1), 0.0, 0.0]
            if x == 0 and even_count:
                position = [size * (x + 1), 0.0, 0.0]
            data.append(dict(
                root_name=root_name,
                segment_name=rig_factory.index_dictionary[x].title(),
                size=size,
                side='left',
                matrix=Matrix(position)
            ))
    return data
