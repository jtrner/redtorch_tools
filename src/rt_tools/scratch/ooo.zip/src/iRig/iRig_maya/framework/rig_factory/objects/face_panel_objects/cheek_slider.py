from rig_factory.objects.face_panel_objects.base_slider import BaseSlider, BaseSliderGuide
from rig_math.matrix import Matrix
from rig_factory.objects.rig_objects.line import Line

from rig_factory.utilities import face_panel_utillities as utl


class CheekSliderGuide(BaseSliderGuide):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Cheek',
        side='left',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(CheekSliderGuide, self).__init__(**kwargs)
        self.toggle_class = CheekSlider.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(CheekSliderGuide, cls).create(controller, **kwargs)
        return this


class CheekSlider(BaseSlider):

    default_settings = dict(
        differentiation_name='Panel',
        root_name='Cheek',
        side='left',
        size=1.0
    )

    def __init__(self, **kwargs):
        super(CheekSlider, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(CheekSlider, cls).create(controller, **kwargs)
        size = this.size
        side = this.side
        matrices = this.matrices
        side_mult = -1.0 if side == 'left' else 1.0

        cheek_handle = this.create_handle(
            segment_name='Main',
            shape='face_cheek',
            size=size,
            side=side,
            matrix=matrices[0]
        )
        matrix = Matrix(scale=[1.5, 1.5, 1.0])
        cheek_handle.plugs['shapeMatrix'].set_value(matrix)
        utl.set_attr_limit(cheek_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(cheek_handle, 'TransY', -1.0, 1.0)
        if side == 'right':
            cheek_handle.groups[-1].plugs['rotateY'].set_value(180)

        squint_handle = this.create_handle(
            segment_name='Squint',
            shape='face_squint',
            size=size,
            side=side,
            matrix=matrices[0] * Matrix(2.25 * side_mult, 0.5, 0.0)
        )
        utl.set_attr_limit(squint_handle, 'TransX', -1.0, 1.0)
        utl.set_attr_limit(squint_handle, 'TransY', -1.0, 1.0)

        line = this.create_child(
            Line,
            segment_name='Line',
            parent=this,
            matrix=matrices[0] * Matrix(1.25 * side_mult, -0.25, 0.0)
        )
        line.curve.plugs['controlPoints'].element(0).set_value((side_mult, 0.0, 0.0))
        line.curve.plugs['controlPoints'].element(1).set_value((side_mult, 1.5, 0.0))
        line.plugs['inheritsTransform'].set_value(True)

        root = this.get_root()
        root.add_plugs(
            [
                cheek_handle.plugs['tx'],
                cheek_handle.plugs['ty'],
                squint_handle.plugs['tx'],
                squint_handle.plugs['ty']
            ]
        )

        return this
