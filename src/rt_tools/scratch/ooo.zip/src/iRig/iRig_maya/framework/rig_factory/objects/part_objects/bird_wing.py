from rig_factory.objects.part_objects.base_wing import BaseWing, BaseWingGuide
from rig_factory.objects.part_objects.feather_part import FeatherPart, FeatherPartGuide


class BirdWingGuide(BaseWingGuide):

    default_settings = {
        'root_name': 'Wing',
        'size': 1.0,
        'side': 'left',
        'digit_segment_count': 2,
        'primary_digit_count': 10,
        'secondary_digit_count': 7,
        'tertiary_digit_count': 9,
    }

    digit_class = FeatherPartGuide


    def __init__(self, **kwargs):
        super(BirdWingGuide, self).__init__(**kwargs)
        self.toggle_class = BirdWing.__name__

    def create_members(self):
        super(BirdWingGuide, self).create_members()

class BirdWing(BaseWing):

    digit_class = FeatherPart

    def finish_create(self, **kwargs):
        super(BirdWing, self).finish_create()
