import os
import rig_factory
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.rig_objects.guide_handle import GuideHandle
from rig_factory.objects.rig_objects.curve_handle import CurveHandle
from rig_factory.objects.rig_objects.surface_point import SurfacePoint
from rig_factory.objects.base_objects.properties import ObjectProperty, ObjectListProperty, DataProperty
from rig_math.matrix import Matrix
import rig_factory.environment as env


class FaceHandleGuide(GuideHandle):

    owner = ObjectProperty(
        name='owner'
    )
    vertices = ObjectListProperty(
        name='vertices'
    )
    mirror_point = ObjectProperty(
        name='mirror_point'
    )

    def __init__(self, **kwargs):
        super(FaceHandleGuide, self).__init__(**kwargs)

    def snap_to_mesh(self, mesh):
        self.controller.snap_to_mesh(self, mesh)


class FaceHandle(CurveHandle):

    mirror_point = ObjectProperty(
        name='mirror_point'
    )
    joint_root = ObjectProperty(
        name='joint_root'
    )
    owner = ObjectProperty(
        name='owner'
    )
    gimbal_handle = ObjectProperty(
        name='gimbal_handle'
    )
    groups = ObjectListProperty(
        name='groups'
    )
    shard_mesh = ObjectProperty(
        name='shard_mesh'
    )
    shard_transform = ObjectProperty(
        name='shard_transform'
    )
    shard_matrix = ObjectProperty(
        name='shard_matrix'
    )
    follicle_surface = ObjectProperty(
        name='follicle_surface'
    )
    surface_point = ObjectProperty(
        name='surface_point'
    )
    default_position = DataProperty(
        name='default_position'
    )
    create_gimbal = DataProperty(
        name='create_gimbal'
    )
    create_shard = DataProperty(
        name='create_shard'
    )
    gimbal_scale = DataProperty(
        name='gimbal_scale',
        default_value=0.9
    )

    rotation_order = DataProperty(
        name='rotation_order',
        default_value='xyz'
    )

    group_count = 4
    shard_group_index = -3

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs.setdefault('shape', 'cube')
        kwargs['group_count'] = cls.group_count
        parent = kwargs.pop('parent', None)
        owner = kwargs.pop('owner', parent)
        side = kwargs.pop('side', None)
        index = kwargs.pop('index', None)
        matrix = kwargs.pop('matrix', None)
        create_shard = kwargs.pop('create_shard', None)

        world_space_orientation = kwargs.pop('world_space_orientation', True)

        handle_segment_name = kwargs.pop('segment_name', None)
        follicle_surface = kwargs.get('follicle_surface')
        surface_point = None
        default_position = None
        if not owner:
            raise Exception('Face handles must receive an "owner" keyword argument')
        root = owner.get_root()
        if follicle_surface:
            surface_point = owner.create_child(
                SurfacePoint,
                segment_name='Follicle%s' % handle_segment_name,
                surface=follicle_surface,
                parent=parent,
                side=side,
                matrix=matrix
            )
            u, v = controller.scene.get_closest_surface_uv(
                follicle_surface.m_object,
                Matrix(matrix).get_translation().data
            )
            u = u / follicle_surface.plugs['spansU'].get_value()
            v = v / follicle_surface.plugs['spansV'].get_value()
            default_position = (u, v)
            surface_point.follicle.plugs['parameterU'].set_value(u)
            surface_point.follicle.plugs['parameterV'].set_value(v)
            if world_space_orientation:
                matrix = surface_point.get_matrix()
            parent = surface_point
        group_names = [
            'Tpx',
            'Tpp',
            'Top',
            'Ofs',
            'Drv',
            'Cns'
        ]
        groups = []
        for g in range(cls.group_count):
            if g == 0:
                suffix = 'Zro'
            else:
                suffix = group_names[len(group_names) - cls.group_count + g]
            group = parent.create_child(
                Transform,
                segment_name=handle_segment_name,
                suffix=suffix,
                side=side,
                matrix=matrix,
                **kwargs
            )
            parent = group
            groups.append(group)
        this = super(FaceHandle, cls).create(
            controller,
            parent=parent,
            segment_name=handle_segment_name,
            side=side,
            **kwargs
        )

        this.groups = groups

        if create_shard:
            shard_transform = this.create_child(
                Transform,
                segment_name=handle_segment_name,
                side=side,
                index=index,
                parent=root.utilities_group,
                matrix=matrix
            )
            shard_mesh = controller.create_shard_mesh(
                shard_transform
            )
            shard_matrix = shard_transform.create_child(
                DependNode,
                node_type='shardMatrix'
            )
            controller.connect_plug(
                shard_mesh.plugs['outMesh'],
                shard_matrix.plugs['inMesh']
            )
            controller.connect_plug(
                shard_matrix.plugs['translate'],
                groups[this.shard_group_index].plugs['translate']
            )
            controller.connect_plug(
                shard_matrix.plugs['rotate'],
                groups[this.shard_group_index].plugs['rotate']
             )
            this.shard_mesh = shard_mesh
            this.shard_transform = shard_transform
            this.shard_matrix = shard_matrix

        if surface_point:
            par_u_plug = this.create_plug(
                'ParameterU',
                k=True,
                at='double'
            )
            par_v_plug = this.create_plug(
                'ParameterV',
                k=True,
                at='double'
            )
            u, v = controller.scene.get_closest_surface_uv(
                follicle_surface.m_object,
                this.get_translation().data
            )
            add_u = this.create_child(
                DependNode,
                node_type='addDoubleLinear',
                segment_name='%sU' % handle_segment_name,
            )
            add_v = this.create_child(
                DependNode,
                node_type='addDoubleLinear',
                segment_name='%sV' % handle_segment_name,
            )
            u = u / follicle_surface.plugs['spansU'].get_value()
            v = v / follicle_surface.plugs['spansV'].get_value()
            par_u_plug.connect_to(add_u.plugs['input1'])
            par_v_plug.connect_to(add_v.plugs['input1'])
            add_u.plugs['input2'].set_value(u)
            add_v.plugs['input2'].set_value(v)
            add_u.plugs['output'].connect_to(surface_point.follicle.plugs['parameterU'])
            add_v.plugs['output'].connect_to(surface_point.follicle.plugs['parameterV'])

        if kwargs.get('create_gimbal'):
            side = this.side

            if this.functionality_name:
                functionality_name = '%sGimbal' % this.functionality_name
            else:
                functionality_name = 'Gimbal'

            this.gimbal_handle = this.create_child(
                CurveHandle,
                shape=this.shape,
                axis=this.axis,
                segment_name=this.segment_name,
                functionality_name=functionality_name
            )
            this.gimbal_handle.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.secondary_colors[side]
            )
            shape_matrix = Matrix()
            shape_matrix.set_scale([
                this.size * this.gimbal_scale,
                this.size * this.gimbal_scale,
                this.size * this.gimbal_scale,
            ])
            this.gimbal_handle.plugs['shapeMatrix'].set_value(shape_matrix)
            visibility_plug = this.create_plug(
                'gimbalVisibility',
                at='double',
                k=False,
                dv=0.0,
                min=0.0,
                max=1.0
            )
            visibility_plug.set_channel_box(True)
            for curve in this.gimbal_handle.curves:
                visibility_plug.connect_to(curve.plugs['visibility'])
            this.plugs['rotateOrder'].set_channel_box(True)
            this.plugs['rotateOrder'].connect_to(this.gimbal_handle.plugs['rotateOrder'])

        this.default_position = default_position
        this.mirror_plugs = ['tx']
        this.surface_point = surface_point
        this.groups = groups
        this.owner = owner

        return this

    def __init__(self, **kwargs):
        super(FaceHandle, self).__init__(**kwargs)

    def assign_vertices(self, *vertices):
        self.controller.assign_vertices(self, *vertices)

    def snap_to_mesh(self, mesh):
        self.controller.snap_to_mesh(self, mesh)
