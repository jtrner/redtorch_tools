from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.rig_objects.capsule import Capsule
from rig_factory.objects.rig_objects.cone import Cone
from rig_factory.objects.rig_objects.line import Line
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_factory.objects.rig_objects.grouped_handle import LocalHandle
import rig_factory

import rig_factory.environment as env


class PistonGuide(PartGuide):
    default_settings = dict(
        root_name='Piston',
        size=2.0,
        piston_amount=1,
        shape='cube',
        create_gimbal=False,
        side='center',
        count=1,
        stretchy=False
    )

    shape = DataProperty(
        name='shape'
    )

    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    count = DataProperty(
        name='count'
    )

    stretchy = DataProperty(
        name='stretchy'
    )

    def __init__(self, **kwargs):
        super(PistonGuide, self).__init__(**kwargs)
        self.toggle_class = Piston.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        """
        Use rig_objects.handle_guide.CubeHandleGuide
        """
        handle_positions = kwargs.get('handle_positions', dict())
        kwargs.setdefault('side', 'center')
        this = super(PistonGuide, cls).create(controller, **kwargs)
        side = this.side
        size = this.size
        piston_amount = kwargs.get('piston_amount', cls.default_settings['piston_amount'])

        # Create wheels

        size_plug = this.plugs['size']
        piston_jnt_list = []
        piston_guide_list = []

        wheel_piston_pin_jnt = this.create_child(
            Joint,
            segment_name='WheelPin',
            side=this.side
        )
        piston_jnt_list.append(wheel_piston_pin_jnt)

        body_piston_pin_jnt = this.create_child(
            Joint,
            segment_name='BodyPin',
            side=this.side
        )
        piston_jnt_list.append(body_piston_pin_jnt)

        wheel_piston_guide = this.create_handle(
            segment_name='Wheel',
            side=this.side
        )
        piston_guide_list.append(wheel_piston_guide)

        body_piston_guide = this.create_handle(
            segment_name='Body',
            side=this.side
        )
        piston_guide_list.append(body_piston_guide)

        size_multiply = this.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='ItemSize'
        )

        for i in range(this.count):
            segment_name = rig_factory.index_dictionary[i].title()

            start_piston_jnt = this.create_child(
                Joint,
                segment_name='%sStart' % segment_name,
                side=this.side
            )
            piston_jnt_list.append(start_piston_jnt)

            end_piston_jnt = this.create_child(
                Joint,
                segment_name='%sEnd' % segment_name,
                side=this.side
            )
            piston_jnt_list.append(end_piston_jnt)

            up_jnt = this.create_child(
                Joint,
                segment_name='%sUpVector' % segment_name,
                side=this.side
            )
            piston_jnt_list.append(up_jnt)

            start_piston_guide = this.create_handle(
                segment_name='%sStart' % segment_name,
                side=this.side,
                size=0.5
            )
            piston_guide_list.append(start_piston_guide)

            end_piston_guide = this.create_handle(
                segment_name='%sEnd' % segment_name,
                side=this.side,
                size=0.5
            )
            piston_guide_list.append(end_piston_guide)

            up_guide = this.create_handle(
                segment_name='%sUp' % segment_name,
                functionality_name='UpVector',
                side=this.side
            )
            piston_guide_list.append(up_guide)

            start_locator = start_piston_guide.create_child(
                Locator,
                segment_name='%sStart' % segment_name
            )
            end_locator = end_piston_guide.create_child(
                Locator,
                segment_name='%sEnd' % segment_name
            )
            up_locator = up_guide.create_child(
                Locator,
                segment_name='%sUp' % segment_name
            )
            up_line = this.create_child(
                Line,
                segment_name='%sUpLine' % segment_name
            )
            aim_line = this.create_child(
                Line,
                segment_name='%sAimLine' % segment_name
            )

            capsule = this.create_child(
                Capsule,
                index=0,
                segment_name='%sCapsule' % segment_name,
            )

            start_cone_x = start_piston_jnt.create_child(
                Cone,
                segment_name='%sStartConeX' % segment_name,
                size=size,
                axis=[1.0, 0.0, 0.0]
            )
            start_cone_y = start_piston_jnt.create_child(
                Cone,
                segment_name='%sStartConeY' % segment_name,
                size=size,
                axis=[0.0, 1.0, 0.0]
            )
            start_cone_z = start_piston_jnt.create_child(
                Cone,
                segment_name='%sStartConeZ' % segment_name,
                size=size,
                axis=[0.0, 0.0, 1.0]
            )

            end_cone_x = end_piston_jnt.create_child(
                Cone,
                segment_name='%sEndConeX' % segment_name,
                size=size,
                axis=[1.0, 0.0, 0.0]
            )
            end_cone_y = end_piston_jnt.create_child(
                Cone,
                segment_name='%sEndConeY' % segment_name,
                size=size,
                axis=[0.0, 1.0, 0.0]
            )
            end_cone_z = end_piston_jnt.create_child(
                Cone,
                segment_name='%sEndConeZ' % segment_name,
                size=size,
                axis=[0.0, 0.0, 1.0]
            )


            all_cones = [start_cone_x, start_cone_y, start_cone_z, end_cone_x, end_cone_y, end_cone_z]

            for cones in all_cones:
                cones.plugs.set_values(
                    overrideEnabled=True,
                    overrideDisplayType=2,
                )

            root = this.get_root()
            start_cone_x.mesh.assign_shading_group(root.shaders['x'].shading_group)
            start_cone_y.mesh.assign_shading_group(root.shaders['y'].shading_group)
            start_cone_z.mesh.assign_shading_group(root.shaders['z'].shading_group)
            end_cone_x.mesh.assign_shading_group(root.shaders['x'].shading_group)
            end_cone_y.mesh.assign_shading_group(root.shaders['y'].shading_group)
            end_cone_z.mesh.assign_shading_group(root.shaders['z'].shading_group)

            start_locator.plugs['visibility'].set_value(False)
            end_locator.plugs['visibility'].set_value(False)
            up_locator.plugs['visibility'].set_value(False)

            wheel_piston_pos = handle_positions.get(wheel_piston_guide.name, [0.0, 0.0, 5.0])
            wheel_piston_guide.plugs['translate'].set_value(wheel_piston_pos)
            body_piston_pos = handle_positions.get(body_piston_guide.name, [0.0, 0.0, -5.0])
            body_piston_guide.plugs['translate'].set_value(body_piston_pos)
            start_piston_pos = handle_positions.get(start_piston_guide.name, [0.0, 0.0, 0.0])
            start_piston_guide.plugs['translate'].set_value(start_piston_pos)
            end_piston_pos = handle_positions.get(end_piston_guide.name, [0.0, 10.0, 0.0])
            end_piston_guide.plugs['translate'].set_value(end_piston_pos)
            up_guide_pos = handle_positions.get(up_guide.name, [0.0, 10.0, 5.0])
            up_guide.plugs['translate'].set_value(up_guide_pos)

            # Constraints

            controller.create_point_constraint(
                start_piston_guide,
                start_piston_jnt
            )

            controller.create_point_constraint(
                end_piston_guide,
                end_piston_jnt
            )

            controller.create_point_constraint(
                up_guide,
                up_jnt
            )

            controller.create_point_constraint(
                start_piston_jnt,
                end_piston_jnt,
                capsule
            )

            controller.create_aim_constraint(
                end_piston_jnt,
                capsule,
                aimVector=env.aim_vector
            )

            controller.create_aim_constraint(
                end_piston_guide,
                start_piston_jnt,
                worldUpType='object',
                worldUpObject=up_guide.get_selection_string(),
                aimVector=env.aim_vector,
                upVector=env.up_vector,
                mo=False
            )

            aim_vector = []
            for x in env.aim_vector:
                aim_vector.append(x * -1)

            controller.create_aim_constraint(
                start_piston_guide,
                end_piston_jnt,
                worldUpType='object',
                worldUpObject=up_guide.get_selection_string(),
                aimVector=aim_vector,
                upVector=env.up_vector,
                mo=False
            )


            # Attributes

            end_locator.plugs['worldPosition'].element(0).connect_to(up_line.curve.plugs['controlPoints'].element(0))
            up_locator.plugs['worldPosition'].element(0).connect_to(up_line.curve.plugs['controlPoints'].element(1))
            start_locator.plugs['worldPosition'].element(0).connect_to(aim_line.curve.plugs['controlPoints'].element(0))
            end_locator.plugs['worldPosition'].element(0).connect_to(aim_line.curve.plugs['controlPoints'].element(1))
            start_locator.plugs['worldPosition'].element(0).connect_to(capsule.plugs['position1'])
            end_locator.plugs['worldPosition'].element(0).connect_to(capsule.plugs['position2'])
            start_piston_guide.plugs['radius'].set_value(size * 0.25)
            end_piston_guide.plugs['radius'].set_value(size * 0.25)
            size_multiply.plugs['outputY'].connect_to(start_piston_guide.plugs['size'])
            size_multiply.plugs['outputY'].connect_to(end_piston_guide.plugs['size'])
            size_multiply.plugs['outputX'].connect_to(up_guide.plugs['size'])
            size_plug.connect_to(capsule.plugs['size'])

            start_piston_guide.mesh.assign_shading_group(root.shaders[this.side].shading_group)
            end_piston_guide.mesh.assign_shading_group(root.shaders[this.side].shading_group)
            up_guide.mesh.assign_shading_group(root.shaders[this.side].shading_group)
            capsule.mesh.assign_shading_group(root.shaders[this.side].shading_group)

        size_plug.connect_to(size_multiply.plugs['input1X'])
        size_plug.connect_to(size_multiply.plugs['input1Y'])
        size_multiply.plugs['input2X'].set_value(1)
        size_multiply.plugs['input2Y'].set_value(0.25)


        size_multiply.plugs['outputX'].connect_to(wheel_piston_guide.plugs['size'])
        size_multiply.plugs['outputX'].connect_to(body_piston_guide.plugs['size'])

        controller.create_point_constraint(
            wheel_piston_guide,
            wheel_piston_pin_jnt
        )

        controller.create_point_constraint(
            body_piston_guide,
            body_piston_pin_jnt
        )


        for joint in piston_jnt_list:
            joint.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
                radius=size * 0.75
            )

        wheel_piston_guide.plugs['radius'].set_value(size * 0.25)
        body_piston_guide.plugs['radius'].set_value(size * 0.25)



        # Shaders
        wheel_piston_guide.mesh.assign_shading_group(root.shaders[this.side].shading_group)
        body_piston_guide.mesh.assign_shading_group(root.shaders[this.side].shading_group)


        root = this.get_root()
        for guides in piston_guide_list:
            if root:
                root.add_plugs(
                    [
                        guides.plugs['tx'],
                        guides.plugs['ty'],
                        guides.plugs['tz']
                    ]
                )

        this.base_handles = piston_guide_list

        this.joints = piston_jnt_list

        return this

class Piston(Part):
    deformers = ObjectListProperty(
        name='deformers'
    )

    geometry = ObjectListProperty(
        name='geometry'
    )

    shape = DataProperty(
        name='shape'
    )

    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    stretchy = DataProperty(
        name='stretchy'
    )

    count = DataProperty(
        name='count'
    )

    def __init__(self, **kwargs):
        super(Piston, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(Piston, cls).create(controller, **kwargs)
        size = this.size
        matrices = this.matrices

        wheel_piston_pin_handle_jnt = this.create_child(
            Joint,
            segment_name='WheelPin',
            index=0,
            side=this.side,
            matrix=matrices[0],
            parent=this.joint_group
        )

        body_piston_pin_handle_jnt = this.create_child(
            Joint,
            segment_name='BodyPin',
            index=0,
            side=this.side,
            matrix=matrices[1],
            parent=this.joint_group
        )

        wheel_piston_pin_handle = this.create_handle(
            handle_type=GroupedHandle,
            segment_name='WheelPin',
            shape='cube',
            side=this.side,
            size=size,
            matrix=matrices[0],
            create_gimbal=this.create_gimbal
        )

        body_piston_pin_handle = this.create_handle(
            handle_type=GroupedHandle,
            segment_name='BodyPin',
            shape='cube',
            side=this.side,
            size=size,
            matrix=matrices[1],
            create_gimbal=this.create_gimbal
        )

        piston_jnt_handle_list = []
        start_piston_matrix = 2
        end_piston_matrix = 3
        up_piston_matrix = 4
        root = this.get_root()
        for i in range(this.count):
            segment_name = rig_factory.index_dictionary[i].title()
            start_piston_transform = this.create_child(
                Transform,
                segment_name='%sStart' % segment_name,
                matrix=matrices[start_piston_matrix]
            )

            end_piston_transform = this.create_child(
                Transform,
                segment_name='%sEnd' % segment_name,
                matrix=matrices[end_piston_matrix]
            )

            start_piston_pin_handle_jnt = this.create_child(
                Joint,
                segment_name='%sStart' % segment_name,
                matrix=matrices[start_piston_matrix],
                parent=this.joint_group
            )
            piston_jnt_handle_list.append(start_piston_pin_handle_jnt)
            start_piston_matrix = start_piston_matrix + 3

            end_piston_pin_handle_jnt = this.create_child(
                Joint,
                segment_name='%sEnd' % segment_name,
                matrix=matrices[end_piston_matrix],
                parent=this.joint_group
            )
            piston_jnt_handle_list.append(end_piston_pin_handle_jnt)
            end_piston_matrix = end_piston_matrix + 3

            piston_part_handle_jnt = this.create_child(
                Joint,
                segment_name='%sPiston' % segment_name,
                parent=this.joint_group
            )
            piston_jnt_handle_list.append(piston_part_handle_jnt)

            piston_part_handle = this.create_handle(
                handle_type=GroupedHandle,
                segment_name='%sPiston' % segment_name,
                shape='cube',
                side=this.side,
                size=size
            )

            up_handle_jnt = this.create_child(
                Joint,
                segment_name='%sUp' % segment_name,
                matrix=matrices[up_piston_matrix],
                parent=this.joint_group
            )
            piston_jnt_handle_list.append(up_handle_jnt)
            up_piston_matrix = up_piston_matrix + 3


            piston_dist = this.create_child(
                DependNode,
                segment_name='%sPistonDistance' % segment_name,
                side=this.side,
                node_type='distanceBetween'
            )

            piston_stretch_mdn = this.create_child(
                DependNode,
                segment_name='%sStretch' % segment_name,
                side=this.side,
                node_type='multiplyDivide'
            )

            piston_volume_mdn = this.create_child(
                DependNode,
                segment_name='%sVolume' % segment_name,
                side=this.side,
                node_type='multiplyDivide'
            )

            start_piston_pin_handle_jnt.plugs['worldMatrix'].element(0).connect_to(piston_dist.plugs['inMatrix1'])
            end_piston_pin_handle_jnt.plugs['worldMatrix'].element(0).connect_to(piston_dist.plugs['inMatrix2'])
            piston_dist.plugs['distance'].connect_to(piston_stretch_mdn.plugs['input1X'])
            piston_distance = piston_dist.plugs['distance'].get_value()
            piston_stretch_mdn.plugs['input2X'].set_value(piston_distance)
            piston_stretch_mdn.plugs['operation'].set_value(2)
            piston_stretch_mdn.plugs['outputX'].connect_to(piston_volume_mdn.plugs['input1X'])
            piston_volume_mdn.plugs['input2X'].set_value(-1)
            piston_volume_mdn.plugs['operation'].set_value(3)

            if this.stretchy:
                piston_stretch_mdn.plugs['outputX'].connect_to(piston_part_handle_jnt.plugs['scaleY'])
                piston_volume_mdn.plugs['outputX'].connect_to(piston_part_handle_jnt.plugs['scaleX'])
                piston_volume_mdn.plugs['outputX'].connect_to(piston_part_handle_jnt.plugs['scaleZ'])

            else:
                pass


            controller.create_parent_constraint(
                body_piston_pin_handle,
                up_handle_jnt,
                mo=True
            )

            controller.create_parent_constraint(
                wheel_piston_pin_handle,
                start_piston_transform,
                mo=True
            )

            controller.create_parent_constraint(
                body_piston_pin_handle,
                end_piston_transform,
                mo=True
            )

            controller.create_point_constraint(
                start_piston_transform,
                start_piston_pin_handle_jnt,
                mo=True
            )

            controller.create_point_constraint(
                end_piston_transform,
                end_piston_pin_handle_jnt,
                mo=True
            )

            controller.create_aim_constraint(
                piston_part_handle_jnt,
                start_piston_pin_handle_jnt,
                worldUpType='object',
                worldUpObject=up_handle_jnt.get_selection_string(),
                aimVector=env.aim_vector,
                upVector=env.up_vector,
                mo=False
            )

            aim_vector = []
            for x in env.aim_vector:
                aim_vector.append(x * -1)

            controller.create_aim_constraint(
                piston_part_handle_jnt,
                end_piston_pin_handle_jnt,
                worldUpType='object',
                worldUpObject=up_handle_jnt.get_selection_string(),
                aimVector=aim_vector,
                upVector=env.up_vector,
                mo=False
            )

            piston_pc = controller.create_point_constraint(
                start_piston_transform,
                end_piston_transform,
                piston_part_handle.groups[1]
            )

            controller.create_parent_constraint(
                piston_part_handle,
                piston_part_handle_jnt
            )

            controller.create_aim_constraint(
                start_piston_transform,
                piston_part_handle.groups[1],
                worldUpType='object',
                worldUpObject=up_handle_jnt.get_selection_string(),
                aimVector=aim_vector,
                upVector=env.up_vector,
                mo=False
            )

            if root:
                root.add_plugs(
                    [
                        piston_part_handle.plugs['tx'],
                        piston_part_handle.plugs['ty'],
                        piston_part_handle.plugs['tz']
                    ]
                )

        controller.create_parent_constraint(
            wheel_piston_pin_handle,
            wheel_piston_pin_handle_jnt
        )

        controller.create_parent_constraint(
            body_piston_pin_handle,
            body_piston_pin_handle_jnt
        )

        #########################################################################################
        if root:
            root.add_plugs(
                [
                    wheel_piston_pin_handle.plugs['tx'],
                    wheel_piston_pin_handle.plugs['ty'],
                    wheel_piston_pin_handle.plugs['tz'],
                    body_piston_pin_handle.plugs['tx'],
                    body_piston_pin_handle.plugs['ty'],
                    body_piston_pin_handle.plugs['tz']
                ]
            )
        this.joint_chain = False
        this.joints = piston_jnt_handle_list
        return this