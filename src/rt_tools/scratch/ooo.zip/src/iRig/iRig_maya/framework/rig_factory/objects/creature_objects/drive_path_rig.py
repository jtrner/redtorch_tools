from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.dag_node import DagNode
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.nurbs_curve import NurbsCurve
from rig_factory.objects.node_objects.nurbs_surface import NurbsSurface
from rig_factory.objects.node_objects.mesh import Mesh
from rig_factory.objects.rig_objects.line import Line
import rig_factory.environment as env
from rig_factory.objects.rig_objects.capsule import Capsule
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_factory.objects.node_objects.locator import Locator
from rig_factory.objects.rig_objects.cone import Cone
from rig_factory.objects.rig_objects.ribbon import Ribbon
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle
from rig_math.vector import Vector
import rig_factory.utilities.joint_volume_utiilities as jvu
import rig_factory


class DrivePathGuide(PartGuide):

    default_settings = {
        'root_name': 'DrivePath',
        'size': 1.0,
        'side': 'center',
        'count': 5,
        'joint_count': 25,
        'secondary_count': 9,
        'create_gimbals': False,
        'create_tweaks': False,
        'create_joint_handle': False,
        'fk_mode': True,
        'slide': 0.25,
        'lock_length': 0.0,
        'create_scaling_joints': False

    }

    joint_count = DataProperty(
        name='joint_count'
    )
    count = DataProperty(
        name='count'
    )
    secondary_count = DataProperty(
        name='secondary_count'
    )
    create_gimbals = DataProperty(
        name='create_gimbals'
    )
    create_tweaks = DataProperty(
        name='create_tweaks'
    )
    up_handle = ObjectProperty(
        name='count'
    )
    fk_mode = DataProperty(
        name='fk_mode'
    )
    slide = DataProperty(
        name='slide'
    )
    lock_length = DataProperty(
        name='lock_length'
    )
    create_joint_handle = DataProperty(
        name='create_joint_handle'
    )
    base_joints = ObjectListProperty(
        name='base_joints'
    )
    create_scaling_joints = DataProperty(
        name='create_scaling_joints'
    )
    def __init__(self, **kwargs):
        super(DrivePathGuide, self).__init__(**kwargs)
        self.toggle_class = DrivePath.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(DrivePathGuide, cls).create(controller, **kwargs)
        handle_positions = kwargs.get('handle_positions', dict())
        size = this.size
        side = this.side
        spacing = size * 2.0
        root = this.get_root()
        size_plug = this.plugs['size']
        size_multiply = this.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='Size'
        )

        size_plug.connect_to(size_multiply.plugs['input1X'])
        size_plug.connect_to(size_multiply.plugs['input1Y'])
        size_plug.connect_to(size_multiply.plugs['input1Z'])
        size_multiply.plugs['input2X'].set_value(0.5)
        size_multiply.plugs['input2Y'].set_value(0.25)
        size_multiply.plugs['input2Z'].set_value(0.25)

        joints = []
        base_joints = []
        locators = []
        handles = []
        base_handles = []
        capsules = []

        up_handle = this.create_handle(
            segment_name='Up'
        )
        up_locator = up_handle.create_child(Locator)
        up_locator.plugs['v'].set_value(False)
        up_handle.plugs['translate'].set_value(handle_positions.get(up_handle.name, [0.0, 0.0, size*2.0]))
        up_handle.mesh.assign_shading_group(this.get_root().shaders[side].shading_group)
        size_plug.connect_to(up_handle.plugs['size'])

        root.add_plugs(
            [
                up_handle.plugs['tx'],
                up_handle.plugs['ty'],
                up_handle.plugs['tz']
            ]
        )

        for i in range(this.count):
            index_character = rig_factory.index_dictionary[i].upper()
            base_joint = this.create_child(
                Joint,
                segment_name='Base%s' % index_character
            )
            secondary_handle = this.create_handle(
                segment_name=index_character
            )
            position = handle_positions.get(secondary_handle.name, [0.0, spacing*i, 0.0])
            secondary_handle.plugs['translate'].set_value(position)

            cone_x = base_joint.create_child(
                Cone,
                segment_name='ConeX%s' % index_character,
                axis=[1.0, 0.0, 0.0]
            )
            cone_y = base_joint.create_child(
                Cone,
                segment_name='ConeY%s' % index_character,
                axis=[0.0, 1.0, 0.0]
            )
            cone_z = base_joint.create_child(
                Cone,
                segment_name='ConeZ%s' % index_character,
                axis=[0.0, 0.0, 1.0]
            )
            locator = base_joint.create_child(
                Locator
            )
            controller.create_point_constraint(
                secondary_handle,
                base_joint,
                mo=False
            )

            size_multiply.plugs['outputX'].connect_to(secondary_handle.plugs['size'])
            size_multiply.plugs['outputX'].connect_to(cone_x.plugs['size'])
            size_multiply.plugs['outputX'].connect_to(cone_y.plugs['size'])
            size_multiply.plugs['outputX'].connect_to(cone_z.plugs['size'])
            base_joint.plugs.set_values(
                drawStyle=2
            )
            cone_x.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
            )
            cone_y.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
            )
            cone_z.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
            )
            locator.plugs.set_values(
                visibility=False
            )
            locator.plugs['visibility'].set_value(False)
            secondary_handle.mesh.assign_shading_group(root.shaders[side].shading_group)
            cone_x.mesh.assign_shading_group(root.shaders['x'].shading_group)
            cone_y.mesh.assign_shading_group(root.shaders['y'].shading_group)
            cone_z.mesh.assign_shading_group(root.shaders['z'].shading_group)

            base_joints.append(base_joint)
            locators.append(locator)
            handles.append(secondary_handle)
            base_handles.append(secondary_handle)

        for i in range(this.count):
            if i < this.count - 1:
                controller.create_aim_constraint(
                    handles[i + 1],
                    base_joints[i],
                    worldUpType='object',
                    worldUpObject=up_handle.get_selection_string(),
                    aimVector=env.side_aim_vectors[side],
                    upVector=env.side_up_vectors[side]
                )
            else:
                controller.create_aim_constraint(
                    handles[i - 1],
                    base_joints[i],
                    worldUpType='object',
                    worldUpObject=up_handle,
                    aimVector=[x * -1 for x in env.side_aim_vectors[side]],
                    upVector=env.side_up_vectors[side]
                )

        up_vector_line = this.create_child(
            Line,
            segment_name='Line'
        )
        locators[0].plugs['worldPosition'].element(0).connect_to(up_vector_line.curve.plugs['controlPoints'].element(0))
        up_locator.plugs['worldPosition'].element(0).connect_to(up_vector_line.curve.plugs['controlPoints'].element(1))
        up_vector_line.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
        )

        secondary_surface = build_extrude_ribbon(
            this,
            base_joints,
            up_handle,
            'Secondary',
            construction_history=True
        )
        secondary_transforms = create_ribbon_transforms(
            this,
            secondary_surface,
            this.secondary_count
        )
        secondary_surface.plugs['Slide'].set_value(False)

        for i, transform in enumerate(secondary_transforms):

            prism_node = transform.create_child(
                DependNode,
                node_type='polyPrism',
                suffix='Ppm'
            )

            prism_mesh = transform.create_child(
                Mesh
            )

            transform.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2,
            )
            size_multiply.plugs['outputZ'].connect_to(prism_node.plugs['length'])
            size_multiply.plugs['outputX'].connect_to(prism_node.plugs['sideLength'])
            prism_node.plugs['numberOfSides'].set_value(6)
            prism_node.plugs['output'].connect_to(prism_mesh.plugs['inMesh'])

            prism_mesh.assign_shading_group(root.shaders[side].shading_group)
            transform.plugs['translate'].set_locked(True)
            transform.plugs['rotate'].set_locked(True)
            transform.plugs['scale'].set_locked(True)

        if not secondary_transforms:
            secondary_transforms = base_joints

        joint_surface = build_extrude_ribbon(
            this,
            secondary_transforms,
            up_handle,
            'Joint',
            construction_history=True
        )
        transforms = create_ribbon_transforms(
            this,
            joint_surface,
            this.joint_count
        )

        locators = []
        capsule_start_width = size
        capsule_end_width = size*0.2

        joint_parent = this
        for i, transform in enumerate(transforms):
            locator = transform.create_child(Locator)
            locator.plugs['v'].set_value(False)
            locators.append(locator)
            end_segment_width = capsule_end_width / len(transforms) * i
            start_segment_width = capsule_start_width - (capsule_start_width / len(transforms) * i)
            index_character = rig_factory.index_dictionary[i].upper()
            joint = transform.create_child(
                Joint,
                segment_name=index_character,
                parent=joint_parent
            )
            controller.create_parent_constraint(
                transform,
                joint,
                mo=False
            )
            joints.append(joint)
            joint_parent = joint
            joint.plugs.set_values(
                overrideEnabled=True,
                overrideDisplayType=2
            )
            joint.plugs.set_locked(
                translate=True,
                rotate=True,
                scale=True
            )
            if i != 0:
                capsule = transform.create_child(
                    Capsule,
                    segment_name='Segment%s' % index_character,
                    parent=this
                )
                multiply_node = capsule.create_child(
                    DependNode,
                    node_type='multDoubleLinear'
                )
                size_plug.connect_to(multiply_node.plugs['input1'])
                multiply_node.plugs['input2'].set_value(start_segment_width + end_segment_width)
                multiply_node.plugs['output'].connect_to(capsule.plugs['size'])
                capsule.poly_cylinder.plugs['roundCap'].set_value(0)
                capsule.mesh.assign_shading_group(root.shaders[side].shading_group)
                locators[i-1].plugs['worldPosition'].element(0).connect_to(capsule.plugs['position1'])
                locators[i].plugs['worldPosition'].element(0).connect_to(capsule.plugs['position2'])

                controller.create_point_constraint(transforms[i-1], transforms[i], capsule)
                controller.create_aim_constraint(
                    joint,
                    capsule,
                    aimVector=env.aim_vector,
                    upVector=env.up_vector,
                    worldUpObject=transforms[i-1],
                    worldUpType='objectRotation',
                    worldUpVector=[1.0, 0.0, 0.0]
                )

        slide_plug = this.create_plug(
            'Slide',
            at='double',
            k=True,
            min=0.0,
            max=1.0,
            dv=this.slide
        )
        lock_length_plug = this.create_plug(
            'LockLength',
            at='double',
            k=True,
            min=0.0,
            max=1.0,
            dv=this.lock_length
        )
        grow_joints_plug = this.create_plug(
            'GrowJoints',
            at='double',
            k=True,
            min=0.001,
            max=1.0,
            dv=1.0
        )
        grow_handles_plug = this.create_plug(
            'GrowHandles',
            at='double',
            k=True,
            min=0.001,
            max=1.0,
            dv=1.0
        )
        lock_length_plug.connect_to(joint_surface.plugs['LockLength'])
        lock_length_plug.connect_to(secondary_surface.plugs['LockLength'])

        slide_plug.connect_to(joint_surface.plugs['Slide'])
        grow_joints_plug.connect_to(joint_surface.plugs['Grow'])

        slide_plug.connect_to(secondary_surface.plugs['Slide'])
        grow_handles_plug.connect_to(secondary_surface.plugs['Grow'])


        this.up_handle = up_handle
        this.base_joints = base_joints
        this.joints = joints

        return this

    def get_toggle_blueprint(self):
        blueprint = super(DrivePathGuide, self).get_toggle_blueprint()
        position_1 = self.handles[0].get_matrix().get_translation()
        position_2 = self.handles[1].get_matrix().get_translation()
        blueprint.update(
            matrices=[list(x.get_matrix()) for x in self.base_joints],
            up_vector=(position_2 - position_1).normalize().data,
            slide=self.plugs['Slide'].get_value()
        )
        return blueprint

    def get_blueprint(self):
        blueprint = super(DrivePathGuide, self).get_blueprint()
        blueprint['slide'] = self.plugs['Slide'].get_value()
        return blueprint


def build_extrude_ribbon(part, transforms, up_object, segment_name, construction_history=True):

    root = part.get_root()
    if not part.plugs.exists('RibbonWidth'):
        ribbon_width_plug = part.create_plug(
            'RibbonWidth',
            at='double',
            k=True,
            min=0.01,
            max=1.0,
            dv=0.5
        )
    else:
        ribbon_width_plug = part.plugs['RibbonWidth']

    ribbon_transform = part.create_child(
        Transform,
        segment_name=segment_name
    )

    ribbon_base_curve = ribbon_transform.create_child(
        NurbsCurve,
        degree=2,
        segment_name='%sBase' % segment_name,
        positions=[x.get_translation() for x in transforms]
    )
    ribbon_base_curve.plugs['intermediateObject'].set_value(True)
    ribbon_surface = ribbon_transform.create_child(NurbsSurface)

    for i, joint in enumerate(transforms):
        joint.plugs['translate'].connect_to(ribbon_base_curve.plugs['controlPoints'].element(i))

    extrude = part.create_child(
        DependNode,
        node_type='extrude',
        segment_name='%sExtrude' % segment_name
    )
    extrude_vector_subtract = part.create_child(
        DependNode,
        node_type='plusMinusAverage',
        segment_name='%sExtrude' % segment_name
    )
    ribbon_width_multiply = part.create_child(
        DependNode,
        node_type='multiplyDivide',
        segment_name='%sLengthMultiply' % segment_name
    )
    ribbon_transform.plugs['translate'].set_locked(True)
    ribbon_transform.plugs['rotate'].set_locked(True)
    ribbon_transform.plugs['scale'].set_locked(True)
    ribbon_transform.plugs.set_values(
        overrideEnabled=True,
        overrideDisplayType=2
    )

    up_locator = up_object.create_child(
        Locator,
        segment_name='%sUpRibbonLocator' % segment_name
    )
    base_locator = transforms[0].create_child(
        Locator,
        segment_name='%sBaseRibbonLocator' % segment_name
    )

    up_locator.plugs['visibility'].set_value(False)
    base_locator.plugs['visibility'].set_value(False)
    part.plugs['size'].connect_to(ribbon_width_multiply.plugs['input1X'])
    ribbon_width_plug.connect_to(ribbon_width_multiply.plugs['input2X'])
    extrude_vector_subtract.plugs['operation'].set_value(2)
    base_locator.plugs['worldPosition'].element(0).connect_to(extrude_vector_subtract.plugs['input3D'].element(0))
    up_locator.plugs['worldPosition'].element(0).connect_to(extrude_vector_subtract.plugs['input3D'].element(1))
    extrude.plugs['extrudeType'].set_value(0)
    extrude.plugs['useProfileNormal'].set_value(False)
    extrude_vector_subtract.plugs['output3D'].connect_to(extrude.plugs['direction'])
    ribbon_width_multiply.plugs['outputX'].connect_to(extrude.plugs['length'])
    extrude.plugs['outputSurface'].connect_to(ribbon_surface.plugs['create'])
    ribbon_base_curve.plugs['worldSpace'].element(0).connect_to(extrude.plugs['profile'])
    ribbon_surface.assign_shading_group(root.shaders['highlight'].shading_group)
    return ribbon_surface


class DrivePath(Part):

    add_root = DataProperty(
        name='add_root'
    )
    fk_mode = DataProperty(
        name='fk_mode'
    )
    create_tweaks = DataProperty(
        name='create_tweaks'
    )
    create_gimbals = DataProperty(
        name='create_gimbals'
    )
    up_vector = DataProperty(
        name='up_vector'
    )
    settings_handle = ObjectProperty(
        name='settings_handle'
    )
    joint_matrices = DataProperty(
        name='joint_matrices'
    )
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )
    joint_count = DataProperty(
        name='joint_count'
    )
    secondary_count = DataProperty(
        name='secondary_count'
    )
    slide = DataProperty(
        name='slide'
    )
    lock_length = DataProperty(
        name='lock_length'
    )
    create_joint_handle = DataProperty(
        name='create_joint_handle'
    )
    create_scaling_joints = DataProperty(
        name='create_scaling_joints'
    )
    def __init__(self, **kwargs):
        super(DrivePath, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(DrivePath, cls).create(controller, **kwargs)
        matrices = this.matrices
        size = this.size
        side = this.side
        base_joints = this.joints

        root = this.get_root()

        joint_parent = this.joint_group
        handle_parent = this
        handles = []
        secondary_handles = []
        tweak_handles = []

        for x, matrix in enumerate(matrices):
            segment_name = rig_factory.index_dictionary[x].title()
            joint = this.create_child(
                Joint,
                segment_name='Base%s' % segment_name,
                matrix=matrix,
                parent=joint_parent
            )
            joint.zero_rotation()
            joint.plugs.set_values(
                overrideEnabled=1,
                overrideDisplayType=2,
                drawStyle=2
            )
            base_joints.append(joint)
            handle = this.create_handle(
                segment_name=segment_name,
                size=size,
                matrix=matrix,
                side=side,
                shape='circle',
                parent=handle_parent,
                create_gimbal=this.create_gimbals
            )
            handles.append(handle)

            if this.fk_mode:
                handle_parent = handle.gimbal_handle if this.create_gimbals else handle


            handle.plugs['scale'].connect_to(joint.plugs['scale'])
            handle.plugs['rotateOrder'].connect_to(joint.plugs['rotateOrder'])
            joint_driver = handle

            if this.create_tweaks:
                tweak_handle = this.create_handle(
                    segment_name='Tweak%s' % segment_name,
                    size=size * 0.25,
                    matrix=matrix,
                    side=side,
                    shape='diamond',
                    create_gimbal=False,
                    parent=handle.gimbal_handle if this.create_gimbals else handle
                )
                joint_driver = tweak_handle
                root.add_plugs(
                    tweak_handle.plugs['rx'],
                    tweak_handle.plugs['ry'],
                    tweak_handle.plugs['rz'],
                    tweak_handle.plugs['tx'],
                    tweak_handle.plugs['ty'],
                    tweak_handle.plugs['tz'],
                    tweak_handle.plugs['sx'],
                    tweak_handle.plugs['sy'],
                    tweak_handle.plugs['sz']
                )

                tweak_handles.append(tweak_handle)
            elif this.create_gimbals:
                joint_driver = handle.gimbal_handle

            controller.create_parent_constraint(
                joint_driver,
                joint
            )

            controller.create_scale_constraint(
                joint_driver,
                joint
            )

            root.add_plugs(
                handle.plugs['rx'],
                handle.plugs['ry'],
                handle.plugs['rz'],
                handle.plugs['tx'],
                handle.plugs['ty'],
                handle.plugs['tz'],
                handle.plugs['sx'],
                handle.plugs['sy'],
                handle.plugs['sz']
            )

        settings_matrix = base_joints[0].get_matrix()
        settings_handle = this.create_handle(
            shape='gear',
            segment_name='Settings',
            matrix=settings_matrix,
            parent=base_joints[0],
            create_gimbal=False

        )
        settings_handle.groups[0].plugs['tz'].set_value(size * 5 if side == 'right' else size * -5)

        secondary_ribbon = this.create_child(
            Ribbon,
            [list(x.get_translation()) for x in this.matrices],
            segment_name='Secondary',
            vector=(Vector(this.up_vector) * (this.size * 0.05)).data,
            extrude=True,
            side=this.side,
            degree=2
        )
        this.controller.scene.reverseSurface(
            secondary_ribbon.nurbs_surface,
            ch=False,
            d=3,
            rpo=1
        )
        this.controller.scene.skinCluster(
            base_joints,
            secondary_ribbon.nurbs_surface,
            toSelectedBones=True,
            maximumInfluences=1
        )
        secondary_ribbon.plugs['visibility'].set_value(False)

        secondary_transforms = create_ribbon_transforms(
            this,
            secondary_ribbon.nurbs_surface,
            this.secondary_count,
            tangent_parameter_value=0.5
        )

        secondary_joints = []
        for i, transform in enumerate(secondary_transforms):
            index_character = rig_factory.index_dictionary[i].upper()
            secondary_handle = this.create_handle(
                segment_name='Secondary%s' % index_character,
                shape='circle',
                size=this.size * 0.75,
                create_gimbal=this.create_gimbals
            )
            secondary_joint = secondary_handle.create_child(
                Joint,
                parent=root.deform_group
            )
            this.controller.create_parent_constraint(
                transform,
                secondary_handle.groups[0],
                mo=False
            )
            this.controller.create_parent_constraint(
                secondary_handle.gimbal_handle if secondary_handle.gimbal_handle else secondary_handle,
                secondary_joint,
                mo=False
            )
            secondary_joints.append(secondary_joint)
            secondary_handle.plugs['overrideEnabled'].set_value(True)
            secondary_handle.plugs['overrideColorRGB'].set_value(env.secondary_colors[this.side])
            secondary_handle.plugs['overrideRGBColors'].set_value(1)
            secondary_joint.plugs['drawStyle'].set_value(2)

            secondary_parameter_plug = secondary_handle.create_plug(
                'parameter',
                at='double',
                dv=0.0
            )
            transform.plugs['parameter'].connect_to(secondary_parameter_plug)

            root.add_plugs(
                secondary_handle.plugs['tx'],
                secondary_handle.plugs['ty'],
                secondary_handle.plugs['tz']
            )
            secondary_handles.append(secondary_handle)

        if not secondary_joints:
            secondary_joints = this.base_deform_joints
        joint_ribbon = this.create_child(
            Ribbon,
            [list(x.get_translation()) for x in secondary_joints],
            segment_name='Joint',
            vector=(Vector(this.up_vector) * (this.size * 0.05)).data,
            extrude=True,
            degree=2
        )

        this.controller.scene.reverseSurface(
            joint_ribbon.nurbs_surface,
            ch=False,
            d=3,
            rpo=1
        )

        this.controller.scene.skinCluster(
            secondary_joints,
            joint_ribbon.nurbs_surface,
            toSelectedBones=True,
            maximumInfluences=1
        )
        joint_ribbon.plugs['visibility'].set_value(False)

        transforms = create_ribbon_transforms(
            this,
            joint_ribbon.nurbs_surface,
            this.joint_count,
            tangent_parameter_value=0.5
        )

        slide_plug = settings_handle.create_plug(
            'Slide',
            at='double',
            k=True,
            min=0.0,
            max=1.0,
            dv=this.slide
        )
        joint_grow_plug = settings_handle.create_plug(
            'JointGrow',
            at='double',
            k=True,
            min=0.001,
            max=1.0,
            dv=1.0
        )
        handle_grow_plug = settings_handle.create_plug(
            'HandleGrow',
            at='double',
            k=True,
            min=0.001,
            max=1.0,
            dv=1.0
        )
        lock_length_plug = settings_handle.create_plug(
            'LockLength',
            at='double',
            k=True,
            min=0.0,
            max=1.0,
            dv=0.0
        )

        slide_plug.connect_to(joint_ribbon.nurbs_surface.plugs['Slide'])
        lock_length_plug.connect_to(joint_ribbon.nurbs_surface.plugs['LockLength'])
        slide_plug.connect_to(secondary_ribbon.nurbs_surface.plugs['Slide'])
        lock_length_plug.connect_to(secondary_ribbon.nurbs_surface.plugs['LockLength'])

        joint_grow_plug.connect_to(joint_ribbon.nurbs_surface.plugs['Grow'])
        handle_grow_plug.connect_to(secondary_ribbon.nurbs_surface.plugs['Grow'])

        root.add_plugs(
            slide_plug,
            joint_grow_plug,
            handle_grow_plug,
            lock_length_plug
        )
        joints = []
        joint_parent = this.joint_group
        for i, transform in enumerate(transforms):
            segment_name = rig_factory.index_dictionary[i].upper()
            driver_transform = transform
            if this.create_joint_handle:
                joint_handle = this.create_handle(
                    segment_name='SecondaryBind%s' % segment_name,
                    shape='circle',
                    size=this.size * 0.25,
                    parent=transform,
                    create_gimbal=False
                )
                joint_handle.plugs['overrideEnabled'].set_value(True)
                joint_handle.plugs['overrideColorRGB'].set_value(env.secondary_colors[this.side])
                joint_handle.plugs['overrideRGBColors'].set_value(1)
                this.controller.create_parent_constraint(
                    driver_transform,
                    joint_handle.groups[0],
                    mo=False
                )
                driver_transform = joint_handle
                root.add_plugs(
                    [
                        joint_handle.plugs['tx'],
                        joint_handle.plugs['ty'],
                        joint_handle.plugs['tz']
                    ]
                )
            joint = this.create_child(
                Joint,
                segment_name=segment_name,
                parent=joint_parent
            )
            parameter_plug = joint.create_plug(
                'parameter',
                at='double',
                dv=0.0
            )
            transform.plugs['parameter'].connect_to(parameter_plug)
            joint.plugs.set_values(
                overrideEnabled=True,
                overrideRGBColors=True,
                overrideColorRGB=env.colors['bindJoints'],
                overrideDisplayType=0
            )
            this.controller.create_parent_constraint(
                driver_transform,
                joint,
                mo=False
            )
            if i != 0:
                joints[i - 1].plugs['scale'].connect_to(
                    joint.plugs['inverseScale'],
                )
            joint_parent = joint
            joints.append(joint)
        secondary_ribbon.plugs['inheritsTransform'].set_value(False)
        joint_ribbon.plugs['inheritsTransform'].set_value(False)
        if this.create_scaling_joints:

            scale_x_plugs = []
            scale_z_plugs = []
            if tweak_handles:
                for i, tweak_handle in enumerate(tweak_handles):
                    segment_character = rig_factory.index_dictionary[i].upper()
                    paremeter_plug = tweak_handle.create_plug(
                        'parameter_driver',
                        at='double',
                        dv=0.0
                    )
                    tweak_getter = tweak_handle.create_child(
                        Locator,
                        segment_name='TweakGetter%s' % segment_character
                    )
                    closest_point = tweak_handle.create_child(
                        DependNode,
                        node_type='closestPointOnSurface'
                    )
                    tweak_getter.plugs['visibility'].set_value(False)
                    joint_ribbon.nurbs_surface.plugs['worldSpace'].element(0).connect_to(closest_point.plugs['inputSurface'])
                    tweak_getter.plugs['worldPosition'].element(0).connect_to(closest_point.plugs['inPosition'])
                    closest_point.plugs['parameterU'].connect_to(paremeter_plug)

                scale_x_plugs = jvu.generate_distribution_plugs(
                    joint_ribbon.nurbs_surface,
                    [x.plugs['parameter'] for x in joints],
                    [x.plugs['sx'] for x in tweak_handles],
                    'SX',
                    subtract_value=1.0
                )
                scale_z_plugs = jvu.generate_distribution_plugs(
                    joint_ribbon.nurbs_surface,
                    [x.plugs['parameter'] for x in joints],
                    [x.plugs['sz'] for x in tweak_handles],
                    'SZ',
                    subtract_value=1.0
                )
            for i, handle in enumerate(secondary_handles):
                segment_character = rig_factory.index_dictionary[i].upper()
                paremeter_plug = handle.create_plug(
                    'parameter_driver',
                    at='double',
                    dv=0.0
                )
                tweak_getter = handle.create_child(
                    Locator,
                    segment_name='SecondaryGetter%s' % segment_character
                )
                closest_point = handle.create_child(
                    DependNode,
                    node_type='closestPointOnSurface'
                )
                tweak_getter.plugs['visibility'].set_value(False)
                joint_ribbon.nurbs_surface.plugs['worldSpace'].element(0).connect_to(closest_point.plugs['inputSurface'])
                tweak_getter.plugs['worldPosition'].element(0).connect_to(closest_point.plugs['inPosition'])
                closest_point.plugs['parameterU'].connect_to(paremeter_plug)

            scale_x_secondary_plugs = jvu.generate_distribution_plugs(
                joint_ribbon.nurbs_surface,
                [x.plugs['parameter'] for x in joints],
                [x.plugs['sx'] for x in secondary_handles],
                'SXSecondary',
                subtract_value=1.0
            )
            scale_z_secondary_plugs = jvu.generate_distribution_plugs(
                joint_ribbon.nurbs_surface,
                [x.plugs['parameter'] for x in joints],
                [x.plugs['sz'] for x in secondary_handles],
                'SZSecondary',
                subtract_value=1.0
            )
            squash_plugs = jvu.generate_volume_plugs(
                joint_ribbon.nurbs_surface,
                [x.plugs['parameter'] for x in joints]
            )
            for i in range(len(joints)):
                index_character = rig_factory.index_dictionary[i].upper()
                add_default = this.create_child(
                    DependNode,
                    segment_name='AddDefault%s' % index_character,
                    node_type='plusMinusAverage'
                )
                squash_plugs[i][0].connect_to(add_default.plugs['input2D'].element(0).child(0))
                squash_plugs[i][1].connect_to(add_default.plugs['input2D'].element(0).child(1))
                if scale_x_plugs:
                    scale_x_plugs[i].connect_to(add_default.plugs['input2D'].element(1).child(0))
                if scale_z_plugs:
                    scale_z_plugs[i].connect_to(add_default.plugs['input2D'].element(1).child(1))
                scale_x_secondary_plugs[i].connect_to(add_default.plugs['input2D'].element(2).child(0))
                scale_z_secondary_plugs[i].connect_to(add_default.plugs['input2D'].element(2).child(1))
                add_default.plugs['input2D'].element(3).child(0).set_value(1.0)
                add_default.plugs['input2D'].element(3).child(1).set_value(1.0)
                add_default.plugs['output2D'].child(0).connect_to(joints[i].plugs['sx'])
                add_default.plugs['output2D'].child(1).connect_to(joints[i].plugs['sz'])
            auto_volume_plug = settings_handle.create_plug(
                'AutoVolume',
                at='double',
                dv=1.0,
                k=True,
                min=0.0,
                max=10.0
            )
            min_auto_volume_plug = settings_handle.create_plug(
                'MinAutoVolume',
                at='double',
                dv=-0.5,
                k=True
            )
            max_auto_volume_plug = settings_handle.create_plug(
                'MaxAutoVolume',
                at='double',
                dv=0.5,
                k=True
            )
            auto_volume_plug.connect_to(joint_ribbon.nurbs_surface.plugs['AutoVolume'])
            min_auto_volume_plug.connect_to(joint_ribbon.nurbs_surface.plugs['MinAutoVolume'])
            max_auto_volume_plug.connect_to(joint_ribbon.nurbs_surface.plugs['MaxAutoVolume'])
            root.add_plugs(
                auto_volume_plug
            )

        drive_handle = this.create_handle(
            handle_type=GroupedHandle,
            shape='ball',
            side=this.side,
            segment_name='Constrain',
            size=size,
            matrix=matrices[0]
        )

        surface_fol_transform = this.create_child(
            Transform,
            segment_name='Follicle',
            parent=this.utility_group
        )

        surface_fol_shape = surface_fol_transform.create_child(
            DagNode,
            node_type='follicle',
        )

        surface_fol_shape.plugs['outTranslate'].connect_to(surface_fol_transform.plugs['translate'])
        surface_fol_shape.plugs['outRotate'].connect_to(surface_fol_transform.plugs['rotate'])
        joint_ribbon.nurbs_surface.plugs['local'].connect_to(surface_fol_shape.plugs['inputSurface'])
        joint_ribbon.nurbs_surface.plugs['worldMatrix'].element(0).connect_to(surface_fol_shape.plugs['inputWorldMatrix'])

        drive_plug = drive_handle.create_plug(
            'Driver',
            at='double',
            k=True,
            min=0.0,
            max=100.0,
            dv=0.0
        )

        driver_plug_md = this.create_child(
            DependNode,
            segment_name='Driver',
            side=this.side,
            node_type='multiplyDivide'
        )

        controller.create_parent_constraint(
            surface_fol_transform,
            drive_handle.groups[0],
            mo=True
        )

        drive_plug.connect_to(driver_plug_md.plugs['input1X'])
        driver_plug_md.plugs['input2X'].set_value(0.01)
        driver_plug_md.plugs['outputX'].connect_to(surface_fol_shape.plugs['parameterU'])

        this.settings_handle = settings_handle
        this.joints = joints
        if root:
            root.add_plugs(
                [
                    drive_plug
                ]
            )
        return this

    def get_blueprint(self):
        blueprint = super(DrivePath, self).get_blueprint()
        return blueprint


def create_ribbon_transforms(part, ribbon_surface, count, tangent_parameter_value=0.0):

    controller = part.controller
    slide_plug = ribbon_surface.create_plug(
        'Slide',
        at='double',
        k=True,
        min=0.0,
        max=1.0,
        dv=1.0
    )
    grow_plug = ribbon_surface.create_plug(
        'Grow',
        at='double',
        k=True,
        min=0.001,
        max=1.0,
        dv=1.0
    )

    lock_length_plug = ribbon_surface.create_plug(
        'LockLength',
        at='double',
        k=True,
        min=0.0,
        max=1.0,
        dv=0.0
    )

    segment_name = ribbon_surface.segment_name

    curves_group = part.create_child(
        Transform,
        segment_name='%sCurves' % segment_name
    )
    curves_group.plugs.set_values(
        overrideEnabled=True,
        overrideDisplayType=2,
        inheritsTransform=False
    )
    tangent_base_curve = curves_group.create_child(
        NurbsCurve,
        segment_name='%sTangentBase' % segment_name
    )
    tangent_curve = curves_group.create_child(
        NurbsCurve,
        segment_name='%sTangent' % segment_name
    )
    up_base_curve = curves_group.create_child(
        NurbsCurve,
        segment_name='%sUpBase' % segment_name
    )
    up_curve = curves_group.create_child(
        NurbsCurve,
        segment_name='%sUp' % segment_name
    )
    tangent_curve_from_surface = curves_group.create_child(
        DependNode,
        node_type='curveFromSurfaceIso'
    )
    up_curve_from_surface = curves_group.create_child(
        DependNode,
        node_type='curveFromSurfaceIso',
        segment_name='%sUp' % segment_name
    )
    grow_multiply = part.create_child(
        DependNode,
        node_type='multiplyDivide',
        segment_name='%sGrow' % segment_name
    )
    arc_length_dimension = part.create_child(
        DagNode,
        segment_name='%sLength' % segment_name,
        node_type='arcLengthDimension',
        parent=part.utility_group
    )

    tangent_base_curve.plugs['intermediateObject'].set_value(True)
    tangent_curve.plugs['intermediateObject'].set_value(True)
    up_base_curve.plugs['intermediateObject'].set_value(True)
    up_curve.plugs['intermediateObject'].set_value(True)

    # Curve stacks
    ribbon_surface.plugs['worldSpace'].element(0).connect_to(tangent_curve_from_surface.plugs['inputSurface'])
    tangent_curve_from_surface.plugs['outputCurve'].connect_to(tangent_base_curve.plugs['create'])
    tangent_base_curve.plugs['worldSpace'].element(0).connect_to(tangent_curve.plugs['create'])
    tangent_curve.plugs['worldSpace'].element(0).connect_to(arc_length_dimension.plugs['nurbsGeometry'])

    ribbon_surface.plugs['worldSpace'].element(0).connect_to(up_curve_from_surface.plugs['inputSurface'])
    up_curve_from_surface.plugs['outputCurve'].connect_to(up_base_curve.plugs['create'])
    up_base_curve.plugs['worldSpace'].element(0).connect_to(up_curve.plugs['create'])

    # Set attributes
    tangent_curve_from_surface.plugs['isoparmDirection'].set_value(0)
    tangent_curve_from_surface.plugs['isoparmValue'].set_value(tangent_parameter_value)
    tangent_base_curve.plugs['intermediateObject'].set_value(True)

    up_curve_from_surface.plugs['isoparmDirection'].set_value(0)
    up_curve_from_surface.plugs['isoparmValue'].set_value(1.0)
    up_base_curve.plugs['intermediateObject'].set_value(True)

    grow_plug.connect_to(grow_multiply.plugs['input1X'])
    ribbon_surface.plugs['spansU'].connect_to(grow_multiply.plugs['input2X'])
    arc_length_dimension.plugs.set_values(
        uParamValue=ribbon_surface.plugs['spansU'].get_value(),
        visibility=False,
    )

    starting_length = arc_length_dimension.plugs['arcLength'].get_value()
    transforms = []
    for i in range(count):
        index_character = rig_factory.index_dictionary[i].upper()
        transform = curves_group.create_child(
            Transform,
            segment_name='%sRibbon%s' % (segment_name, index_character)
        )
        parameter_plug = transform.create_plug(
            'parameter',
            at='double',
            dv=0.0
        )
        up_transform = curves_group.create_child(
            Transform,
            segment_name='%sRibbonUp%s' % (segment_name, index_character)
        )
        motion_path = transform.create_child(
            DependNode,
            node_type='motionPath',
            suffix='Mpth'
        )
        tangent_point_on_curve_info = transform.create_child(
            DependNode,
            node_type='pointOnCurveInfo'
        )
        up_point_on_curve_info = transform.create_child(
            DependNode,
            node_type='pointOnCurveInfo',
            segment_name='%sUp%s' % (segment_name, index_character)
        )

        blend_parameters = transform.create_child(
            DependNode,
            node_type='blendColors'
        )
        nearest_point_on_curve = transform.create_child(
            DependNode,
            node_type='nearestPointOnCurve',
            suffix='Npoc'
        )

        lock_length_divide = transform.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='%sLockLengthDivide%s' % (segment_name, index_character)
        )
        lock_length_parameter = transform.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='%sLockLengthParemetere%s' % (segment_name, index_character)
        )
        grow_multiply = transform.create_child(
            DependNode,
            node_type='multDoubleLinear',
            segment_name='%sGrow%s' % (segment_name, index_character)
        )

        lock_length_multiply = transform.create_child(
            DependNode,
            node_type='multDoubleLinear',
            segment_name='%sLockLength%s' % (segment_name, index_character)
        )
        blend_lock_length = transform.create_child(
            DependNode,
            node_type='blendColors',
            segment_name='%sBlendLockLength%s' % (segment_name, index_character)
        )
        parameter_clamp = transform.create_child(
            DependNode,
            node_type='clamp',
            segment_name='%sParameter%s' % (segment_name, index_character)
        )
        parameter_clamp.plugs['minR'].set_value(0.0)
        parameter_clamp.plugs['maxR'].set_value(float(ribbon_surface.plugs['spansU'].get_value()))

        #  Divide total length by starting length
        lock_length_divide.plugs['operation'].set_value(2)
        lock_length_parameter.plugs['operation'].set_value(2)

        lock_length_divide.plugs['input1X'].set_value(starting_length)
        arc_length_dimension.plugs['arcLength'].connect_to(lock_length_divide.plugs['input2X'])

        lock_length_divide.plugs['outputX'].connect_to(lock_length_parameter.plugs['input1X'])
        lock_length_parameter.plugs['input2X'].set_value(float(count - 1))

        lock_length_parameter.plugs['outputX'].connect_to(lock_length_multiply.plugs['input1'])
        lock_length_multiply.plugs['input2'].set_value(float(i))

        lock_length_plug.connect_to(blend_lock_length.plugs['blender'])
        blend_lock_length.plugs['color2R'].set_value(1.0 / (count - 1) * i)
        lock_length_multiply.plugs['output'].connect_to(blend_lock_length.plugs['color1R'])
        blend_lock_length.plugs['outputR'].connect_to(motion_path.plugs['uValue'])

        tangent_point_on_curve_info.plugs['turnOnPercentage'].set_value(False)
        tangent_curve.plugs['worldSpace'].element(0).connect_to(tangent_point_on_curve_info.plugs['inputCurve'])
        motion_path.plugs['fractionMode'].set_value(True)
        tangent_curve.plugs['worldSpace'].element(0).connect_to(motion_path.plugs['geometryPath'])
        motion_path.plugs['allCoordinates'].connect_to(nearest_point_on_curve.plugs['inPosition'])
        tangent_curve.plugs['worldSpace'].element(0).connect_to(nearest_point_on_curve.plugs['inputCurve'])
        nearest_point_on_curve.plugs['parameter'].connect_to(blend_parameters.plugs['color1R'])
        blend_parameters.plugs['color2R'].set_value(float(ribbon_surface.plugs['spansU'].get_value()) / (count- 1) * i)
        slide_plug.connect_to(blend_parameters.plugs['blender'])
        blend_parameters.plugs['outputR'].connect_to(grow_multiply.plugs['input1'])
        grow_plug.connect_to(grow_multiply.plugs['input2'])
        grow_multiply.plugs['output'].connect_to(parameter_clamp.plugs['inputR'])
        parameter_clamp.plugs['outputR'].connect_to(tangent_point_on_curve_info.plugs['parameter'])
        tangent_point_on_curve_info.plugs['position'].connect_to(transform.plugs['translate'])
        up_point_on_curve_info.plugs['turnOnPercentage'].set_value(False)
        up_curve.plugs['worldSpace'].element(0).connect_to(up_point_on_curve_info.plugs['inputCurve'])
        grow_multiply.plugs['output'].connect_to(parameter_plug)
        parameter_plug.connect_to(up_point_on_curve_info.plugs['parameter'])
        up_point_on_curve_info.plugs['position'].connect_to(up_transform.plugs['translate'])

        controller.create_tangent_constraint(
            tangent_curve,
            transform,
            aimVector=env.side_aim_vectors[part.side],
            upVector=env.side_up_vectors[part.side],
            worldUpType='object',
            worldUpObject=up_transform.name
        )
        transforms.append(transform)

    return transforms

