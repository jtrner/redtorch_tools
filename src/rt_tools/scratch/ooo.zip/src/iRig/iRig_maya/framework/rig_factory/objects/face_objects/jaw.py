
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.rig_objects.grouped_handle import LocalHandle
from rig_factory.objects.part_objects.chain_guide import ChainGuide
from rig_math.matrix import Matrix
import rig_factory.positions as pos


class JawGuide(ChainGuide):

    default_settings = dict(
        root_name='Jaw',
        size=0.25,
        side='center'
    )
    segment_names = DataProperty(
        name='segment_names',
        default_value=['Base', 'Tip']
    )

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['up_vector_indices'] = [0]
        kwargs['count'] = 2
        kwargs.setdefault('root_name', 'Jaw')
        this = super(JawGuide, cls).create(controller, **kwargs)
        this.set_handle_positions(pos.BIPED_POSITIONS)
        return this

    def __init__(self, **kwargs):
        super(JawGuide, self).__init__(**kwargs)
        self.toggle_class = Jaw.__name__

    def get_toggle_blueprint(self):
        blueprint = super(JawGuide, self).get_toggle_blueprint()
        guide_vertices = []
        for handle in self.handles:
            guide_vertices.append([(x.mesh.name, x.index) for x in handle.vertices])
        blueprint['guide_vertices'] = guide_vertices

        return blueprint


class Jaw(Part):
    deformers = ObjectListProperty(
        name='deformers'
    )

    geometry = ObjectListProperty(
        name='geometry'
    )

    driver_transform = ObjectProperty(
        name='driver_transform'
    )

    guide_vertices = DataProperty(
        name='guide_vertices'
    )
    segment_names = DataProperty(
        name='segment_names',
        default_value=['Base', 'Tip']
    )

    def __init__(self, **kwargs):
        super(Jaw, self).__init__(**kwargs)

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(Jaw, cls).create(controller, **kwargs)
        size = this.size
        root_name = this.root_name
        matrices = this.matrices
        position_1 = matrices[0].get_translation()
        position_2 = matrices[1].get_translation()
        jaw_vector = position_2 - position_1

        joint_1 = this.create_child(
            Joint,
            segment_name=this.segment_names[0],
            matrix=matrices[0],
            parent=this.joint_group
        )
        joint_2 = this.create_child(
            Joint,
            segment_name=this.segment_names[1],
            parent=joint_1
        )

        driver_pos = this.create_child(
            Transform,
            segment_name='DriverPosition',
            matrix=matrices[0]
        )
        driver_transform = driver_pos.create_child(
            Transform,
            segment_name='Driver',
            matrix=matrices[0]
        )

        joint_1.zero_rotation()
        joint_2.zero_rotation()
        joint_2.plugs['ty'].set_value(1.0)
        jaw_control = this.create_handle(
            handle_type=LocalHandle,
            group_count=5,
            shape='cube',
            size=size,
            matrix=matrices[0],
            segment_name=this.segment_names[0],
        )

        controller.create_parent_constraint(
            jaw_control,
            driver_transform,
            mo=False
        )

        jaw_control.stretch_shape(
            matrices[1].get_translation()
        )
        jaw_control.multiply_shape_matrix(Matrix(scale=[3.0, 1.2, 1.0]))

        up_transform = jaw_control.groups[0].create_child(
            Transform,
            segment_name='Up',
        )
        up_transform.plugs['tz'].set_value(size * -15)
        joint_1.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
            radius=size
        )
        joint_2.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
            radius=size
        )

        jaw_multiply_node = this.create_child(
            DependNode,
            node_type='multiplyDivide',
        )
        jaw_multiply_node.plugs['input2X'].set_value(-5)
        jaw_multiply_node.plugs['input2Z'].set_value(-5)
        jaw_multiply_node.plugs['outputX'].connect_to(jaw_control.groups[1].plugs['rx'])
        jaw_multiply_node.plugs['outputZ'].connect_to(jaw_control.groups[1].plugs['rz'])
        controller.create_parent_constraint(
            jaw_control.gimbal_handle,
            joint_1
        )

        create_corrective_driver(
            driver_transform.plugs['rx'],
            driver_transform.plugs['rz'],
            45.0, 1.0,
            -45.0, 1.0,
            'DriverDownLeft'
        )

        create_corrective_driver(
            driver_transform.plugs['rx'],
            driver_transform.plugs['rz'],
            45.0, 1.0,
            45.0, 1.0,
            'DriverDownRight'
        )

        root = this.get_root()
        if root:
            root.add_plugs(
                [
                    jaw_control.plugs['tx'],
                    jaw_control.plugs['ty'],
                    jaw_control.plugs['tz'],
                    jaw_control.plugs['rx'],
                    jaw_control.plugs['ry'],
                    jaw_control.plugs['rz'],
                    jaw_control.plugs['rotateOrder']
                ]
            )
        this.driver_transform = driver_transform
        this.joints = [joint_1, joint_2]
        return this


def create_corrective_driver(plug_1, plug_2, in_value_1, out_value_1, in_value_2, out_value_2, name):
    node = plug_2.get_node()
    segment_name = '%s%s' % (
        plug_1.root_name.title(),
        plug_2.root_name.title()
    )
    multiply_node = node.create_child(
        DependNode,
        node_type='multiplyDivide',
        segment_name=name,
        functionality_name='Corrective'
    )
    remap_node_1 = node.create_child(
        DependNode,
        node_type='remapValue',
        segment_name='%sA' % name,
        functionality_name='Corrective'
    )
    remap_node_2 = node.create_child(
        DependNode,
        node_type='remapValue',
        segment_name='%sB' % name,
        functionality_name='Corrective'
    )
    remap_node_1.plugs['value'].element(0).child(0).set_value(0.0)
    remap_node_1.plugs['value'].element(0).child(1).set_value(0.0)
    remap_node_1.plugs['value'].element(1).child(0).set_value(in_value_1)
    remap_node_1.plugs['value'].element(1).child(1).set_value(out_value_1)
    remap_node_2.plugs['value'].element(0).child(0).set_value(0.0)
    remap_node_2.plugs['value'].element(0).child(0).set_value(0.0)
    remap_node_2.plugs['value'].element(1).child(0).set_value(in_value_2)
    remap_node_2.plugs['value'].element(1).child(1).set_value(out_value_2)
    plug_1.connect_to(remap_node_1.plugs['inputValue'])
    plug_2.connect_to(remap_node_2.plugs['inputValue'])
    remap_node_1.plugs['outValue'].connect_to(multiply_node.plugs['input1X'])
    remap_node_2.plugs['outValue'].connect_to(multiply_node.plugs['input2X'])
    combo_plug = node.create_plug(
        name,
        k=True,
        at='double'
    )
    multiply_node.plugs['outputX'].connect_to(combo_plug)
