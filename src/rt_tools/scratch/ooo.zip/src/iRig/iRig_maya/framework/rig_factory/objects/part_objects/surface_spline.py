from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.node_objects.nurbs_surface import NurbsSurface
from rig_factory.objects.part_objects.part import Part, PartGuide
import rig_factory.utilities.spline_builders as spb
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.node_objects.locator import Locator
from rig_math.matrix import Matrix
from rig_math.vector import Vector
import rig_factory


class ArrayMixin(object):

    def __init__(self, **kwargs):
        super(ArrayMixin, self).__init__(**kwargs)

    def get_control_points(self):
        return self.controller.get_control_points(self)

    def snap_to_mesh(self, mesh):
        self.controller.snap_to_mesh(self, mesh)

    def create_points(self, *vertices, **kwargs):
        return self.controller.create_points(self, *vertices, **kwargs)

    def create_point(self, **kwargs):
        return self.controller.create_point(self, **kwargs)


class SurfaceSplineGuide(PartGuide, ArrayMixin):

    surface_data = DataProperty(
        name='surface_data'
    )
    locators = ObjectListProperty(
        name='locators'
    )
    count = DataProperty(
        name='count'
    )
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )
    spline_handles = ObjectListProperty(
        name='spline_handles'
    )
    joint_count = DataProperty(
        name='joint_count',
        default_value=19
    )
    use_fit_curve = DataProperty(
        name='use_fit_curve',
        default_value=False
    )
    create_gimbal = DataProperty(
        name='create_gimbal'
    )
    threshold = DataProperty(
        name='threshold',
        default_value=0.01
    )
    secondary_parameters = DataProperty(
        name='secondary_parameters'
    )
    secondary_translations = DataProperty(
        name='secondary_translations'
    )
    up_vector_position = DataProperty(
        name='up_vector_position'
    )
    follicle_surface = ObjectProperty(
        name='follicle_surface'
    )
    up_vector_transform = ObjectProperty(
        name='up_vector_transform'
    )
    main_curve = ObjectProperty(
        name='spline_curve'
    )
    ribbon_surface = ObjectProperty(
        name='ribbon_surface'
    )
    create_shards = DataProperty(
        name='create_shards',
        default_value=False
    )
    create_spline_on_surface = DataProperty(
        name='create_spline_on_surface',
        default_value=False
    )
    create_roll_joints = DataProperty(
        name='create_roll_joints',
        default_value=False
    )

    default_settings = dict(
        root_name='Handle',
        count=5,
        lower_count=None,
        size=3.0,
        side=None,
        threshold=0.01,
        create_gimbal=False,
        use_fit_curve=False,
        joint_count=9,
        create_shards=False,
        create_spline_on_surface=True,
        create_roll_joints=False
    )

    def __init__(self, **kwargs):
        super(SurfaceSplineGuide, self).__init__(**kwargs)
        self.toggle_class = SurfaceSpline.__name__

    @classmethod
    def create(cls, controller, **kwargs):

        this = super(SurfaceSplineGuide, cls).create(controller, **kwargs)
        count = this.count
        side = this.side
        size = this.size

        size_multiply = this.create_child(
            DependNode,
            node_type='multiplyDivide',
            segment_name='Size'
        )

        size_plug = this.plugs['size']

        size_plug.connect_to(size_multiply.plugs['input1X'])
        size_plug.connect_to(size_multiply.plugs['input1Y'])
        size_multiply.plugs['input2X'].set_value(0.5)
        size_multiply.plugs['input2Y'].set_value(0.5)

        handle_data = create_handle_data(
            count,
            side,
            this.root_name,
            size
        )

        if this.surface_data:
            positions, knots_u, knots_v, degree_u, degree_v, form_u, form_v = this.surface_data
            follicle_surface_transform = this.create_child(
                Transform,
                segment_name='Slide'
            )
            this.follicle_surface = follicle_surface_transform.create_child(
                NurbsSurface,
                positions=positions,
                knots_u=knots_u,
                knots_v=knots_v,
                degree_u=degree_u,
                degree_v=degree_v,
                form_u=form_u,
                form_v=form_v
            )
            this.follicle_surface.plugs['curvePrecisionShaded'].set_value(10)
            # this.follicle_surface.plugs['overrideDisplayType'].set_value(2)
            this.follicle_surface.plugs['overrideEnabled'].set_value(1)
            this.follicle_surface.assign_shading_group(this.get_root().shaders[this.side].shading_group)

        if not this.surface_data or not this.create_spline_on_surface:
            all_positions = [Matrix(x['matrix']).get_translation() for x in handle_data]
            combined_positions = Vector([0.0, 0.0, 0.0])
            for position in all_positions:
                combined_positions = combined_positions + position
            average_position = combined_positions / len(all_positions)
            up_vector_transform = this.create_child(
                Transform,
                matrix=Matrix(average_position),
                segment_name='UpVector'
            )
            up_vector_transform.create_child(
                Locator
            )
            this.up_vector_transform = up_vector_transform
            if this.up_vector_position:
                this.up_vector_transform.set_matrix(Matrix(this.up_vector_position))
            else:
                this.up_vector_position = list(average_position)

        all_joints = []
        all_handles = []

        if handle_data:

            upper_handles = []
            upper_joints = []

            if len(handle_data) == 1:
                handle_data[0]['segment_name'] = 'Main'

            start_handle, start_joint = spb.create_guide_handle(
                this,
                **handle_data[0]
            )
            all_handles.append(start_handle)
            all_joints.append(start_joint)

            size_multiply.plugs['outputX'].connect_to(start_handle.plugs['size'])

            if len(handle_data) > 2:

                for data in handle_data[1:-1]:
                    handle, joint = spb.create_guide_handle(
                        this,
                        **data
                    )
                    size_multiply.plugs['outputX'].connect_to(handle.plugs['size'])
                    upper_handles.append(handle)
                    upper_joints.append(joint)
                all_joints.extend(upper_joints)
                all_handles.extend(upper_handles)

            if len(handle_data) > 1:

                end_handle, end_joint = spb.create_guide_handle(
                    this,
                    **handle_data[-1]
                )
                size_multiply.plugs['outputX'].connect_to(end_handle.plugs['size'])
                all_handles.append(end_handle)
                all_joints.append(end_joint)
        this.base_handles = list(all_handles)
        if len(all_joints) > 1 and this.joint_count:

            spline_group = this.create_child(
                Transform,
                segment_name='Spline'
            )

            spline_handles, spline_joints = spb.create_spline(
                this,
                spline_group,
                all_joints
            )

            for handle in spline_handles:
                handle.plugs.set_locked(
                    rotate=True,
                    scale=True
                )
            for joint in spline_joints:
                joint.plugs.set_values(
                    overrideEnabled=True,
                    overrideDisplayType=2,
                )
                joint.plugs['type'].set_value(18)
                joint.plugs['otherType'].set_value('spline')

            this.spline_joints = spline_joints
            this.spline_handles = spline_handles
            all_handles.extend(spline_handles)

            # Backward compatible "Slide" values
            joint_parameters = kwargs.pop('joint_parameters', None)
            if joint_parameters and len(spline_handles) == len(joint_parameters):
                for i in range(len(joint_parameters)):
                    slide_value = 1.0 / (len(joint_parameters)-1) * i + (joint_parameters[i] * 0.1)
                    spline_handles[i].plugs['Slide'].set_value(slide_value)

        this.set_handles(all_handles)
        this.joints = all_joints
        return this

    def get_blueprint(self):
        blueprint = super(SurfaceSplineGuide, self).get_blueprint()
        blueprint.update(dict(
            handle_positions=self.get_handle_positions(),
            handle_vertices=self.get_vertex_data(),
            secondary_parameters=[x.plugs['Slide'].get_value() for x in self.spline_handles],
            secondary_translations=[x.plugs['translate'].get_value() for x in self.spline_handles],
            up_vector_position=list(self.up_vector_transform.get_translation()) if self.up_vector_transform else None,
            surface_data=self.follicle_surface.get_surface_data() if self.follicle_surface else self.surface_data
        ))
        return blueprint

    def get_handle_data(self):
        if not self.base_handles:
            raise Exception('No Base Handles Found')
        handle_data = []
        for i, handle in enumerate(self.base_handles):
            handle = self.base_handles[i]
            handle_data.append(
                dict(
                    klass=handle.__class__.__name__,
                    module=handle.__module__,
                    vertices=[(x.mesh.get_selection_string(), x.index) for x in handle.vertices],
                    matrix=list(self.joints[i].get_matrix()),
                    root_name=handle.root_name,
                    segment_name=handle.segment_name,
                    differentiation_name=handle.differentiation_name,
                    size=handle.size,
                    side=handle.side
                )
            )
        return handle_data

    def get_toggle_blueprint(self):
        blueprint = super(SurfaceSplineGuide, self).get_toggle_blueprint()
        blueprint['handle_data'] = self.get_handle_data()
        blueprint['secondary_parameters'] = [x.plugs['Slide'].get_value() for x in self.spline_handles]
        blueprint['secondary_translations'] = [x.plugs['translate'].get_value() for x in self.spline_handles]
        blueprint['up_vector_position'] = list(self.up_vector_transform.get_translation()) if self.up_vector_transform else None
        blueprint['surface_data'] = self.follicle_surface.get_surface_data() if self.follicle_surface else self.surface_data
        return blueprint

    def get_mirror_blueprint(self):
        sides = dict(left='right', right='left')
        handles = self.handles
        if not all(self.side == x.side for x in handles):
            raise Exception('Non uniform handle sides not supported in mirror blueprint')
        blueprint = super(SurfaceSplineGuide, self).get_mirror_blueprint()
        handle_data = []
        for handle in self.handles:
            handle_matrix = list(handle.get_matrix())
            handle_matrix[12] = handle_matrix[12]*-1
            handle_properties = dict(
                klass=handle.__class__.__name__,
                module=handle.__module__,
                root_name=handle.root_name,
                size=handle.plugs['size'].get_value(1.0),
                side=sides[handle.side],
                index=handle.index,
                handle_matrix=handle_matrix
            )
            mirror_vertices = []
            for vertex in handle.vertices:
                position = vertex.get_translation()
                position[0] = position[0] * -1
                mirror_index = self.controller.get_closest_vertex_index(
                    vertex.mesh,
                    position,
                )
                mirror_vertex = vertex.mesh.get_vertex(mirror_index)
                mirror_vertices.append(mirror_vertex)
            handle_properties['vertices'] = [(x.mesh.get_selection_string(), x.index) for x in mirror_vertices]
            handle_data.append(handle_properties)
        blueprint['handle_data'] = handle_data
        if self.up_vector_transform:
            position = list(self.up_vector_transform.get_translation())
            position[2] *= -1
            blueprint['up_vector_position'] = position

        return blueprint

    def set_vertex_data(self, *args, **kwargs):
        super(SurfaceSplineGuide, self).set_vertex_data(*args, **kwargs)
        self.consolidate_slide_values()

    def consolidate_slide_values(self):
        for handle in self.spline_handles:
            position = list(handle.get_translation())
            closest_parameter = self.controller.scene.get_closest_curve_parameter(
                self.main_curve.m_object,
                list(handle.get_translation())
            )
            handle.plugs['Slide'].set_value(closest_parameter / self.main_curve.plugs['spans'].get_value())
            self.controller.scene.xform(handle, ws=True, t=position)



class SurfaceSpline(Part):

    surface_data = DataProperty(
        name='surface_data'
    )
    create_gimbal = DataProperty(
        name='create_gimbal'
    )
    use_fit_curve = DataProperty(
        name='use_fit_curve',
        default_value=False
    )
    fit_curve = ObjectProperty(
        name='fit_curve'
    )
    base_curve = ObjectProperty(
        name='base_curve'
    )
    follicle_surface = ObjectProperty(
        name='follicle_surface'
    )
    handle_data = DataProperty(
        name='handle_data'
    )
    joint_count = DataProperty(
        name='joint_count'
    )
    main_curve = ObjectProperty(
        name='main_curve'
    )
    ribbon_surface = ObjectProperty(
        name='ribbon_surface'
    )
    spline_joints = ObjectListProperty(
        name='spline_joints'
    )
    spline_handles = ObjectListProperty(
        name='spline_handles'
    )
    secondary_parameters = DataProperty(
        name='secondary_parameters'
    )
    secondary_translations = DataProperty(
        name='secondary_translations'
    )
    create_shards = DataProperty(
        name='create_shards',
        default_value=False
    )
    upper_joints = ObjectListProperty(
        name='upper_joints'
    )
    lower_joints = ObjectListProperty(
        name='lower_joints'
    )
    start_joint = ObjectProperty(
        name='start_joint'
    )
    end_joint = ObjectProperty(
        name='end_joint'
    )
    up_vector_position = DataProperty(
        name='up_vector_position'
    )
    up_vector_transform = ObjectProperty(
        name='up_vector_transform'
    )
    create_spline_on_surface = DataProperty(
        name='create_spline_on_surface',
        default_value=False
    )
    create_roll_joints = DataProperty(
        name='create_roll_joints',
        default_value=False
    )
    base_handles = ObjectListProperty(
        name='base_handles'
    )

    def __init__(self, **kwargs):
        super(SurfaceSpline, self).__init__(**kwargs)
        self.disconnected_joints = True
        self.joint_chain = False

    @classmethod
    def create(cls, controller, **kwargs):
        handle_data = kwargs.pop('handle_data', None)
        if not handle_data:
            raise Exception('You must provide the handle_data keyword to create a %s' % cls.__name__)
        this = super(SurfaceSpline, cls).create(controller, **kwargs)

        if this.surface_data:
            positions, knots_u, knots_v, degree_u, degree_v, form_u, form_v = this.surface_data
            surface_transform = this.create_child(
                Transform,
                segment_name='Surface'
            )
            this.follicle_surface = surface_transform.create_child(
                NurbsSurface,
                positions=positions,
                knots_u=knots_u,
                knots_v=knots_v,
                degree_u=degree_u,
                degree_v=degree_v,
                form_u=form_u,
                form_v=form_v
            )
            this.follicle_surface.plugs['v'].set_value(False)

        if not this.surface_data or not this.create_spline_on_surface:
            up_vector_transform = this.create_child(
                Transform,
                segment_name='UpVector'
            )
            up_vector_transform.create_child(
                Locator
            )
            this.up_vector_transform = up_vector_transform
            if this.up_vector_position:
                this.up_vector_transform.set_matrix(Matrix(this.up_vector_position))
            else:
                this.up_vector_position = this.up_vector_transform.get_matrix()
        all_joints = []
        all_handles = []
        if handle_data:
            upper_handles = []
            upper_joints = []
            if len(handle_data) == 1:
                handle_data[0]['segment_name'] = 'Main'
            start_handle, start_joint = spb.create_handle(this, **handle_data[0])
            all_handles.append(start_handle)
            all_joints.append(start_joint)
            this.start_joint = start_joint
            if len(handle_data) > 2:
                for data in handle_data[1:-1]:
                    handle, joint = spb.create_handle(this, **data)
                    upper_handles.append(handle)
                    upper_joints.append(joint)
                    all_handles.append(handle)
                    all_joints.append(joint)
            if len(handle_data) > 1:
                end_handle, end_joint = spb.create_handle(this, **handle_data[-1])
                all_handles.append(end_handle)
                all_joints.append(end_joint)
                this.end_joint = end_joint

        root = this.get_root()
        for handle in all_handles:
            root.add_plugs(
                handle.plugs['tx'],
                handle.plugs['ty'],
                handle.plugs['tz']
            )
        this.joints = all_joints
        this.base_handles = list(all_handles)
        this.handles = list(all_handles)

        return this

    def create_deformation_rig(self, **kwargs):
        super(SurfaceSpline, self).create_deformation_rig(**kwargs)

        if len(self.joints) > 1 and self.joint_count:

            for deform_joint in self.deform_joints:
                deform_joint.plugs['v'].set_value(False)

            spline_handles, spline_joints = spb.create_spline(
                self,
                self,
                self.joints
            )

            for joint in spline_joints:
                joint.plugs['type'].set_value(18)
                joint.plugs['otherType'].set_value('spline')

            for handle in spline_handles:
                self.get_root().add_plugs(
                    handle.plugs['tx'],
                    handle.plugs['ty'],
                    handle.plugs['tz']
                )

            # Backward compatible "Slide" values
            joint_parameters = kwargs.pop('joint_parameters', None)
            if joint_parameters and len(spline_handles) == len(joint_parameters):
                for i in range(len(joint_parameters)):
                    slide_value = 1.0 / (len(joint_parameters)-1) * i + (joint_parameters[i] * 0.1)
                    spline_handles[i].plugs['Slide'].set_value(slide_value)

            if self.secondary_parameters and len(spline_handles) == len(self.secondary_parameters):
                for i in range(len(spline_handles)):
                    spline_handles[i].plugs['Slide'].set_value(self.secondary_parameters[i])
                    spline_handles[i].plugs['Slide'].set_locked(True)
            if self.secondary_translations and len(spline_handles) == len(self.secondary_translations):
                for i in range(len(spline_handles)):
                    spline_handles[i].groups[-2].plugs['translate'].set_value(self.secondary_translations[i])




            all_handles = list(self.handles)
            all_handles.extend(spline_handles)
            self.secondary_handles = spline_handles
            self.deform_joints.extend(self.spline_joints)
            self.spline_joints = spline_joints
            self.spline_handles = spline_handles
            self.set_handles(all_handles)

    def get_toggle_blueprint(self):
        blueprint = super(SurfaceSpline, self).get_toggle_blueprint()
        blueprint['handle_data'] = self.get_handle_data()
        blueprint['surface_data'] = self.follicle_surface.get_surface_data() if self.follicle_surface else self.surface_data

        return blueprint

    def get_blueprint(self):
        blueprint = super(SurfaceSpline, self).get_blueprint()
        blueprint['handle_data'] = self.get_handle_data()
        blueprint['up_vector_position'] = list(self.up_vector_transform.get_translation()) if self.up_vector_transform else None
        blueprint['surface_data'] = self.follicle_surface.get_surface_data() if self.follicle_surface else self.surface_data

        return blueprint

    def get_handle_data(self):
        handle_data = []
        if not self.base_handles:
            raise Exception('No Base Handles Found')
        for i, handle in enumerate(self.base_handles):
            handle = self.base_handles[i]
            handle_data.append(
                dict(
                    klass=handle.__class__.__name__,
                    module=handle.__module__,
                    vertices=[(x.mesh.get_selection_string(), x.index) for x in handle.vertices],
                    matrix=list(self.joints[i].get_matrix()),
                    root_name=handle.root_name,
                    segment_name=handle.segment_name,
                    differentiation_name=handle.differentiation_name,
                    size=handle.size,
                    side=handle.side
                )
            )
        return handle_data


def is_even(number):
    if (number % 2) == 0:
        return True
    return False


def create_handle_data(count, side, root_name, size):
    # if count < 2:
    #     raise Exception('Count must be at-least 2')

    data = []
    if side in ['left', 'right']:
        for x in range(count):
            if x == 0:
                handle_segment_name = 'InCorner'
            elif x == count - 1:
                handle_segment_name = 'OutCorner'
            else:
                handle_segment_name = rig_factory.index_dictionary[x - 1].title()
            data.append(dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side=side,
                matrix=Matrix([(size*2) * x, 0.0, 0.0]) if side == 'left' else Matrix([(size*-2) * x, 0.0, 0.0])
            ))
    elif side == 'center':
        for x in range(count):
            if x == 0:
                handle_segment_name = 'Start'
            elif x == count-1:
                handle_segment_name = 'End'
            else:
                handle_segment_name = rig_factory.index_dictionary[x - 1].title()
            data.append(dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side=side,
                matrix=Matrix([0.0, (size*2) * x, 0.0])
            ))
    elif side is None:
        even_count = is_even(count)
        side_count = count / 2 if even_count else (count - 1) / 2
        for x in range(side_count):
            if x == side_count-1:
                handle_segment_name = 'Corner'
            else:
                handle_segment_name = rig_factory.index_dictionary[x].title()
            position = [(size * -2) * (x + 1), 0.0, 0.0]
            if x == 0 and even_count:
                position = [(size * -1) * (x + 1), 0.0, 0.0]
            data.insert(0, dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side='right',
                matrix=Matrix(position)
            ))

        if not even_count:
            data.append(dict(
                root_name=root_name,
                handle_segment_name = rig_factory.index_dictionary[0].title(),
                size=size,
                side='center',
                matrix=Matrix([0.0, 0.0, 0.0])
            ))
        for x in range(side_count):
            position = [(size * 2) * (x + 1), 0.0, 0.0]
            if x == side_count-1:
                handle_segment_name = 'Corner'
            else:
                handle_segment_name = rig_factory.index_dictionary[x].title()
            data.append(dict(
                root_name=root_name,
                segment_name=handle_segment_name,
                size=size,
                side='left',
                matrix=Matrix(position)
            ))

    return data


def chunks(lst, n):
    for i in range(0, len(lst), n):
        yield lst[i:i + n]


def merge_lists(list_1, list_2):
    merged_list = []
    for a, b in zip(list_1, list_2):
        merged_list.append(a)
        merged_list.append(b)
    return merged_list
