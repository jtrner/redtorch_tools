from rig_factory.objects.deformer_objects.nonlinear import NonLinear


class Wave(NonLinear):

    handle_type = 'deformWave'
    deformer_type = 'wave'
    suffix = 'Wave'

    def __init__(self, **kwargs):
        super(Wave, self).__init__(**kwargs)
