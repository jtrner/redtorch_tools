from rig_factory.objects.base_objects.properties import DataProperty
from rig_factory.objects.node_objects.transform import Transform
from rig_factory.objects.part_objects.part import Part, PartGuide
from rig_factory.objects.rig_objects.cone import Cone


class TransformPartGuide(PartGuide):

    group_count = DataProperty(
        name='group_count',
        default_value=5
    )

    group_matrix = DataProperty(
        name='group_matrix'
    )

    default_settings = dict(
        root_name='Transform',
        side='center',
        size=3,
        group_count=5
    )

    def __init__(self, **kwargs):
        super(TransformPartGuide, self).__init__(**kwargs)
        self.toggle_class = TransformPart.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs.setdefault('side', 'center')
        this = super(TransformPartGuide, cls).create(controller, **kwargs)
        size_plug = this.plugs['size']

        side = this.side
        size = this.size
        handle = this.create_handle(
            segment_name='Base',
            matrix=this.group_matrix
        )
        cone_x = handle.create_child(
            Cone,
            segment_name='ConeX',
            size=size,
            axis=[1.0, 0.0, 0.0]
        )
        cone_y = handle.create_child(
            Cone,
            segment_name='ConeY',
            size=size,
            axis=[0.0, 1.0, 0.0]
        )
        cone_z = handle.create_child(
            Cone,
            segment_name='ConeZ',
            size=size,
            axis=[0.0, 0.0, 1.0]
        )
        size_plug.connect_to(handle.plugs['size'])
        size_plug.connect_to(cone_x.plugs['size'])
        size_plug.connect_to(cone_y.plugs['size'])
        size_plug.connect_to(cone_z.plugs['size'])
        cone_x.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
        )
        cone_y.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
        )
        cone_z.plugs.set_values(
            overrideEnabled=True,
            overrideDisplayType=2,
        )
        handle.plugs.set_locked(
            scale=True
        )
        # Shaders
        root = this.get_root()
        cone_x.mesh.assign_shading_group(root.shaders['x'].shading_group)
        cone_y.mesh.assign_shading_group(root.shaders['y'].shading_group)
        cone_z.mesh.assign_shading_group(root.shaders['z'].shading_group)
        handle.mesh.assign_shading_group(root.shaders[side].shading_group)
        return this

    def get_blueprint(self):
        blueprint = super(TransformPartGuide, self).get_blueprint()
        blueprint['group_matrix'] = list(self.handles[0].get_matrix())
        blueprint.pop('handle_positions', None)  # Handling with group_matrix
        blueprint.pop('index_handle_positions', None)  # Handling with group_matrix
        return blueprint

    def get_toggle_blueprint(self):
        blueprint = super(TransformPartGuide, self).get_toggle_blueprint()
        blueprint['group_matrix'] = list(self.handles[0].get_matrix())
        return blueprint

class TransformPart(Part):

    group_count = DataProperty(
        name='group_count',
        default_value=5
    )

    group_matrix = DataProperty(
        name='group_matrix'
    )

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(TransformPart, cls).create(controller, **kwargs)
        group_names = [
            'Tpx',
            'Tpp',
            'Top',
            'Ofs',
            'Drv',
            'Cns'
        ]
        groups = []
        kwargs.pop('parent', None)
        parent = this
        for g in range(this.group_count):
            if g == 0:
                suffix = 'Zro'  # Top group suffix is always "Zro"
            else:
                suffix = group_names[len(group_names) - this.group_count + g]
            group = this.create_child(
                Transform,
                segment_name='Main',
                suffix=suffix,
                parent=parent,
                matrix=this.group_matrix,
                **kwargs
            )
            parent = group
            groups.append(group)

        return this

    def create_groups(self, **kwargs):
        pass
