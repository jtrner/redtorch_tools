
from rig_factory.objects.deformer_objects.bend import Bend
from rig_factory.objects.deformer_objects.twist import Twist
from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.node_objects.depend_node import DependNode
from rig_factory.objects.part_objects.part import Part
from rig_factory.objects.base_objects.properties import DataProperty, ObjectListProperty, ObjectProperty
from rig_factory.objects.part_objects.chain_guide import ChainGuide
from rig_math.matrix import Matrix


class FeatherPartGuide(ChainGuide):
    default_settings = dict(
        root_name='Feather',
        differentiation_name='Primary',
        size=1.0,
        side='center',
    )

    create_gimbal = DataProperty(
        name='create_gimbal',
        default_value=False
    )

    nonlinear_position = DataProperty(
        name='nonlinear_position',
        default_value=0.5
    )

    def __init__(self, **kwargs):
        super(FeatherPartGuide, self).__init__(**kwargs)
        self.toggle_class = FeatherPart.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        kwargs['count'] = 2
        this = super(FeatherPartGuide, cls).create(controller, **kwargs)
        return this


class FeatherPart(Part):
    # Private blueprint attributes.
    _weights = DataProperty(  # Structure: [twist, bendX, bendY]
        name='_weights'
    )
    _geometry_names = DataProperty(
        name='_geometry_names',
        default_value=[]
    )
    geometries = ObjectListProperty(
        name='geometries'
    )
    # Public object attributes.
    twist = ObjectProperty(
        name='twist'
    )
    bend_x = ObjectProperty(
        name='bendX'
    )
    bend_z = ObjectProperty(
        name='bendY'
    )
    create_gimbal = DataProperty(
        name='create_gimbal',
        default_value=False
    )
    nonlinear_position = DataProperty(
        name='nonlinear_position',
        default_value=0.5
    )
    @classmethod
    def create(cls, *args, **kwargs):
        """
        Main entry point which begins the creation of the part in scene.
        """
        this = super(FeatherPart, cls).create(*args, **kwargs)
        joint_1 = this.create_child(
            Joint,
            segment_name='Base',
            matrix=this.matrices[0],
            parent=this.joint_group
        )
        joint_2 = joint_1.create_child(
            Joint,
            segment_name='Tip',
            matrix=this.matrices[1]
        )
        joint_1.zero_rotation()
        joint_2.zero_rotation()
        joint_1.plugs['type'].set_value(18)
        joint_1.plugs['otherType'].set_value('feather')
        joint_2.plugs['type'].set_value(18)
        joint_2.plugs['otherType'].set_value('feather')

        handle = this.create_handle(
            segment_name='Settings',
            shape='marker',
            axis='z',
            matrix=this.matrices[0]
        )

        length = (joint_2.get_translation() - joint_1.get_translation()).mag()
        handle.set_shape_matrix(Matrix([0.0,  (length * -1.1) if this.side=='right' else (length * 1.1), 0.0]))
        if this.side == 'right':
            handle.multiply_shape_matrix(Matrix(scale=[1.0, -1.0, 1.0]))

        this.controller.create_parent_constraint(handle, joint_1)
        this.joints = [joint_1, joint_2]

        bend_x_plug = handle.create_plug(
            'BendX',
            at='double',
            keyable=True
        )
        bend_z_plug = handle.create_plug(
            'BendZ',
            at='double',
            keyable=True
        )
        twist_plug = handle.create_plug(
            'Twist',
            at='double',
            keyable=True
        )

        handle.create_plug(
            'BendXInput',
            at='double',
            keyable=False
        )
        handle.create_plug(
            'BendZInput',
            at='double',
            keyable=False
        )
        handle.create_plug(
            'TwistInput',
            at='double',
            keyable=False
        )

        handle.create_plug(
            'BendXOutput',
            at='double',
            keyable=False
        )
        handle.create_plug(
            'BendZOutput',
            at='double',
            keyable=False
        )
        handle.create_plug(
            'TwistOutput',
            at='double',
            keyable=False
        )


        bend_x_add = this.create_child(
            DependNode,
            node_type='addDoubleLinear',
            segment_name='BendX'
        )
        bend_z_add = this.create_child(
            DependNode,
            node_type='addDoubleLinear',
            segment_name='BendZ'
        )
        twist_add = this.create_child(
            DependNode,
            node_type='addDoubleLinear',
            segment_name='Twist'
        )
        handle.plugs['BendX'].connect_to(bend_x_add.plugs['input1'])
        handle.plugs['BendXInput'].connect_to(bend_x_add.plugs['input2'])
        bend_x_add.plugs['output'].connect_to(handle.plugs['BendXOutput'])

        handle.plugs['BendZ'].connect_to(bend_z_add.plugs['input1'])
        handle.plugs['BendZInput'].connect_to(bend_z_add.plugs['input2'])
        bend_z_add.plugs['output'].connect_to(handle.plugs['BendZOutput'])

        handle.plugs['Twist'].connect_to(twist_add.plugs['input1'])
        handle.plugs['TwistInput'].connect_to(twist_add.plugs['input2'])
        twist_add.plugs['output'].connect_to(handle.plugs['TwistOutput'])

        root = this.get_root()
        root.add_plugs(
            bend_x_plug,
            bend_z_plug,
            twist_plug,
        )
        return this

    def create_deformation_rig(self, **kwargs):
        """
        Creates the deformers and deformer rig for the part
        Although slinClusters can be created by this part, they are
        not created during part creation; only nonlinear deformers are
        handled with during part creation.
        """
        # Executes the parent class's method.
        super(FeatherPart, self).create_deformation_rig(**kwargs)
        # Gets the part's root object.
        root = self.get_root()
        # Adds target geometries using saved list of geometry names.
        # This also procs the creation of the deformers, as nonLinear
        # deformers cannot exist without geometry it is safer to let the
        # create/remove geometry methods manage their existence.
        if self._geometry_names:
            self.add_geometries([
                root.geometry[geometry_name]
                for geometry_name in self._geometry_names
                if geometry_name in root.geometry
            ])
        # Loads any saved deformer weights.
        if self._weights:
            weights_twist, weights_bendX, weights_bendY = self._weights
            self.twist.set_weights(weights_twist)
            self.bend_x.set_weights(weights_bendX)
            self.bend_z.set_weights(weights_bendY)

    def create_deformers(self, geometries):
        # type: (List) -> None
        """
        Creates deformers for the part and applies their matrix data.
        """
        # Gets the deform joint to parent the deformers to.
        parent_joint = self.deform_joints[0]
        # Gets the distance between the first and second matrix
        # and uses it for scaling the deformers.
        vector_1 = self.matrices[0].get_translation()
        vector_2 = self.matrices[1].get_translation()
        length = (vector_2 - vector_1).magnitude()

        twist_handle = parent_joint.create_child(
            Twist,
            geometry=geometries,
            segment_name='Twist'
        )
        bend_x_handle = parent_joint.create_child(
            Bend,
            geometry=geometries,
            segment_name='BendX'
        )
        bend_z_handle = parent_joint.create_child(
            Bend,
            geometry=geometries,
            segment_name='BendZ'
        )
        bend_position = [
            0.0,
            length * -0.5 if self.side == 'right' else length * 0.5,
            0.0
        ]
        twist_position = [
            0.0,
            length * -0.75 if self.side == 'right' else length * 0.75,
            0.0
        ]
        bend_scale = [length*0.5, length*0.5, length*0.5]
        twist_scale = [length*0.25, length*0.25, length*0.25]
        bend_matrix = Matrix(bend_position, scale=bend_scale)
        twist_matrix = Matrix(twist_position, scale=twist_scale)
        # if self.side =='right':
        #     bend_matrix.flip_z()
        #     bend_matrix.flip_y()
        #     twist_matrix.flip_z()
        #     twist_matrix.flip_y()
        twist_handle.handle_shape.plugs['handleWidth'].set_value(1.0)
        bend_x_handle.set_matrix(bend_matrix, world_space=False)
        bend_z_handle.set_matrix(bend_matrix, world_space=False)
        twist_handle.set_matrix(twist_matrix, world_space=False)

        bend_z_handle.plugs['ry'].set_value(90.0)
        self.twist = twist_handle.deformer
        self.bend_x = bend_x_handle.deformer
        self.bend_z = bend_z_handle.deformer
        bend_x_driver = self.handles[0].plugs['BendXOutput']
        bend_z_driver = self.handles[0].plugs['BendZOutput']
        twist_driver = self.handles[0].plugs['TwistOutput']
        if self.side == 'right':
            bend_twist_multiply = self.create_child(
                DependNode,
                node_type='multiplyDivide',
                segment_name='BendTwist'
            )

            self.handles[0].plugs['BendXOutput'].connect_to(bend_twist_multiply.plugs['input1X'])
            self.handles[0].plugs['BendZOutput'].connect_to(bend_twist_multiply.plugs['input1Y'])
            self.handles[0].plugs['TwistOutput'].connect_to(bend_twist_multiply.plugs['input1Z'])
            bend_twist_multiply.plugs['input2X'].set_value(-1.0)
            bend_twist_multiply.plugs['input2Y'].set_value(-1.0)
            bend_twist_multiply.plugs['input2Z'].set_value(-1.0)
            bend_x_driver = bend_twist_multiply.plugs['outputX']
            bend_z_driver = bend_twist_multiply.plugs['outputY']
            twist_driver = bend_twist_multiply.plugs['outputZ']

        bend_x_driver.connect_to(self.bend_x.plugs['curvature'])
        bend_z_driver.connect_to(self.bend_z.plugs['curvature'])
        if self.side == 'right':
            bend_x_handle.deformer.plugs['highBound'].set_value(0.0)
            bend_z_handle.deformer.plugs['highBound'].set_value(0.0)
            twist_driver.connect_to(self.twist.plugs['startAngle'])
        else:
            twist_driver.connect_to(self.twist.plugs['endAngle'])
            bend_x_handle.deformer.plugs['lowBound'].set_value(0.0)
            bend_z_handle.deformer.plugs['lowBound'].set_value(0.0)

        # # Applies the guide handle's matrix to deformer handles.
        # deformer_matrix = Matrix(self.matrices[0])
        # matrix_data = [list(x) for x in self.matrices[0].data]
        # # x_axis = matrix_data[0][0:-1]
        # # z_axis = matrix_data[2][0:-1]
        # deformer_matrix = Matrix(*list(itertools.chain.from_iterable(matrix_data)))
        # # deformer_matrix.set_translation((vector_2*self.nonlinear_position) + (vector_1*(1.0 - self.nonlinear_position)))
        # deformer_matrix.set_scale([1.0, length, 1.0])
        # twist.handle.set_matrix(deformer_matrix)
        # bendX.handle.set_matrix(deformer_matrix)
        # bendY.handle.set_matrix(deformer_matrix)
        # The BendY handle is offset 90 degrees from the BendX handle
        # so the feather can bend on two axis.
        # I couldn't figure out an elegant way to modify the matrix to
        # get this result so I just rotated it in local space.
        # rotate_value = bendY.handle.plugs['ry'].get_value() + 90
        # bendY.handle.plugs['ry'].set_value(rotate_value)
        # Applies scale uniformly to all deformers' axis.
        # for deformer in twist, bendX, bendY:
        #     deformer.handle.plugs['sx'].set_value(length)
        #     deformer.handle.plugs['sy'].set_value(length)
        #     deformer.handle.plugs['sz'].set_value(length)
        twist_handle.plugs['v'].set_value(False)
        bend_x_handle.plugs['v'].set_value(False)
        bend_z_handle.plugs['v'].set_value(False)

    def get_blueprint(self):
        # type: () -> Dict
        """
        :return:
            Blueprint data that can be saved to file.
        """
        # Updates geometry names attribute.
        self._geometry_names = [geometry.name for geometry in self.geometries]
        # Updates the weights attribute.
        # If no target geometries exist then no deformers can exist
        # either so we could not get the deformer weights from them.
        if self.geometries:
            self._weights = [
                self.twist.get_weights(),
                self.bend_x.get_weights(),
                self.bend_z.get_weights()
            ]
        else:
            self._weights = []
        # Get's default blueprint and updates it with custom part data.
        blueprint = super(FeatherPart, self).get_blueprint()
        blueprint['_geometry_names'] = self._geometry_names
        blueprint['_weights']        = self._weights
        # Returns blueprint.
        return blueprint

    def get_toggle_blueprint(self):
        # type: () -> Dict
        """
        :return:
            Blueprint data used when toggling between guide state and
            rig state.
        """
        # Updates geometry names attribute.
        self._geometry_names = [geometry.name for geometry in self.geometries]
        # Updates the weights attribute.
        # If no target geometries exist then no deformers can exist
        # either so we could not get the deformer weights from them.
        if self.geometries:
            self._weights = [
                self.twist.get_weights(),
                self.bend_x.get_weights(),
                self.bend_z.get_weights()
            ]
        else:
            self._weights = []
        # Get's default blueprint and updates it with custom part data.
        blueprint = super(FeatherPart, self).get_toggle_blueprint()
        blueprint['rig_data']['_geometry_names'] = self._geometry_names
        blueprint['rig_data']['_weights']        = self._weights
        # Returns blueprint.
        return blueprint

    def add_selected_geometries(self):
        # type: () -> None
        """
        Adds all valid selected geometry as deformation targets.
        Prints a confirmation message to the command line.
        """
        # Gets the geometry objects for all items in the current
        # viewport selection.
        root = self.get_root()
        geometries = [
            root.geometry[x]
            for x in self.controller.get_selected_mesh_names()
            if x in root.geometry
        ]
        # Adds geometries as deformation objects for the part.
        self.add_geometries(geometries, add_skin_clusters=True)
        # Prints a confirmation message to the command line.
        warning = (
            'add_selected_geometries : Set geometries to'
            + ' ' + ' '.join(x.name for x in self.geometries)
        )
        self.controller.scene.warning(warning)

    def add_geometries(self, geometries, add_skin_clusters=False):
        # type: (List, bool) -> None
        """
        Adds given geometries to all deformer sets, as well as skinning
        given geometries to the parts deform joint.
        Ignores geometries that have already been added to the part, or
        are already attached to a skinCluster.
        If no new and unskinned geometries are given, a framework
        warning will be raised.
        :param geometries:
            Mesh objects for geometries to attach to the part.
        :param add_skin_clusters:
            Also adds skinClusters to the given geometries which bind
            them to the parts deform joint. Do not use this flag during 
            part creation since the framework will rebuild previous 
            skinCluster data automatically.
        """
        # Gets Mesh objects for all skinned geometries in the scene.
        root = self.get_root()
        skinned_geometries = {
            root.geometry[geometry_name]
            for skinCluster in self.controller.scene.ls(type='skinCluster')
            for geometry_name in (
                self.controller.scene.skinCluster(
                    skinCluster,
                    query=True,
                    geometry=True
                )
            )
            if geometry_name in root.geometry
        }
        # Filters for all new and unskinned geometries.
        new_geometries = [
            geometry
            for geometry in geometries
            if geometry not in self.geometries
            if geometry not in skinned_geometries
        ]
        # If no new and unskinned geometries were found in the given
        # selection, a framework warning will be raised, and the method
        # will exit.
        if not new_geometries:
            self.controller.raise_warning(
                'add_geometries : No new and unskinned geometries were'
                ' found in the given selection.'
            )
            return None
        # Adds skinClusters to the given geometries, binding them to
        # the only deform join in the part.
        if add_skin_clusters:
            for new_geometry in new_geometries:
                self.controller.scene.skinCluster(
                    new_geometry,
                    self.deform_joints[0],
                    bindMethod=0,
                    tsb=True
                )
        # If target geometries already exist, the given geometries are
        # added to the deformers deformer sets.
        # If not, the deformers are created using the given geometries.
        if self.geometries:
            self.twist.add_geometry(new_geometries)
            self.bend_x.add_geometry(new_geometries)
            self.bend_z.add_geometry(new_geometries)
        else:
            self.create_deformers(new_geometries)
        # Updates geometries using the twist's deformer set
        # (Any of the three deformers' sets would work).
        self.geometries.extend(new_geometries)

    def remove_selected_geometries(self):
        # type: () -> None
        """
        Removes all valid selected geometry as deformation targets.
        Prints a confirmation message to the command line.
        """
        # Gets the geometry objects for all items in the current
        # viewport selection.
        root = self.get_root()
        geometries = [
            root.geometry[x]
            for x in self.controller.get_selected_mesh_names()
            if x in root.geometry
        ]
        # Removes geometries as deformation objects from the part.
        self.remove_geometries(geometries)
        # Prints a confirmation message to the command line.
        warning = (
            'remove_selected_geometries : Set geometries to'
            + ' ' + ' '.join(x.name for x in self.geometries)
        )
        self.controller.scene.warning(warning)

    def remove_geometries(self, geometries):
        # type: (List) -> None
        """
        Removes given geometries from all deformer sets.
        Ignores geometries that are not attached to the part.
        :param geometries:
            Geometries to add to remove remove from part.
        """
        # Gets all geometries that are attached to the part.
        attached_geometries = [
            geometry for geometry in geometries
            if geometry in self.geometries
        ]
        # If no new and unskinned geometries were found in the given
        # selection, a framework warning will be raised, and the method
        # will exit.
        if not attached_geometries:
            self.controller.raise_warning(
                'remove_geometries : No attached geometries were'
                ' found in the given selection.'
            )
            return None
        # Unbinds all geometries.
        for geometry in attached_geometries:
            self.controller.scene.skinCluster(geometry, edit=True, unbind=True)
        # Gets a list of all geometries that are still attached to the
        # part after the removal process.
        remaining_geometries = [
            geometry for geometry in self.geometries
            if geometry not in attached_geometries
        ]
        # If there are remaining geometries,
        # Removes given geometries from all deformer sets and updates
        # the `geometries` attribute.
        # Otherwise, simply deletes the deformers, and clears the
        # `geometries` attribute.
        if remaining_geometries:
            self.twist.remove_geometry(attached_geometries)
            self.bend_x.remove_geometry(attached_geometries)
            self.bend_z.remove_geometry(attached_geometries)
            self.geometries = list(self.twist.deformer_set.members)
        else:
            self.controller.schedule_objects_for_deletion(
                self.twist,
                self.bend_x,
                self.bend_z,
            )
            self.controller.delete_scheduled_objects()
            self.geometries = []

    def finalize(self):
        # type: () -> None
        """
        Finalizes the part, making any last minute changes.
        """
        super(FeatherPart, self).finalize()
        # Hides the deformer handles.
        if self.twist:
            self.twist.plugs['v'].set_value(False)
        if self.bend_x:
            self.bend_x.plugs['v'].set_value(False)
        if self.bend_z:
            self.bend_z.plugs['v'].set_value(False)
