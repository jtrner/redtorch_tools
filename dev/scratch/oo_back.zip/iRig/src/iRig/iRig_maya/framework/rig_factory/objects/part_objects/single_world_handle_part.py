from rig_factory.objects.node_objects.joint import Joint
from rig_factory.objects.part_objects.part import PartGuide, Part
from rig_factory.objects.base_objects.properties import DataProperty
from rig_factory.objects.rig_objects.grouped_handle import GroupedHandle, GimbalHandle


class SingleWorldHandleGuide(PartGuide):

    default_settings = dict(
        root_name='handle',
        size=0.5,
        side='center',
        create_gimbal=False
    )

    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    def __init__(self, **kwargs):
        super(SingleWorldHandleGuide, self).__init__(**kwargs)
        self.toggle_class = SingleWorldHandle.__name__

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(SingleWorldHandleGuide, cls).create(controller, **kwargs)
        handle = this.create_handle()
        joint = this.create_child(
            Joint
        )
        controller.create_parent_constraint(
            handle,
            joint
        )
        this.joints = [joint]
        this.base_handles = [handle]
        return this


class SingleWorldHandle(Part):

    create_gimbal = DataProperty(
        name='create_gimbal'
    )

    @classmethod
    def create(cls, controller, **kwargs):
        this = super(SingleWorldHandle, cls).create(controller, **kwargs)
        handle = this.create_handle(
            handle_type=GroupedHandle if not this.create_gimbal else GimbalHandle,
        )
        joint = this.create_child(
            Joint
        )
        controller.create_parent_constraint(
            handle,
            joint
        )
        this.joints = [joint]
        return this

