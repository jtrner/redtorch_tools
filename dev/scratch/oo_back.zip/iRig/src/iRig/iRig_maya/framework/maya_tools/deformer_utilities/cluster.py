import maya.OpenMaya as om


def get_cluster_data(m_object):
    # Get geometry, weights, plug values from wire deformer

    return dict()


def create_cluster(data):
    # should return m_object of wrap deformer

    return om.MObject()
