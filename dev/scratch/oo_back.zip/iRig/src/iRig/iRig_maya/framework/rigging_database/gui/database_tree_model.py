import json
import uuid
from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
import rigging_database.gui.environment as env
import rigging_database.table_objects as tob


class DatabaseTreeModel(QAbstractItemModel):

    supported_types = (
        tob.ProjectRoot,
        tob.Project,
        tob.Entity
    )

    items_selected_signal = Signal(list)

    def __init__(self, root, *args, **kwargs):
        super(DatabaseTreeModel, self).__init__(*args, **kwargs)
        self.root = root
        self.part_group_icon = QIcon('%s/meta_cube.png' % env.images_directory)
        self.part_icon = QIcon('%s/cube.png' % env.images_directory)
        self.point_icon = QIcon('%s/point.png' % env.images_directory)
        self.font = QFont('', 12, False)

        self.unique_identifier = uuid.uuid4()

    def columnCount(self, index):
        return 1

    def get_item(self, index):
        return index.internalPointer() if index.isValid() else self.root

    def setData(self, index, value, role):
        item = self.get_item(index)
        if index.column() == 1:
            if role == Qt.EditRole:
                item.data = value
                if isinstance(item.parent, tob.Entity):
                    item.parent.data[item.name] = value
                return True
        return True

    def data(self, index, role):
        column = index.column()
        item = self.get_item(index)
        if column == 0:
            if role == Qt.DecorationRole:
                if item.__class__ == tob.Entity:
                    return self.part_icon
                elif item.__class__ == tob.Project:
                    return self.part_group_icon
                else:
                    return self.point_icon
            if role == Qt.DisplayRole:
                if item.__class__ == tob.Entity:
                    return item.code
                elif item.__class__ == tob.Project:
                    return item.name

            if role == Qt.FontRole:
                return self.font

    def rowCount(self, index):
        if self.root:
            parent = self.get_item(index)
            if isinstance(parent, self.supported_types):
                return len(get_members(parent))
            else:
                return 0
        else:
            return 0

    def flags(self, index):
        if not index.isValid():
            return Qt.ItemIsEnabled
        return Qt.ItemIsEnabled | Qt.ItemIsDropEnabled | Qt.ItemIsDragEnabled | Qt.ItemIsSelectable

    def index(self, row, column, parent_index=QModelIndex()):
        if parent_index.isValid() and parent_index.column() != 0:
            return QModelIndex()
        parent_item = self.get_item(parent_index)
        members = get_members(parent_item)
        if members:
            if row < len(members):
                new_index = self.createIndex(row, column, members[row])
                return new_index
        return QModelIndex()

    def parent(self, index):
        item = self.get_item(index)
        owner = get_owner(item)
        if owner == self.root:
            return QModelIndex()
        if owner is None:
            return QModelIndex()
        member_index = self.get_member_index(owner)
        if member_index is None:
            raise Exception('member index failed')
        index = self.createIndex(member_index, 0, owner)
        return index

    def get_index_from_item(self, item):
        index = QModelIndex()
        for x in self.get_index_list(item):
            index = self.index(x, 0, index)
        return index

    def get_index_list(self, item):
        owner = get_owner(item)
        if owner is None:
            return []
        elif isinstance(item, self.supported_types):
            index_list = self.get_index_list(owner)
            index_list.append(self.get_member_index(item))
            return index_list

        else:
            raise Exception('Invalid item type "%s"' % type(item))

    def get_member_index(self, item):
        if get_owner(item) == None:
            return 0
        elif isinstance(item, self.supported_types):
            owner = get_owner(item)
            if owner:
                members = get_members(owner)
                if item not in members:
                    return 0
                return members.index(item)
            else:
                return 0

        else:
            raise Exception('Invalid item type "%s"' % type(item))


def get_ancestors(item):
    ancestors = [item]
    owner = get_owner(item)
    while owner:
        ancestors.insert(0, owner)
        owner = get_owner(owner)
    return ancestors


def get_descendants(item):
    descendants = [item]
    members = get_members(item)
    descendants.extend(members)
    for member in members:
        descendants.extend(get_descendants(member))
    return descendants


def get_members(item):
    if isinstance(item, tob.ProjectRoot):
        return item.projects
    elif isinstance(item, tob.Project):
        return item.entities
    elif isinstance(item, tob.Entity):
        return []
    else:
        raise Exception('The model does not support object type "%s"' % type(item))


def get_owner(item):
    if isinstance(item, (tob.ProjectRoot)):
        return None
    elif isinstance(item, (tob.Project)):
        return item.project_root
    elif isinstance(item, (tob.Entity)):
        return item.project
    else:
        raise Exception('The model does not support object type "%s"' % type(item))



