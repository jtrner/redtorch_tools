import os
import sys
from qtpy.QtCore import *
from qtpy.QtGui import *
from qtpy.QtWidgets import *
from rigging_database.gui.database_widget import DatabaseWidget
import resources


def test():

    style_sheet_path = '%s/qss/slate.qss' % os.path.dirname(__file__.replace('\\', '/'))
    with open(style_sheet_path, mode='r') as f:
        style_sheet = f.read()
        app = QApplication(sys.argv)
        app.setStyleSheet(style_sheet)
        widget = DatabaseWidget()
        widget.resize(QSize(600, 800))
        widget.show()
        widget.raise_()
        sys.exit(app.exec_())


if __name__ == '__main__':
    test()