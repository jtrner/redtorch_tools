import sys
import inspect
import os
import json
import rig_factory
import rig_factory.objects as obs

framework_directory = os.path.dirname(os.path.dirname(rig_factory.__file__.replace('\\', '/')))
parts_directory = '%s/part_library' % framework_directory
part_versions_directory = '%s/versions' % parts_directory
part_versions_json_path = '%s/versions.json' % part_versions_directory

LOCALS = locals()

with open(part_versions_json_path, mode='r') as f:
    version_data = json.load(f)


def load_modules():

    for name, obj in inspect.getmembers(obs):
        if inspect.isclass(obj):
            if issubclass(obj, obs.BaseObject):
                LOCALS[name] = obj


def load_module_versions(**part_versions):
    load_modules()
    for module_name in part_versions:
        module_version = part_versions[module_name]
        if module_version is not None:
            if module_name not in version_data:
                raise StandardError('The module "%s" does not appear to be a part of the versions library' % module_name)
            module_version_data = version_data[module_name]
            if module_version not in module_version_data:
                raise StandardError('The module version "%s" does not appear to exist' % module_version)
            module_properties = module_version_data[module_version]
            local_path = module_properties['path']
            full_path = '%s%s' % (part_versions_directory, local_path)
            module_directory = os.path.dirname(full_path)
            sys.path.insert(0, module_directory)
            module = __import__(module_name)
            for name, obj in inspect.getmembers(module):
                if inspect.isclass(obj):
                    if issubclass(obj, obs.BasePart):
                        print name, obj
                        LOCALS[name] = obj
            sys.path.pop(0)

load_modules()
