import rigging_database.session as ses
import rigging_database.table_objects as tob
import shotgun
sg = shotgun.connect()
session = ses.initialize_session('G:/Rigging/.rigging/project_data.db')


def build_database_from_shotgun():
    for project_data in sg.find('Project', [], ['name', 'sg_code']):
        project_data.pop('id')
        project_data.pop('type')

        project = session.query(tob.Project).filter(tob.Project.name == project_data['name']).first()
        if not project:
            project = tob.Project(**project_data)
            session.add(project)

        for entity_data in sg.find(
                "Asset",
                [["project.Project.sg_code", "is", project_data['sg_code']]],
                ["code", "sg_asset_type"]
        ):
            entity_data.pop('id')
            entity_data.pop('type')
            entity = session.query(tob.Entity)\
                .filter(tob.Entity.code == entity_data['code'])\
                .join(tob.Entity.project)\
                .filter(tob.Project.id == project.id).first()
            if not entity:
                entity_data['project'] = project
                entity = tob.Entity(**entity_data)
                session.add(entity)

    session.commit()


if __name__ == '__main__':
    build_database_from_shotgun()
