__version__ = "0.0.0"
__developer__ = 'Paxton Gerrish'
__email__ = 'paxton@iconcreativestudio.com'

import os
import json
POSITIONS_FILEPATH = '%s/data/biped_positions.json' % os.path.dirname(__file__).replace('\\', '/')

with open(POSITIONS_FILEPATH, mode='r') as f:
    BIPED_POSITIONS = json.loads(f.read())
